import asyncio
import logging
import re
import uuid
from datetime import datetime, timedelta, time as dt_time, timezone
from functools import partial
from typing import Dict, Any, Optional, Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ConversationHandler,
    ContextTypes,
)
import MetaTrader5 as mt5

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    CONFERMA,
    INCASSO_MODIFICA_CHIEDI,
    INCASSO_MODIFICA_NUOVO,
    LOTTI,
    MEMO,
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    OPEN_BLOCK_END,
    OPEN_BLOCK_START,
    PROGRAMMA_ORARIO,
    SIMBOLO_BROKER,
    SL,
    SL_DAILY_SAFETY_FACTOR,
    SL_RISCHIO_CONFERMA,
    TP,
    TP_DAILY_SAFETY_FACTOR,
    TP_RISCHIO_CONFERMA,
)
from .messaging import _cancel_kb, _kb_errore_ordine, ack, back_button, safe_edit_message_text
from .storage import carica_dati_async, modifica_dati_async
from .state import modifier_add_scheduled_trade, modifier_save_trade_memo
from .mt5_sync import DatiSimboloNonValidi, MSG_AUTOTRADING_OFF, calcola_prezzi_sl_tp
from .mt5_async import (
    autotrading_attivo_async,
    calcola_margine_wrapper_async,
    chiudi_posizione_async,
    esegui_ordine_async,
    get_symbol_info_wrapper_async,
    info_account_async,
    info_account_prop_async,
    valida_simbolo_volume_async,
)
from .trade_core import (
    _incasso_corrente,
    _time_in_range,
    calcola_lotti_broker,
    distanza_prezzo,
    divisore_incasso,
    fattore_compensazione,
    genera_magic,
)
from .semiauto_core import dollari_da_distanza
from .hedge_journal import journal_put, journal_remove, journal_update
from .news import (
    _blocco_news_o_abbonamento,
    fascia_blocco_aperture,
    trading_bloccato_ora_o_news,
)
from .modalita import semiauto_attiva
from .handlers_base import guard_auth
from .handlers_menu import _blocco_nuovo_trade

# In semi-automatica la gamba prop la apre l'UTENTE: l'intestazione del flusso
# lo dice fin dal primo messaggio, cosi' non si confondono le due modalita'.
async def _intestazione_manuale() -> str:
    if await semiauto_attiva():
        return "👤 Trading Semi-Automatico"
    return "👤Trading Manuale"

# ========================= APERTURA TRADE MANUALE =========================
async def inizia_compra(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    context.user_data.pop("memo", None)
    query = update.callback_query
    await ack(query)
    # All'ingresso NON si applica la fascia di blocco aperture: il cliente deve
    # poter configurare e PROGRAMMARE un trade anche durante quelle ore (per
    # aprirlo piu' tardi). L'apertura immediata resta bloccata in conferma_esegui.
    bloccato, motivo = await _blocco_news_o_abbonamento()
    if bloccato:
        await safe_edit_message_text(
            query, f"⛔ {motivo}", InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    # "Compra" = BUY sulla PROP (comanda la prop; il broker hedgia opposto).
    context.user_data["direzione"] = "BUY"
    await safe_edit_message_text(
        query,
        f"{await _intestazione_manuale()}\n\nInserisci Stop Loss in $:\n\n"
        "Valori accettati: maggiori di 0",
        _cancel_kb(),
    )
    return SL

async def inizia_vendi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    context.user_data.pop("memo", None)
    query = update.callback_query
    await ack(query)
    # All'ingresso NON si applica la fascia di blocco aperture (vedi inizia_compra):
    # durante quelle ore il cliente deve poter configurare e PROGRAMMARE un trade.
    bloccato, motivo = await _blocco_news_o_abbonamento()
    if bloccato:
        await safe_edit_message_text(
            query, f"⛔ {motivo}", InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    # "Vendi" = SELL sulla PROP (comanda la prop; il broker hedgia opposto).
    context.user_data["direzione"] = "SELL"
    await safe_edit_message_text(
        query,
        f"{await _intestazione_manuale()}\n\nInserisci Stop Loss in $:\n\n"
        "Valori accettati: maggiori di 0",
        _cancel_kb(),
    )
    return SL

async def ricevi_sl(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
        if val <= 0:
            raise ValueError
        context.user_data["sl"] = val
    except ValueError:
        await update.message.reply_text(
            "Valore non valido. Inserisci un numero positivo per lo Stop Loss in dollari.",
            reply_markup=_cancel_kb(),
        )
        return SL

    # ── Controllo automatico: SL inserito vs perdita giornaliera rimasta ─────
    # Se lo SL (perdita prop a stop loss) raggiunge la perdita giornaliera
    # rimasta della prop — con un margine di sicurezza del 10% — chiediamo
    # conferma esplicita prima di proseguire (apertura immediata o programmata).
    # Se i dati prop non sono disponibili (config assente o MT5 irraggiungibile)
    # NON blocchiamo il flusso: il controllo e' un aiuto, non un vincolo.
    try:
        dati = await carica_dati_async()
        # "cfg_prop" e NON "cfg": la locale oscurerebbe l'alias del modulo config.
        cfg_prop = dati.get("prop_avanzata", {})
        rimasta = None
        if cfg_prop:
            info_p = await info_account_prop_async(MT5_PROP_EXE, cfg_prop)
            if info_p and info_p.get("perdita_giornaliera_rimasta") is not None:
                rimasta = float(info_p["perdita_giornaliera_rimasta"])
        if rimasta is not None and val >= rimasta * SL_DAILY_SAFETY_FACTOR:
            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton("✅ Si", callback_data="slrisk_si"),
                InlineKeyboardButton("❌ No", callback_data="slrisk_no"),
            ]])
            await update.message.reply_text(
                "⚠️ La perdita della prop a stop loss sta per superare o ha "
                "superato la perdita giornaliera rimasta.\n\n"
                f"Perdita a stop loss inserita: {val:.2f}$\n"
                f"Perdita giornaliera rimasta: {rimasta:.2f}$\n\n"
                "NOTA: viene tenuto in conto un 10% di margine di sicurezza\n\n"
                "Sei sicuro di voler continuare?\n\n"
                "‼️ Continuando, rischi di violare le regole della prop.",
                reply_markup=keyboard,
            )
            return SL_RISCHIO_CONFERMA
    except Exception:
        logger.exception("Controllo SL/perdita giornaliera fallito: proseguo senza avviso.")

    await update.message.reply_text("Inserisci Take Profit in $:", reply_markup=_cancel_kb())
    return TP

async def sl_rischio_conferma(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Risposta all'avviso 'SL oltre la perdita giornaliera rimasta'."""
    query = update.callback_query
    await ack(query)
    if query.data == "slrisk_si":
        # L'utente conferma: si prosegue normalmente con il Take Profit.
        await safe_edit_message_text(query, "Inserisci Take Profit in $:", _cancel_kb())
        return TP
    # "No": si torna all'inserimento dello Stop Loss.
    context.user_data.pop("sl", None)
    await safe_edit_message_text(
        query,
        f"{await _intestazione_manuale()}\n\nInserisci Stop Loss in $:\n\n"
        "Valori accettati: maggiori di 0",
        _cancel_kb(),
    )
    return SL

_CHIEDI_LOTTI = "Inserisci i lotti che vuoi aprire (es. 1.2):"

async def ricevi_tp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
        if val <= 0:
            raise ValueError
        context.user_data["tp"] = val
    except ValueError:
        await update.message.reply_text(
            "Valore non valido. Inserisci un numero positivo per il Take Profit in dollari.",
            reply_markup=_cancel_kb(),
        )
        return TP

    # ── Controllo automatico: TP inserito vs profitto giornaliero rimasto ────
    # Speculare al controllo sullo Stop Loss. Il limite nasce dalla REGOLA DI
    # CONSISTENZA della prop (profitto giornaliero massimo): superarlo puo'
    # invalidare la sfida tanto quanto sfondare la perdita giornaliera.
    # Se la consistenza non e' configurata (o il target e' 0) non c'e' limite e
    # non si chiede nulla. Come per lo SL: si avvisa, non si blocca mai.
    try:
        dati = await carica_dati_async()
        # "cfg_prop" e NON "cfg": la locale oscurerebbe l'alias del modulo config.
        cfg_prop = dati.get("prop_avanzata", {})
        rimasto = None
        if cfg_prop:
            info_p = await info_account_prop_async(MT5_PROP_EXE, cfg_prop)
            if info_p and info_p.get("profitto_giornaliero_rimasto") is not None:
                rimasto = float(info_p["profitto_giornaliero_rimasto"])
        if rimasto is not None and val >= rimasto * TP_DAILY_SAFETY_FACTOR:
            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton("✅ Si", callback_data="tprisk_si"),
                InlineKeyboardButton("❌ No", callback_data="tprisk_no"),
            ]])
            await update.message.reply_text(
                "⚠️ Il guadagno della prop a take profit sta per superare o ha "
                "superato il profitto giornaliero massimo (regola di consistenza).\n\n"
                f"Guadagno a take profit inserito: {val:.2f}$\n"
                f"Profitto giornaliero rimasto: {rimasto:.2f}$\n\n"
                "NOTA: viene tenuto in conto un 3% di margine di sicurezza\n\n"
                "Sei sicuro di voler continuare?\n\n"
                "‼️ Continuando, rischi di violare le regole della prop.",
                reply_markup=keyboard,
            )
            return TP_RISCHIO_CONFERMA
    except Exception:
        logger.exception("Controllo TP/profitto giornaliero fallito: proseguo senza avviso.")

    await update.message.reply_text(_CHIEDI_LOTTI, reply_markup=_cancel_kb())
    return LOTTI

async def tp_rischio_conferma(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Risposta all'avviso 'TP oltre il profitto giornaliero massimo'."""
    query = update.callback_query
    await ack(query)
    if query.data == "tprisk_si":
        # L'utente conferma: si prosegue normalmente con i lotti.
        await safe_edit_message_text(query, _CHIEDI_LOTTI, _cancel_kb())
        return LOTTI
    # "No": si torna all'inserimento del Take Profit.
    context.user_data.pop("tp", None)
    await safe_edit_message_text(query, "Inserisci Take Profit in $:", _cancel_kb())
    return TP

async def ricevi_lotti(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
        if val <= 0:
            raise ValueError
        context.user_data["lotti_prop"] = val
    except ValueError:
        await update.message.reply_text(
            "Valore non valido. Inserisci un numero positivo per i lotti.",
            reply_markup=_cancel_kb(),
        )
        return LOTTI

    dati = await carica_dati_async()
    incasso_corrente = _incasso_corrente(dati)
    context.user_data["incasso_target"] = incasso_corrente

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Sì", callback_data="incmod_si"),
         InlineKeyboardButton("❌ No", callback_data="incmod_no")],
        [InlineKeyboardButton("🚫 Annulla", callback_data="annulla")],
    ])
    await update.message.reply_text(
        "💰 Modifica incasso\n\n"
        "Vuoi modificare l'incasso?\n"
        f"Incasso corrente: {incasso_corrente:.2f}$",
        reply_markup=keyboard,
    )
    return INCASSO_MODIFICA_CHIEDI

async def _vai_a_memo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Incasso finalizzato: chiede il MEMO.

    I lotti broker NON si calcolano piu' qui: servono i prezzi di ingresso di
    ENTRAMBI i conti per misurare lo scarto di quotazione, e quelli si leggono
    in ricevi_memo (dove servono comunque per i margini). Calcolarli due volte,
    o leggere MT5 due volte, sarebbe solo un modo per farli divergere.
    """
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=("📝 Inserisci un MEMO per questo trade:\n"
              "(es. 'FundedNext Sfida casella 2B /SL -2000 TP +3000', primo giro)"),
        reply_markup=_cancel_kb(),
    )
    return MEMO

async def incasso_modifica_chiedi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Sì/No alla domanda 'vuoi modificare l'incasso?' (prima del MEMO)."""
    query = update.callback_query
    await ack(query)
    if query.data == "incmod_si":
        await safe_edit_message_text(query, "💰 Inserisci il nuovo incasso ($):", _cancel_kb())
        return INCASSO_MODIFICA_NUOVO
    # incmod_no -> mantieni l'incasso corrente
    return await _vai_a_memo(update, context)

async def ricevi_nuovo_incasso(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
        if val <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "Valore non valido. Inserisci un numero maggiore di 0 per l'incasso.",
            reply_markup=_cancel_kb(),
        )
        return INCASSO_MODIFICA_NUOVO

    def _upd(d):
        if "prop_avanzata" not in d:
            d["prop_avanzata"] = {}
        # Chiavi gemelle SEMPRE allineate (stesso concetto, due chiavi storiche).
        d["prop_avanzata"]["incasso_target"]      = val
        d["prop_avanzata"]["incasso_se_bruciata"] = val
        return d

    await modifica_dati_async(_upd)
    context.user_data["incasso_target"] = val
    await update.message.reply_text(f"✅ Incasso aggiornato a {val:.2f}$.")
    return await _vai_a_memo(update, context)

async def ricevi_memo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    memo = update.message.text.strip()
    if not memo:
        await update.message.reply_text("Il memo non può essere vuoto.", reply_markup=_cancel_kb())
        return MEMO
    if len(memo) > 200:
        await update.message.reply_text("Il memo è troppo lungo (max 200 caratteri).", reply_markup=_cancel_kb())
        return MEMO
    context.user_data["memo"] = memo

    # COMANDA LA PROP: la direzione scelta dall'utente e' quella della PROP;
    # il Broker hedgia sempre nella direzione opposta.
    direzione_prop   = context.user_data["direzione"]
    direzione_broker = "SELL" if direzione_prop == "BUY" else "BUY"
    sl_dol           = context.user_data["sl"]
    tp_dol           = context.user_data["tp"]
    lotti_prop       = context.user_data["lotti_prop"]
    incasso_target   = float(context.user_data.get("incasso_target", 0) or 0)

    # I prezzi sono uso INTERNO (per validare l'ordine e per misurare lo scarto
    # di quotazione): non vengono mostrati nel riepilogo, all'utente bastano i $.
    info_sym_prop = await get_symbol_info_wrapper_async(MT5_PROP_EXE, cfg.SIMBOLO_PROP, direzione_prop)
    if not info_sym_prop:
        await update.message.reply_text("Impossibile connettersi alla Prop per calcolare i prezzi.")
        return ConversationHandler.END

    info_sym_broker = await get_symbol_info_wrapper_async(MT5_BROKER_EXE, SIMBOLO_BROKER, direzione_broker)

    # ── LOTTI BROKER ────────────────────────────────────────────────────────
    # Il divisore e' la PERDITA MASSIMA TOTALE in $ della prop configurata, non
    # piu' il 6000 fisso (che valeva solo per un 100k al 6%): vedi
    # trade_core.divisore_incasso.
    #
    # Alla formula si aggiunge la COMPENSAZIONE dello scarto di quotazione tra i
    # due conti, misurato adesso sui prezzi di ingresso reali. In
    # semi-automatica NON si applica: li' la correzione si fa spostando i
    # LIVELLI della gamba broker (semiauto_core.livelli_broker_da_prop), e
    # farla anche sui lotti la conterebbe due volte.
    dati     = await carica_dati_async()
    divisore = divisore_incasso(dati)
    semiauto = await semiauto_attiva()
    compensazione = None
    scarto = None
    if not semiauto and info_sym_broker:
        scarto = float(info_sym_broker["prezzo_entrata"]) - float(info_sym_prop["prezzo_entrata"])
        compensazione = fattore_compensazione(
            distanza_prezzo(sl_dol, lotti_prop, info_sym_prop["point"], info_sym_prop["tick_value"]),
            scarto, direzione_prop,
        )
    lotti_broker = calcola_lotti_broker(lotti_prop, incasso_target, divisore, compensazione)
    context.user_data["lotti_broker"] = lotti_broker
    # La riga di log porta TUTTI i numeri che entrano nel conto: e' l'unico
    # posto in cui, a distanza di giorni, si puo' ricostruire perche' un trade
    # ha aperto proprio quei lotti.
    logger.info(
        f"Lotti broker: {lotti_prop} prop x ({incasso_target} incasso / {divisore:g} DD max)"
        + (f" x {compensazione:.4f} compensazione (scarto {scarto:+.4f}$)"
           if compensazione is not None else
           f" senza compensazione (scarto {'non misurabile' if scarto is None else f'{scarto:+.4f}$ fuori banda'})")
        + f" = {lotti_broker}"
    )

    margin_broker = None
    if info_sym_broker:
        tipo_ord_b = mt5.ORDER_TYPE_BUY if direzione_broker == "BUY" else mt5.ORDER_TYPE_SELL
        margin_broker = await calcola_margine_wrapper_async(
            MT5_BROKER_EXE, tipo_ord_b, SIMBOLO_BROKER, lotti_broker, info_sym_broker["prezzo_entrata"],
        )
    tipo_ord_p = mt5.ORDER_TYPE_BUY if direzione_prop == "BUY" else mt5.ORDER_TYPE_SELL
    margin_prop = await calcola_margine_wrapper_async(
        MT5_PROP_EXE, tipo_ord_p, cfg.SIMBOLO_PROP, lotti_prop, info_sym_prop["prezzo_entrata"],
    )

    # ── SL/TP del BROKER in $ (hedge invertito) ───────────────────────────────
    # Stesso movimento di prezzo, ma lotti scalati: broker_$ = prop_$ * (Lb/Lp).
    # Direzioni invertite => quando il prop e' a SL il broker e' a TP e viceversa.
    ratio = (lotti_broker / lotti_prop) if lotti_prop > 0 else 0.0
    sl_broker_dol = tp_dol * ratio   # broker perde quando il prop e' al TP
    tp_broker_dol = sl_dol * ratio   # broker guadagna quando il prop e' a SL
    if compensazione is not None and info_sym_broker:
        # Con la compensazione attiva i lotti sono stati ingranditi APPOSTA, e
        # il conto scalato qui sopra direbbe una bugia: il broker non percorre
        # la stessa distanza della prop, perche' entra a un prezzo diverso. Qui
        # si mostrano i valori VERI. Il guadagno viene quasi identico a quello
        # della formula pura — ed e' esattamente il punto della correzione: piu'
        # lotti su una corsa piu' corta, per incassare la stessa cifra.
        segno     = 1.0 if direzione_prop == "BUY" else -1.0
        dist_sl_p = distanza_prezzo(sl_dol, lotti_prop, info_sym_prop["point"], info_sym_prop["tick_value"])
        dist_tp_p = distanza_prezzo(tp_dol, lotti_prop, info_sym_prop["point"], info_sym_prop["tick_value"])
        p_b, tv_b = info_sym_broker["point"], info_sym_broker["tick_value"]
        tp_broker_dol = dollari_da_distanza(dist_sl_p + segno * scarto, lotti_broker, p_b, tv_b)
        sl_broker_dol = dollari_da_distanza(dist_tp_p - segno * scarto, lotti_broker, p_b, tv_b)

    # ── % di margine occupato post-trade (vincolo prudenziale 70%) ────────────
    info_acc_prop   = await info_account_async(MT5_PROP_EXE)
    info_acc_broker = await info_account_async(MT5_BROKER_EXE)

    def _fmt_margine(margine: Optional[float], info_acc: Optional[Dict[str, Any]]) -> str:
        if margine is None:
            return ""
        if not info_acc:
            return f"💰 Margine: ${margine:.2f}\n"
        # Base = Saldo INCLUSO BONUS (balance + credit). Il credito bonus fa da
        # margine; usare questa base lo conta SEMPRE, a prescindere dalla
        # convenzione del broker sull'equity, ed e' stabile (non oscilla col
        # P/L flottante). Per la prop credit=0 -> base = balance.
        base = float(info_acc.get("balance", 0.0) or 0.0) + float(info_acc.get("credit", 0.0) or 0.0)
        if base <= 0:
            return f"💰 Margine: ${margine:.2f}\n"
        used_now  = float(info_acc.get("margin", 0.0) or 0.0)
        post_used = used_now + float(margine)
        pct       = post_used / base * 100.0
        warn      = " ⚠️ supera 70%" if pct >= 70.0 else ""
        return f"💰 Margine: ${margine:.2f} ({pct:.1f}%){warn}\n"

    riepilogo  = "📊 RIEPILOGO ORDINE HEDGE\n\n"
    riepilogo += f"💸 Incasso se la prop viene bruciata:\n{incasso_target:.2f}$\n"
    # La compensazione va DICHIARATA: chi rifà il conto a mano deve ritrovare i
    # lotti che vede scritti, non scoprire uno scarto che sembra un errore.
    if compensazione is not None and abs(compensazione - 1.0) > 1e-9:
        riepilogo += (
            f"(lotti broker {(compensazione - 1) * 100:+.1f}% per lo scarto di "
            f"quotazione: {scarto:+.2f}$)\n"
        )
    riepilogo += "\n"
    riepilogo += f"🏢 PROP ({direzione_prop} {cfg.SIMBOLO_PROP})\n"
    riepilogo += f"📦 Lotti: {lotti_prop}\n"
    riepilogo += f"🛑 SL: ${sl_dol:.2f}\n"
    riepilogo += f"🎯 TP: ${tp_dol:.2f}\n"
    riepilogo += _fmt_margine(margin_prop, info_acc_prop)
    riepilogo += f"\n🏦 BROKER ({direzione_broker} {SIMBOLO_BROKER})\n"
    riepilogo += f"📦 Lotti: {lotti_broker}\n"
    riepilogo += f"🛑 SL: ${sl_broker_dol:.2f}\n"
    riepilogo += f"🎯 TP: ${tp_broker_dol:.2f}\n"
    riepilogo += _fmt_margine(margin_broker, info_acc_broker)
    riepilogo += f"\n📝 Memo: {memo}\n\n"
    ###riepilogo += "ℹ️ I prezzi SL/TP sono calcolati live al momento dell'esecuzione.\n"
    riepilogo += "⚠️ RICORDA: Soglia margine consigliata: < 70%.\n"
    riepilogo += (
        "\nℹ️ La posizione Prop la aprirai TU dal tuo MetaTrader: qui sotto "
        "trovi i parametri da usare.\n\nProcedo?"
        if semiauto else "\nConfermi l'esecuzione?"
    )

    # Memorizziamo il testo del riepilogo per poterlo ri-mostrare se l'utente
    # dalla schermata di programmazione preme "Indietro".
    context.user_data["riepilogo_text"] = riepilogo
    await update.message.reply_text(riepilogo, reply_markup=_riepilogo_keyboard(semiauto))
    return CONFERMA

def _controlla_livelli_broker(
    direzione_broker: str,
    info_sym_broker: Dict[str, Any],
    sl_price: float,
    tp_price: float,
) -> Optional[str]:
    """Verifica che SL/TP della gamba BROKER stiano dal lato giusto del prezzo
    del broker, oltre la distanza minima che il broker stesso impone
    (trade_stops_level). Ritorna None se va tutto bene, altrimenti una riga
    che spiega ESATTAMENTE cosa non torna, con i numeri.

    I livelli arrivano specchiati da quelli calcolati sul feed della PROP: e'
    corretto come geometria dell'hedge, ma va confermato sul prezzo reale del
    broker prima di spedire l'ordine.
    """
    prezzo = float(info_sym_broker.get("prezzo_entrata", 0) or 0)
    point  = float(info_sym_broker.get("point", 0) or 0)
    if prezzo <= 0 or point <= 0:
        return None                     # dato non certo: non si blocca mai
    # Margine minimo: quello dichiarato dal broker, con un pavimento di 10
    # point per assorbire lo scarto di quotazione tra i due feed.
    distanza_min = max(int(info_sym_broker.get("stops_level", 0) or 0), 10) * point

    if direzione_broker == "BUY":
        # BUY: lo SL sta SOTTO il prezzo, il TP SOPRA.
        if sl_price >= prezzo - distanza_min:
            return (f"Lo SL Broker ({sl_price:.2f}) è troppo vicino o sopra il prezzo "
                    f"Broker ({prezzo:.2f}); serve almeno {distanza_min:.2f}$ di distanza.")
        if tp_price <= prezzo + distanza_min:
            return (f"Il TP Broker ({tp_price:.2f}) è troppo vicino o sotto il prezzo "
                    f"Broker ({prezzo:.2f}); serve almeno {distanza_min:.2f}$ di distanza.")
    else:
        # SELL: lo SL sta SOPRA il prezzo, il TP SOTTO.
        if sl_price <= prezzo + distanza_min:
            return (f"Lo SL Broker ({sl_price:.2f}) è troppo vicino o sotto il prezzo "
                    f"Broker ({prezzo:.2f}); serve almeno {distanza_min:.2f}$ di distanza.")
        if tp_price >= prezzo - distanza_min:
            return (f"Il TP Broker ({tp_price:.2f}) è troppo vicino o sopra il prezzo "
                    f"Broker ({prezzo:.2f}); serve almeno {distanza_min:.2f}$ di distanza.")
    return None

async def _esegui_hedge(
    direzione_prop: str,
    sl_dol: float,
    tp_dol: float,
    lotti_prop: float,
    lotti_broker: float,
    memo: str = "",
) -> Tuple[bool, str, Optional[int], Optional[int]]:
    """
    Esegue l'hedge Broker+Prop: validazione volumi, ricalcolo prezzi SL/TP LIVE,
    invio ordini con rollback, salvataggio del trade_memo.

    COMANDA LA PROP: 'direzione_prop' e' la direzione scelta dall'utente
    (Compra=BUY, Vendi=SELL) e viene aperta sulla PROP; il Broker hedgia
    SEMPRE nella direzione opposta.

    NON fa alcuna interazione UI: e' il core condiviso tra l'apertura immediata
    (conferma_esegui) e quella programmata (scheduled_open_loop). Il chiamante
    deve aver gia' verificato credenziali presenti e blocchi news/orario.

    Ritorna (ok, messaggio, ticket_broker, ticket_prop).
    """
    dati = await carica_dati_async()
    broker = dati.get("broker")
    prop   = dati.get("prop")
    if not broker or not prop:
        return False, "❌ Credenziali mancanti.", None, None
    direzione_broker = "SELL" if direzione_prop == "BUY" else "BUY"

    # Validazioni sui due terminali in parallelo (un worker ciascuno).
    (valid_b, err_b), (valid_p, err_p) = await asyncio.gather(
        valida_simbolo_volume_async(MT5_BROKER_EXE, SIMBOLO_BROKER, lotti_broker),
        valida_simbolo_volume_async(MT5_PROP_EXE, cfg.SIMBOLO_PROP, lotti_prop),
    )
    if not valid_b:
        return False, f"❌ Errore volume Broker ({lotti_broker}): {err_b}", None, None
    if not valid_p:
        return False, f"❌ Errore volume Prop ({lotti_prop}): {err_p}", None, None

    # ── PRE-FLIGHT: meglio un hedge NON PARTITO che un rollback pagato ──────
    # Storicamente il caso peggiore era: gamba Broker aperta, ordine Prop
    # rifiutato (AutoTrading spento / margine insufficiente), rollback che
    # brucia spread. Questi controlli intercettano le cause piu' frequenti
    # PRIMA di toccare il mercato: se qualcosa non va, costo ZERO.
    # (None = "non determinabile" -> non si blocca: mai falsi allarmi, v51.)
    at_b, at_p = await asyncio.gather(
        autotrading_attivo_async(
            MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"]),
        autotrading_attivo_async(
            MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"]),
    )
    if at_b is False or at_p is False:
        lato_off = "Broker" if at_b is False else "Prop"
        return False, (
            f"❌ Ordine {lato_off} non aperto.\nMotivo: {MSG_AUTOTRADING_OFF}.\n\n"
            f"🛡 Controllo preventivo: NESSUN ordine inviato. L'hedge non è "
            f"partito — nessuna posizione aperta, nessun costo."
        ), None, None

    # ── Ricalcolo prezzi SL/TP LIVE per evitare valori stantii ─────────────
    info_sym_prop, info_sym_broker = await asyncio.gather(
        get_symbol_info_wrapper_async(MT5_PROP_EXE, cfg.SIMBOLO_PROP, direzione_prop),
        get_symbol_info_wrapper_async(MT5_BROKER_EXE, SIMBOLO_BROKER, direzione_broker),
    )
    if not info_sym_prop:
        return False, "❌ Impossibile leggere il prezzo Prop. Riprova.", None, None
    try:
        sl_price_prop, tp_price_prop = calcola_prezzi_sl_tp(
            direzione_prop, info_sym_prop["prezzo_entrata"],
            sl_dol, tp_dol, lotti_prop,
            info_sym_prop["point"], info_sym_prop["tick_value"],
        )
    except DatiSimboloNonValidi as e:
        logger.error(f"Hedge non avviato: {e}")
        return False, (
            "❌ Il terminale Prop non espone dati validi per il simbolo "
            f"{cfg.SIMBOLO_PROP} (mercato chiuso o simbolo non pronto).\n\n"
            "🛡 Nessun ordine inviato. Riprova tra poco."
        ), None, None
    sl_price_broker = tp_price_prop
    tp_price_broker = sl_price_prop

    # ── PRE-FLIGHT 1-bis: i livelli del BROKER sono validi sul SUO prezzo? ───
    # I livelli della gamba Broker sono lo SPECCHIO di quelli della Prop, ma i
    # due feed NON coincidono (e' la ragione stessa per cui esiste il guardiano
    # di coppia). Se il broker quota anche solo qualche decina di centesimi piu'
    # in la', lo SL specchiato puo' finire dalla parte SBAGLIATA del prezzo: il
    # broker rifiuta con 10016 e l'hedge finisce in rollback PAGATO. Qui il caso
    # si intercetta prima di toccare il mercato: costo zero.
    # Dato non leggibile -> non si blocca (filosofia v51: mai falsi allarmi).
    if info_sym_broker:
        errore_livelli = _controlla_livelli_broker(
            direzione_broker, info_sym_broker, sl_price_broker, tp_price_broker,
        )
        if errore_livelli:
            logger.warning(f"Hedge non avviato: livelli Broker non validi — {errore_livelli}")
            return False, (
                f"❌ SL/TP non compatibili col prezzo del Broker.\n{errore_livelli}\n\n"
                "🛡 Controllo preventivo: NESSUN ordine inviato. L'hedge non è "
                "partito — nessuna posizione aperta, nessun costo.\n\n"
                "👉 Allarga Stop Loss e/o Take Profit e riprova."
            ), None, None

    # Pre-flight 2: margine sufficiente su ENTRAMBI i lati (+5% di sicurezza).
    # Il "fondi insufficienti" scoperto DOPO la prima gamba era l'altra causa
    # tipica di rollback. Margine/conto non leggibili -> non si blocca.
    tipo_ord_p = mt5.ORDER_TYPE_BUY if direzione_prop == "BUY" else mt5.ORDER_TYPE_SELL
    tipo_ord_b = mt5.ORDER_TYPE_BUY if direzione_broker == "BUY" else mt5.ORDER_TYPE_SELL
    controlli_margine = [
        ("Prop", MT5_PROP_EXE, tipo_ord_p, cfg.SIMBOLO_PROP,
         lotti_prop, info_sym_prop["prezzo_entrata"]),
    ]
    if info_sym_broker:
        controlli_margine.append(
            ("Broker", MT5_BROKER_EXE, tipo_ord_b, SIMBOLO_BROKER,
             lotti_broker, info_sym_broker["prezzo_entrata"]))
    for lato_m, path_m, tipo_m, sim_m, lotti_m, prezzo_m in controlli_margine:
        margine_m, acc_m = await asyncio.gather(
            calcola_margine_wrapper_async(path_m, tipo_m, sim_m, lotti_m, prezzo_m),
            info_account_async(path_m),
        )
        if margine_m is None or not acc_m:
            continue
        disponibile = float(acc_m.get("free_margin", 0) or 0)
        if float(margine_m) * 1.05 > disponibile:
            return False, (
                f"❌ Margine insufficiente sul lato {lato_m}: servono "
                f"~{float(margine_m):.2f}$ (+5% di sicurezza), disponibili "
                f"{disponibile:.2f}$.\n\n"
                f"🛡 Controllo preventivo: NESSUN ordine inviato. L'hedge non è "
                f"partito — nessuna posizione aperta, nessun costo."
            ), None, None

    magic_operazione = await genera_magic()
    uid = uuid.uuid4().hex[:8]

    # ── Giornale transazionale: l'intento va su disco PRIMA di toccare il
    # mercato. Se il processo muore in qualsiasi punto da qui in poi, il
    # recovery (boot + retry periodico) sa esattamente a che passo eravamo
    # e rimedia: gamba orfana richiusa, hedge completo registrato.
    await journal_put(
        uid, kind="hedge_open", status="ordering", magic=magic_operazione,
        direzione_broker=direzione_broker, direzione_prop=direzione_prop,
        lotti_broker=lotti_broker, lotti_prop=lotti_prop,
        sl_dol=sl_dol, tp_dol=tp_dol, memo=(memo or "").strip(),
    )

    # ── GAMBE IN PARALLELO ──────────────────────────────────────────────────
    # Un worker MT5 dedicato per terminale: i due ordini partono INSIEME
    # (millisecondi tra le gambe invece di secondi = hedge piu' simmetrico).
    # esegui_ordine_async conserva il retry SICURO anti-duplicato per gamba.
    logger.info(
        f"Hedge {uid}: invio SIMULTANEO ordini Broker ({direzione_broker}, "
        f"{lotti_broker} lotti) e Prop ({direzione_prop}, {lotti_prop} lotti)"
    )
    (ticket_b, motivo_b), (ticket_p, motivo_p) = await asyncio.gather(
        esegui_ordine_async(
            MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
            direzione_broker, SIMBOLO_BROKER, lotti_broker,
            sl_price_broker, tp_price_broker, "", magic_operazione,
        ),
        esegui_ordine_async(
            MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
            direzione_prop, cfg.SIMBOLO_PROP, lotti_prop,
            sl_price_prop, tp_price_prop, "", magic_operazione,
        ),
    )
    logger.info(f"Hedge {uid}: esiti — Broker ticket={ticket_b}, Prop ticket={ticket_p}")
    await journal_update(
        uid,
        ticket_broker=int(ticket_b) if ticket_b else None,
        ticket_prop=int(ticket_p) if ticket_p else None,
        status="ordered",
    )

    if not ticket_b and not ticket_p:
        # Nessuna gamba aperta: nessuna esposizione, nessun rollback.
        await journal_remove(uid)
        logger.error(f"Hedge {uid}: entrambi gli ordini falliti (B: {motivo_b} / P: {motivo_p})")
        # La frase "Ordine X non aperto" e' il marcatore con cui la UI sceglie
        # il pulsante "Riavvia terminale" giusto: la includiamo SOLO per il
        # lato con l'AutoTrading spento (broker prioritario se entrambi).
        marker_b = bool(motivo_b and MSG_AUTOTRADING_OFF in motivo_b)
        marker_p = bool(motivo_p and MSG_AUTOTRADING_OFF in motivo_p)
        headline = "Ordine Broker non aperto. " if marker_b else (
            "Ordine Prop non aperto. " if marker_p else "")
        extra = (
            "\n\n👉 Premi qui sotto per riavviare il terminale "
            "(riaccende l'Algo Trading), poi riapri il trade."
            if (marker_b or marker_p) else ""
        )
        return False, (
            f"❌ {headline}Nessuna delle due gambe è stata aperta.\n"
            f"• Broker: {motivo_b or 'non disponibile'}\n"
            f"• Prop: {motivo_p or 'non disponibile'}\n\n"
            f"Nessuna posizione lasciata aperta.{extra}"
        ), None, None

    if (not ticket_b) != (not ticket_p):
        # ── ULTIMA CHANCE prima del rollback ────────────────────────────────
        # Una gamba e' aperta, l'altra no. Il rollback e' un COSTO CERTO
        # (spread pagato per niente): prima si ritenta UNA volta la gamba
        # fallita, dopo una breve pausa. Prezzi SL/TP ORIGINALI (la simmetria
        # dell'hedge non si tocca), entry comunque live, stesso magic (il
        # controllo anti-duplicato protegge). La gamba gia' aperta ha i suoi
        # SL/TP: l'esposizione durante il tentativo e' limitata.
        lato_retry = "Prop" if ticket_b else "Broker"
        logger.warning(f"Hedge {uid}: gamba {lato_retry} fallita, ULTIMA CHANCE prima del rollback.")
        await asyncio.sleep(1.5)
        if not ticket_p:
            ticket_p, motivo_p = await esegui_ordine_async(
                MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
                direzione_prop, cfg.SIMBOLO_PROP, lotti_prop,
                sl_price_prop, tp_price_prop, "", magic_operazione, max_retry=0,
            )
            if ticket_p:
                await journal_update(uid, ticket_prop=int(ticket_p))
                logger.info(f"Hedge {uid}: gamba Prop RECUPERATA all'ultima chance (ticket={ticket_p}).")
        else:
            ticket_b, motivo_b = await esegui_ordine_async(
                MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
                direzione_broker, SIMBOLO_BROKER, lotti_broker,
                sl_price_broker, tp_price_broker, "", magic_operazione, max_retry=0,
            )
            if ticket_b:
                await journal_update(uid, ticket_broker=int(ticket_b))
                logger.info(f"Hedge {uid}: gamba Broker RECUPERATA all'ultima chance (ticket={ticket_b}).")

    if not ticket_b or not ticket_p:
        # UNA gamba aperta e l'altra no = hedge scoperto. Questo trade NON e'
        # ancora in trade_memos, quindi il monitor non lo vedrebbe: il rollback
        # immediato e' la rete di sicurezza (ora simmetrica: puo' fallire il
        # Broker con la Prop aperta, caso impossibile con l'invio sequenziale).
        # Se anche il rollback fallisce, l'intento resta nel giornale e il
        # recovery riprova OGNI MINUTO.
        if ticket_b:
            lato_aperto, ticket_aperto = "Broker", ticket_b
            path_r, cred_r = MT5_BROKER_EXE, broker
            lato_fallito, motivo_fallito = "Prop", motivo_p
        else:
            lato_aperto, ticket_aperto = "Prop", ticket_p
            path_r, cred_r = MT5_PROP_EXE, prop
            lato_fallito, motivo_fallito = "Broker", motivo_b
        logger.error(
            f"Hedge {uid}: ordine {lato_fallito} fallito ({motivo_fallito}), "
            f"rollback {lato_aperto} ticket={ticket_aperto}"
        )
        await journal_update(uid, status="rollback")
        chiuso = False
        for tentativo in range(3):
            chiuso = await chiudi_posizione_async(
                path_r, int(cred_r["id"]), cred_r["password"], cred_r["server"], ticket_aperto,
            )
            if chiuso:
                break
            logger.error(f"Hedge {uid}: rollback {lato_aperto} tentativo {tentativo + 1} fallito, riprovo.")
            await asyncio.sleep(1.0)
        if chiuso:
            logger.info(f"Hedge {uid}: rollback {lato_aperto} OK (ticket={ticket_aperto} richiuso).")
            await journal_remove(uid)   # rollback riuscito: nessuna esposizione residua
            coda = (
                f"↩️ Gamba {lato_aperto} richiusa automaticamente "
                f"(nessuna posizione lasciata aperta)."
            )
        else:
            # L'intento RESTA nel giornale con status "orphan": il recovery
            # periodico continuera' a riprovare la chiusura ogni minuto.
            await journal_update(uid, status="orphan")
            logger.critical(
                f"Hedge {uid}: ROLLBACK {lato_aperto.upper()} FALLITO. Gamba {lato_aperto} "
                f"ticket={ticket_aperto} RIMASTA APERTA e scoperta. Il recovery riprova ogni minuto."
            )
            coda = (
                f"‼️ ATTENZIONE: la gamba {lato_aperto} (ticket {ticket_aperto}) è rimasta APERTA e "
                f"NON sono riuscito a richiuderla automaticamente.\n"
                f"Il recovery automatico riproverà OGNI MINUTO; se vuoi chiuderla "
                f"subito, falla a mano dal terminale {lato_aperto}."
            )
        extra_f = (
            f"\n\n👉 Premi qui sotto per riavviare il terminale {lato_fallito} "
            "(riaccende l'Algo Trading), poi riapri il trade."
            if chiuso and motivo_fallito and MSG_AUTOTRADING_OFF in motivo_fallito else ""
        )
        return False, (
            f"❌ Ordine {lato_fallito} non aperto.\nMotivo: {motivo_fallito or 'non disponibile'}.\n\n{coda}{extra_f}"
        ), None, None

    await journal_update(uid, status="both_opened")

    # Il trade va SEMPRE registrato in trade_memos, anche senza memo testuale:
    # il monitor di chiusura (trade_close_monitor_loop) itera trade_memos.values(),
    # quindi un trade non registrato non riceverebbe MAI la notifica di chiusura
    # per TP/SL. Il campo "memo" resta opzionale (stringa vuota se l'utente
    # non l'ha inserito) e i call site lo gestiscono via `memo or "—"`.
    memo = (memo or "").strip()
    trade_payload = {
        "memo":                memo,
        "timestamp":           datetime.now().isoformat(),
        "opened_at_utc":       datetime.now(timezone.utc).isoformat(),
        "direzione_broker":    direzione_broker,
        "direzione_prop":      direzione_prop,
        "lotti_broker":        lotti_broker,
        "lotti_prop":          lotti_prop,
        "sl_dol":              sl_dol,
        "tp_dol":              tp_dol,
        "ticket_broker":       ticket_b,
        "ticket_prop":         ticket_p,
        "broker_close_info":   None,
        "prop_close_info":     None,
        "pair_closed_notified": False,
        # "closed_source" (non "closure_source"): e' la chiave che TUTTI i
        # percorsi di chiusura scrivono e leggono. La variante con la 'u' era
        # un refuso e restava un campo fantasma che nessuno consultava.
        "closed_source":       None,
    }
    await modifica_dati_async(
        partial(
            modifier_save_trade_memo,
            ticket_b=ticket_b, ticket_p=ticket_p, payload=trade_payload,
        )
    )
    await journal_remove(uid)   # operazione conclusa e registrata: intento chiuso

    success_text = (
        f"✅ Hedge completato!\n\n"
        f"🏦 Sul Broker ho aperto: ({lotti_broker} Lotti)\n"
        f"🏢 Sulla Prop ho aperto: ({lotti_prop} Lotti)"
    )
    if memo:
        success_text += f"\n📝 Memo: {memo}"
    return True, success_text, ticket_b, ticket_p

async def conferma_esegui(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    if not await guard_auth(update, context):
        return ConversationHandler.END

    dati = await carica_dati_async()
    if not dati.get("broker") or not dati.get("prop"):
        await safe_edit_message_text(query, "❌ Credenziali mancanti.")
        return ConversationHandler.END

    # Difesa: ricontrollo "un trade alla volta" appena prima di inviare l'ordine
    # (lo stato potrebbe essere cambiato durante la configurazione del trade).
    bloccato_dup, motivo_dup = await _blocco_nuovo_trade()
    if bloccato_dup:
        await safe_edit_message_text(
            query, motivo_dup, InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    bloccato, motivo = await trading_bloccato_ora_o_news()
    if bloccato:
        await safe_edit_message_text(
            query, f"⛔ {motivo}",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    # ── BIVIO DELLE DUE MODALITA' ────────────────────────────────────────────
    # In semi-automatica il bot non manda nessun ordine alla prop: consegna le
    # istruzioni all'utente e prosegue sui pulsanti globali (import ritardato:
    # handlers_semiauto importa questo modulo).
    if await semiauto_attiva():
        from .handlers_semiauto import avvia_flusso_semiauto
        return await avvia_flusso_semiauto(update, context)

    direzione_prop   = context.user_data["direzione"]
    lotti_prop       = context.user_data["lotti_prop"]
    lotti_broker     = context.user_data["lotti_broker"]
    sl_dol           = context.user_data["sl"]
    tp_dol           = context.user_data["tp"]
    memo             = context.user_data.pop("memo", "").strip()

    await safe_edit_message_text(query, "⏳ Esecuzione hedge in corso...")
    ok, msg, _tb, _tp = await _esegui_hedge(
        direzione_prop, sl_dol, tp_dol, lotti_prop, lotti_broker, memo,
    )
    context.user_data.pop("riepilogo_text", None)
    if ok:
        await safe_edit_message_text(
            query, msg,
            InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Indietro", callback_data="gestisci")]]),
        )
    else:
        # Se il motivo e' "AutoTrading spento nel terminale", la tastiera include
        # il pulsante per riavviare il terminale giusto (riaccende l'Algo Trading).
        await safe_edit_message_text(query, msg, _kb_errore_ordine(msg, "manuale"))
    return ConversationHandler.END

# ========================= APERTURA PROGRAMMATA =========================
def _riepilogo_keyboard(semiauto: bool = False) -> InlineKeyboardMarkup:
    """Tastiera del riepilogo.

    In semi-automatica la PROGRAMMAZIONE non c'e': all'orario stabilito il bot
    dovrebbe aprire da solo la gamba prop, e con la sola lettura non puo'.
    Mostrare il pulsante significherebbe promettere qualcosa che non accadra'.
    """
    righe = [[InlineKeyboardButton(
        "✅ Sì, procedi" if semiauto else "✅ Sì, apri adesso", callback_data="conferma_si",
    )]]
    if not semiauto:
        righe.append([InlineKeyboardButton("⏰ Sì, programma apertura", callback_data="conferma_programma")])
    righe.append([InlineKeyboardButton("✏️ No, modifica", callback_data="conferma_no")])
    righe.append([InlineKeyboardButton("❌ Annulla",       callback_data="annulla")])
    return InlineKeyboardMarkup(righe)

async def conferma_programma(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    # In semi-automatica il pulsante non viene nemmeno mostrato: questa e' la
    # difesa contro un click su un riepilogo vecchio, rimasto in chat da prima
    # del cambio di modalita'.
    if await semiauto_attiva():
        await safe_edit_message_text(
            query,
            "⛔ In modalità semi-automatica l'apertura programmata non è "
            "disponibile: all'orario stabilito il bot dovrebbe aprire da solo la "
            "posizione sulla Prop, e con le credenziali di sola lettura non può.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    # Difesa: ricontrollo "un trade alla volta" prima di avviare la programmazione.
    bloccato_dup, motivo_dup = await _blocco_nuovo_trade()
    if bloccato_dup:
        await safe_edit_message_text(
            query, motivo_dup, InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    await safe_edit_message_text(
        query,
        "⏰ Trading Manuale - Programmazione\n\n"
        "⚠️🚨Attenzione! Usa il buon senso e NON programmare tutti i trade alla stessa ora 🚨⚠️\n\n"
        "Inserisci l'orario di apertura nel formato HH:MM (es: 14:30).\n"
        "Il trade verrà aperto alla prossima occorrenza dell'orario inserito.",
        InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Indietro", callback_data="programma_indietro")]]),
    )
    return PROGRAMMA_ORARIO

async def programma_indietro(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    testo = context.user_data.get("riepilogo_text", "Confermi l'esecuzione?")
    await safe_edit_message_text(query, testo, _riepilogo_keyboard(await semiauto_attiva()))
    return CONFERMA

async def ricevi_orario_programmato(update: Update, context: ContextTypes.DEFAULT_TYPE):
    testo = (update.message.text or "").strip()
    indietro_kb = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Indietro", callback_data="programma_indietro")]])

    m = re.fullmatch(r"(\d{1,2}):(\d{2})", testo)
    if not m:
        await update.message.reply_text(
            "Formato non valido. Inserisci l'orario come HH:MM (es: 14:30).",
            reply_markup=indietro_kb,
        )
        return PROGRAMMA_ORARIO
    hh, mm = int(m.group(1)), int(m.group(2))
    if not (0 <= hh <= 23 and 0 <= mm <= 59):
        await update.message.reply_text(
            "Orario non valido. Ore 00-23, minuti 00-59.", reply_markup=indietro_kb,
        )
        return PROGRAMMA_ORARIO

    target_t = dt_time(hh, mm)
    # La finestra di blocco aperture e' deterministica: rifiutiamo subito invece
    # di far scattare uno "skip" silenzioso all'esecuzione. Gli orari si stampano
    # dalla configurazione e non a mano: scritti a mano erano rimasti indietro
    # quando la fascia si e' spostata (vedi news.fascia_blocco_aperture).
    if _time_in_range(target_t, OPEN_BLOCK_START, OPEN_BLOCK_END):
        await update.message.reply_text(
            f"⛔ L'orario {hh:02d}:{mm:02d} cade nella finestra di blocco aperture "
            f"({fascia_blocco_aperture()}). Scegli un altro orario.",
            reply_markup=indietro_kb,
        )
        return PROGRAMMA_ORARIO

    # Prossima occorrenza in ORA LOCALE: se l'orario di oggi e' gia' passato,
    # si usa quello di domani.
    now_local    = datetime.now()
    target_local = now_local.replace(hour=hh, minute=mm, second=0, microsecond=0)
    if target_local <= now_local:
        target_local += timedelta(days=1)
    # Mercato XAUUSD chiuso nel weekend: se l'orario calcolato cade di sabato o
    # domenica l'ordine verrebbe rifiutato dal broker (e finirebbe "failed").
    # Lo spostiamo al lunedi' successivo alla STESSA ora, cosi' il trade parte
    # alla riapertura del mercato invece di fallire.
    spostato_weekend = False
    if target_local.weekday() >= 5:          # 5 = sabato, 6 = domenica
        target_local += timedelta(days=7 - target_local.weekday())
        spostato_weekend = True
    scheduled_for_utc = target_local.astimezone(timezone.utc)

    # Verifica che tutti i parametri del trade siano ancora in sessione.
    try:
        trade = {
            "id":               uuid.uuid4().hex,
            # Direzione scelta dall'utente = direzione PROP (il broker hedgia opposto).
            "direzione_prop":   context.user_data["direzione"],
            "sl_dol":           float(context.user_data["sl"]),
            "tp_dol":           float(context.user_data["tp"]),
            "lotti_prop":       float(context.user_data["lotti_prop"]),
            "lotti_broker":     float(context.user_data["lotti_broker"]),
            "incasso_target":   float(context.user_data.get("incasso_target", 0) or 0),
            "memo":             context.user_data.get("memo", "").strip(),
            "scheduled_for_utc":   scheduled_for_utc.isoformat(),
            "scheduled_for_local": target_local.strftime("%Y-%m-%d %H:%M"),
            "created_at_utc":   datetime.now(timezone.utc).isoformat(),
            "status":           "pending",
        }
    except KeyError:
        await update.message.reply_text(
            "⚠️ Dati del trade non più disponibili (sessione scaduta). Ricomincia l'apertura.",
            reply_markup=InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    await modifica_dati_async(partial(modifier_add_scheduled_trade, trade=trade))

    for k in ("memo", "sl", "tp", "lotti_prop", "lotti_broker", "direzione",
              "incasso_target", "riepilogo_text"):
        context.user_data.pop(k, None)

    await update.message.reply_text(
        f"⏰ Apertura programmata!\n\n"
        f"Il trade verrà aperto il {target_local.strftime('%d/%m alle %H:%M')} (ora locale).\n"
        + ("📅 Orario spostato a lunedì: nel weekend il mercato è chiuso.\n"
           if spostato_weekend else "")
        + f"Memo: {trade['memo'] or '—'}\n\n"
        f"Puoi vederlo o annullarlo da Manuale → 'Trade programmati'.",
        reply_markup=InlineKeyboardMarkup([back_button("manuale")]),
    )
    return ConversationHandler.END
