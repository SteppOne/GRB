"""Nomi dei server MT5: come li scrive l'utente, come li pretende il terminale.

MT5 accetta il nome del server SOLO se combacia con quello che ha in elenco:
"FundedNext-Server 2" entra, "FundedNext-Server2" no. Quello spazio prima della
cifra e' invisibile a occhio, viene copiato a mano da una mail o da un telefono,
e nei log della prop produce due errori che sembrano diversi ma sono la stessa
cosa:

    account 'FundedNext-Server2' - '14139031' has been deleted
    '14139031': authorization on FundedNext-Server 2 failed (Invalid account)

Finora il bot passava a MT5 la stringa cosi' com'era e, quando falliva, chiedeva
all'utente di ricontrollare — cioe' gli chiedeva di accorgersi di uno spazio.

Questo modulo e' PURO (niente MT5, niente Telegram, niente rete):
  • genera le grafie plausibili di un nome scritto a mano, in ordine di
    probabilita', cosi' il chiamante puo' provarle finche' una entra;
  • conosce i nomi UFFICIALI delle famiglie documentate, per riconoscerli a
    meno di spazi/trattini/maiuscole e per poterli elencare quando nessuna
    grafia funziona.

Le trasformazioni generiche vengono prima della tabella: un domani un'altra
prop con lo stesso vizio e' gia' coperta senza toccare niente.
"""
import re
from typing import List, Optional, Tuple

# Nomi UFFICIALI, verificati sulla documentazione del fornitore (help center
# FundedNext, agosto 2026). La chiave e' la famiglia, usata per riconoscere
# "e' un server FundedNext ma la grafia non e' nessuna di queste".
# NB: lo spazio prima della cifra e' voluto — non e' un refuso da "sistemare".
SERVER_NOTI = {
    "FundedNext": [
        "FundedNext-Server",      # conti a pagamento
        "FundedNext-Server 2",    # conti a pagamento
        "FundedNext-Server 3",    # competizione mensile gratuita e trial
    ],
}

# Quante grafie si provano al massimo. Ogni tentativo e' un login vero verso il
# broker: poche e mirate, non un dizionario.
MAX_VARIANTI = 5

def normalizza(nome: str) -> str:
    """Chiave di confronto: solo lettere e cifre, minuscole.

    Serve a far combaciare "FundedNext-Server 2", "fundednext server2" e
    "FundedNext - SERVER 2", che per un umano sono la stessa cosa e per MT5 no.
    """
    return "".join(c for c in (nome or "").lower() if c.isalnum())

def canonico(nome: str) -> Optional[str]:
    """Il nome ufficiale, se la grafia scritta lo identifica senza ambiguita'.

    Confronto a meno di spazi, trattini e maiuscole: "fundednextserver2"
    identifica "FundedNext-Server 2" e nient'altro.
    """
    chiave = normalizza(nome)
    if not chiave:
        return None
    for ufficiali in SERVER_NOTI.values():
        for ufficiale in ufficiali:
            if normalizza(ufficiale) == chiave:
                return ufficiale
    return None

def famiglia_nota(nome: str) -> Optional[Tuple[str, List[str]]]:
    """(famiglia, nomi ufficiali) se il server appartiene a una famiglia che
    conosciamo, altrimenti None. Riconosce anche le grafie sbagliate: serve
    proprio a dire "e' FundedNext, ma nessuno dei suoi server si chiama cosi'".
    """
    chiave = normalizza(nome)
    if not chiave:
        return None
    for famiglia, ufficiali in SERVER_NOTI.items():
        if chiave.startswith(normalizza(famiglia)):
            return famiglia, ufficiali
    return None

# "...Server2" / "...Server 2": la cifra finale attaccata o staccata dal nome.
_CIFRA_FINALE = re.compile(r"^(.*[A-Za-z])\s*(\d+)$")

def _cifra_staccata(s: str) -> str:
    """FundedNext-Server2 -> FundedNext-Server 2 (il caso che rompe tutto)."""
    m = _CIFRA_FINALE.match(s)
    return f"{m.group(1)} {m.group(2)}" if m else ""

def _cifra_attaccata(s: str) -> str:
    """L'inverso: per i broker che invece la vogliono attaccata."""
    m = _CIFRA_FINALE.match(s)
    return f"{m.group(1)}{m.group(2)}" if m else ""

def _trattino_stretto(s: str) -> str:
    """FundedNext - Server 2 -> FundedNext-Server 2."""
    stretto = re.sub(r"\s*-\s*", "-", s)
    return stretto if stretto != s else ""

def _primo_spazio_in_trattino(s: str) -> str:
    """FundedNext Server 2 -> FundedNext-Server 2.

    Solo il PRIMO spazio, ed esclusivamente se non c'e' gia' un trattino: nei
    nomi MT5 il trattino separa il broker dal server, e il resto (l'eventuale
    numero) va lasciato dov'e'.
    """
    if "-" in s or " " not in s:
        return ""
    return s.replace(" ", "-", 1)

def varianti_server(nome: str) -> List[str]:
    """Grafie da provare, in ordine di probabilita' decrescente.

    La prima e' quella con cui conviene partire: il nome ufficiale se lo
    riconosciamo, altrimenti quello che ha scritto l'utente. Lista vuota solo
    se non ha scritto nulla.
    """
    grezzo = " ".join((nome or "").split())    # taglia e compatta gli spazi
    if not grezzo:
        return []
    proposte = [
        canonico(grezzo) or "",                # il nome documentato vince
        grezzo,                                # poi quello che ha scritto lui
        _cifra_staccata(grezzo),
        _cifra_attaccata(grezzo),
        _trattino_stretto(grezzo),
        _primo_spazio_in_trattino(grezzo),
    ]
    viste, ordinate = set(), []
    for proposta in proposte:
        if proposta and proposta not in viste:
            viste.add(proposta)
            ordinate.append(proposta)
    return ordinate[:MAX_VARIANTI]

def suggerimento_nomi(nome: str) -> str:
    """Coda da allegare all'errore di accesso quando il server e' di una
    famiglia documentata ma la grafia non e' nessuna di quelle valide.

    E' l'unico modo per far uscire l'utente dal vicolo cieco: dirgli
    "ricontrolla il nome" non aiuta chi non vede lo spazio.
    """
    riconosciuta = famiglia_nota(nome)
    if not riconosciuta:
        return ""
    famiglia, ufficiali = riconosciuta
    elenco = "\n".join(f"   • {u}" for u in ufficiali)
    return (
        f"\n\nI server di {famiglia} si chiamano esattamente cosi "
        f"(attenzione allo SPAZIO prima del numero):\n{elenco}"
    )
