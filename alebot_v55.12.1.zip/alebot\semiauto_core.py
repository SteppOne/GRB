"""Cuore NON interattivo della modalita' semi-automatica.

Qui c'e' solo aritmetica: nessun Telegram, nessun MT5, nessuno stato globale.
E' la parte che decide se la posizione aperta A MANO dall'utente sulla prop e'
quella che il bot aveva chiesto, e con quali livelli esatti va corretta. Sta in
un modulo suo perche' e' la parte che DEVE essere verificabile riga per riga:
un errore qui non produce un messaggio brutto, produce un hedge sbilanciato.

Tre concetti, tutti espressi in dollari perche' e' cosi' che ragiona l'utente:

  livelli ESATTI   i prezzi di SL/TP che, PARTITI DAL PREZZO DI INGRESSO REALE
                   della posizione, danno esattamente la perdita e il guadagno
                   richiesti. Si possono calcolare solo DOPO l'apertura: prima
                   il prezzo di ingresso non esiste ancora.

  livelli PROVVISORI  gli stessi numeri calcolati sul prezzo di mercato di
                   adesso, da mostrare PRIMA dell'apertura. Invecchiano: e' la
                   ragione per cui il primo controllo ha una tolleranza.

  scarto           di quanto la perdita/guadagno reali (quelli che derivano dai
                   livelli davvero impostati) si discostano da quelli chiesti.
"""
from typing import Any, Dict, Optional, Tuple

from .mt5_sync import DatiSimboloNonValidi, calcola_prezzi_sl_tp

# Esiti di valuta_posizione_prop.
ESITO_OK              = "ok"               # livelli entro tolleranza: si copre
ESITO_DA_CORREGGERE   = "da_correggere"    # sistemabile: l'utente ritocca SL/TP
ESITO_NON_SISTEMABILE = "non_sistemabile"  # va chiusa e si ricomincia

# Motivi di ESITO_NON_SISTEMABILE (li usa la UI per scegliere il testo).
MOTIVO_DIREZIONE = "direzione"
MOTIVO_LOTTI     = "lotti"
MOTIVO_DATI      = "dati"

# Perche' una posizione prop e' rimasta SCOPERTA. Stanno qui — nel modulo senza
# dipendenze — perche' li usano parti del bot che non possono importarsi a
# vicenda: il guardiano di coppia, il monitor delle chiusure, il recovery del
# giornale e il flusso di apertura.
ALERT_BROKER_CHIUSO = "broker_chiuso"      # la gamba broker si e' chiusa da sola
ALERT_COPERTURA_KO  = "copertura_fallita"  # la copertura non e' mai partita
ALERT_DA_CHIUDERE   = "chiusura_richiesta" # era in corso una chiusura pianificata


def dollari_da_distanza(
    distanza_prezzo: float, lotti: float, point: float, tick_value: float,
) -> float:
    """Quanti dollari vale uno scostamento di prezzo, su questo simbolo.

    Inverso esatto di calcola_prezzi_sl_tp: li' i dollari diventano prezzo,
    qui il prezzo torna dollari. Le due funzioni vanno lette insieme.
    """
    if point <= 0 or tick_value <= 0 or lotti <= 0:
        return 0.0
    return abs(float(distanza_prezzo)) / float(point) * float(tick_value) * float(lotti)


def livelli_esatti(
    direzione: str, prezzo_ingresso: float,
    sl_dol: float, tp_dol: float, lotti: float,
    point: float, tick_value: float,
) -> Tuple[float, float]:
    """(sl_price, tp_price) esatti a partire dal prezzo di ingresso REALE."""
    return calcola_prezzi_sl_tp(
        direzione, float(prezzo_ingresso), float(sl_dol), float(tp_dol),
        float(lotti), float(point), float(tick_value),
    )


def _lato_corretto(direzione: str, prezzo: float, sl: float, tp: float) -> bool:
    """SL e TP stanno dalla parte giusta del prezzo di ingresso?

    Un SL messo dal lato sbagliato non e' un dettaglio estetico: verrebbe
    colpito subito e trasformerebbe la protezione nel suo contrario.
    """
    if direzione == "BUY":
        return sl < prezzo < tp
    return tp < prezzo < sl


def valuta_posizione_prop(
    direzione_attesa: str,
    lotti_attesi: float,
    sl_dol: float,
    tp_dol: float,
    posizione: Dict[str, Any],
    point: float,
    tick_value: float,
    tolleranza_perc: float,
) -> Dict[str, Any]:
    """La posizione aperta a mano e' quella richiesta? E i livelli reggono?

    'posizione' e' uno snapshot MT5 gia' normalizzato (vedi
    _get_open_positions_snapshot_sync): type "BUY"/"SELL", volume, price_open,
    sl, tp.

    Ritorna sempre un dict con almeno {"esito", "motivo"} e, quando i conti
    sono stati fatti, anche i livelli esatti e gli scarti — cosi' la UI puo'
    scrivere numeri veri invece di frasi generiche.

    NOTA sui lotti: un volume diverso da quello richiesto NON viene "adattato".
    Il dito storto (1.5 -> 15 lotti) e' l'errore piu' facile da fare su un
    telefono ed e' anche quello che moltiplica il rischio per dieci: si ferma
    tutto e si ricomincia, che e' l'unica risposta sicura.
    """
    tipo = str(posizione.get("type") or "").strip().upper()
    if tipo != str(direzione_attesa).strip().upper():
        return {
            "esito":  ESITO_NON_SISTEMABILE,
            "motivo": MOTIVO_DIREZIONE,
            "tipo_trovato": tipo or "?",
        }

    try:
        volume = float(posizione.get("volume") or 0.0)
    except (TypeError, ValueError):
        volume = 0.0
    # Confronto sul passo minimo di volume (0.01): i float non tornano mai
    # identici al confronto secco.
    if abs(volume - float(lotti_attesi)) > 1e-6:
        return {
            "esito":  ESITO_NON_SISTEMABILE,
            "motivo": MOTIVO_LOTTI,
            "lotti_trovati": volume,
        }

    try:
        prezzo_ingresso = float(posizione.get("price_open") or 0.0)
        sl = float(posizione.get("sl") or 0.0)
        tp = float(posizione.get("tp") or 0.0)
    except (TypeError, ValueError):
        prezzo_ingresso = sl = tp = 0.0

    if prezzo_ingresso <= 0 or point <= 0 or tick_value <= 0 or volume <= 0:
        return {"esito": ESITO_NON_SISTEMABILE, "motivo": MOTIVO_DATI}

    try:
        sl_esatto, tp_esatto = livelli_esatti(
            direzione_attesa, prezzo_ingresso, sl_dol, tp_dol, volume, point, tick_value,
        )
    except DatiSimboloNonValidi:
        return {"esito": ESITO_NON_SISTEMABILE, "motivo": MOTIVO_DATI}

    base = {
        "prezzo_ingresso": prezzo_ingresso,
        "lotti":           volume,
        "sl_esatto":       sl_esatto,
        "tp_esatto":       tp_esatto,
        "sl_impostato":    sl,
        "tp_impostato":    tp,
    }

    # SL o TP assenti: MT5 li espone a 0. E' il caso piu' frequente di
    # "ho sbagliato qualcosa": sistemabile, si chiede di impostarli.
    if sl <= 0 or tp <= 0:
        return {
            **base,
            "esito":  ESITO_DA_CORREGGERE,
            "motivo": "mancanti",
        }
    if not _lato_corretto(direzione_attesa, prezzo_ingresso, sl, tp):
        return {
            **base,
            "esito":  ESITO_DA_CORREGGERE,
            "motivo": "lato",
        }

    sl_dol_reale = dollari_da_distanza(prezzo_ingresso - sl, volume, point, tick_value)
    tp_dol_reale = dollari_da_distanza(tp - prezzo_ingresso, volume, point, tick_value)
    scarto_sl = abs(sl_dol_reale - float(sl_dol)) / float(sl_dol) * 100.0 if sl_dol else 0.0
    scarto_tp = abs(tp_dol_reale - float(tp_dol)) / float(tp_dol) * 100.0 if tp_dol else 0.0
    base.update({
        "sl_dol_reale":  sl_dol_reale,
        "tp_dol_reale":  tp_dol_reale,
        "scarto_sl":     scarto_sl,
        "scarto_tp":     scarto_tp,
    })
    if scarto_sl > float(tolleranza_perc) or scarto_tp > float(tolleranza_perc):
        return {**base, "esito": ESITO_DA_CORREGGERE, "motivo": "scarto"}
    return {**base, "esito": ESITO_OK, "motivo": ""}


def livelli_gia_esatti(
    posizione: Dict[str, Any], sl_esatto: float, tp_esatto: float,
    point: float, tolleranza_point: float,
) -> bool:
    """Controllo FINALE: l'utente ha impostato DAVVERO i valori esatti?

    Qui non si tollera piu' la deriva del prezzo (i livelli esatti sono fissi,
    ancorati al prezzo di ingresso): si tollera solo l'arrotondamento con cui
    il bot li ha stampati, cioe' pochi 'point'. Serve a non fidarsi del click
    "Ho modificato la posizione" quando la modifica non e' stata fatta.
    """
    try:
        sl = float(posizione.get("sl") or 0.0)
        tp = float(posizione.get("tp") or 0.0)
    except (TypeError, ValueError):
        return False
    if sl <= 0 or tp <= 0:
        return False
    margine = max(float(point) * float(tolleranza_point), 1e-9)
    return abs(sl - float(sl_esatto)) <= margine and abs(tp - float(tp_esatto)) <= margine


def livelli_broker_da_prop(
    sl_prop: float, tp_prop: float, offset: float,
) -> Tuple[float, float]:
    """Livelli della gamba BROKER a partire da quelli (esatti) della PROP.

    Due passaggi, entrambi necessari:

      1) SPECCHIO. Il broker sta dalla parte opposta: quando la prop e' al suo
         Stop Loss il broker e' al suo Take Profit, e viceversa. Quindi
         sl_broker <- tp_prop e tp_broker <- sl_prop.

      2) OFFSET DI FEED. Broker e prop NON quotano l'oro allo stesso prezzo:
         c'e' uno scarto quasi costante tra i due (nel documento: 0,34$). Se si
         copiassero i prezzi tali e quali, i due livelli scatterebbero in
         momenti di mercato diversi — ed e' esattamente il guasto che il
         guardiano di coppia deve rincorrere. Sommando lo scarto misurato ADESSO
         tra i due feed, i due livelli tornano a puntare allo STESSO istante di
         mercato. Lo scarto assorbe anche il tempo passato tra l'apertura a mano
         sulla prop e l'apertura della copertura: e' li' dentro, gia' misurato.
    """
    return float(tp_prop) + float(offset), float(sl_prop) + float(offset)


def offset_feed(info_broker: Optional[Dict[str, Any]], info_prop: Optional[Dict[str, Any]]) -> float:
    """Scarto di quotazione broker-prop, misurato sui prezzi medi di adesso.

    Si usa il medio (bid+ask)/2 e non bid o ask: gli spread dei due broker sono
    diversi e confrontare due lati diversi del book inquinerebbe la misura con
    meta' spread. Dati mancanti -> 0.0, cioe' semplice specchio: la scelta
    prudente, identica al comportamento della modalita' automatica.
    """
    def _medio(info: Optional[Dict[str, Any]]) -> Optional[float]:
        if not info:
            return None
        try:
            bid = float(info.get("bid", 0) or 0)
            ask = float(info.get("ask", 0) or 0)
        except (TypeError, ValueError):
            return None
        if bid > 0 and ask > 0:
            return (bid + ask) / 2.0
        prezzo = float(info.get("prezzo_entrata", 0) or 0)
        return prezzo if prezzo > 0 else None

    medio_b, medio_p = _medio(info_broker), _medio(info_prop)
    if medio_b is None or medio_p is None:
        return 0.0
    return medio_b - medio_p
