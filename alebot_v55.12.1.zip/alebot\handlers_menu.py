import logging
from datetime import datetime
from functools import partial
from typing import Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes,
)

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    RANDOM_LOTTI_PERC,
    RANDOM_SL_TP_PERC,
    SIMBOLO_BROKER,
)
from .broker_condiviso import intervalli_magic_storico
from .messaging import ack, back_button, safe_edit_message_text
from .storage import carica_dati_async, modifica_dati_async
from .state import (
    _inizio_ciclo_utc,
    modifier_remove_scheduled_trade,
    modifier_set_randomizzazione,
)
from .mt5_async import get_open_tickets_by_symbol_async, get_trade_history_async
from .modalita import semiauto_attiva
from .randomizzazione import randomizzazione_attiva
from .handlers_base import guard_auth

# ========================= GESTISCI POSIZIONI =========================
async def menu_gestisci(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    keyboard = [[InlineKeyboardButton("👤 Manuale", callback_data="manuale")]]
    # "Automatico" non puo' esistere in semi-automatica: li' la prop la comanda
    # l'utente, quindi non c'e' niente da automatizzare.
    if not await semiauto_attiva():
        keyboard.append([InlineKeyboardButton("🔁 Automatico (In sviluppo)", callback_data="automatico")])
    keyboard += [
        [InlineKeyboardButton("ℹ️ Info account",          callback_data="info_account_menu")],
        [InlineKeyboardButton("📰 Notizie",               callback_data="notizie")],
        [InlineKeyboardButton("📊 Dashboard calcolatore", url="https://when100mil.netlify.app/ciccino/ciccino.html")],
        [InlineKeyboardButton("⬅️ Indietro",              callback_data="indietro")],
    ]
    await safe_edit_message_text(query, "Gestisci Posizioni", InlineKeyboardMarkup(keyboard))

async def menu_manuale(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    semiauto = await semiauto_attiva()
    keyboard = [
        [
            InlineKeyboardButton("🟢 Apri trade",   callback_data="apritrade"),
            InlineKeyboardButton("🔴 Chiudi trade", callback_data="chiuditrade"),
        ],
        [InlineKeyboardButton("🔍 Stato trade", callback_data="statotrade")],
    ]
    # Le due voci qui sotto aprono una posizione sulla PROP per conto
    # dell'utente: in semi-automatica il bot non puo' farlo (sola lettura), e un
    # pulsante che non puo' mantenere la promessa e' peggio di un pulsante assente.
    if not semiauto:
        keyboard.append([InlineKeyboardButton("⏰ Trade programmati",        callback_data="trade_programmati")])
        keyboard.append([InlineKeyboardButton("🎯 Trade minimo per giorno", callback_data="trademin")])
    # La randomizzazione resta visibile in ENTRAMBE le modalita': anche in
    # semi-automatica ritocca i numeri, solo che li digita l'utente. Lo stato e'
    # sull'etichetta perche' e' l'informazione che serve prima di aprire un
    # trade, non dopo essere entrati nella schermata.
    keyboard.append([InlineKeyboardButton(
        f"🎲 Randomizzazione: {'ON' if await randomizzazione_attiva() else 'OFF'}",
        callback_data="randomizza",
    )])
    # "Dettaglio Storico" spostato nelle schermate Info Account Broker/Prop.
    keyboard.append([InlineKeyboardButton("⬅️ Indietro", callback_data="gestisci")])
    testo = (
        "👤 Trading Semi-Automatico\n\nSeleziona un'operazione:"
        if semiauto else "Manuale"
    )
    await safe_edit_message_text(query, testo, InlineKeyboardMarkup(keyboard))

# ========================= RANDOMIZZAZIONE =========================
def _schermata_randomizzazione(attiva: bool, avviso: str = "") -> Tuple[str, InlineKeyboardMarkup]:
    """Testo e tastiera della schermata (nessun accesso a disco: e' pura resa).

    Si mostra UN SOLO pulsante di azione, quello che cambia davvero lo stato:
    due pulsanti "Attiva/Disattiva" affiancati fanno sempre nascere il dubbio su
    quale dei due sia quello premuto l'ultima volta.
    """
    testo = (
        f"{avviso}🎲 Randomizzazione\n\n"
        f"Stato attuale: {'🟢 ATTIVA' if attiva else '🔴 DISATTIVATA'}\n\n"
        "Quando è attiva, a ogni apertura il bot ritocca da solo i valori che "
        "hai inserito, così i tuoi trade non sono mai identici tra loro:\n\n"
        f"• Stop Loss e Take Profit: fino a ±{RANDOM_SL_TP_PERC:g}% "
        f"(su 1.800$ sono ±{1800 * RANDOM_SL_TP_PERC / 100:.2f}$)\n"
        f"• Lotti: fino a ±{RANDOM_LOTTI_PERC:g}% "
        f"(su 1,50 lotti sono ±{1.5 * RANDOM_LOTTI_PERC / 100:.2f})\n\n"
        "I valori ritoccati li vedi nel riepilogo PRIMA di confermare, con "
        "l'indicazione di quanto è stato aggiunto o tolto. Lotti broker, livelli "
        "e copertura si ricalcolano sui valori nuovi: l'hedge resta bilanciato.\n\n"
        "🛡 Il ritocco non ti avvicina mai alla perdita giornaliera della prop se "
        "il valore che hai digitato non la stava già toccando.\n\n"
        "ℹ️ Sui lotti il rischio non cambia: lo Stop Loss è in dollari, quindi "
        "con più lotti lo stop viene calcolato più vicino."
    )
    azione = (
        InlineKeyboardButton("🚫 Disattiva", callback_data="rnd_set|off") if attiva
        else InlineKeyboardButton("✅ Attiva",  callback_data="rnd_set|on")
    )
    return testo, InlineKeyboardMarkup([[azione], back_button("manuale")])

async def randomizzazione_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    testo, kb = _schermata_randomizzazione(await randomizzazione_attiva())
    await safe_edit_message_text(query, testo, kb)

async def randomizzazione_set_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    data   = query.data or ""
    attiva = data.split("|", 1)[1].strip().lower() == "on" if "|" in data else False
    await modifica_dati_async(partial(modifier_set_randomizzazione, attiva=attiva))
    logger.info(f"Randomizzazione {'attivata' if attiva else 'disattivata'} dall'owner.")
    avviso = (
        "✅ Randomizzazione attivata.\n\n" if attiva
        else "🚫 Randomizzazione disattivata: i trade useranno esattamente i "
             "valori che inserisci.\n\n"
    )
    testo, kb = _schermata_randomizzazione(attiva, avviso)
    await safe_edit_message_text(query, testo, kb)

async def trade_programmati_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    dati = await carica_dati_async()
    pendenti = [
        t for t in dati.get("scheduled_trades", [])
        if isinstance(t, dict) and t.get("status") == "pending"
    ]
    pendenti.sort(key=lambda t: t.get("scheduled_for_utc", ""))
    if not pendenti:
        await safe_edit_message_text(
            query, "⏰ Nessun trade programmato in attesa.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return
    lines = ["⏰ Trade programmati in attesa:\n"]
    keyboard = []
    for t in pendenti:
        # La direzione mostrata e' la scelta dell'utente (= direzione PROP);
        # fallback su "direzione_broker" per i trade salvati prima del fix.
        dir_scelta = t.get("direzione_prop", t.get("direzione_broker"))
        dir_label  = "Compra" if dir_scelta == "BUY" else "Vendi"
        memo      = t.get("memo", "") or "—"
        lines.append(
            f"• {t.get('scheduled_for_local', '?')} | {dir_label} | "
            f"{t.get('lotti_prop', '?')} lotti | {memo}"
        )
        keyboard.append([InlineKeyboardButton(
            f"❌ Annulla {t.get('scheduled_for_local', '?')}",
            callback_data=f"sched_cancel|{t.get('id', '')}",
        )])
    keyboard.append(back_button("manuale"))
    await safe_edit_message_text(query, "\n".join(lines), InlineKeyboardMarkup(keyboard))

async def sched_cancel_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    data = query.data or ""
    trade_id = data.split("|", 1)[1] if "|" in data else ""
    res = await modifica_dati_async(partial(modifier_remove_scheduled_trade, trade_id=trade_id))
    testo = "✅ Trade programmato annullato." if res is not None else "ℹ️ Trade programmato non più presente."
    await safe_edit_message_text(query, testo, InlineKeyboardMarkup([back_button("manuale")]))

# ---- Storico trade (lettura da MT5, sola lettura) ----
async def storico_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    keyboard = [
        [InlineKeyboardButton("🏦 Storico Broker", callback_data="storico_show|broker")],
        [InlineKeyboardButton("🏛️ Storico Prop",   callback_data="storico_show|prop")],
        [InlineKeyboardButton("⬅️ Indietro",        callback_data="manuale")],
    ]
    await safe_edit_message_text(
        query, "📜 Storico Trade\n\nScegli il conto:", InlineKeyboardMarkup(keyboard),
    )

async def storico_show_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    data  = query.data or ""
    conto = data.split("|", 1)[1] if "|" in data else ""

    dati = await carica_dati_async()
    # Sul BROKER lo storico MT5 puo' contenere i trade di un altro bot che
    # condivide il conto: si tengono solo quelli firmati da questo bot. La PROP
    # e' un conto personale e si legge intera — li' un trade non firmato dal bot
    # e' comunque dell'utente, e nasconderglielo sarebbe sbagliato.
    magic_ranges = None
    if conto == "broker":
        cred, path, simbolo = dati.get("broker"), MT5_BROKER_EXE, SIMBOLO_BROKER
        titolo, back_cb     = "🏦 Dettaglio Storico Broker", "info_broker"
        magic_ranges        = intervalli_magic_storico()
    else:
        cred, path, simbolo = dati.get("prop"),   MT5_PROP_EXE,   cfg.SIMBOLO_PROP
        titolo, back_cb     = "🏛️ Dettaglio Storico Prop",   "info_prop"

    back = InlineKeyboardMarkup([back_button(back_cb)])
    if not cred or not cred.get("id") or not cred.get("password") or not cred.get("server"):
        await safe_edit_message_text(
            query, f"{titolo}\n\n⚠️ Credenziali non ancora configurate per questo conto.", back,
        )
        return

    await safe_edit_message_text(query, f"{titolo}\n\n⏳ Recupero storico…", back)
    # Tutti i trade chiusi del CICLO in corso (dall'ultimo Reset P/L); se non e'
    # mai stato fatto un reset, fallback agli ultimi 30 giorni.
    inizio_ciclo = _inizio_ciclo_utc(dati)
    storico = await get_trade_history_async(
        path, int(cred["id"]), cred["password"], cred["server"], simbolo,
        days=30, limit=None, since_utc=inizio_ciclo, magic_ranges=magic_ranges,
    )
    periodo = "nel ciclo in corso" if inizio_ciclo else "negli ultimi 30 giorni"
    if storico is None:
        await safe_edit_message_text(
            query, f"{titolo}\n\n❌ MT5 non raggiungibile in questo momento. Riprova tra poco.", back,
        )
        return
    if not storico:
        await safe_edit_message_text(
            query, f"{titolo}\n\nNessun trade chiuso {periodo}.", back,
        )
        return

    # Tetto di visualizzazione per restare entro i limiti dei messaggi Telegram:
    # il TOTALE in fondo e' comunque calcolato su TUTTO il periodo.
    MAX_RIGHE_STORICO = 50
    righe = [titolo, f"Trade chiusi {periodo}:", ""]
    for r in storico[:MAX_RIGHE_STORICO]:
        try:
            ora = datetime.fromisoformat(r["open_time_utc"]).strftime("%d/%m %H:%M")
        except Exception:
            ora = "?"
        pl    = float(r.get("profit", 0) or 0)
        segno = "🟢" if pl >= 0 else "🔴"
        righe.append(f"{segno} {ora} | {r['esito']} | {pl:+.2f}$")
    if len(storico) > MAX_RIGHE_STORICO:
        righe.append(f"… e altri {len(storico) - MAX_RIGHE_STORICO} trade più vecchi non mostrati.")
    totale = sum(float(r.get("profit", 0) or 0) for r in storico)
    righe.append("")
    righe.append(f"Totale: {totale:+.2f}$ ({len(storico)} trade)")
    if magic_ranges:
        righe.append("")
        righe.append("🔒 Mostrati solo i trade aperti da questo bot.")
    await safe_edit_message_text(query, "\n".join(righe), back)

async def _blocco_per_programmati() -> Tuple[bool, str]:
    """C'e' un hedge PROGRAMMATO in attesa? (True = non aprire altro sulla prop)

    Piu' stretto di _blocco_nuovo_trade: non interroga MT5, guarda solo la coda
    degli ordini programmati. Serve al trade-sfida, che altrimenti poteva
    aprirsi sulla prop e ritrovarsi affiancato dall'hedge programmato allo
    scatto dell'orario — due posizioni sulla stessa prop, cioe' proprio cio'
    che la regola "un trade alla volta" vuole impedire.
    """
    dati = await carica_dati_async()
    pendenti = [
        t for t in dati.get("scheduled_trades", [])
        if isinstance(t, dict) and t.get("status") in ("pending", "firing")
    ]
    if pendenti:
        quando = pendenti[0].get("scheduled_for_local", "?")
        return True, (
            f"⛔ C'è già un trade programmato in attesa ({quando}).\n"
            "Aprirne un altro sulla Prop violerebbe la regola “un trade alla volta”.\n"
            "Annullalo da Manuale → “Trade programmati”, oppure attendi."
        )
    return False, ""

async def _blocco_nuovo_trade() -> Tuple[bool, str]:
    """Regola 'un trade alla volta'. Ritorna (True, messaggio) se NON si puo'
    aprire/programmare un nuovo trade perche' sulla PROP c'e' gia' un trade aperto
    oppure uno programmato in attesa; (False, "") se via libera.

    - Il BROKER NON viene controllato apposta: e' un conto condiviso che in futuro
      potra' avere trade aperti da altri bot (il conto broker resta lo stesso).
    - Se MT5 non e' raggiungibile (impossibile verificare), si BLOCCA per prudenza:
      meglio negare l'apertura che rischiare un doppio trade.
    """
    # Un'apertura semi-automatica in corso NON esiste ancora su MT5 (la
    # posizione la deve aprire l'utente): senza questo controllo il bot
    # consegnerebbe due istruzioni e si ritroverebbe due posizioni sulla prop.
    # Import ritardato: handlers_semiauto dipende da questo modulo.
    from .handlers_semiauto import blocco_semiauto_in_corso
    bloccato_semi, motivo_semi = await blocco_semiauto_in_corso()
    if bloccato_semi:
        return True, motivo_semi

    dati = await carica_dati_async()
    pendenti = [
        t for t in dati.get("scheduled_trades", [])
        if isinstance(t, dict) and t.get("status") in ("pending", "firing")
    ]
    if pendenti:
        return True, (
            "⛔ C'è già un trade programmato in attesa.\n"
            "Attendi la chiusura per aprire o programmare un altro trade."
        )
    prop = dati.get("prop")
    if prop and prop.get("id") and prop.get("password") and prop.get("server"):
        tickets = await get_open_tickets_by_symbol_async(
            MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
        )
        if tickets is None:
            return True, (
                "⚠️ Non riesco a verificare i trade sulla Prop (MT5 non raggiungibile). "
                "Riprova tra poco."
            )
        if tickets:
            return True, (
                "⛔ C'è già un trade aperto sulla Prop.\n"
                "Attendi la chiusura per aprire o programmare un altro trade."
            )
    return False, ""

async def apritrade_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    indietro = InlineKeyboardMarkup([back_button("manuale")])

    await safe_edit_message_text(query, "⏳ Controllo trade aperti sulla Prop…", indietro)
    bloccato, motivo = await _blocco_nuovo_trade()
    if bloccato:
        await safe_edit_message_text(query, motivo, indietro)
        return

    label_broker = SIMBOLO_BROKER.replace("XAUUSD", "XAU/USD")
    keyboard = [
        [InlineKeyboardButton(label_broker, callback_data=SIMBOLO_BROKER)],
        [InlineKeyboardButton("⬅️ Indietro", callback_data="manuale")],
    ]
    await safe_edit_message_text(query, "Scegli strumento", InlineKeyboardMarkup(keyboard))

async def scegli_direzione(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    label_broker = SIMBOLO_BROKER.replace("XAUUSD", "XAU/USD")
    keyboard = [
        [
            InlineKeyboardButton("🟢 Compra", callback_data="compra"),
            InlineKeyboardButton("🔴 Vendi",  callback_data="vendi"),
        ],
        [InlineKeyboardButton("⬅️ Indietro", callback_data="apritrade")],
    ]
    await safe_edit_message_text(query, label_broker, InlineKeyboardMarkup(keyboard))

# Unico placeholder ancora REGISTRATO in app.py (pulsante "Automatico").
# Gli altri tre (chiudi_trade_sviluppo, stato_trade_sviluppo,
# configura_incasso_sviluppo) non erano agganciati ad alcun handler: rimossi.
async def automatico_sviluppo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "🔧 Funzione in sviluppo.", InlineKeyboardMarkup([back_button("gestisci")]))
