"""Comando /modalita: si passa da automatica a semi-automatica e viceversa.

Il cambio di modalita' NON e' una preferenza estetica: sposta la responsabilita'
della gamba prop dal bot all'utente (o viceversa). Per questo qui c'e' piu'
codice di controllo che di interfaccia:

  • non si cambia con operazioni a mercato. Passare ad automatica mentre esiste
    una posizione prop aperta a mano vorrebbe dire consegnarla a un bot che
    crede di poterla chiudere; passare a semi-automatica mentre un hedge e'
    vivo vorrebbe dire togliere al bot la chiave di casa proprio mentre serve;

  • dopo il cambio si CONTROLLA la password prop e si dice all'utente se e'
    quella giusta per la modalita' scelta (sola lettura in semi-automatica,
    master in automatica). E' un avviso, non un blocco: il conto potrebbe
    essere momentaneamente irraggiungibile e nessuno deve restare fuori dal
    proprio bot per questo.
"""
import logging
from functools import partial
from typing import Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import MODALITA_AUTO, MODALITA_SEMIAUTO, MT5_BROKER_EXE, MT5_PROP_EXE, SIMBOLO_BROKER
from .broker_condiviso import separa_posizioni
from .messaging import ack, back_button, safe_edit_message_text
from .modalita import etichetta, modalita_corrente, normalizza_modalita, semiauto_attiva
from .state import modifier_set_modalita
from .storage import carica_dati_async, modifica_dati_async
from .mt5_async import _get_open_positions_snapshot_async, info_account_async
from .handlers_base import (
    _menu_principale_testo_kb,
    _nome_utente,
    guard_auth,
    mostra_menu_principale,
)

_TESTO_AUTO = (
    "Il bot apre e chiude DA SOLO entrambe le gambe (Prop + Broker).\n"
    "Nelle credenziali Prop serve la password MASTER."
)
_TESTO_SEMIAUTO = (
    "La posizione sulla Prop la apri e la chiudi TU dal tuo MetaTrader; il bot "
    "ti guida, verifica i livelli, apre la copertura sul Broker e sorveglia la "
    "coppia.\nNelle credenziali Prop puoi usare la password di SOLA LETTURA."
)


def _tastiera_scelta(attuale: str) -> InlineKeyboardMarkup:
    righe = []
    if attuale != MODALITA_AUTO:
        righe.append([InlineKeyboardButton("🔁 Passa ad AUTOMATICA", callback_data=f"mod_set|{MODALITA_AUTO}")])
    if attuale != MODALITA_SEMIAUTO:
        righe.append([InlineKeyboardButton("👤 Passa a SEMI-AUTOMATICA", callback_data=f"mod_set|{MODALITA_SEMIAUTO}")])
    righe.append(back_button("indietro"))
    return InlineKeyboardMarkup(righe)


async def _operazioni_a_mercato() -> Tuple[bool, str]:
    """C'e' qualcosa in ballo che vieta il cambio di modalita'?

    Guarda, nell'ordine, cio' che il bot sa di suo (attese semi-automatiche,
    programmati, trade-sfida) e poi le posizioni REALI aperte da questo bot sui
    due conti. Su MT5 irraggiungibile si NEGA: cambiare modalita' senza sapere
    cosa c'e' a mercato e' esattamente il modo di ritrovarsi una gamba che
    nessuno sorveglia.
    """
    from .handlers_semiauto import blocco_semiauto_in_corso   # lazy: dipende da handlers_trade
    bloccato, _ = await blocco_semiauto_in_corso()
    if bloccato:
        return True, (
            "⛔ C'è un'operazione semi-automatica in corso.\n"
            "Completala o annullala prima di cambiare modalità."
        )

    dati = await carica_dati_async()
    if [t for t in dati.get("scheduled_trades", []) or []
            if isinstance(t, dict) and t.get("status") in ("pending", "firing")]:
        return True, (
            "⛔ C'è un trade programmato in attesa.\n"
            "Annullalo (Manuale → Trade programmati) prima di cambiare modalità."
        )
    if [t for t in dati.get("challenge_trades", []) or []
            if isinstance(t, dict) and t.get("status") in ("open", "closing")]:
        return True, (
            "⛔ C'è un trade minimo giornaliero ancora aperto.\n"
            "Attendi la sua chiusura prima di cambiare modalità."
        )

    broker, prop = dati.get("broker"), dati.get("prop")
    for cred, exe, simbolo, nome in (
        (broker, MT5_BROKER_EXE, SIMBOLO_BROKER,   "Broker"),
        (prop,   MT5_PROP_EXE,   cfg.SIMBOLO_PROP, "Prop"),
    ):
        if not cred or not all(cred.get(k) for k in ("id", "password", "server")):
            continue
        snap = await _get_open_positions_snapshot_async(
            exe, int(cred["id"]), cred["password"], cred["server"], simbolo,
        )
        if snap is None:
            return True, (
                f"⚠️ Non riesco a leggere le posizioni sul conto {nome} "
                "(terminale non raggiungibile).\n"
                "Non cambio modalità al buio: riprova tra poco."
            )
        mie, _altrui = separa_posizioni(snap, dati)
        if mie:
            return True, (
                f"⛔ Ci sono {len(mie)} posizioni aperte da questo bot sul conto {nome}.\n"
                "Chiudile prima di cambiare modalità: il cambio sposta la "
                "responsabilità della gamba Prop e non deve avvenire a mercato aperto."
            )
    return False, ""


async def _avviso_password_prop(nuova: str) -> str:
    """Riga di avviso se la password prop non e' quella adatta alla modalita'."""
    info = await info_account_async(MT5_PROP_EXE)
    if not info or "trade_allowed" not in info:
        return ""
    consentito = bool(info.get("trade_allowed"))
    if nuova == MODALITA_SEMIAUTO and consentito:
        return (
            "\n\nℹ️ Sul conto Prop risulta ancora attiva una password che CONSENTE "
            "di operare. Per lavorare in sicurezza sostituiscila con quella di "
            "SOLA LETTURA da: ⚙️ Configura Operatività → 🔑 Gestisci Credenziali → 📊 Prop."
        )
    if nuova == MODALITA_AUTO and not consentito:
        return (
            "\n\n⚠️ Sul conto Prop risulta attiva una password di SOLA LETTURA: "
            "in modalità automatica il bot deve poter aprire e chiudere sulla Prop. "
            "Inserisci la password MASTER da: ⚙️ Configura Operatività → "
            "🔑 Gestisci Credenziali → 📊 Prop."
        )
    return ""


def _riepilogo(attuale: str) -> str:
    return (
        f"⚙️ Modalità operativa\n\nAttiva: {etichetta(attuale).upper()}\n\n"
        f"🔁 automatica ({MODALITA_AUTO})\n{_TESTO_AUTO}\n\n"
        f"👤 semi-automatica ({MODALITA_SEMIAUTO})\n{_TESTO_SEMIAUTO}\n\n"
        "Per cambiare: premi un pulsante qui sotto oppure scrivi\n"
        f"/modalita {MODALITA_AUTO}   —   /modalita {MODALITA_SEMIAUTO}"
    )


async def _applica(nuova: str) -> Tuple[bool, str]:
    """Cambia modalita' (se lecito). Ritorna (cambiata, messaggio da mostrare)."""
    attuale = await modalita_corrente()
    if nuova == attuale:
        return False, f"ℹ️ La modalità {etichetta(nuova)} è già attiva."
    bloccato, motivo = await _operazioni_a_mercato()
    if bloccato:
        return False, motivo
    await modifica_dati_async(partial(modifier_set_modalita, modalita=nuova))
    logger.warning(f"Modalità operativa cambiata: {attuale} -> {nuova}")
    corpo = _TESTO_SEMIAUTO if nuova == MODALITA_SEMIAUTO else _TESTO_AUTO
    return True, (
        f"✅ Modalità impostata: {etichetta(nuova).upper()}.\n\n{corpo}"
        + await _avviso_password_prop(nuova)
    )


async def _manda_schermata_iniziale(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Dopo il cambio si rivede il menu principale, che ora dichiara la modalità.

    Va inviato come messaggio NUOVO e non modificando quello del comando:
    altrimenti la conferma del cambio — che contiene anche l'eventuale avviso
    sulla password prop — verrebbe cancellata dal menu.
    """
    testo, kb = _menu_principale_testo_kb(_nome_utente(update), await semiauto_attiva())
    chat = update.effective_chat
    if chat is None:
        return
    try:
        await context.bot.send_message(chat_id=chat.id, text=testo, reply_markup=kb)
    except Exception as e:
        logger.warning(f"Menu post-cambio modalità non inviato ({e}).")


# ========================= HANDLER =========================
async def modalita_comando(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/modalita [normale_auto|normale_semiauto]"""
    if not await guard_auth(update, context):
        return
    argomento = " ".join(context.args or []).strip() if hasattr(context, "args") else ""
    if not argomento:
        attuale = await modalita_corrente()
        await update.message.reply_text(_riepilogo(attuale), reply_markup=_tastiera_scelta(attuale))
        return
    nuova = normalizza_modalita(argomento)
    if nuova is None:
        await update.message.reply_text(
            f"❓ Modalità «{argomento}» non riconosciuta.\n\n"
            f"Usa:\n/modalita {MODALITA_AUTO}\n/modalita {MODALITA_SEMIAUTO}"
        )
        return
    await update.message.reply_text("⏳ Verifico che non ci siano operazioni a mercato…")
    cambiata, messaggio = await _applica(nuova)
    await update.message.reply_text(messaggio)
    if cambiata:
        await _manda_schermata_iniziale(update, context)


async def modalita_set_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Pulsanti «Passa a…» della schermata /modalita."""
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    dato  = (query.data or "")
    nuova = normalizza_modalita(dato.split("|", 1)[1] if "|" in dato else "")
    if nuova is None:
        await safe_edit_message_text(query, "❓ Modalità non riconosciuta.")
        return
    await safe_edit_message_text(query, "⏳ Verifico che non ci siano operazioni a mercato…")
    cambiata, messaggio = await _applica(nuova)
    await safe_edit_message_text(
        query, messaggio, InlineKeyboardMarkup([back_button("indietro")]),
    )
    if cambiata:
        await _manda_schermata_iniziale(update, context)


async def menu_comando(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/menu — alias di /help, il nome usato dai messaggi della semi-automatica."""
    await mostra_menu_principale(update, context)
