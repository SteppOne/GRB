"""Giornale transazionale delle operazioni di mercato multi-passo.

Ogni operazione che tocca il mercato in PIU' passi (hedge = 2 ordini,
trade-sfida = ordine + registrazione, chiusura di massa = N chiusure)
scrive PRIMA un intento persistente e cifrato nello stato, lo aggiorna a
ogni passo e lo rimuove SOLO a operazione conclusa. Se il processo muore
in un punto qualsiasi, il recovery al boot (e il retry periodico) sa
esattamente cosa stava succedendo e rimedia:

  - hedge con una sola gamba a mercato  -> la gamba orfana viene RICHIUSA;
  - hedge completo ma non registrato    -> viene registrato (monitor, P/L);
  - trade-sfida aperto ma non registrato-> viene registrato col suo timer;
  - chiusura di massa interrotta        -> le chiusure rimanenti RIPRENDONO.

REGOLA D'ORO: su informazione incerta (MT5 irraggiungibile) il recovery
NON agisce e riprova al giro successivo. Meglio un ritardo che una
chiusura sbagliata.

Tipi di intento (campo "kind"): hedge_open, challenge_open, close_pairs,
close_survivor, test_open, semiauto_cover.

MODALITA' SEMI-AUTOMATICA: quando la prop e' in sola lettura il recovery NON
puo' piu' chiudere le sue posizioni. La regola d'oro non cambia, cambia il
rimedio: dove prima chiudeva, ora accende l'allarme "prop scoperta" e insiste
con l'utente finche' non l'ha chiusa lui.
"""
import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import MT5_BROKER_EXE, MT5_PROP_EXE, SIMBOLO_BROKER
from .storage import carica_dati_async, modifica_dati_async
from .state import modifier_add_challenge_trade, modifier_save_trade_memo
from .messaging import notifica_owner
from .modalita import prop_sola_lettura
from .semiauto_core import ALERT_BROKER_CHIUSO, ALERT_COPERTURA_KO, ALERT_DA_CHIUDERE
from .mt5_async import (
    _get_open_positions_snapshot_async,
    chiudi_posizione_async,
)

JOURNAL_KEY = "op_journal"

# Un intento creato in QUESTA vita del processo e' "in corso", non "crashato":
# il retry periodico lo ignora finche' non supera STALE_MINUTES (nessuna
# operazione legittima dura cosi' tanto). Gli intenti di una vita precedente
# (boot_id diverso) sono recuperabili subito.
BOOT_ID = uuid.uuid4().hex
STALE_MINUTES = 10

CLOSE_RETRY = 3
CLOSE_RETRY_PAUSE_S = 1.0


# ========================= MODIFIERS (puri) =========================
def modifier_journal_put(d: dict, entry_id: str, entry: Dict[str, Any]) -> dict:
    j = d.get(JOURNAL_KEY) or {}
    j[entry_id] = entry
    d[JOURNAL_KEY] = j
    return d

def modifier_journal_update(d: dict, entry_id: str, updates: Dict[str, Any]) -> Optional[dict]:
    j = d.get(JOURNAL_KEY) or {}
    rec = j.get(entry_id)
    if not isinstance(rec, dict):
        return None
    rec = dict(rec)
    rec.update(updates)
    j[entry_id] = rec
    d[JOURNAL_KEY] = j
    return d

def modifier_journal_remove(d: dict, entry_id: str) -> Optional[dict]:
    j = d.get(JOURNAL_KEY) or {}
    if entry_id not in j:
        return None
    del j[entry_id]
    d[JOURNAL_KEY] = j
    return d


# ========================= API ASYNC =========================
async def journal_put(entry_id: str, **campi: Any) -> None:
    entry = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "boot_id":     BOOT_ID,
        **campi,
    }
    await modifica_dati_async(partial(modifier_journal_put, entry_id=entry_id, entry=entry))

async def journal_update(entry_id: str, **updates: Any) -> None:
    await modifica_dati_async(partial(modifier_journal_update, entry_id=entry_id, updates=updates))

async def journal_remove(entry_id: str) -> None:
    await modifica_dati_async(partial(modifier_journal_remove, entry_id=entry_id))


# ========================= RECOVERY =========================
def _entry_recuperabile(entry: Dict[str, Any], solo_stantii: bool) -> bool:
    """Un intento va recuperato se appartiene a una vita PRECEDENTE del
    processo, oppure (nel retry periodico) se e' stantio oltre ogni durata
    legittima. Con solo_stantii=False (boot) si recupera tutto."""
    if not solo_stantii:
        return True
    if entry.get("boot_id") != BOOT_ID:
        return True
    # Operazione conclusa MALE mentre il bot era vivo (rollback fallito,
    # chiusure rimaste indietro): non e' "in corso", va ritentata subito.
    if entry.get("status") == "orphan" or entry.get("alerted"):
        return True
    try:
        creato = datetime.fromisoformat(entry.get("created_utc", ""))
        if creato.tzinfo is None:
            creato = creato.replace(tzinfo=timezone.utc)
    except Exception:
        return True  # timestamp illeggibile: trattalo come stantio
    return datetime.now(timezone.utc) - creato > timedelta(minutes=STALE_MINUTES)


async def _chiudi_con_retry(path: str, cred: dict, ticket: int) -> bool:
    for tentativo in range(CLOSE_RETRY):
        ok = await chiudi_posizione_async(
            path, int(cred["id"]), cred["password"], cred["server"], ticket,
        )
        if ok:
            return True
        logger.error(f"Recovery: chiusura ticket {ticket} tentativo {tentativo + 1} fallito.")
        await asyncio.sleep(CLOSE_RETRY_PAUSE_S)
    return False


async def _prop_non_chiudibile(
    app, entry_id: str, prop_ticket: int, broker_ticket: int = 0,
    motivo: str = ALERT_COPERTURA_KO,
) -> None:
    """Semi-automatica: una posizione PROP andrebbe chiusa ma il bot non puo'.

    Invece di sprecare tentativi che il server rifiutera' (il conto e' in sola
    lettura), si accende l'allarme "prop scoperta": un messaggio subito e poi
    uno ogni cinque minuti finche' l'utente non chiude dal telefono. L'intento
    resta nel giornale finche' la posizione esiste, cosi' nessuno se ne
    dimentica.

    Import ritardato di proposito: loops importa questo modulo, non viceversa.
    """
    from .loops import segnala_prop_scoperta
    logger.warning(
        f"Recovery: posizione Prop {prop_ticket} da chiudere ma modalità "
        f"semi-automatica (sola lettura): sollecito l'utente."
    )
    await segnala_prop_scoperta(app, int(prop_ticket), int(broker_ticket or 0), motivo)
    await journal_update(entry_id, status="orphan", alerted=True, attesa_utente=True)


def _ticket_per_magic(snapshot: list, magic: int) -> Optional[int]:
    for p in snapshot:
        if isinstance(p, dict) and int(p.get("magic", 0) or 0) == int(magic):
            return int(p["ticket"])
    return None


def _tickets_aperti(snapshot: list) -> set:
    return {int(p["ticket"]) for p in snapshot if isinstance(p, dict)}


async def _recover_hedge_open(app, entry_id: str, entry: dict,
                              broker: dict, prop: dict,
                              snap_b: list, snap_p: list,
                              trade_memos: dict) -> None:
    magic = int(entry.get("magic", 0) or 0)
    # Il ticket puo' essere noto dal giornale O ritrovato per magic: copre anche
    # l'ordine accettato dal server di cui non abbiamo mai visto la risposta.
    tb = int(entry.get("ticket_broker") or 0) or _ticket_per_magic(snap_b, magic)
    tp = int(entry.get("ticket_prop")   or 0) or _ticket_per_magic(snap_p, magic)
    aperto_b = bool(tb) and (tb in _tickets_aperti(snap_b))
    aperto_p = bool(tp) and (tp in _tickets_aperti(snap_p))

    if tb and tp:
        # Entrambe le gambe sono ESISTITE: l'hedge era completo, mancava solo la
        # registrazione. Registra il memo: da qui in poi il monitor standard fa
        # tutto (notifica di chiusura, conteggio P/L) sia per gambe ancora
        # aperte sia per gambe gia' chiuse dal mercato nel frattempo.
        if str(tb) not in trade_memos and str(tp) not in trade_memos:
            payload = {
                "memo":                entry.get("memo", ""),
                "timestamp":           datetime.now().isoformat(),
                "opened_at_utc":       entry.get("created_utc"),
                "direzione_broker":    entry.get("direzione_broker"),
                "direzione_prop":      entry.get("direzione_prop"),
                "lotti_broker":        entry.get("lotti_broker"),
                "lotti_prop":          entry.get("lotti_prop"),
                "sl_dol":              entry.get("sl_dol"),
                "tp_dol":              entry.get("tp_dol"),
                "ticket_broker":       tb,
                "ticket_prop":         tp,
                "broker_close_info":   None,
                "prop_close_info":     None,
                "pair_closed_notified": False,
                "closed_source":       None,
            }
            await modifica_dati_async(partial(
                modifier_save_trade_memo, ticket_b=tb, ticket_p=tp, payload=payload,
            ))
        await notifica_owner(app, (
            "🛟 Recovery hedge dopo riavvio: entrambe le gambe risultano eseguite "
            f"(Broker {tb} / Prop {tp}). Trade registrato e ora monitorato normalmente."
        ))
        await journal_remove(entry_id)
        return

    if aperto_p and not aperto_b and await prop_sola_lettura():
        # Semi-automatica: la gamba superstite e' la PROP e il bot ha la sola
        # lettura. Non la chiude: la fa chiudere all'utente, insistendo.
        await _prop_non_chiudibile(app, entry_id, int(tp), int(tb or 0), ALERT_COPERTURA_KO)
        return

    if aperto_b or aperto_p:
        # UNA sola gamba a mercato: e' un'esposizione scoperta -> va richiusa.
        lato   = "Broker" if aperto_b else "Prop"
        path   = MT5_BROKER_EXE if aperto_b else MT5_PROP_EXE
        cred   = broker if aperto_b else prop
        ticket = tb if aperto_b else tp
        chiuso = await _chiudi_con_retry(path, cred, int(ticket))
        if chiuso:
            await notifica_owner(app, (
                f"🛟 Recovery hedge dopo riavvio: trovata gamba {lato} ORFANA "
                f"(ticket {ticket}, l'altra gamba non era mai stata aperta).\n"
                f"↩️ L'ho RICHIUSA automaticamente: nessuna posizione scoperta."
            ))
            await journal_remove(entry_id)
        else:
            if not entry.get("alerted"):
                await notifica_owner(app, (
                    f"‼️ Recovery hedge: gamba {lato} ORFANA (ticket {ticket}) e NON "
                    f"riesco a richiuderla. Continuo a riprovare ogni minuto.\n"
                    f"Se persiste, CHIUDILA A MANO dal terminale {lato}."
                ))
            await journal_update(entry_id, status="orphan", alerted=True)
        return

    if tb or tp:
        # Una gamba e' esistita ma ora NON e' piu' aperta (chiusa da SL/TP o a
        # mano mentre il bot era giu'): nessuna esposizione residua.
        lato, ticket = ("Broker", tb) if tb else ("Prop", tp)
        await notifica_owner(app, (
            f"🛟 Recovery hedge dopo riavvio: la gamba {lato} (ticket {ticket}) era "
            f"stata aperta ma risulta GIA' CHIUSA (SL/TP o chiusura manuale). "
            f"L'altra gamba non era mai partita. Nessuna posizione scoperta; "
            f"verifica il P/L nello Storico."
        ))
        await journal_remove(entry_id)
        return

    # Nessuna gamba mai arrivata al mercato: l'intento muore senza rumore.
    logger.info(f"Recovery hedge {entry_id}: nessun ordine risulta eseguito, intento rimosso.")
    await journal_remove(entry_id)


async def _recover_challenge_open(app, entry_id: str, entry: dict,
                                  snap_p: list,
                                  challenge_trades: list) -> None:
    magic  = int(entry.get("magic", 0) or 0)
    ticket = int(entry.get("ticket") or 0) or _ticket_per_magic(snap_p, magic)
    if not ticket:
        logger.info(f"Recovery trade-sfida {entry_id}: nessun ordine risulta eseguito.")
        await journal_remove(entry_id)
        return

    registrato = any(
        isinstance(t, dict) and int(t.get("prop_ticket", 0) or 0) == ticket
        for t in challenge_trades
    )
    if registrato:
        await journal_remove(entry_id)
        return

    if ticket in _tickets_aperti(snap_p):
        # Aperto ma mai registrato (crash tra ordine e registrazione): ripristina
        # il piano originale. Il backstop nel loop lo chiudera' al close_at
        # previsto (o subito, se l'orario e' gia' passato).
        try:
            opened = datetime.fromisoformat(entry.get("created_utc", ""))
            if opened.tzinfo is None:
                opened = opened.replace(tzinfo=timezone.utc)
        except Exception:
            opened = datetime.now(timezone.utc)
        minuti   = float(entry.get("minuti", 0) or 0)
        close_at = opened + timedelta(minutes=minuti)
        record = {
            "id":            uuid.uuid4().hex,
            "prop_ticket":   ticket,
            "direzione":     entry.get("direzione", "BUY"),
            "lotti":         float(entry.get("lotti", 0) or 0),
            "minuti":        minuti,
            "opened_at_utc": opened.isoformat(),
            "close_at_utc":  close_at.isoformat(),
            "status":        "open",
        }
        await modifica_dati_async(partial(modifier_add_challenge_trade, trade=record))
        await notifica_owner(app, (
            f"🛟 Recovery trade-sfida dopo riavvio: posizione Prop (ticket {ticket}) "
            f"ritrovata e registrata. Verra' chiusa come da piano originale "
            f"({entry.get('minuti')} min dall'apertura)."
        ))
    else:
        await notifica_owner(app, (
            f"🛟 Recovery trade-sfida dopo riavvio: il trade (ticket {ticket}) risulta "
            f"GIA' CHIUSO. Nessuna posizione scoperta."
        ))
    await journal_remove(entry_id)


async def _recover_close_survivor(app, entry_id: str, entry: dict,
                                  broker: dict, prop: dict,
                                  snap_b: list, snap_p: list) -> None:
    """Gamba superstite individuata dal guardiano di coppia ma chiusura
    interrotta (crash) o fallita: si completa qui."""
    lato   = entry.get("lato", "broker")
    ticket = int(entry.get("ticket", 0) or 0)
    snap   = snap_b if lato == "broker" else snap_p
    if ticket <= 0 or ticket not in _tickets_aperti(snap):
        await journal_remove(entry_id)     # gia' chiusa: intento consumato
        return
    if lato != "broker" and await prop_sola_lettura():
        pair = entry.get("pair") or []
        altro = int(pair[0]) if pair else 0
        await _prop_non_chiudibile(app, entry_id, ticket, altro, ALERT_BROKER_CHIUSO)
        return
    etich = "Broker" if lato == "broker" else "Prop"
    cred  = broker if lato == "broker" else prop
    path  = MT5_BROKER_EXE if lato == "broker" else MT5_PROP_EXE
    if await _chiudi_con_retry(path, cred, ticket):
        await notifica_owner(app, (
            f"🛟 Recovery: la gamba {etich} superstite (ticket {ticket}) "
            f"e' stata RICHIUSA. Nessuna posizione scoperta."
        ))
        await journal_remove(entry_id)
    else:
        if not entry.get("alerted"):
            await notifica_owner(app, (
                f"‼️ Recovery: NON riesco a chiudere la gamba {etich} superstite "
                f"(ticket {ticket}). Continuo a riprovare; se persiste chiudila a mano."
            ))
        await journal_update(entry_id, alerted=True)


async def _recover_test_open(app, entry_id: str, entry: dict,
                             broker: dict, prop: dict,
                             snap_b: list, snap_p: list) -> None:
    """Test trading interrotto a meta' (crash tra la gamba Broker e quella
    Prop): le posizioni di prova vanno richiuse, non lasciate a mercato.

    Sono 0.01 lotti, ma su una prop una posizione fantasma puo' bastare a
    violare una regola — e comunque nessun percorso di mercato deve restare
    fuori dal giornale."""
    magic   = int(entry.get("magic", 0) or 0)
    rimasti: list = []
    sola_lettura = await prop_sola_lettura()
    for lato, snap, cred, path, etich in (
        ("broker", snap_b, broker, MT5_BROKER_EXE, "Broker"),
        ("prop",   snap_p, prop,   MT5_PROP_EXE,   "Prop"),
    ):
        ticket = int(entry.get(f"ticket_{lato}") or 0) or _ticket_per_magic(snap, magic)
        if not ticket or ticket not in _tickets_aperti(snap):
            continue
        if lato == "prop" and sola_lettura:
            # Prova aperta prima del passaggio alla semi-automatica: la chiude
            # l'utente, il bot non ha piu' i permessi.
            from .loops import segnala_prop_scoperta
            await segnala_prop_scoperta(app, ticket, 0, ALERT_DA_CHIUDERE)
            rimasti.append(f"⚠️ {etich} {ticket} da chiudere A MANO (sola lettura)")
            continue
        if await _chiudi_con_retry(path, cred, int(ticket)):
            rimasti.append(f"{etich} {ticket} richiusa")
        else:
            rimasti.append(f"⚠️ {etich} {ticket} NON richiusa")

    if any(r.startswith("⚠️") for r in rimasti):
        if not entry.get("alerted"):
            await notifica_owner(app, (
                "‼️ Recovery test trading: non riesco a chiudere una posizione "
                f"di prova ({', '.join(rimasti)}). Continuo a riprovare; "
                "se persiste chiudila a mano dal terminale."
            ))
        await journal_update(entry_id, status="orphan", alerted=True)
        return
    if rimasti:
        await notifica_owner(app, (
            f"🛟 Recovery test trading dopo riavvio: {', '.join(rimasti)}. "
            f"Nessuna posizione di prova lasciata aperta."
        ))
    else:
        logger.info(f"Recovery test {entry_id}: nessuna posizione di prova residua.")
    await journal_remove(entry_id)


async def _recover_semiauto_cover(app, entry_id: str, entry: dict,
                                  snap_b: list, snap_p: list,
                                  trade_memos: dict) -> None:
    """Copertura semi-automatica interrotta: la prop e' gia' a mercato (l'ha
    aperta l'utente) e mancava solo la gamba broker.

    Tre esiti possibili, tutti obbligati:
      • la copertura ESISTE (o e' esistita) ma non era stata registrata -> si
        registra: da quel momento monitor, guardiano e ricevute la vedono;
      • la copertura NON c'e' e la prop e' ancora aperta -> e' scoperta: allarme
        all'utente, che e' l'unico che puo' chiuderla;
      • la copertura non c'e' e nemmeno la prop -> non e' successo nulla.
    """
    magic = int(entry.get("magic", 0) or 0)
    tp    = int(entry.get("ticket_prop") or 0)
    tb    = int(entry.get("ticket_broker") or 0) or _ticket_per_magic(snap_b, magic)

    if tb and tp:
        if str(tb) not in trade_memos and str(tp) not in trade_memos:
            payload = {
                "memo":                 entry.get("memo", ""),
                "timestamp":            datetime.now().isoformat(),
                "opened_at_utc":        entry.get("created_utc"),
                "modalita":             "semiauto",
                "direzione_broker":     entry.get("direzione_broker"),
                "direzione_prop":       entry.get("direzione_prop"),
                "lotti_broker":         entry.get("lotti_broker"),
                "lotti_prop":           entry.get("lotti_prop"),
                "sl_dol":               entry.get("sl_dol"),
                "tp_dol":               entry.get("tp_dol"),
                "ticket_broker":        tb,
                "ticket_prop":          tp,
                "broker_close_info":    None,
                "prop_close_info":      None,
                "pair_closed_notified": False,
                "closed_source":        None,
            }
            await modifica_dati_async(partial(
                modifier_save_trade_memo, ticket_b=tb, ticket_p=tp, payload=payload,
            ))
            await notifica_owner(app, (
                "🛟 Recovery semi-automatica: la copertura sul Broker "
                f"(ticket {tb}) risulta APERTA ma non era registrata. "
                f"L'ho abbinata alla posizione Prop {tp}: da ora il trade è "
                f"sorvegliato normalmente."
            ))
        await journal_remove(entry_id)
        return

    if tp and tp in _tickets_aperti(snap_p):
        await _prop_non_chiudibile(app, entry_id, tp, 0, ALERT_COPERTURA_KO)
        return

    logger.info(f"Recovery semi-automatica {entry_id}: nessuna posizione residua, intento rimosso.")
    await journal_remove(entry_id)


async def _recover_close_pairs(app, entry_id: str, entry: dict,
                               broker: dict, prop: dict,
                               snap_b: list, snap_p: list) -> None:
    aperti = {"broker": _tickets_aperti(snap_b), "prop": _tickets_aperti(snap_p)}
    creds  = {"broker": broker, "prop": prop}
    paths  = {"broker": MT5_BROKER_EXE, "prop": MT5_PROP_EXE}
    done   = set(entry.get("done") or [])
    falliti: list = []
    richiusi = 0
    # Chiusura di massa avviata PRIMA del passaggio alla semi-automatica: le
    # posizioni prop rimaste ora non sono piu' chiudibili dal bot.
    sola_lettura = await prop_sola_lettura()

    for lato in ("broker", "prop"):
        for ticket in entry.get(f"tickets_{lato}", []) or []:
            ticket = int(ticket)
            token  = f"{lato}:{ticket}"
            if token in done:
                continue
            if ticket not in aperti[lato]:
                done.add(token)      # gia' chiusa (dal mercato o in precedenza)
                continue
            if lato == "prop" and sola_lettura:
                from .loops import segnala_prop_scoperta
                await segnala_prop_scoperta(app, ticket, 0, ALERT_DA_CHIUDERE)
                done.add(token)      # non e' lavoro nostro: ora e' dell'utente
                continue
            if await _chiudi_con_retry(paths[lato], creds[lato], ticket):
                done.add(token)
                richiusi += 1
            else:
                falliti.append(token)

    await journal_update(entry_id, done=sorted(done))
    if falliti:
        if not entry.get("alerted"):
            await notifica_owner(app, (
                "‼️ Recovery chiusura di massa: NON riesco a chiudere "
                f"{len(falliti)} posizioni ({', '.join(falliti)}). "
                "Continuo a riprovare ogni minuto; se persiste chiudile a mano."
            ))
            await journal_update(entry_id, alerted=True)
        return

    if richiusi:
        await notifica_owner(app, (
            f"🛟 Recovery dopo riavvio: la chiusura di massa era stata interrotta; "
            f"ho chiuso le {richiusi} posizioni rimanenti. "
            f"Le notifiche di chiusura con P/L arrivano dal monitor come di consueto."
        ))
    await journal_remove(entry_id)


async def recover_journal(app, solo_stantii: bool = False) -> int:
    """Recupera gli intenti interrotti. Ritorna il numero di intenti processati.
    Chiamata al boot (solo_stantii=False) e periodicamente dal loop programmato
    (solo_stantii=True: ignora le operazioni legittimamente in corso)."""
    dati    = await carica_dati_async()
    journal = dati.get(JOURNAL_KEY) or {}
    da_fare = {
        k: v for k, v in journal.items()
        if isinstance(v, dict) and _entry_recuperabile(v, solo_stantii)
    }
    if not da_fare:
        return 0

    broker = dati.get("broker")
    prop   = dati.get("prop")
    if not broker or not prop:
        logger.warning("Recovery giornale rimandato: credenziali assenti.")
        return 0

    # REGOLA D'ORO: senza una fotografia CERTA delle posizioni aperte (None =
    # MT5 irraggiungibile) non si agisce. Gli intenti restano e si riprova.
    snap_b = await _get_open_positions_snapshot_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    )
    snap_p = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if snap_b is None or snap_p is None:
        logger.warning("Recovery giornale rimandato: MT5 non raggiungibile.")
        return 0

    trade_memos      = dati.get("trade_memos", {}) or {}
    challenge_trades = dati.get("challenge_trades", []) or []
    n = 0
    for entry_id, entry in da_fare.items():
        try:
            kind = entry.get("kind")
            logger.warning(f"Recovery giornale: intento '{kind}' {entry_id} interrotto, rimedio.")
            if kind == "hedge_open":
                await _recover_hedge_open(app, entry_id, entry, broker, prop,
                                          snap_b, snap_p, trade_memos)
            elif kind == "challenge_open":
                await _recover_challenge_open(app, entry_id, entry,
                                              snap_p, challenge_trades)
            elif kind == "semiauto_cover":
                await _recover_semiauto_cover(app, entry_id, entry,
                                              snap_b, snap_p, trade_memos)
            elif kind == "close_pairs":
                await _recover_close_pairs(app, entry_id, entry, broker, prop,
                                           snap_b, snap_p)
            elif kind == "close_survivor":
                await _recover_close_survivor(app, entry_id, entry, broker, prop,
                                              snap_b, snap_p)
            elif kind == "test_open":
                await _recover_test_open(app, entry_id, entry, broker, prop,
                                         snap_b, snap_p)
            else:
                logger.error(f"Recovery giornale: kind sconosciuto '{kind}', intento rimosso.")
                await journal_remove(entry_id)
            n += 1
        except Exception:
            logger.exception(f"Recovery giornale: errore sull'intento {entry_id} (riprovo al prossimo giro).")
    return n
