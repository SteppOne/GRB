import json
import logging
from functools import partial
from typing import Dict, Any, Optional, Tuple

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
)

logger = logging.getLogger(__name__)

from .storage import carica_dati_async, leggi_chiave_async, modifica_dati_async
from .state import modifier_update_trade_memo
from .mt5_sync import MSG_AUTOTRADING_OFF

# ========================= CALLBACK QUERY ACK SICURO =========================
async def ack(query, text: Optional[str] = None, show_alert: bool = False) -> bool:
    """Acknowledge idempotente. Assorbe BadRequest "Query is too old"."""
    if query is None:
        return False
    try:
        if text is None:
            await query.answer()
        else:
            await query.answer(text=text, show_alert=show_alert)
        return True
    except Exception as e:
        logger.debug(f"ack() ignorato per query scaduta/non valida: {e}")
        return False

# ========================= TASTIERA ANNULLA =========================
def _cancel_kb(callback_data: str = "annulla") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ Annulla", callback_data=callback_data)]
    ])

def _kb_errore_ordine(msg: str, back_cb: str = "manuale") -> InlineKeyboardMarkup:
    """Tastiera per un ordine fallito. Se il motivo e' l'AutoTrading spento NEL
    TERMINALE (retcode 10027, riconosciuto via MSG_AUTOTRADING_OFF), aggiunge il
    pulsante per riavviare IL TERMINALE GIUSTO — broker o prop, mai entrambi —
    che al riavvio forza l'Algo Trading ON. Cosi' l'utente recupera dal bot,
    senza aprire la VPS. Negli altri casi: solo 'Indietro'."""
    righe = []
    if MSG_AUTOTRADING_OFF in msg:
        if "Ordine Broker non aperto" in msg:
            righe.append([InlineKeyboardButton("🔄 Riavvia terminale Broker", callback_data="riavvia_broker")])
        elif "Ordine Prop non aperto" in msg:
            righe.append([InlineKeyboardButton("🔄 Riavvia terminale Prop", callback_data="riavvia_prop")])
    righe.append(back_button(back_cb))
    return InlineKeyboardMarkup(righe)

# ========================= SAFE MESSAGE EDIT =========================
async def safe_edit_message_text(query, text, reply_markup=None):
    """Modifica il messaggio solo se contenuto o tastiera sono cambiati."""
    try:
        msg = query.message
        current_text   = msg.text or msg.caption or ""
        current_markup = msg.reply_markup
        new_markup_json = json.dumps(reply_markup.to_dict(), sort_keys=True) if reply_markup else None
        old_markup_json = json.dumps(current_markup.to_dict(), sort_keys=True) if current_markup else None
        if current_text == text and new_markup_json == old_markup_json:
            await ack(query)
            return
        await query.edit_message_text(text, reply_markup=reply_markup)
    except Exception as e:
        err_msg = str(e)
        if "Message is not modified" in err_msg:
            await ack(query)
            return
        logger.warning(f"safe_edit_message_text fallito: {e}")
        await ack(query, "Messaggio non più disponibile.", show_alert=True)

# ========================= HELPER MEMO / TRADE PAIR =========================
def _compose_trade_close_message(
    record: Dict[str, Any],
    broker_info: Optional[Dict[str, Any]],
    prop_info: Optional[Dict[str, Any]],
    trigger_label: str = "automaticamente",
) -> str:
    memo = record.get("memo", "").strip()

    def side_line(label: str, info: Optional[Dict[str, Any]]) -> str:
        if not info:
            return f"• Guadagno/Perdita {label}: n/d"
        pnl = float(info.get("profit", 0.0) or 0.0)
        # Niente motivo tra parentesi qui: il titolo del messaggio indica gia'
        # se la chiusura e' avvenuta per SL o TP.
        return f"• Guadagno/Perdita {label}: {pnl:+.2f}$"

    # COMANDA LA PROP: l'esito (Stop Loss / Take Profit) si determina dalla gamba
    # PROP. Nell'hedge la gamba Broker e' opposta (se la prop fa TP, il broker fa
    # SL): basarsi sul broker darebbe l'etichetta sbagliata. Fallback al broker
    # solo se manca del tutto il dato della prop.
    prop_reason   = (prop_info or {}).get("reason_label")
    broker_reason = (broker_info or {}).get("reason_label")
    reason_finale = prop_reason or broker_reason
    headline_reason = f" ({reason_finale})" if reason_finale else ""

    # La ricevuta parla la lingua della modalita' con cui il trade e' stato
    # APERTO (campo salvato nel memo), non di quella attiva adesso: se nel
    # frattempo l'utente ha cambiato modalita', il resoconto resta fedele a
    # com'e' andata davvero.
    if str(record.get("modalita") or "") == "semiauto":
        msg = f"✅ Trade semi-automatico chiuso automaticamente{headline_reason}.\n\n"
    else:
        msg = f"✅ Trade chiuso {trigger_label}{headline_reason}.\n\n"
    msg += side_line("Prop",   prop_info) + "\n"
    msg += side_line("Broker", broker_info)
    if memo:
        msg += f"\n\nMEMO: {memo}"
    return msg

def _trade_pair_key(record: Dict[str, Any]) -> Tuple[int, int]:
    return (int(record.get("broker_ticket", 0)), int(record.get("prop_ticket", 0)))

async def _mark_trade_pair_closed(ticket_b: int, ticket_p: int, updates: Dict[str, Any]) -> None:
    await modifica_dati_async(
        partial(modifier_update_trade_memo, ticket_b=ticket_b, ticket_p=ticket_p, updates=updates)
    )

async def get_trade_record_by_ticket(ticket: int) -> Dict[str, Any]:
    dati = await carica_dati_async()
    return dati.get("trade_memos", {}).get(str(ticket), {}) or {}

async def get_memo_by_ticket(ticket: int) -> str:
    return (await get_trade_record_by_ticket(ticket)).get("memo", "")

async def notifica_owner(app: Application, testo: str, reply_markup=None) -> bool:
    """Manda un messaggio all'owner. Ritorna l'esito REALE della consegna.

    Il valore di ritorno serve a chi deve poi dichiarare ad altri se il cliente
    ha ricevuto o no (avvisi di scadenza -> canale admin): senza, un utente che
    ha bloccato il bot era indistinguibile da uno raggiunto. La quasi totalita'
    dei chiamanti lo ignora, ed e' giusto cosi': per loro resta best-effort.
    """
    # leggi_chiave_async: una notifica non ha bisogno di una copia profonda
    # dell'intero stato (trade_memos inclusi) solo per leggere un chat-id.
    owner_id = await leggi_chiave_async("owner_chat_id")
    if not owner_id:
        # Prima questo caso era muto anche nel log: nessuna traccia del fatto
        # che il messaggio non fosse mai partito.
        logger.error("Notifica non inviata: owner_chat_id assente (mai fatto /start?).")
        return False
    try:
        await app.bot.send_message(chat_id=owner_id, text=testo, reply_markup=reply_markup)
        return True
    except Exception as e:
        logger.error(f"Impossibile notificare owner: {e}")
        return False

def back_button(callback: str) -> list:
    return [InlineKeyboardButton("⬅️ Indietro", callback_data=callback)]
