"""Modalita' operativa del bot: automatica (storica) o semi-automatica.

UNA sola domanda decide il comportamento di mezzo bot: "la prop la comanda il
bot o la comanda l'utente?".

  normale_auto      il bot apre e chiude entrambe le gambe. E' la modalita' di
                    sempre: nessun percorso cambia, nessuna regressione.

  normale_semiauto  sulla prop l'utente opera A MANO dal MetaTrader del
                    telefono e nel bot mette la password di SOLA LETTURA. Da
                    quel momento il bot sulla prop puo' solo GUARDARE: guida
                    l'apertura, verifica i livelli, apre la copertura sul
                    broker, sorveglia la coppia e — quando servirebbe chiudere
                    la prop — AVVISA invece di provarci, perche' un ordine di
                    chiusura verrebbe rifiutato dal server (retcode 10017).

Questo modulo e' il posto UNICO da cui si legge la modalita'. Chi deve sapere
se puo' toccare la prop chiama `prop_sola_lettura()`, che dice esattamente
quello — non "siamo in semiauto" — cosi' il codice chiamante spiega da solo
perche' si comporta cosi'.
"""
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

from .config import MODALITA_AUTO, MODALITA_DEFAULT, MODALITA_SEMIAUTO
from .storage import leggi_chiave_async

CHIAVE_MODALITA = "modalita_operativa"

# Come l'utente puo' scriverla nel comando /modalita. I nomi ufficiali sono i
# due del documento; gli altri sono scorciatoie tollerate (chi scrive da
# telefono non ha voglia di digitare "normale_semiauto" ogni volta).
_ALIAS = {
    "normale_auto":     MODALITA_AUTO,
    "auto":             MODALITA_AUTO,
    "automatica":       MODALITA_AUTO,
    "automatico":       MODALITA_AUTO,
    "normale":          MODALITA_AUTO,
    "normale_semiauto": MODALITA_SEMIAUTO,
    "semiauto":         MODALITA_SEMIAUTO,
    "semi_auto":        MODALITA_SEMIAUTO,
    "semiautomatica":   MODALITA_SEMIAUTO,
    "semiautomatico":   MODALITA_SEMIAUTO,
    "semi":             MODALITA_SEMIAUTO,
}

ETICHETTE = {
    MODALITA_AUTO:     "automatica",
    MODALITA_SEMIAUTO: "semi-automatica",
}


def normalizza_modalita(testo: Any) -> Optional[str]:
    """Testo digitato dall'utente -> nome ufficiale della modalita' (o None).

    Accetta spazi al posto degli underscore ("normale semiauto") perche' su
    telefono l'underscore e' scomodo e l'utente scrive come parla.
    """
    if not testo:
        return None
    chiave = str(testo).strip().lower().replace("-", "_").replace(" ", "_")
    while "__" in chiave:
        chiave = chiave.replace("__", "_")
    return _ALIAS.get(chiave)


def modalita_da_dati(dati: Optional[Dict[str, Any]]) -> str:
    """Modalita' letta da uno stato gia' in mano (nessun accesso al disco).

    Un valore sconosciuto (stato manomesso, downgrade) vale automatica: la
    modalita' storica e' l'unica che non presuppone nulla sulle credenziali.
    """
    valore = (dati or {}).get(CHIAVE_MODALITA)
    return valore if valore in ETICHETTE else MODALITA_DEFAULT


async def modalita_corrente() -> str:
    """Modalita' attiva adesso. Lettura di una sola chiave: nessuna copia
    profonda dell'intero stato (viene chiamata da loop molto frequenti)."""
    valore = await leggi_chiave_async(CHIAVE_MODALITA)
    return valore if valore in ETICHETTE else MODALITA_DEFAULT


async def semiauto_attiva() -> bool:
    return (await modalita_corrente()) == MODALITA_SEMIAUTO


async def prop_sola_lettura() -> bool:
    """Il bot puo' inviare ordini alla PROP?  False = solo lettura.

    Alias volutamente esplicito di `semiauto_attiva`: nei punti che stanno per
    chiudere o aprire qualcosa sulla prop, il nome della funzione deve dire il
    MOTIVO del controllo, non la modalita' in cui ci si trova.
    """
    return await semiauto_attiva()


def etichetta(modalita: str) -> str:
    return ETICHETTE.get(modalita, ETICHETTE[MODALITA_DEFAULT])
