import logging
import os
import time
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Dict, Any, List, Optional, Tuple

import MetaTrader5 as mt5

logger = logging.getLogger(__name__)

# NIENTE import da .config, DELIBERATAMENTE. Questo modulo e' l'unica
# dipendenza dei processi WORKER (vedi mt5_worker), che vengono generati con
# 'spawn' e re-importano tutta la catena: passando da config si tirerebbero
# dentro telegram, telegram.ext, cryptography e psutil in OGNI worker, senza
# usarne una riga. BASE_DIR e' identico a quello di config.py (entrambi i file
# vivono in alebot/, quindi il padre del pacchetto e' la cartella del bot).
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ========================= AUTOTRADING (Algo Trading) =========================
# File .ini che FORZA l'AutoTrading ("Algo Trading") ON all'avvio del terminale.
# MT5 lo applica con:  terminal64.exe /config:<file>.  Sezione [Experts] con
# AllowLiveTrading=1 (verificato sulla documentazione ufficiale MetaQuotes).
MT5_AUTOTRADE_INI = os.path.join(BASE_DIR, "mt5_autotrading.ini")
_MT5_AUTOTRADE_INI_CONTENUTO = (
    "; Generato da AleBot: forza l'AutoTrading (Algo Trading) ON all'avvio del terminale.\n"
    "[Experts]\n"
    "Enabled=1\n"
    "AllowLiveTrading=1\n"
    "AllowDllImport=0\n"
)

def _short_path(path: str) -> str:
    """Path Windows in forma corta 8.3 (senza spazi): sicuro per /config: senza
    problemi di quoting (BASE_DIR puo' contenere spazi). Fallback al path
    originale se l'API non e' disponibile o la generazione 8.3 e' disattivata."""
    try:
        import ctypes
        from ctypes import wintypes
        _GetShort = ctypes.windll.kernel32.GetShortPathNameW
        _GetShort.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD]
        _GetShort.restype  = wintypes.DWORD
        buf = ctypes.create_unicode_buffer(600)
        n = _GetShort(path, buf, 600)
        if n and n < 600 and buf.value:
            return buf.value
    except Exception:
        pass
    return path

def _config_autotrading_arg(credenziali: Optional[Dict[str, str]] = None) -> Optional[str]:
    """Scrive l'ini di avvio del terminale e ritorna '/config:<path-corto>'.

    Oltre a forzare l'AutoTrading ON, se riceve le credenziali aggiunge la
    sezione [Common] con Login/Password/Server.

    PERCHE' E' DECISIVO (guasto reale del 26/07/2026):
    mt5.login() dall'API Python cambia il conto ATTIVO del terminale ma NON
    salva la password. Al riavvio successivo — che sia il nostro pulsante o un
    aggiornamento automatico di MT5 — il terminale prova a riaprire quell'ultimo
    conto, non ha la password e si ferma su una FINESTRA MODALE. Da quel momento
    l'IPC non risponde piu': il bot non puo' autenticarsi, perche' per farlo gli
    servirebbe proprio il canale che la finestra sta bloccando. Stallo totale,
    risolvibile solo entrando sulla VPS.
    Avviando il terminale con le credenziali nell'ini, il conto giusto e' gia'
    connesso all'apertura: la finestra non compare mai.

    ATTENZIONE: il file contiene la password in chiaro. Vive pochi secondi —
    il chiamante DEVE invocare _rimuovi_config_avvio() appena il terminale e'
    partito (MT5 legge l'ini solo all'avvio).
    """
    contenuto = _MT5_AUTOTRADE_INI_CONTENUTO
    if credenziali and all(credenziali.get(k) for k in ("id", "password", "server")):
        contenuto = (
            "[Common]\n"
            f"Login={int(credenziali['id'])}\n"
            f"Password={credenziali['password']}\n"
            f"Server={credenziali['server']}\n"
            "\n"
        ) + contenuto
    try:
        with open(MT5_AUTOTRADE_INI, "w", encoding="utf-8") as f:
            f.write(contenuto)
    except OSError:
        logger.warning("Config AutoTrading non scrivibile: avvio terminale senza /config.")
        return None
    return f"/config:{_short_path(MT5_AUTOTRADE_INI)}"


def _rimuovi_config_avvio() -> None:
    """Cancella l'ini di avvio: puo' contenere la password del conto e non deve
    restare su disco un secondo piu' del necessario."""
    try:
        if os.path.exists(MT5_AUTOTRADE_INI):
            os.remove(MT5_AUTOTRADE_INI)
    except OSError as e:
        logger.warning(f"Impossibile rimuovere {MT5_AUTOTRADE_INI}: {e}")

# ========================= TIMEOUT E QUARANTENA TERMINALE =========================
# L'API MetaTrader5 ha un timeout di DEFAULT di 60 SECONDI su initialize() e
# altri 60 su login(). Un terminale che chiede la password del conto (tipico
# dopo un aggiornamento MT5: la password salvata viene persa) fa quindi
# bloccare OGNI chiamata per un minuto o due. Con il guardiano di coppia che
# ritenta ogni 2 secondi, il lock del terminale risultava occupato quasi
# sempre: i comandi Telegram si accodavano e il bot sembrava morto.
# Qui il tetto e' esplicito e basso: un guasto si scopre in secondi, non in minuti.
# Due tetti DIVERSI, perche' i due passi hanno tempi diversi:
#  - initialize: se il terminale e' appena ripartito deve ancora avviarsi,
#    collegarsi al server e sincronizzare i simboli. Nei log reali del
#    26/07/2026 sono serviti da 12 a 40 SECONDI. Un tetto stretto qui era il
#    difetto peggiore: abbandonavamo la chiamata un attimo prima che riuscisse.
#  - login: e' un solo giro di rete verso il broker, 20s sono abbondanti.
# Restano comunque MOLTO sotto i 60+60 s di default dell'API MT5.
MT5_INIT_TIMEOUT_MS  = 45_000
MT5_LOGIN_TIMEOUT_MS = 20_000
MT5_CONNECT_TIMEOUT_MS = MT5_INIT_TIMEOUT_MS   # compatibilita' nome storico

# Dopo N fallimenti di AUTENTICAZIONE consecutivi sullo stesso terminale non ha
# piu' senso martellarlo: la password non cambia da sola. Il terminale entra in
# "quarantena" e le chiamate falliscono ISTANTANEAMENTE (invece di sprecare
# 10s ciascuna tenendo occupato il lock), finche' non scade la finestra di
# backoff. Alla scadenza passa UNA sonda: se il login torna a funzionare, la
# quarantena si azzera da sola. Nessun intervento manuale richiesto.
AUTH_KO_PRIMA_DI_QUARANTENA = 3
QUARANTENA_BACKOFF_S = (15, 60, 300)   # progressivo, poi resta a 300s

# ---- Motivo dell'ULTIMO fallimento di autenticazione, per terminale ----
# mt5.shutdown() AZZERA mt5.last_error(): verificato sull'API MetaTrader5
# 5.0.5735 — dopo uno shutdown last_error() risponde (1, 'Success') qualunque
# cosa sia appena andata storta. connessione_mt5 chiude SEMPRE la sessione sui
# percorsi d'errore, quindi chi la chiamava e poi leggeva last_error() per
# capire il motivo trovava "Success" e scambiava un rifiuto del broker per un
# guasto tecnico. Qui il motivo viene fotografato NELL'ISTANTE del guasto.
_ultimo_esito_auth: Dict[str, Dict[str, Any]] = {}

# Sotto questa soglia i codici MT5 sono guasti di TRASPORTO (-10000..-10005:
# IPC, invio, ricezione, init, connect, timeout). Sopra (-1..-8) e' il
# terminale che ha risposto "no": il canale funzionava.
MT5_SOGLIA_ERRORI_INTERNI = -10000
# Autenticazione rifiutata. Arriva sia da login() sia da initialize(): in
# quest'ultimo caso significa "il terminale non e' collegato a nessun conto"
# quando l'initialize e' nudo, e "credenziali rifiutate" quando gliele
# passiamo. La classificazione NON si basa su questo codice da solo: vedi
# _rifiuto_del_broker.
MT5_ERR_AUTH_FAILED = -6

def _ricorda_esito_auth(
    path: str, passo: str, errore: Any, con_credenziali: bool = False,
) -> None:
    try:
        codice, messaggio = int(errore[0]), str(errore[1])
    except (TypeError, ValueError, IndexError):
        codice, messaggio = None, str(errore)
    _ultimo_esito_auth[path] = {
        "passo": passo, "codice": codice, "messaggio": messaggio,
        # Se le credenziali erano nella chiamata, un rifiuto parla di LORO e
        # non della salute del terminale (vedi _rifiuto_del_broker).
        "con_credenziali": bool(con_credenziali),
    }

# Ultime credenziali VALIDE viste su ciascun terminale (solo in RAM, dentro il
# worker che serve quel terminale: non tocca mai il disco).
# Servono a _mt5_attach: le sue chiamate — stato del terminale, data del
# server, validazione di un simbolo — non ricevono credenziali, e senza di
# esse un terminale che si e' scollegato non torna piu' su.
_ultime_credenziali: Dict[str, Dict[str, Any]] = {}

def _e_auth_failed(errore: Any) -> bool:
    """L'errore MT5 e' "autenticazione rifiutata" (-6)?

    Sull'initialize NUDO significa "il terminale non e' collegato a nessun
    conto"; con le credenziali significa "queste credenziali non vanno". Due
    cose diverse, stesso codice: chi chiama deve sapere quale delle due.
    """
    try:
        return int(errore[0]) == MT5_ERR_AUTH_FAILED
    except (TypeError, ValueError, IndexError):
        return False

def _motivo_ko(errore: Any) -> str:
    """Testo del guasto per la quarantena e per l'avviso all'owner.

    Distingue "il terminale non risponde" da "l'autenticazione e' stata
    rifiutata": il loop di salute ci si basa (stato_sessione_sync cerca la
    parola "rifiutato") per dire all'utente se riavviare il terminale o
    aggiornare le credenziali, e per NON riavviarlo a vuoto. Passando le
    credenziali all'initialize, un -6 arriva ora anche da li': senza questa
    distinzione l'auto-recovery avrebbe continuato a riavviare un terminale
    sano per una password sbagliata.
    """
    if _e_auth_failed(errore):
        return f"login rifiutato {errore}"
    return f"terminale non raggiungibile {errore}"

def ultimo_esito_auth(path: str) -> Dict[str, Any]:
    """Com'e' fallita l'ultima autenticazione su questo terminale:
    {"passo": "initialize"|"login", "codice": int|None, "messaggio": str}."""
    return dict(_ultimo_esito_auth.get(path) or {})

def _rifiuto_del_broker(esito: Dict[str, Any]) -> bool:
    """Il terminale ha RISPOSTO "no", oppure non ha risposto affatto?

    Il discriminante e' il PASSO fallito, non il codice: se e' caduta la login,
    l'IPC funzionava e il terminale ha parlato col broker — quindi e' un
    rifiuto di credenziali/server, e insistere e' inutile. Restano tecnici i
    codici interni (timeout di rete verso il broker compreso), dove ritentare
    ha senso. Prima si guardava solo il codice -6, e ogni altro rifiuto
    (server inesistente, conto non su quel server) finiva tra i guasti tecnici.

    Anche l'INITIALIZE parla col broker, ma solo quando gli passiamo le
    credenziali: li' autentica, e un suo "no" e' un rifiuto a tutti gli
    effetti. Un initialize nudo che fallisce con -6 dice invece soltanto che
    il terminale non e' collegato a nessun conto — e quello e' un guasto da
    ritentare, non una password sbagliata.
    """
    codice = esito.get("codice")
    if codice is None or codice <= MT5_SOGLIA_ERRORI_INTERNI:
        return False
    if esito.get("passo") == "login":
        return True
    return bool(esito.get("con_credenziali"))

_stato_terminali: Dict[str, Dict[str, Any]] = {}

def _stato_term(path: str) -> Dict[str, Any]:
    return _stato_terminali.setdefault(
        path, {"auth_ko": 0, "quarantena_fino_a": 0.0, "login": None,
               "motivo": "", "primo_ko": 0.0},
    )

def _quarantena_attiva(path: str) -> bool:
    return time.monotonic() < _stato_term(path)["quarantena_fino_a"]

def _registra_auth_ko(path: str, login: int, motivo: str) -> None:
    st = _stato_term(path)
    if not st["auth_ko"]:
        # Istante del PRIMO guasto della serie: e' cio' che permette di
        # distinguere un intoppo passeggero (il terminale sta ancora avviandosi)
        # da un guasto persistente. Solo il secondo giustifica un intervento.
        st["primo_ko"] = time.monotonic()
    st["auth_ko"] += 1
    st["login"]    = int(login)
    st["motivo"]   = motivo
    if st["auth_ko"] >= AUTH_KO_PRIMA_DI_QUARANTENA:
        idx = min(st["auth_ko"] - AUTH_KO_PRIMA_DI_QUARANTENA, len(QUARANTENA_BACKOFF_S) - 1)
        attesa = QUARANTENA_BACKOFF_S[idx]
        st["quarantena_fino_a"] = time.monotonic() + attesa
        logger.error(
            f"Terminale {os.path.basename(os.path.dirname(path))}: "
            f"{st['auth_ko']} autenticazioni fallite di fila sul conto {login} "
            f"({motivo}). Sospendo i tentativi per {attesa}s per non bloccare il bot."
        )

def _ricorda_credenziali(path: str, login: int, password: str, server: str) -> None:
    """Fotografa le credenziali che hanno appena funzionato su questo terminale.
    Le riusera' _mt5_attach per rimettere in piedi un terminale scollegato."""
    _ultime_credenziali[path] = {
        "login": int(login), "password": password, "server": server,
    }

def _registra_auth_ok(path: str) -> None:
    st = _stato_term(path)
    if st["auth_ko"]:
        logger.info(
            f"Terminale {os.path.basename(os.path.dirname(path))}: "
            f"autenticazione tornata OK, quarantena azzerata."
        )
    st.update({"auth_ko": 0, "quarantena_fino_a": 0.0, "motivo": "", "primo_ko": 0.0})
    # Anche il motivo dell'ultimo guasto e' acqua passata: lasciarlo li'
    # farebbe diagnosticare col guasto di ieri il fallimento di domani.
    _ultimo_esito_auth.pop(path, None)

def stato_sessione_sync(path: str) -> Dict[str, Any]:
    """Salute dell'autenticazione su questo terminale, per la diagnostica e per
    l'avviso all'owner. Non tocca MT5: legge solo lo stato accumulato."""
    st = _stato_term(path)
    motivo = st["motivo"] or ""
    return {
        "auth_ko":     st["auth_ko"],
        "in_quarantena": _quarantena_attiva(path),
        "login":       st["login"],
        "motivo":      motivo,
        "secondi_alla_riprova": max(0, int(st["quarantena_fino_a"] - time.monotonic())),
        # Da quanto dura ININTERROTTAMENTE il guasto (0 = tutto a posto).
        "secondi_di_guasto": (
            int(time.monotonic() - st["primo_ko"]) if st["primo_ko"] else 0
        ),
        # Il terminale RISPONDE ma rifiuta le credenziali? In quel caso
        # riavviarlo non serve a nulla: e' un problema di password, non di
        # processo. Distinzione indispensabile prima di agire da soli.
        "credenziali_rifiutate": "rifiutato" in motivo.lower(),
    }

def azzera_quarantena_sync(path: Optional[str] = None) -> bool:
    """Sblocca subito i tentativi (dopo un riavvio del terminale o un cambio
    credenziali: la situazione e' cambiata, non ha senso aspettare il backoff).

    Butta via anche le credenziali memorizzate per quel terminale. Se sono
    appena cambiate, riautenticare con le VECCHIE porterebbe il terminale sul
    conto sbagliato — e info_account, che legge senza credenziali, mostrerebbe
    il saldo di un altro conto. Meglio nessuna scorciatoia che una sbagliata:
    la prima operazione vera le rimette a posto.
    """
    if path is None:
        _stato_terminali.clear()
        _ultime_credenziali.clear()
    else:
        _stato_term(path).update({"auth_ko": 0, "quarantena_fino_a": 0.0, "motivo": ""})
        _ultime_credenziali.pop(path, None)
    return True

# ========================= SESSIONE MT5 PERSISTENTE =========================
# Il pacchetto MetaTrader5 dialoga con UN terminale per volta. La v51 pagava
# initialize + login + shutdown per OGNI operazione (secondi, in coda su
# mt5_lock). Qui la connessione resta aperta tra le operazioni e cambia solo
# quando serve:
#   - stesso terminale + stesso account -> riuso diretto (zero round-trip);
#   - stesso terminale, altro account   -> solo mt5.login;
#   - terminale diverso (broker<->prop) -> shutdown + initialize (attach).
# Il login di rete viene saltato quando il terminale risulta gia' autenticato
# sull'account richiesto (account_info().login combacia): e' il costo maggiore
# della v51. Le verifiche credenziali usano force_login=True e NON saltano mai
# il login. Nessuna corsa: tutte le operazioni MT5 sono gia' serializzate da
# mt5_lock (vedi mt5_async).
_mt5_session: Dict[str, Any] = {"path": None}

def _mt5_disconnect() -> None:
    """Chiusura REALE della connessione IPC + reset sessione. Per i percorsi
    d'errore in cui lo stato della connessione non e' piu' affidabile."""
    _mt5_session["path"] = None
    try:
        mt5.shutdown()
    except Exception:
        pass

def _mt5_release() -> None:
    """Fine operazione: la connessione NON viene piu' chiusa (riuso sessione).
    Sostituisce i mt5.shutdown() di fine-chiamata della v51."""
    return None

def _mt5_alive() -> bool:
    """La sessione IPC corrente risponde? (terminale chiuso/riavviato -> False)"""
    try:
        return mt5.terminal_info() is not None
    except Exception:
        return False

def _mt5_initialize(
    path: str,
    login: Optional[int] = None,
    password: Optional[str] = None,
    server: Optional[str] = None,
) -> bool:
    """mt5.initialize con timeout ESPLICITO e, quando le abbiamo, le CREDENZIALI.

    Il timeout: senza, il default e' 60 secondi, e un terminale fermo su una
    finestra di login bloccherebbe il chiamante per un minuto intero, col lock
    del terminale in mano.

    LE CREDENZIALI (guasto diagnosticato sui log di produzione il 06/08/2026).
    Un terminale che non e' autenticato su NESSUN conto risponde all'initialize
    "nudo" con (-6, 'Terminal: Authorization failed'). E ci finisce da solo:
    mt5.login() cambia il conto attivo ma NON salva la password, quindi al
    primo riavvio il terminale riapre l'ultimo conto, non ha la password e
    resta li'. Da quel momento si formava uno stallo perfetto — il bot non
    poteva autenticarsi perche' initialize falliva, e initialize falliva
    perche' il terminale non era autenticato — da cui si usciva solo entrando
    a mano sulla VPS. Nei log: 7 fallimenti di fila, quarantena, auto-recovery
    esaurito ("raggiunto il tetto di 3 tentativi per oggi"), e la verifica
    delle credenziali che rimbalzava su un finto "guasto tecnico".
    L'API accetta login/password/server proprio per questo: initialize aggancia
    il terminale E lo autentica in un colpo solo, senza bisogno di riavviarlo.
    """
    parametri = {"path": path}
    if login is not None and password is not None and server is not None:
        parametri.update({"login": int(login), "password": password, "server": server})
    try:
        return bool(mt5.initialize(timeout=MT5_INIT_TIMEOUT_MS, **parametri))
    except TypeError:
        # Build dell'API senza il parametro timeout: comportamento storico.
        return bool(mt5.initialize(**parametri))

def _mt5_login(login: int, password: str, server: str) -> bool:
    """mt5.login con timeout ESPLICITO (vedi _mt5_initialize)."""
    try:
        return bool(mt5.login(login, password=password, server=server,
                              timeout=MT5_LOGIN_TIMEOUT_MS))
    except TypeError:
        return bool(mt5.login(login, password=password, server=server))

def _mt5_attach(path: str) -> bool:
    """Aggancio al terminale per le chiamate che NON hanno credenziali
    (stato del terminale, data del server, validazione di un simbolo).

    Se l'aggancio "nudo" fallisce perche' il terminale non e' collegato a
    nessun conto, si riprova con le ULTIME credenziali valide viste su questo
    terminale: e' l'unico modo di rimetterlo in piedi da qui.
    """
    if _mt5_session["path"] == path and _mt5_alive():
        return True
    # Terminale in quarantena: rispondi SUBITO invece di sprecare 10s. Le
    # schermate di stato mostreranno "Non connesso", che e' la verita'.
    if _quarantena_attiva(path):
        return False
    if _mt5_session["path"] is not None:
        _mt5_disconnect()
    if _mt5_initialize(path):
        _mt5_session["path"] = path
        return True

    errore = mt5.last_error()
    cred = _ultime_credenziali.get(path)
    if _e_auth_failed(errore) and cred:
        # Terminale scollegato: le credenziali lo rimettono in piedi.
        if _mt5_initialize(path, cred["login"], cred["password"], cred["server"]):
            logger.info(
                f"Terminale {os.path.basename(os.path.dirname(path))}: era "
                f"scollegato, riautenticato sul conto {cred['login']}."
            )
            _mt5_session["path"] = path
            _registra_auth_ok(path)
            return True
        errore = mt5.last_error()

    _mt5_session["path"] = None
    if _e_auth_failed(errore) and not cred:
        # NIENTE QUARANTENA QUI, ed e' il punto che rendeva lo stallo eterno.
        # -6 sull'aggancio nudo non dice "terminale rotto": dice "nessuno ci
        # ha ancora fatto il login". Contarlo come guasto metteva il terminale
        # in quarantena, e la quarantena bloccava connessione_mt5 — cioe'
        # l'unica chiamata che, avendo le credenziali, poteva rimetterlo in
        # piedi. Nei log di produzione: 87 fallimenti di fila e nove ore di
        # stallo che non si sarebbe sbloccato da solo mai.
        logger.warning(
            f"Terminale {os.path.basename(os.path.dirname(path))}: acceso ma "
            f"non collegato a nessun conto ({errore}). Attendo un'operazione "
            f"con credenziali per autenticarlo."
        )
        return False
    _registra_auth_ko(path, 0, f"terminale non raggiungibile ({errore})")
    return False

def _account_info_login() -> Optional[int]:
    """Login dell'account su cui il terminale corrente e' autenticato, o None."""
    try:
        info = mt5.account_info()
    except Exception:
        return None
    if info is None:
        return None
    return int(getattr(info, "login", 0) or 0)

# ========================= FUNZIONI MT5 (Sincrone) =========================
def connessione_mt5(
    path: str, login: int, password: str, server: str,
    force_login: bool = False, conta_guasti: bool = True,
) -> bool:
    """Garantisce: terminale `path` connesso e autenticato su `login`.

    Con force_login=True esegue SEMPRE mt5.login (necessario quando si
    VERIFICANO credenziali digitate dall'utente: il riuso della sessione
    non deve mai 'promuovere' una password sbagliata).

    Con conta_guasti=False il fallimento NON incrementa il contatore di
    quarantena. Serve alle verifiche INTERATTIVE: la quarantena esiste per
    impedire ai loop di fondo di martellare un terminale malato, non per
    punire chi sta digitando una password nuova. Senza, un paio di tentativi
    andati male durante la configurazione mettevano il terminale in
    quarantena, e l'utente si vedeva arrivare l'allarme "non riesco ad
    autenticarmi" mentre era proprio li' a sistemare le credenziali.
    """
    # QUARANTENA: questo terminale ha gia' rifiutato l'autenticazione piu' volte
    # di fila. Ritentare adesso costerebbe 10 secondi di lock per nulla — e con
    # il guardiano di coppia che chiama ogni 2s significava tenere il terminale
    # occupato in permanenza, accodare i comandi Telegram e far sembrare il bot
    # morto. Si fallisce all'istante; alla scadenza del backoff passa una sonda.
    # force_login (verifica credenziali digitate dall'utente) NON e' mai
    # sospeso: e' proprio l'azione con cui si esce dal guasto.
    if not force_login and _quarantena_attiva(path):
        return False

    # Sessione gia' attiva sul terminale richiesto?
    if _mt5_session["path"] == path:
        acc_login = _account_info_login()
        if acc_login is not None:
            if not force_login and acc_login == int(login):
                return True                      # riuso completo
            if _mt5_login(login, password, server):
                _ricorda_credenziali(path, login, password, server)
                _registra_auth_ok(path)
                return True                      # stesso terminale, login diretto
            if acc_login == int(login):
                # Stesso conto, login comunque rifiutato: la sessione non
                # c'entra, e' proprio la password. Nessun motivo di insistere.
                errore = mt5.last_error()
                logger.error(f"Login fallito per {path}, errore: {errore}")
                # PRIMA dello shutdown: dopo, last_error() dice "Success".
                _ricorda_esito_auth(path, "login", errore)
                if conta_guasti:
                    _registra_auth_ko(path, login, f"login rifiutato {errore}")
                _mt5_disconnect()
                return False
            # CONTO DIVERSO da quello a cui la sessione era agganciata: e' il
            # caso "stessa prop, account nuovo" (sfida superata -> conto reale,
            # stesso server, stesso terminale). MT5 deve prima scollegarsi dal
            # conto precedente, e su una sessione ancora sporca il login puo'
            # essere rifiutato anche con credenziali PERFETTE. Non ci si crede
            # al primo no: si riparte da zero qui sotto, una volta sola.
            logger.info(
                f"Login sul conto {login} rifiutato mentre la sessione era "
                f"agganciata al conto {acc_login}: riprovo da sessione pulita."
            )
        _mt5_disconnect()                        # sessione sporca o degradata
    elif _mt5_session["path"] is not None:
        _mt5_disconnect()                        # cambio terminale broker<->prop

    # Le credenziali vanno passate ALL'INITIALIZE: un terminale non autenticato
    # rifiuterebbe l'aggancio "nudo" con -6, e non ci sarebbe modo di uscirne.
    if not _mt5_initialize(path, login, password, server):
        errore = mt5.last_error()
        logger.error(f"initialize() fallita per {path}, errore: {errore}")
        _mt5_session["path"] = None
        _ricorda_esito_auth(path, "initialize", errore, con_credenziali=True)
        if conta_guasti:
            _registra_auth_ko(path, login, _motivo_ko(errore))
        return False
    _mt5_session["path"] = path
    # L'initialize con credenziali ha gia' autenticato: nessun login da fare.
    # force_login resta escluso apposta: quando si VERIFICA una password
    # digitata dall'utente non ci si fida di un terminale che risulta gia'
    # collegato a quel conto — potrebbe esserlo da prima, con la password
    # vecchia. Li' il login esplicito qui sotto e' l'unica prova valida.
    if not force_login and _account_info_login() == int(login):
        _ricorda_credenziali(path, login, password, server)
        _registra_auth_ok(path)
        return True                              # terminale gia' autenticato giusto
    if not _mt5_login(login, password, server):
        errore = mt5.last_error()
        logger.error(f"Login fallito per {path}, errore: {errore}")
        _ricorda_esito_auth(path, "login", errore)   # prima dello shutdown
        if conta_guasti:
            _registra_auth_ko(path, login, f"login rifiutato {errore}")
        _mt5_disconnect()
        return False
    _ultimo_esito_auth.pop(path, None)
    _ricorda_credenziali(path, login, password, server)
    _registra_auth_ok(path)
    return True

def verifica_mt5_credenziali_sync(path: str, login: int, password: str, server: str) -> bool:
    # force_login: le credenziali digitate vanno validate dal server, sempre.
    ok = connessione_mt5(path, login, password, server, force_login=True)
    try:
        return ok
    finally:
        _mt5_release()

def verifica_credenziali_dettagliata_sync(
    path: str, login: int, password: str, server: str,
) -> Tuple[str, str]:
    """Verifica le credenziali distinguendo il MOTIVO del fallimento.

    Ritorna (esito, dettaglio) con esito in:
      "ok"          -> login riuscito;
      "credenziali" -> il broker ha RIFIUTATO id/password/server (inutile insistere);
      "tecnico"     -> terminale occupato, non raggiungibile, timeout... (RITENTABILE).

    PERCHE' ESISTE: cambiando account sulla STESSA prop, il terminale e' gia'
    autenticato sul conto precedente e mt5.login() deve prima scollegarsi. Il
    primo tentativo puo' fallire per motivi puramente tecnici, mentre i loop di
    fondo (guardiano di coppia, baseline prop) continuano a riautenticare il
    VECCHIO account ogni pochi secondi. La v53 mostrava in entrambi i casi
    "Connessione fallita. Verifica credenziali." — e il cliente, con la password
    giusta in mano, non aveva modo di capire. Ora il chiamante sa se ritentare.
    """
    try:
        # conta_guasti=False: e' l'utente che sta digitando, non un loop che
        # martella. Un tentativo andato male non deve mettere in quarantena il
        # terminale proprio mentre si stanno sistemando le credenziali.
        ok = connessione_mt5(path, int(login), password, server,
                             force_login=True, conta_guasti=False)
    except Exception as e:
        logger.exception("verifica_credenziali_dettagliata_sync: errore imprevisto")
        return "tecnico", f"errore interno ({type(e).__name__}: {e})"
    finally:
        _mt5_release()
    if ok:
        return "ok", ""
    # Il motivo si legge da ultimo_esito_auth, NON da mt5.last_error(): a
    # questo punto connessione_mt5 ha gia' chiuso la sessione, e uno shutdown
    # riporta last_error() a (1, 'Success'). Leggerlo qui significava
    # classificare OGNI fallimento come "tecnico" — con tre ritentativi
    # inutili, la protezione anti-bruteforce mai attivata e un messaggio
    # ("il terminale non ha risposto in tempo") che mandava l'utente a
    # cercare il guasto dalla parte sbagliata.
    esito = ultimo_esito_auth(path)
    codice    = esito.get("codice")
    messaggio = esito.get("messaggio") or ""
    if _rifiuto_del_broker(esito):
        return "credenziali", f"il broker ha rifiutato l'accesso ({messaggio})"
    return "tecnico", f"MT5 non ha completato l'accesso (codice {codice}: {messaggio})"

def _verifica_ordine_esistente_sync(
    path: str, login: int, password: str, server: str, simbolo: str, magic: int,
) -> Optional[int]:
    """Cerca posizione gia' aperta col magic dato; usato per il retry sicuro
    degli ordini (una risposta None puo' nascondere un ordine gia' accettato)."""
    if not connessione_mt5(path, login, password, server):
        return None
    try:
        posizioni = mt5.positions_get(symbol=simbolo) or []
        for p in posizioni:
            if getattr(p, "magic", 0) == magic:
                return p.ticket
        return None
    finally:
        _mt5_release()

def _autotrading_attivo_sync(path: str, login: int, password: str, server: str) -> Optional[bool]:
    """Stato dell'AutoTrading (pulsante Algo Trading) nel terminale, via
    terminal_info().trade_allowed. Ritorna:
      True  -> Algo Trading ON,
      False -> Algo Trading OFF (le nuove operazioni verrebbero rifiutate),
      None  -> non determinabile (terminale non raggiungibile / info assente).
    Il None evita falsi allarmi: si avvisa solo su un False CERTO."""
    if not connessione_mt5(path, login, password, server):
        return None
    try:
        ti = mt5.terminal_info()
        if ti is None:
            return None
        return bool(getattr(ti, "trade_allowed", False))
    except Exception:
        return None
    finally:
        try:
            _mt5_release()
        except Exception:
            pass

def verifica_e_identifica_broker_sync(path: str, login: int, password: str, server: str):
    """Esegue il login MT5 e legge l'identita' REALE riportata dal server del broker.
    Ritorna (ok, server_reale, company). Se il login fallisce: (False, "", "").
    server_reale/company vengono dal broker dopo l'autenticazione: non sono falsificabili
    digitando un server fasullo (con credenziali sbagliate il login non riesce)."""
    if not connessione_mt5(path, int(login), password, server, force_login=True):
        try:
            _mt5_release()
        except Exception:
            pass
        return (False, "", "")
    try:
        info = mt5.account_info()
        if info is None:
            return (False, "", "")
        return (True, getattr(info, "server", "") or "", getattr(info, "company", "") or "")
    finally:
        try:
            _mt5_release()
        except Exception:
            pass

def verifica_e_identifica_broker_dettagliata_sync(
    path: str, login: int, password: str, server: str,
) -> Tuple[str, str, str, str]:
    """Come verifica_e_identifica_broker_sync, ma col MOTIVO del fallimento.
    Ritorna (esito, server_reale, company, dettaglio); esito come in
    verifica_credenziali_dettagliata_sync ("ok"/"credenziali"/"tecnico")."""
    esito, dettaglio = verifica_credenziali_dettagliata_sync(path, login, password, server)
    if esito != "ok":
        return esito, "", "", dettaglio
    try:
        info = mt5.account_info()
        if info is None:
            return "tecnico", "", "", "il terminale non espone i dati dell'account"
        return (
            "ok",
            getattr(info, "server", "") or "",
            getattr(info, "company", "") or "",
            "",
        )
    finally:
        try:
            _mt5_release()
        except Exception:
            pass

def info_account(
    path: str,
    login: Optional[int] = None,
    password: Optional[str] = None,
    server: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    # Se forniti, ci logghiamo ESPLICITAMENTE sull'account corretto (come tutte
    # le altre operazioni MT5). Con il solo initialize, account_info/positions_get
    # leggono l'account attualmente mostrato dal terminale, che puo' NON essere
    # quello su cui opera il bot: da qui i valori "statici"/errati (equity==balance,
    # P/L posizioni a 0 anche con trade aperti).
    if login is not None and password is not None and server is not None:
        if not connessione_mt5(path, int(login), password, server):
            logger.error(f"info_account: login fallito per {path}")
            return None
    else:
        if not _mt5_attach(path):
            logger.error(f"info_account: initialize fallita per {path}, errore: {mt5.last_error()}")
            return None
    info = mt5.account_info()
    if info is None:
        _mt5_disconnect()   # sessione degradata: la prossima chiamata riparte pulita
        return None
    posizioni  = mt5.positions_get()
    profit_tot = sum(p.profit for p in posizioni) if posizioni else 0.0
    result = {
        "balance":     info.balance,
        "equity":      info.equity,
        "credit":      float(getattr(info, "credit", 0.0) or 0.0),  # bonus non prelevabile (fa da margine)
        "margin":      info.margin,
        "free_margin": info.margin_free,
        "profit":      profit_tot,
        "currency":    info.currency,
        "trade_mode":  info.trade_mode,
        "leverage":    info.leverage,
        # Il CONTO consente di operare? Con una password di SOLA LETTURA
        # (investor) il server risponde False: e' cosi' che la modalita'
        # semi-automatica riconosce una prop configurata correttamente — e che
        # la modalita' automatica si accorge di non poterci lavorare.
        # Default True se l'attributo non c'e': mai un falso allarme.
        "trade_allowed": bool(getattr(info, "trade_allowed", True)),
    }
    _mt5_release()
    return result

class DatiSimboloNonValidi(ValueError):
    """Il simbolo non espone dati sufficienti per calcolare SL/TP."""

def calcola_prezzi_sl_tp(
    direzione: str, prezzo_entrata: float,
    sl_dol: float, tp_dol: float,
    lotti: float, point: float, tick_value: float,
) -> Tuple[float, float]:
    # Guardia: con lotti o tick_value a 0 questa divisione esplodeva con un
    # ZeroDivisionError nudo che risaliva fino al handler Telegram, lasciando
    # l'utente col messaggio bloccato su "Esecuzione hedge in corso...".
    # trade_tick_value puo' davvero valere 0 (simbolo non ancora selezionato,
    # mercato chiuso, feed non pronto): qui diventa un errore PARLANTE, che i
    # chiamanti trasformano in un messaggio comprensibile.
    if lotti <= 0 or tick_value <= 0 or point <= 0:
        raise DatiSimboloNonValidi(
            f"dati simbolo non validi per il calcolo SL/TP "
            f"(lotti={lotti}, tick_value={tick_value}, point={point})"
        )
    pip_sl = sl_dol / (lotti * tick_value)
    pip_tp = tp_dol / (lotti * tick_value)
    if direzione == "BUY":
        sl_price = prezzo_entrata - pip_sl * point
        tp_price = prezzo_entrata + pip_tp * point
    else:
        sl_price = prezzo_entrata + pip_sl * point
        tp_price = prezzo_entrata - pip_tp * point
    return sl_price, tp_price

# Messaggio per il retcode 10027 (AutoTrading spento NEL TERMINALE). Costante
# condivisa: e' anche il "marcatore" con cui la UI riconosce questo caso specifico
# per mostrare il pulsante "Riavvia terminale" (che riaccende l'Algo Trading).
# Unica fonte di verita': cambiando qui cambia sia il testo sia il riconoscimento.
MSG_AUTOTRADING_OFF = "trading automatico disabilitato nel terminale (pulsante Algo Trading)"

# Codici di errore MT5 (retcode di order_send/order_check) -> messaggio chiaro per l'utente.
_RETCODE_MSG = {
    10004: "richiesta di requote: il prezzo e' cambiato, riprova",
    10006: "richiesta rifiutata dal broker",
    10007: "operazione annullata",
    10010: "ordine eseguito solo parzialmente",
    10011: "errore di elaborazione della richiesta",
    10012: "richiesta scaduta (timeout)",
    10013: "richiesta non valida",
    10014: "volume non valido",
    10015: "prezzo non valido",
    10016: "Stop Loss/Take Profit non validi (troppo vicini al prezzo)",
    10017: "trading non consentito sull'account (account bloccato o in sola lettura)",
    10018: "mercato chiuso",
    10019: "fondi insufficienti: margine non sufficiente per aprire l'ordine",
    10020: "i prezzi sono cambiati, riprova",
    10021: "nessuna quotazione disponibile (mercato non quotato)",
    10024: "troppe richieste, riprova tra poco",
    10026: "trading automatico disabilitato lato server del broker",
    10027: MSG_AUTOTRADING_OFF,
    10028: "richiesta bloccata in elaborazione",
    10029: "ordine o posizione congelati",
    10030: "tipo di riempimento (filling) non supportato",
    10031: "nessuna connessione al server di trading",
    10032: "operazione consentita solo su conti reali",
    10033: "raggiunto il limite di ordini pendenti sull'account",
    10034: "raggiunto il limite di volume/posizioni per il simbolo o l'account",
}

def _motivo_ordine(retcode, comment=None) -> str:
    """Traduce un retcode MT5 in un messaggio leggibile. Fallback: comment del
    server o, in ultima istanza, il codice numerico."""
    if retcode in _RETCODE_MSG:
        return _RETCODE_MSG[retcode]
    c = str(comment).strip() if comment else ""
    if c:
        return c
    if retcode is None:
        return "nessuna risposta dal server di trading"
    return f"errore broker (codice {retcode})"

def _filling_supportato(sym, default_ioc: bool = False) -> int:
    """Sceglie il type_filling che il SIMBOLO dichiara di supportare
    (bitmask symbol_info.filling_mode): IOC se c'e', altrimenti FOK,
    altrimenti RETURN.

    FIX CRONICO: la v51 imponeva ORDER_FILLING_IOC fisso. Sui conti/prop che
    NON supportano IOC ogni ordine falliva con retcode 10030 ("filling non
    supportato"): l'hedge apriva la gamba broker, la prop falliva SEMPRE e il
    rollback bruciava spread a ogni tentativo. Stesso difetto in chiusura.

    default_ioc=True: quando il simbolo NON e' leggibile affatto (symbol_info
    None) non stiamo scegliendo, stiamo tirando a indovinare. In quel caso IOC
    (il default storico v51) e' molto piu' probabile di RETURN, che parecchi
    broker rifiutano sulle esecuzioni a mercato. Usato in CHIUSURA, dove un
    rifiuto lascerebbe una gamba scoperta.
    """
    flags   = int(getattr(sym, "filling_mode", 0) or 0)
    bit_fok = int(getattr(mt5, "SYMBOL_FILLING_FOK", 1))
    bit_ioc = int(getattr(mt5, "SYMBOL_FILLING_IOC", 2))
    if flags & bit_ioc:
        return int(getattr(mt5, "ORDER_FILLING_IOC", 1))
    if flags & bit_fok:
        return int(getattr(mt5, "ORDER_FILLING_FOK", 0))
    if default_ioc and not flags:
        return int(getattr(mt5, "ORDER_FILLING_IOC", 1))
    return int(getattr(mt5, "ORDER_FILLING_RETURN", 2))

# Retcode che indicano "il filling scelto non va bene su questo simbolo/conto":
# non e' un problema di mercato, e ritentare con un'altra modalita' ha senso.
_RETCODE_FILLING_KO = {10030, 10013}

def _filling_alternativi(primo: int) -> List[int]:
    """Ordine di tentativi per il type_filling: prima quello dichiarato dal
    simbolo, poi gli altri. Serve perche' il bitmask filling_mode NON e' sempre
    fedele (alcune prop dichiarano IOC e poi rifiutano con 10030): invece di
    fallire — e pagare un rollback o lasciare una gamba scoperta — si prova
    l'alternativa. In pratica costa un round-trip solo nei casi gia' persi."""
    ioc    = int(getattr(mt5, "ORDER_FILLING_IOC",    1))
    fok    = int(getattr(mt5, "ORDER_FILLING_FOK",    0))
    ritorn = int(getattr(mt5, "ORDER_FILLING_RETURN", 2))
    ordine = [primo] + [f for f in (ioc, fok, ritorn) if f != primo]
    return ordine

def _risolvi_position_ticket(result, simbolo: str, magic: int) -> Optional[int]:
    """Ricava il ticket di POSIZIONE dall'esito di un order_send.

    ATTENZIONE, distinzione che costa cara: `result.order` e' il ticket
    dell'ORDINE, non della POSIZIONE. Sui conti HEDGING coincidono quasi
    sempre, ma sui conti NETTING (usati da diverse prop) un ordine che si
    somma a una posizione esistente produce un position_id DIVERSO. Tutto il
    resto del bot (memo, monitor, guardiano di coppia, recovery) tratta quel
    numero come ticket di posizione: se non coincide, positions_get(ticket=)
    non trova nulla e il GUARDIANO chiude la gamba gemella di un hedge appena
    aperto, credendola superstite.

    Ordine di risoluzione, dal piu' autorevole al piu' difensivo:
      1) il deal generato dall'ordine -> position_id (fonte ufficiale MT5);
      2) la posizione col ticket dell'ordine (caso hedging, il piu' comune);
      3) la posizione con lo stesso magic sul simbolo (rete di sicurezza).
    """
    order_ticket = int(getattr(result, "order", 0) or 0)

    deal_ticket = int(getattr(result, "deal", 0) or 0)
    if deal_ticket:
        try:
            deals = mt5.history_deals_get(ticket=deal_ticket) or ()
            for d in deals:
                pid = int(getattr(d, "position_id", 0) or 0)
                if pid:
                    return pid
        except Exception as e:
            logger.debug(f"_risolvi_position_ticket: history_deals_get non disponibile ({e}).")

    if order_ticket:
        try:
            if mt5.positions_get(ticket=order_ticket):
                return order_ticket
        except Exception:
            pass

    try:
        for p in (mt5.positions_get(symbol=simbolo) or ()):
            if int(getattr(p, "magic", 0) or 0) == int(magic):
                trovato = int(p.ticket)
                if trovato != order_ticket:
                    logger.warning(
                        f"Ticket ordine {order_ticket} != ticket posizione {trovato} "
                        f"(conto netting?): uso quello di POSIZIONE."
                    )
                return trovato
    except Exception:
        pass

    # Nessuna conferma: si torna al ticket dell'ordine (comportamento storico).
    return order_ticket or None

def esegui_ordine(
    path: str, login: int, password: str, server: str,
    direzione: str, simbolo: str, lotti: float,
    sl_price: float, tp_price: float,
    commento: str = "", magic: int = 0,
) -> Tuple[Optional[int], Optional[str]]:
    """Invia l'ordine. Ritorna (ticket, None) se eseguito, oppure (None, motivo)
    in caso di fallimento, con 'motivo' gia' tradotto per l'utente."""
    if not connessione_mt5(path, login, password, server):
        return None, "connessione a MT5 non riuscita (terminale non raggiungibile o credenziali errate)"
    if not mt5.symbol_select(simbolo, True):
        logger.error(f"Impossibile selezionare {simbolo} nel Market Watch")
        _mt5_release()
        return None, f"impossibile selezionare il simbolo {simbolo} nel Market Watch"
    time.sleep(0.2)  # piccolo delay per stabilizzazione tick (no async qui: siamo in thread)
    sym = mt5.symbol_info(simbolo)
    if sym is None:
        logger.error(f"Simbolo {simbolo} non trovato. MT5 error: {mt5.last_error()}")
        _mt5_release()
        return None, f"simbolo {simbolo} non trovato nel terminale"
    if sym.trade_mode == mt5.SYMBOL_TRADE_MODE_DISABLED:
        logger.error(f"Trading disabilitato su {simbolo} (trade_mode=DISABLED)")
        _mt5_release()
        return None, f"trading disabilitato sul simbolo {simbolo}"
    tick = mt5.symbol_info_tick(simbolo)
    if tick is None:
        logger.error(f"Nessun tick disponibile per {simbolo}, errore: {mt5.last_error()}")
        _mt5_release()
        return None, f"nessuna quotazione per {simbolo} (mercato chiuso?)"
    if direzione == "BUY":
        price = tick.ask
        tipo  = mt5.ORDER_TYPE_BUY
    else:
        price = tick.bid
        tipo  = mt5.ORDER_TYPE_SELL
    # Guardia prezzo: durante un break di sessione/rollover il tick puo' esistere
    # ma con ask/bid a 0 -> richiesta non valida (order_send tornerebbe None).
    if not price or price <= 0:
        logger.error(
            f"Prezzo non valido per {simbolo} (ask={getattr(tick, 'ask', None)}, "
            f"bid={getattr(tick, 'bid', None)}): mercato non quotato o sessione chiusa."
        )
        _mt5_release()
        return None, f"prezzo non valido per {simbolo} (mercato non quotato o sessione chiusa)"
    # IMPORTANTE: l'API Python di MT5 vuole FLOAT nei campi numerici della
    # richiesta. Passare un int (es. sl/tp=0) fa tornare order_send=None con
    # last_error fuorviante (1,'Success'). Coerciamo sempre a float.
    request = {
        "action":       mt5.TRADE_ACTION_DEAL,
        "symbol":       simbolo,
        "volume":       float(lotti),
        "type":         tipo,
        "price":        float(price),
        "sl":           float(sl_price),
        "tp":           float(tp_price),
        "deviation":    20,
        "magic":        int(magic),
        "type_time":    mt5.ORDER_TIME_GTC,
        "type_filling": _filling_supportato(sym),
    }
    # Se il broker rifiuta il filling DICHIARATO dal simbolo (succede: il
    # bitmask non e' sempre fedele) si riprova con le altre modalita' invece di
    # dichiarare fallita la gamba e pagare un rollback.
    result = None
    for tentativo, filling in enumerate(_filling_alternativi(request["type_filling"])):
        request["type_filling"] = filling
        result = mt5.order_send(request)
        retcode = getattr(result, "retcode", None) if result else None
        if tentativo:
            logger.warning(
                f"OrderSend: filling alternativo {filling} su {simbolo} -> retcode={retcode}"
            )
        if retcode not in _RETCODE_FILLING_KO:
            break
    logger.info(
        f"OrderSend result: retcode={result.retcode if result else 'None'}, "
        f"comment={result.comment if result else 'N/A'}"
    )
    if result and result.retcode == mt5.TRADE_RETCODE_DONE:
        ticket = _risolvi_position_ticket(result, simbolo, magic)
        _mt5_release()
        return ticket, None
    # Diagnostica: order_send fallito (None o retcode != DONE). order_check()
    # restituisce il motivo REALE (volume sotto il minimo, mercato chiuso,
    # AutoTrading off, margine insufficiente...). Va chiamato PRIMA di shutdown.
    check_retcode = None
    check_comment = None
    try:
        check = mt5.order_check(request)
        if check is not None:
            check_retcode = getattr(check, "retcode", None)
            check_comment = getattr(check, "comment", None)
            logger.error(f"order_check: retcode={check_retcode}, comment={check_comment}")
    except Exception as e:
        logger.debug(f"order_check non disponibile: {e}")
    send_retcode = result.retcode if result else None
    send_comment = result.comment if result else None
    # order_send da' l'esito reale; se assente (None per timeout) usiamo order_check,
    # che riporta la precondizione (es. fondi insufficienti / account bloccato).
    if send_retcode is not None and send_retcode != mt5.TRADE_RETCODE_DONE:
        motivo = _motivo_ordine(send_retcode, send_comment)
    elif check_retcode:
        motivo = _motivo_ordine(check_retcode, check_comment)
    else:
        motivo = _motivo_ordine(send_retcode, send_comment)
    logger.error(
        f"Ordine fallito su {simbolo}: motivo='{motivo}', "
        f"send_retcode={send_retcode}, check_retcode={check_retcode}, "
        f"last_error={mt5.last_error()}, "
        f"vol={request['volume']} (min={getattr(sym, 'volume_min', '?')}, "
        f"step={getattr(sym, 'volume_step', '?')}, max={getattr(sym, 'volume_max', '?')}), "
        f"trade_mode={getattr(sym, 'trade_mode', '?')}, price={request['price']}"
    )
    _mt5_release()
    return None, motivo

# Esiti possibili di una richiesta di chiusura. Tre, non due: "non c'e' piu'"
# e "non sono riuscito a chiuderla" sono OPPOSTI — nel primo caso il lavoro e'
# fatto, nel secondo una gamba di hedge e' viva e scoperta — ma l'API risponde
# a entrambi con una lista vuota, e appiattirli su un unico False faceva
# gridare al lupo su trade andati a buon fine (segnalazione del 07/08/2026).
ESITO_CHIUSA     = "chiusa"        # chiusa adesso, da noi
ESITO_GIA_CHIUSA = "gia_chiusa"    # non c'era piu': obiettivo gia' raggiunto
ESITO_FALLITA    = "fallita"       # non chiusa, oppure non si sa: allarme

def _chiusura_confermata(ticket: int) -> bool:
    """Nello storico esiste il deal di CHIUSURA di questa posizione?

    E' la controprova che serve quando positions_get risponde "vuoto". Vuoto
    puo' voler dire due cose opposte: la posizione e' stata chiusa, oppure il
    terminale non ce la sta mostrando (sincronizzazione appena avviata, dati
    non ancora allineati). Sul dubbio si risponde NO: meglio un allarme di
    troppo che una gamba lasciata a mercato credendola chiusa.

    Stessa disciplina di _extract_close_deal_sync: finestra LARGA (MT5 filtra
    i deal col fuso del SERVER, non UTC) e filtro per position_id in Python,
    perche' il kwarg position= di history_deals_get non e' affidabile.
    """
    try:
        start = datetime.now(timezone.utc) - timedelta(days=3)
        end   = datetime.now(timezone.utc) + timedelta(days=1)
        deals = mt5.history_deals_get(start, end) or []
    except Exception as e:
        logger.warning(f"_chiusura_confermata({ticket}): storico non leggibile ({e}).")
        return False
    out_entry    = getattr(mt5, "DEAL_ENTRY_OUT", 1)
    out_by_entry = getattr(mt5, "DEAL_ENTRY_OUT_BY", 3)
    return any(
        int(getattr(d, "position_id", 0) or 0) == int(ticket)
        and getattr(d, "entry", None) in (out_entry, out_by_entry)
        for d in deals
    )

def chiudi_posizione_esito(
    path: str, login: int, password: str, server: str, ticket: int,
) -> str:
    """Chiude la posizione e dice COM'E' andata (vedi gli ESITO_*)."""
    if not connessione_mt5(path, login, password, server):
        return ESITO_FALLITA
    pos = mt5.positions_get(ticket=ticket)
    if pos is None:
        # MT5 non ha risposto: incertezza totale, nessuna conclusione.
        logger.error(
            f"chiudi_posizione: lettura della posizione {ticket} fallita "
            f"({mt5.last_error()}): non concludo nulla."
        )
        _mt5_release()
        return ESITO_FALLITA
    if not pos:
        # MT5 ha risposto "non e' aperta". Si canta vittoria solo con la
        # controprova nello storico.
        confermata = _chiusura_confermata(ticket)
        logger.info(
            f"chiudi_posizione: la posizione {ticket} non risulta aperta; "
            f"deal di chiusura nello storico: {'SI' if confermata else 'NO'}."
        )
        _mt5_release()
        return ESITO_GIA_CHIUSA if confermata else ESITO_FALLITA
    pos  = pos[0]
    tipo = mt5.ORDER_TYPE_SELL if pos.type == mt5.POSITION_TYPE_BUY else mt5.ORDER_TYPE_BUY
    tick = mt5.symbol_info_tick(pos.symbol)
    if tick is None:
        logger.error(
            f"chiudi_posizione: nessun tick disponibile per {pos.symbol} "
            f"(mercato chiuso?). Errore MT5: {mt5.last_error()}"
        )
        _mt5_release()
        return ESITO_FALLITA
    price = tick.bid if tipo == mt5.ORDER_TYPE_SELL else tick.ask
    sym_close = mt5.symbol_info(pos.symbol)
    if sym_close is None:
        # Simbolo non leggibile: riprovo a selezionarlo prima di rinunciare.
        # Senza questo, _filling_supportato riceveva flags=0 e sceglieva
        # RETURN — spesso rifiutato a mercato: la chiusura falliva e la gamba
        # restava SCOPERTA, cioe' esattamente il guasto che dobbiamo evitare.
        try:
            mt5.symbol_select(pos.symbol, True)
            sym_close = mt5.symbol_info(pos.symbol)
        except Exception:
            sym_close = None
        if sym_close is None:
            logger.warning(
                f"chiudi_posizione: symbol_info({pos.symbol}) non disponibile, "
                f"uso il filling di default (IOC) e i suoi alternativi."
            )
    request = {
        "action":       mt5.TRADE_ACTION_DEAL,
        "symbol":       pos.symbol,
        "volume":       pos.volume,
        "type":         tipo,
        "position":     pos.ticket,
        "price":        price,
        "deviation":    20,
        "magic":        0,
        "type_time":    mt5.ORDER_TIME_GTC,
        "type_filling": _filling_supportato(sym_close, default_ioc=True),
    }
    result = None
    for tentativo, filling in enumerate(_filling_alternativi(request["type_filling"])):
        request["type_filling"] = filling
        result = mt5.order_send(request)
        retcode = getattr(result, "retcode", None) if result else None
        if tentativo:
            logger.warning(
                f"Chiusura {ticket}: filling alternativo {filling} -> retcode={retcode}"
            )
        if retcode not in _RETCODE_FILLING_KO:
            break
    logger.info(
        f"Chiusura posizione {ticket}: "
        f"retcode={result.retcode if result else 'None'}, errore={mt5.last_error()}"
    )
    _mt5_release()
    if result is not None and result.retcode == mt5.TRADE_RETCODE_DONE:
        return ESITO_CHIUSA
    return ESITO_FALLITA

def chiudi_posizione(
    path: str, login: int, password: str, server: str, ticket: int,
) -> bool:
    """Come chiudi_posizione_esito, ridotta a "la posizione e' fuori dal
    mercato?". Una posizione che NON c'era gia' piu' e' un successo per ogni
    chiamante: chi chiude voleva quello. Chi deve anche RACCONTARE cos'e'
    successo (il guardiano di coppia) usa direttamente chiudi_posizione_esito.
    """
    return chiudi_posizione_esito(path, login, password, server, ticket) in (
        ESITO_CHIUSA, ESITO_GIA_CHIUSA,
    )

def posizione_aperta_sync(
    path: str, login: int, password: str, server: str, ticket: int,
) -> Optional[bool]:
    """La posizione `ticket` risulta ANCORA aperta?

      True  -> si', e' a mercato;
      False -> no, NON c'e' piu' (chiusa da SL/TP, a mano, o dal bot);
      None  -> non determinabile (MT5 irraggiungibile).

    Serve a distinguere "chiusura fallita" da "era gia' chiusa":
    chiudi_posizione() ritorna False in ENTRAMBI i casi, e trattarli allo
    stesso modo produceva ritentativi (e avvisi all'owner) infiniti su
    posizioni che non esistevano piu'. Il None resta intoccabile: sul dubbio
    non si conclude nulla — regola d'oro del recovery.
    """
    if not connessione_mt5(path, login, password, server):
        return None
    try:
        pos = mt5.positions_get(ticket=int(ticket))
        # positions_get ritorna None sull'ERRORE e una tupla VUOTA quando la
        # posizione semplicemente non c'e'. Un bool() su entrambi rispondeva
        # "non e' aperta" anche quando MT5 non aveva risposto affatto — cioe'
        # dichiarava chiusa una gamba potenzialmente viva, che e' l'errore
        # peggiore possibile per questa funzione.
        if pos is None:
            logger.warning(
                f"posizione_aperta_sync({ticket}): MT5 non ha risposto "
                f"({mt5.last_error()}), esito NON determinabile."
            )
            return None
        return bool(pos)
    except Exception:
        logger.exception(f"posizione_aperta_sync({ticket}): errore di lettura")
        return None
    finally:
        _mt5_release()

def stato_metatrader(path: str) -> str:
    if not _mt5_attach(path):
        return "Non avviato"
    acc = mt5.account_info()
    _mt5_release()
    return "Connesso" if acc else "Non connesso"

def calcola_margine_wrapper(
    path: str, tipo_ord: int, simbolo: str,
    lotti: float, prezzo_entrata: float,
    login: Optional[int] = None, password: Optional[str] = None, server: Optional[str] = None,
) -> Optional[float]:
    # order_calc_margin dipende dalla leva dell'account: con login esplicito
    # leggiamo SEMPRE l'account giusto (non quello mostrato dal terminale).
    if login is not None and password is not None and server is not None:
        if not connessione_mt5(path, int(login), password, server):
            return None
    else:
        if not _mt5_attach(path):
            return None
    mt5.symbol_select(simbolo, True)
    margine = mt5.order_calc_margin(tipo_ord, simbolo, lotti, prezzo_entrata)
    _mt5_release()
    return margine

def leva_simbolo(
    path: str, simbolo: str,
    login: Optional[int] = None, password: Optional[str] = None, server: Optional[str] = None,
) -> Optional[float]:
    """Leva EFFETTIVA sul SIMBOLO: quante volte il valore nominale di una
    posizione supera il margine che il broker chiede per tenerla aperta.

    NON e' la leva del conto, ed e' il motivo per cui questa funzione esiste.
    Sull'oro i broker limitano la leva per strumento — conto a 1:500 e XAUUSD a
    1:100 e' la norma — e a decidere quanto margine occupa la gamba di
    copertura e' questa, non quella del conto. Mostrare la seconda al posto
    della prima fa credere di avere cinque volte il margine che si ha davvero.

    MT5 non espone da nessuna parte una "leva del simbolo": l'unico modo onesto
    e' chiedere al server quanto margine vuole per UN lotto (order_calc_margin,
    la stessa funzione che alimenta il margine nel riepilogo del trade) e
    confrontarlo col valore nominale di quel lotto:

        leva = (lotti x contract_size x prezzo) / margine

    Ritorna None se manca un pezzo (mercato chiuso, simbolo non pronto, margine
    nullo o negativo). Chi chiama in quel caso scrive "n/d" e NON la leva del
    conto: ripiegare su quella riporterebbe esattamente il numero sbagliato che
    si voleva togliere di mezzo.
    """
    if login is not None and password is not None and server is not None:
        if not connessione_mt5(path, int(login), password, server):
            return None
    else:
        if not _mt5_attach(path):
            return None
    try:
        mt5.symbol_select(simbolo, True)
        sym = mt5.symbol_info(simbolo)
        if sym is None:
            logger.warning(f"leva_simbolo({simbolo}): symbol_info non disponibile.")
            return None
        tick = mt5.symbol_info_tick(simbolo)
        # Il prezzo di acquisto e' quello a cui si calcola il margine di un BUY;
        # il bid fa da rete se l'ask non c'e' (feed a mercato appena chiuso).
        prezzo = float(getattr(tick, "ask", 0.0) or getattr(tick, "bid", 0.0) or 0.0) if tick else 0.0
        contract = float(getattr(sym, "trade_contract_size", 0.0) or 0.0)
        if prezzo <= 0 or contract <= 0:
            logger.warning(
                f"leva_simbolo({simbolo}): dati insufficienti "
                f"(prezzo={prezzo}, contract_size={contract})."
            )
            return None
        margine = mt5.order_calc_margin(mt5.ORDER_TYPE_BUY, simbolo, 1.0, prezzo)
        if not margine or float(margine) <= 0:
            logger.warning(
                f"leva_simbolo({simbolo}): margine non calcolabile "
                f"({margine}), errore MT5: {mt5.last_error()}."
            )
            return None
        return (contract * prezzo) / float(margine)
    except Exception:
        logger.exception(f"leva_simbolo({simbolo}): errore di lettura")
        return None
    finally:
        _mt5_release()

def get_symbol_info_wrapper(
    path: str, simbolo: str, direzione: str,
    login: Optional[int] = None, password: Optional[str] = None, server: Optional[str] = None,
):
    if login is not None and password is not None and server is not None:
        if not connessione_mt5(path, int(login), password, server):
            return None
    else:
        if not _mt5_attach(path):
            return None
    mt5.symbol_select(simbolo, True)
    sym = mt5.symbol_info(simbolo)
    if sym is None:
        _mt5_release()
        return None
    tick = mt5.symbol_info_tick(simbolo)
    if tick is None:
        logger.error(f"Nessun tick disponibile per {simbolo}, mercato chiuso? Errore: {mt5.last_error()}")
        _mt5_release()
        return None
    prezzo_entrata = tick.ask if direzione == "BUY" else tick.bid
    point          = float(getattr(sym, "point", 0.0) or 0.0)
    tick_value     = float(getattr(sym, "trade_tick_value", 0.0) or 0.0)
    _mt5_release()
    # Dati incompleti = dati inutilizzabili: meglio dirlo qui (il chiamante
    # gestisce gia' il None con un messaggio chiaro) che spaccarsi piu' avanti
    # dentro calcola_prezzi_sl_tp.
    if point <= 0 or tick_value <= 0 or not prezzo_entrata or prezzo_entrata <= 0:
        logger.error(
            f"get_symbol_info_wrapper({simbolo}): dati incompleti "
            f"(point={point}, tick_value={tick_value}, prezzo={prezzo_entrata})."
        )
        return None
    return {
        "point":          point,
        "tick_value":     tick_value,
        "prezzo_entrata": prezzo_entrata,
        # Decimali con cui il broker quota il simbolo: serve a STAMPARE i
        # livelli con la stessa precisione che l'utente potra' digitare nel
        # suo MetaTrader (modalita' semi-automatica).
        "digits":         int(getattr(sym, "digits", 2) or 2),
        # Distanza MINIMA imposta dal broker tra prezzo e SL/TP (in point).
        # Serve al pre-flight dell'hedge: i livelli della gamba Broker sono
        # specchiati da quelli della Prop e, con feed diversi, possono finire
        # dal lato sbagliato del prezzo -> ordine rifiutato (10016).
        "stops_level":    int(getattr(sym, "trade_stops_level", 0) or 0),
        "freeze_level":   int(getattr(sym, "trade_freeze_level", 0) or 0),
        "bid":            float(getattr(tick, "bid", 0.0) or 0.0),
        "ask":            float(getattr(tick, "ask", 0.0) or 0.0),
    }

def valida_simbolo_volume(path: str, simbolo: str, volume: float) -> Tuple[bool, str]:
    try:
        if not _mt5_attach(path):
            return False, "Connessione al broker fallita"
        mt5.symbol_select(simbolo, True)
        sym = mt5.symbol_info(simbolo)
        if sym is None:
            _mt5_release()
            return False, f"Simbolo {simbolo} non disponibile"
        if sym.trade_mode == mt5.SYMBOL_TRADE_MODE_DISABLED:
            _mt5_release()
            return False, "Trading disabilitato su questo strumento (SYMBOL_TRADE_MODE_DISABLED)"
        if not hasattr(sym, "volume_min") or not hasattr(sym, "volume_max") or not hasattr(sym, "volume_step"):
            _mt5_release()
            return False, "Dati volume incompleti sul broker"
        vol   = Decimal(str(volume))
        vmin  = Decimal(str(sym.volume_min))
        vmax  = Decimal(str(sym.volume_max))
        vstep = Decimal(str(sym.volume_step))
        if vol < vmin or vol > vmax:
            _mt5_release()
            return False, f"Volume fuori range [{vmin}, {vmax}]"
        if vstep > 0:
            steps = round(vol / vstep)
            if abs(vol - steps * vstep) > Decimal("1e-10"):
                _mt5_release()
                return False, f"Il volume deve essere un multiplo di {vstep}"
        _mt5_release()
        return True, ""
    except Exception as e:
        logger.exception("Errore validazione simbolo/volume")
        _mt5_disconnect()   # stato ignoto dopo un'eccezione: riparti pulito
        return False, f"Errore interno: {str(e)}"

def get_server_date(path: str, simbolo: str) -> date:
    if not _mt5_attach(path):
        return date.today()
    mt5.symbol_select(simbolo, True)
    tick = mt5.symbol_info_tick(simbolo)
    _mt5_release()
    if tick and tick.time > 0:
        return datetime.fromtimestamp(tick.time).date()
    return date.today()

def info_account_prop_sync(
    path: str, config: Dict[str, Any], today: date, dati: Dict[str, Any],
    daily_realized_pnl: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Calcola le metriche prop coerenti con la regola dichiarata dal fornitore:

      • DD TOTALE: STATICO sul capitale iniziale.
        soglia = saldo_partenza * (1 - dd_max_perc/100)
        Esempio: saldo_partenza=100000, dd_max=6% -> soglia=94000.
        Se equity=101000 -> dd_max_rimasto = 7000.
        Se equity=96000  -> dd_max_rimasto = 2000.
        Per coerenza con la regola "balance/equity sotto soglia = violazione"
        usiamo il MINIMO tra balance ed equity (piu' restrittivo).

      • DD GIORNALIERO: PPP = dd_daily_perc * saldo_partenza / 100 (FISSO sul
        capitale iniziale, deciso alla configurazione prop). Il "rimanente"
        parte da PPP e segue il P/L REALIZZATO del giorno. Questo P/L viene
        misurato dai soli TRADE CHIUSI oggi (parametro daily_realized_pnl,
        letto dai deal MT5): cosi' e' immune ai movimenti di SALDO non-trading
        (rinnovo/reset prop che riporta il saldo al capitale iniziale, depositi,
        prelievi/payout). Se lo storico non e' leggibile si ricade sul metodo
        storico (balance_attuale - balance_inizio_giorno). Un guadagno lo ALZA,
        una perdita lo ABBASSA. Viene poi CAPPATO dalla perdita TOTALE massima
        ancora disponibile (non si puo' scendere sotto soglia_minima_totale):
        se in totale resta meno del margine giornaliero, il giornaliero si
        adegua al totale. Reset a mezzanotte del server prop: P/L_giorno=0 ->
        torna a PPP.
    """
    # Login esplicito sull'account prop reale (le creds stanno in dati["prop"]),
    # altrimenti leggeremmo l'account mostrato dal terminale (valori errati).
    prop_cred = dati.get("prop") or {}
    if prop_cred.get("id") and prop_cred.get("password") and prop_cred.get("server"):
        base = info_account(path, int(prop_cred["id"]), prop_cred["password"], prop_cred["server"])
    else:
        base = info_account(path)
    if not base:
        return {}

    def _f(key, default):
        try:
            return float(config.get(key, default))
        except (TypeError, ValueError):
            return float(default)

    saldo_partenza  = _f("saldo_partenza", 100000)
    dd_max_perc     = _f("dd_max_perc", 6)
    dd_daily_perc   = _f("dd_daily_perc", 3)
    target_perc     = _f("target", 10)

    balance_corrente = float(base["balance"])
    equity_corrente  = float(base["equity"])
    # Il piu' restrittivo tra balance ed equity: cosi' la dashboard mostra
    # sempre il margine "peggiore" rispetto alla violazione.
    safety_corrente  = min(balance_corrente, equity_corrente)

    # ── DD totale: STATICO sul capitale iniziale ────────────────────────────
    soglia_minima_totale = saldo_partenza * (1 - dd_max_perc / 100)
    dd_max_rimasto       = safety_corrente - soglia_minima_totale

    # ── Target ──────────────────────────────────────────────────────────────
    mancanti_a_target = saldo_partenza * (1 + target_perc / 100) - balance_corrente

    # ── DD giornaliero: limite fisso sul capitale iniziale ──────────────────
    today_str    = today.isoformat()
    nuovo_giorno = (dati.get("daily_start_date") != today_str)
    if nuovo_giorno:
        balance_inizio = balance_corrente
    else:
        balance_inizio = float(dati.get("daily_start_balance", balance_corrente))

    # PPP: limite giornaliero FISSO, calcolato sul capitale iniziale.
    limite_giornaliero = dd_daily_perc * saldo_partenza / 100

    # P/L REALIZZATO del giorno.
    # FONTE PRIMARIA: somma dei P/L dei soli trade PROP CHIUSI oggi, letta dai
    # deal MT5 (daily_realized_pnl). E' immune ai movimenti di SALDO non-trading:
    # un rinnovo/reset prop che riporta il saldo al capitale iniziale, o un
    # payout, NON viene piu' scambiato per un P/L del giorno (era la causa del
    # "6000 invece di 3000" dopo cambio/rinnovo prop). Il flottante dei trade
    # ancora aperti NON entra.
    # FALLBACK: se lo storico non e' leggibile (daily_realized_pnl=None), si usa
    # la differenza di saldo rispetto al saldo di inizio giornata, come in passato.
    if daily_realized_pnl is not None:
        pnl_giorno_realizzato = float(daily_realized_pnl)
    else:
        pnl_giorno_realizzato = balance_corrente - balance_inizio

    # Margine giornaliero: parte da PPP, lo ALZA il guadagno e lo ABBASSA la
    # perdita del giorno. A mezzanotte (balance_inizio ri-agganciato ->
    # pnl_giorno=0) torna esattamente a PPP, qualunque sia il saldo.
    margine_giornaliero = limite_giornaliero + pnl_giorno_realizzato

    # CAPPELLO della perdita TOTALE massima: non si puo' scendere sotto la
    # soglia totale (saldo_partenza * (1 - dd_max/100)). Quanto resta in TOTALE
    # sul balance: se e' meno del margine giornaliero, il giornaliero si adegua
    # al totale. Applicato solo se un limite totale e' configurato (dd_max > 0).
    totale_rimasto_balance = balance_corrente - soglia_minima_totale
    if dd_max_perc > 0:
        perdita_giornaliera_rimasta = min(margine_giornaliero, totale_rimasto_balance)
    else:
        perdita_giornaliera_rimasta = margine_giornaliero

    # Perdita realizzata del giorno (>=0 in perdita, 0 in pari/profitto): solo
    # informativa/log, non piu' base del calcolo del rimanente.
    perdita_effettiva_giorno = max(0.0, -pnl_giorno_realizzato)

    # ── CONSISTENZA: profitto giornaliero massimo ───────────────────────────
    # La "consistenza" e' il rapporto (in %) tra il profitto giornaliero
    # massimo concesso dalla prop e il target. Esempio Fintokei: target 6%,
    # profitto max giornaliero 3% -> l'utente configura 50.
    #
    #   profitto_max_giornaliero$ = saldo_partenza x target% x consistenza%
    #                             = 100.000 x 6% x 50% = 3.000$
    #
    # Il rimanente parte OGNI GIORNO dalla cifra piena e scende col guadagno
    # realizzato, in modo speculare alla perdita giornaliera. Una giornata in
    # PERDITA non regala margine di profitto in piu' (da qui il max(0, ...)):
    # la regola guarda il risultato del giorno, non quanto hai recuperato.
    # None = nessun limite configurato (consistenza 0/assente, oppure target 0
    # come sui conti reali/funded): il bot non inventa soglie.
    consistenza_perc = _f("consistenza", 0)
    if consistenza_perc > 0 and target_perc > 0:
        profitto_max_giornaliero = saldo_partenza * (target_perc / 100) * (consistenza_perc / 100)
        profitto_giornaliero_rimasto = max(
            0.0, profitto_max_giornaliero - max(0.0, pnl_giorno_realizzato),
        )
    else:
        profitto_max_giornaliero     = 0.0
        profitto_giornaliero_rimasto = None

    # Saldo massimo storico (informativo). Non e' piu' la base del DD calc.
    massimo = float(dati.get("prop_massimo_saldo", balance_corrente))
    if balance_corrente > massimo:
        massimo = balance_corrente
    drawdown_attuale = (massimo - balance_corrente) / massimo * 100 if massimo > 0 else 0

    return {
        **base,
        "saldo_massimo":               massimo,
        "drawdown_attuale":            drawdown_attuale,
        "dd_max_rimasto":              dd_max_rimasto,
        "soglia_minima_totale":        soglia_minima_totale,
        "limite_giornaliero":          limite_giornaliero,
        "perdita_effettiva_giorno":    perdita_effettiva_giorno,
        "perdita_giornaliera_rimasta": perdita_giornaliera_rimasta,
        "consistenza_perc":            consistenza_perc,
        "profitto_max_giornaliero":    profitto_max_giornaliero,
        # None = nessun limite di profitto configurato.
        "profitto_giornaliero_rimasto": profitto_giornaliero_rimasto,
        "mancanti_target":             mancanti_a_target,
        "profit_totale":               base["profit"],
        "nuovo_giorno":                nuovo_giorno,
        "balance_inizio_giorno":       balance_inizio,
    }

def _trova_posizione_sync(path, login, psw, server, simbolo, magic, commento):
    if not connessione_mt5(path, login, psw, server):
        return None
    posizioni = mt5.positions_get(symbol=simbolo)
    if posizioni:
        for p in posizioni:
            if p.magic == magic and p.symbol == simbolo:
                _mt5_release()
                return p.ticket
    _mt5_release()
    return None

def _get_position_by_ticket_sync(path: str, login: int, password: str, server: str, ticket: int):
    if not connessione_mt5(path, login, password, server):
        return None
    try:
        posizioni = mt5.positions_get(ticket=ticket)
        return posizioni[0] if posizioni else None
    finally:
        _mt5_release()

def _deal_reason_label(reason: int) -> str:
    reason_map = {
        getattr(mt5, "DEAL_REASON_CLIENT", -1):   "Chiusura manuale",
        getattr(mt5, "DEAL_REASON_MOBILE", -2):   "Chiusura mobile",
        getattr(mt5, "DEAL_REASON_WEB",    -3):   "Chiusura web",
        getattr(mt5, "DEAL_REASON_EXPERT", -4):   "Chiusura Bot",
        getattr(mt5, "DEAL_REASON_SL",     -5):   "Stop Loss",
        getattr(mt5, "DEAL_REASON_TP",     -6):   "Take Profit",
        getattr(mt5, "DEAL_REASON_SO",     -7):   "Stop Out",
        getattr(mt5, "DEAL_REASON_ROLLOVER", -8): "Rollover",
        getattr(mt5, "DEAL_REASON_VMARGIN",  -9): "Variation Margin",
        getattr(mt5, "DEAL_REASON_SPLIT",   -10): "Split",
    }
    return reason_map.get(reason, f"Reason {reason}")

def _extract_close_deal_sync(
    path: str, login: int, password: str, server: str,
    ticket: int, opened_at_utc: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    if not connessione_mt5(path, login, password, server):
        return None
    try:
        # NOTA TIMEZONE: mt5.history_deals_get filtra i deal usando il fuso del
        # SERVER del broker (spesso UTC+2/+3), non UTC. Una finestra UTC stretta
        # rischia di ESCLUDERE il deal di chiusura appena avvenuto (un deal
        # "ora" sul server UTC+3 ha epoch ~3h avanti rispetto a now_utc).
        # La finestra larga e' sicura perche' SOTTO filtriamo per position_id.
        start = datetime.now(timezone.utc) - timedelta(days=3)
        if opened_at_utc:
            try:
                opened_dt = datetime.fromisoformat(opened_at_utc)
                if opened_dt.tzinfo is None:
                    opened_dt = opened_dt.replace(tzinfo=timezone.utc)
                start = opened_dt - timedelta(days=1)
            except Exception:
                pass
        end   = datetime.now(timezone.utc) + timedelta(days=1)
        # SORGENTE DATI IDENTICA ALLO STORICO: NIENTE parametro position=.
        # Il kwarg position= di history_deals_get NON e' affidabile quando si
        # passano anche le date: MT5 puo' restituire i deal di PIU' trade (caso
        # 12/6/2026: trade da -2005$ notificato come -6935$) oppure, al contrario,
        # un set INCOMPLETO (mancante del deal di ENTRATA con la sua commissione).
        # _get_trade_history_sync (lo Storico, che mostra i valori GIUSTI) prende
        # TUTTI i deal della finestra e poi raggruppa per position_id in Python.
        # Qui facciamo ESATTAMENTE lo stesso e filtriamo per position_id == ticket,
        # cosi' notifica e storico non possono piu' divergere (caso reale 16/6/2026:
        # notifica broker +2018$ contro storico +1188$, perche' il kwarg sommava
        # anche un altro trade chiuso nello stesso istante). Il filtro esclude da
        # solo i movimenti di saldo (position_id=0).
        deals = mt5.history_deals_get(start, end) or []
        deals = [
            d for d in deals
            if int(getattr(d, "position_id", 0) or 0) == int(ticket)
        ]
        if not deals:
            return None
        in_entry     = getattr(mt5, "DEAL_ENTRY_IN",  0)
        out_entry    = getattr(mt5, "DEAL_ENTRY_OUT", 1)
        out_by_entry = getattr(mt5, "DEAL_ENTRY_OUT_BY", 3)
        close_deals  = [
            d for d in deals
            if getattr(d, "entry", None) in (out_entry, out_by_entry)
        ]
        if not close_deals:
            return None
        # ── Completezza della chiusura (fill PARZIALI) ──────────────────────
        # Il server puo' eseguire uno SL/TP in PIU' tranche, scritte in history
        # anche a distanza di secondi. Se leggiamo a meta' esecuzione, il P/L
        # sommato sarebbe solo una frazione del reale (caso reale: SL prop da
        # ~-2000$ notificato come -84$) e il write-once del chiamante lo
        # congelerebbe per sempre. Finche' il volume chiuso non copre quello
        # aperto, la chiusura NON e' completa: torniamo None e il monitor
        # (ogni ~60s) riprovera' al giro successivo con la history completa.
        vol_in  = sum(
            float(getattr(d, "volume", 0.0) or 0.0) for d in deals
            if getattr(d, "entry", None) == in_entry
        )
        vol_out = sum(float(getattr(d, "volume", 0.0) or 0.0) for d in close_deals)
        if vol_in > 0 and vol_out + 1e-8 < vol_in:
            logger.info(
                f"Chiusura ticket {ticket} ancora parziale "
                f"(volume chiuso {vol_out} su {vol_in}): rimando la lettura."
            )
            return None
        deal = max(
            close_deals,
            key=lambda d: int(getattr(d, "time_msc", 0) or int(getattr(d, "time", 0)) * 1000),
        )
        # P/L NETTO dell'INTERA POSIZIONE: somma profit/commission/swap/fee su
        # TUTTI i deal (anche quello di ENTRATA, dove molti broker addebitano la
        # commissione, e le eventuali chiusure PARZIALI). Leggere il solo deal
        # finale (come si faceva prima) perdeva quei valori e sottostimava il
        # P/L realizzato cumulato (pl_broker_realizzato). Stesso criterio di
        # _get_trade_history_sync. I deal sono gia' filtrati per position=ticket.
        gross_profit = sum(float(getattr(d, "profit", 0.0) or 0.0) for d in deals)
        commission   = sum(float(getattr(d, "commission", 0.0) or 0.0) for d in deals)
        swap         = sum(float(getattr(d, "swap", 0.0) or 0.0) for d in deals)
        fee          = sum(float(getattr(d, "fee", 0.0) or 0.0) for d in deals)
        net_profit   = gross_profit + commission + swap + fee
        ts = int(getattr(deal, "time", 0) or 0)
        close_time = (
            datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
            if ts > 0 else datetime.now(timezone.utc).isoformat()
        )
        reason = int(getattr(deal, "reason", -1))
        return {
            "ticket":         ticket,
            "position_id":    int(getattr(deal, "position_id", ticket) or ticket),
            "close_time_utc": close_time,
            "reason":         reason,
            "reason_label":   _deal_reason_label(reason),
            "profit":         round(net_profit, 2),
            "gross_profit":   round(gross_profit, 2),
            "commission":     round(commission, 2),
            "swap":           round(swap, 2),
            "fee":            round(fee, 2),
            "symbol":         getattr(deal, "symbol", ""),
            "comment":        getattr(deal, "comment", ""),
            "entry":          int(getattr(deal, "entry", -1) or -1),
        }
    finally:
        _mt5_release()

def _get_open_positions_snapshot_sync(
    path: str, login: int, password: str, server: str, simbolo: str,
):
    if not connessione_mt5(path, login, password, server):
        return None
    try:
        mt5.symbol_select(simbolo, True)
        posizioni = mt5.positions_get(symbol=simbolo)
        # None = lettura FALLITA, () = nessuna posizione. Il vecchio "or []"
        # li rendeva identici, e il guardiano di coppia (che considera incerto
        # solo None) vedeva "chiusa" ogni gamba di quel conto: in automatica
        # richiudeva la gamba VIVA dell'altro lato. Sul dubbio: None.
        if posizioni is None:
            logger.warning(
                f"_get_open_positions_snapshot_sync({path}): MT5 non ha "
                f"risposto ({mt5.last_error()}), snapshot NON determinabile."
            )
            return None
        risultato = []
        for p in posizioni:
            risultato.append({
                "ticket":     p.ticket,
                "symbol":     p.symbol,
                "type":       "BUY" if p.type == mt5.POSITION_TYPE_BUY else "SELL",
                "volume":     p.volume,
                "profit":        p.profit,
                "price_open":    p.price_open,
                "price_current": p.price_current,
                "sl":            p.sl,
                "tp":            p.tp,
                "magic":         getattr(p, "magic", 0),
            })
        return risultato
    finally:
        _mt5_release()

def _get_open_tickets_by_symbol_sync(
    path: str, login: int, password: str, server: str, simbolo: str,
) -> Optional[list]:
    if not connessione_mt5(path, login, password, server):
        return None
    try:
        mt5.symbol_select(simbolo, True)
        posizioni = mt5.positions_get(symbol=simbolo)
        # Come nello snapshot: None e' "non so", non "nessun trade". Qui
        # alimenta la regola "un trade alla volta", che nel dubbio BLOCCA.
        if posizioni is None:
            logger.warning(
                f"_get_open_tickets_by_symbol_sync({path}): MT5 non ha "
                f"risposto ({mt5.last_error()}), ticket NON determinabili."
            )
            return None
        return [p.ticket for p in posizioni]
    finally:
        _mt5_release()

def _get_trade_history_sync(
    path: str, login: int, password: str, server: str,
    simbolo: str, days: int = 30, limit: Optional[int] = 15,
    since_utc: Optional[datetime] = None,
    magic_ranges: Optional[List[Tuple[int, int]]] = None,
) -> Optional[list]:
    """Storico dei trade CHIUSI su un conto (broker o prop), letto da MT5.

    Ritorna una lista (max 'limit' se non None, dal piu' recente al piu'
    vecchio) di dict:
      {open_time_utc, close_time_utc, esito, profit}
    dove 'esito' e' la causa di chiusura (Stop Loss / Take Profit / manuale...)
    e 'profit' e' il P/L NETTO realizzato in valuta (profit+commission+swap+fee).

    Periodo: se 'since_utc' e' fornito, tutti i trade chiusi DA quel momento
    (inizio del ciclo = ultimo Reset P/L); altrimenti gli ultimi 'days' giorni.

    'magic_ranges' = lista di (primo, oltre_ultimo): se fornita, tiene solo i
    trade aperti con un magic in uno di quegli intervalli. Serve sul conto
    BROKER, che puo' essere condiviso con un altro bot: li' lo storico MT5 e' di
    tutti e mostrarlo intero falsa i totali.
    Il magic si legge dal deal di INGRESSO, l'unico che lo porta con certezza
    (quello di uscita da SL/TP puo' arrivare a zero, dipende dal server). Se il
    deal di ingresso e' fuori finestra il magic resta ignoto e il trade viene
    TENUTO: meglio una riga di troppo che nascondere all'utente roba sua.

    Sorgente: mt5.history_deals_get, autorevole e persistente per ciascun conto
    (indipendente dai dati locali del bot). I deal vengono raggruppati per
    position_id: il deal di ENTRATA da' l'orario di apertura, quello di USCITA
    la causa di chiusura; il P/L e' la somma su tutti i deal della posizione
    (gestisce anche le chiusure parziali). Ritorna None solo se la connessione
    fallisce; [] se non ci sono trade nel periodo.
    """
    if not connessione_mt5(path, login, password, server):
        return None
    try:
        if since_utc is not None and since_utc.tzinfo is None:
            since_utc = since_utc.replace(tzinfo=timezone.utc)
        inizio_finestra = (
            since_utc if since_utc is not None
            else datetime.now(timezone.utc) - timedelta(days=days)
        )
        # Finestra allargata di 2 giorni: il filtro temporale di MT5 usa il fuso
        # del SERVER (spesso UTC+2/+3), quindi allarghiamo per non perdere i
        # trade al bordo; il taglio preciso avviene poi in Python.
        start = inizio_finestra - timedelta(days=2)
        end   = datetime.now(timezone.utc) + timedelta(days=1)
        deals = mt5.history_deals_get(start, end) or []

        in_entry  = getattr(mt5, "DEAL_ENTRY_IN",     0)
        out_entry = getattr(mt5, "DEAL_ENTRY_OUT",    1)
        out_by    = getattr(mt5, "DEAL_ENTRY_OUT_BY", 3)

        posizioni: Dict[int, Dict[str, Any]] = {}
        for d in deals:
            if getattr(d, "symbol", "") != simbolo:
                continue  # scarta altri strumenti e i movimenti di saldo (symbol vuoto)
            pid = int(getattr(d, "position_id", 0) or 0)
            if pid == 0:
                continue
            g = posizioni.setdefault(pid, {"in": None, "out": None, "net": 0.0, "magic": None})
            g["net"] += (
                float(getattr(d, "profit", 0) or 0)
                + float(getattr(d, "commission", 0) or 0)
                + float(getattr(d, "swap", 0) or 0)
                + float(getattr(d, "fee", 0) or 0)
            )
            t_msc = int(getattr(d, "time_msc", 0) or int(getattr(d, "time", 0)) * 1000)
            entry = getattr(d, "entry", None)
            if entry == in_entry:
                if g["in"] is None or t_msc < g["in"][0]:
                    g["in"] = (t_msc, d)
                    g["magic"] = int(getattr(d, "magic", 0) or 0)
            elif entry in (out_entry, out_by):
                if g["out"] is None or t_msc > g["out"][0]:
                    g["out"] = (t_msc, d)

        cutoff_ms = inizio_finestra.timestamp() * 1000
        risultato = []
        for g in posizioni.values():
            if g["out"] is None:
                continue  # posizione ancora aperta: non e' "storico"
            out_msc, out_deal = g["out"]
            if out_msc < cutoff_ms:
                continue  # chiusa oltre la finestra richiesta
            if magic_ranges and g["magic"] is not None:
                if not any(primo <= g["magic"] < oltre for primo, oltre in magic_ranges):
                    continue  # trade di un altro bot sullo stesso conto broker
            open_msc = g["in"][0] if g["in"] else out_msc
            reason   = int(getattr(out_deal, "reason", -1))
            risultato.append({
                "open_time_utc":  datetime.fromtimestamp(open_msc / 1000, tz=timezone.utc).isoformat(),
                "close_time_utc": datetime.fromtimestamp(out_msc / 1000, tz=timezone.utc).isoformat(),
                "esito":          _deal_reason_label(reason),
                "profit":         round(g["net"], 2),
            })
        risultato.sort(key=lambda r: r["close_time_utc"], reverse=True)
        return risultato[:limit] if limit is not None else risultato
    finally:
        _mt5_release()

def _prop_daily_realized_pnl_sync(
    path: str, login: int, password: str, server: str,
    simbolo: str, server_today: date,
) -> Optional[float]:
    """P/L NETTO realizzato OGGI (giorno-server) dai soli trade CHIUSI sulla prop.

    Somma profit+commission+swap+fee delle posizioni il cui deal di USCITA cade
    nella data-server 'server_today'. I movimenti di SALDO (deposito, prelievo/
    payout, reset/rinnovo prop) hanno symbol vuoto e vengono ESCLUSI dal filtro
    per simbolo: cosi' il P/L del giorno riflette SOLO il trading e non "salta"
    quando un rinnovo/reset riporta il saldo al capitale iniziale (era la causa
    del bug "perdita giornaliera 6000 invece di 3000").

    La data di ciascun deal e' derivata come fromtimestamp(deal.time), la STESSA
    convenzione di get_server_date che definisce 'server_today': il confronto e'
    quindi self-consistent, senza dover conoscere il fuso orario del server prop.

    Ritorna la somma (0.0 se oggi nessun trade e' stato chiuso) oppure None se la
    connessione MT5 fallisce (il chiamante ricade sul metodo per differenza saldo).
    """
    if not connessione_mt5(path, login, password, server):
        return None
    try:
        # Finestra ampia: cattura anche i deal di ENTRATA (con le loro commissioni)
        # delle posizioni aperte nei giorni scorsi ma CHIUSE oggi. Il filtro fine
        # "chiusa oggi" avviene poi per data-server del deal di uscita.
        start = datetime.now(timezone.utc) - timedelta(days=4)
        end   = datetime.now(timezone.utc) + timedelta(days=1)
        deals = mt5.history_deals_get(start, end) or []

        in_entry  = getattr(mt5, "DEAL_ENTRY_IN",     0)
        out_entry = getattr(mt5, "DEAL_ENTRY_OUT",    1)
        out_by    = getattr(mt5, "DEAL_ENTRY_OUT_BY", 3)

        def _raggruppa(elenco) -> Dict[int, Dict[str, Any]]:
            gruppi: Dict[int, Dict[str, Any]] = {}
            for d in elenco:
                if getattr(d, "symbol", "") != simbolo:
                    continue  # esclude altri strumenti e i movimenti di saldo (symbol vuoto)
                pid = int(getattr(d, "position_id", 0) or 0)
                if pid == 0:
                    continue
                g = gruppi.setdefault(pid, {"out_time": None, "net": 0.0, "ha_entrata": False})
                g["net"] += (
                    float(getattr(d, "profit", 0) or 0)
                    + float(getattr(d, "commission", 0) or 0)
                    + float(getattr(d, "swap", 0) or 0)
                    + float(getattr(d, "fee", 0) or 0)
                )
                entry = getattr(d, "entry", None)
                if entry == in_entry:
                    g["ha_entrata"] = True
                elif entry in (out_entry, out_by):
                    t = int(getattr(d, "time", 0) or 0)
                    if g["out_time"] is None or t > g["out_time"]:
                        g["out_time"] = t
            return gruppi

        def _chiusa_oggi(g: Dict[str, Any]) -> bool:
            if g["out_time"] is None:
                return False  # posizione ancora aperta: non concorre al realizzato
            try:
                return datetime.fromtimestamp(g["out_time"]).date() == server_today
            except (OverflowError, OSError, ValueError):
                return False

        posizioni = _raggruppa(deals)
        di_oggi   = {pid: g for pid, g in posizioni.items() if _chiusa_oggi(g)}

        # Una posizione APERTA piu' di 4 giorni fa e chiusa OGGI ha il suo deal
        # di ENTRATA fuori dalla finestra: la commissione di apertura (che molti
        # broker addebitano proprio li') mancherebbe dal conteggio, e la perdita
        # del giorno risulterebbe piu' LEGGERA del vero — cioe' l'errore nella
        # direzione peggiore per il margine di sicurezza prop. Se manca almeno
        # un'entrata, una SOLA rilettura larga rimette a posto quei pid.
        senza_entrata = [pid for pid, g in di_oggi.items() if not g["ha_entrata"]]
        if senza_entrata:
            logger.info(
                f"P/L giornaliero prop: {len(senza_entrata)} posizioni chiuse oggi "
                f"ma aperte oltre la finestra breve, rileggo lo storico esteso."
            )
            deals_estesi = mt5.history_deals_get(
                datetime.now(timezone.utc) - timedelta(days=180), end,
            ) or []
            if deals_estesi:
                completi = _raggruppa(deals_estesi)
                for pid in senza_entrata:
                    if pid in completi:
                        di_oggi[pid] = completi[pid]

        return round(sum(g["net"] for g in di_oggi.values()), 2)
    finally:
        try:
            _mt5_release()
        except Exception:
            pass
