import asyncio
import copy
import json
import logging
import os
import time
from datetime import date, datetime, timedelta, timezone
from typing import Callable, Dict, Any, Optional

logger = logging.getLogger(__name__)
from cryptography.fernet import Fernet

from .config import BACKUP_FILE, DATA_FILE, KEY_FILE, OWNER_CHAT_SIDECAR

# ========================= CIFRATURA =========================
def carica_o_genera_chiave() -> bytes:
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, "rb") as f:
            return f.read()
    key = Fernet.generate_key()
    with open(KEY_FILE, "wb") as f:
        f.write(key)
    return key

cipher = Fernet(carica_o_genera_chiave())

def _try_read_data_file(path: str) -> Optional[Dict[str, Any]]:
    """Tenta di leggere/decifrare un file di stato. Restituisce None su errore."""
    if not os.path.exists(path):
        return None
    try:
        with open(path, "rb") as f:
            content = f.read()
        if not content:
            return None
        return json.loads(cipher.decrypt(content))
    except Exception as e:
        logger.warning(f"Lettura fallita per {path}: {e}")
        return None

def carica_dati() -> Dict[str, Any]:
    """
    Carica lo stato dal file principale. Se illeggibile/corrotto, prova
    automaticamente il backup. Se nessuno dei due file esiste -> {} (primo avvio).
    Se almeno UNO esiste ma entrambi sono illeggibili -> solleva eccezione,
    per evitare un reset silenzioso di dati validi.
    """
    primary = _try_read_data_file(DATA_FILE)
    if primary is not None:
        return primary
    if not os.path.exists(DATA_FILE) and not os.path.exists(BACKUP_FILE):
        return {}
    logger.warning("File di stato principale assente o illeggibile, provo il backup.")
    backup = _try_read_data_file(BACKUP_FILE)
    if backup is not None:
        logger.warning("Recupero dati dal backup riuscito.")
        return backup
    raise RuntimeError(
        f"Sia '{DATA_FILE}' che '{BACKUP_FILE}' esistono ma sono illeggibili/corrotti. "
        "Avvio rifiutato per evitare il reset silenzioso. Ripristina manualmente un backup valido."
    )

# Su Windows os.replace fallisce con PermissionError se un ALTRO processo
# (antivirus, indicizzatore, backup) tiene un handle momentaneo sul file di
# destinazione. Non e' un errore vero: sparisce in decine di millisecondi.
# Senza ritentare, un salvataggio di stato fallirebbe del tutto — e sopra
# salva_dati passa anche il GIORNALE TRANSAZIONALE, cioe' la scrittura che
# avviene PRIMA di toccare il mercato. Stessa difesa gia' adottata
# nell'heartbeat (vedi loops.heartbeat_loop).
REPLACE_RETRY        = 5
REPLACE_RETRY_PAUSE_S = 0.15

def _replace_con_retry(src: str, dst: str) -> None:
    """os.replace atomico, con ritentativi sui lock transitori di Windows."""
    for tentativo in range(REPLACE_RETRY):
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if tentativo == REPLACE_RETRY - 1:
                raise
            logger.warning(
                f"Scrittura stato: '{os.path.basename(dst)}' momentaneamente "
                f"bloccato (tentativo {tentativo + 1}/{REPLACE_RETRY}), riprovo."
            )
            time.sleep(REPLACE_RETRY_PAUSE_S)

def salva_dati(dati: Dict[str, Any]) -> None:
    """
    Scrittura atomica con rotazione di backup:
      1) scrive su file temporaneo + fsync (durabile su disco)
      2) sposta il file precedente in .bak (rename atomico)
      3) sposta il temporaneo in DATA_FILE (rename atomico)

    Garanzia: in qualunque istante esiste sempre almeno UN file leggibile
    (DATA_FILE o BACKUP_FILE). Un kill brutale non puo' lasciare lo stato
    in un limbo vuoto.
    """
    payload = cipher.encrypt(json.dumps(dati).encode())
    tmp_file = DATA_FILE + ".tmp"
    try:
        with open(tmp_file, "wb") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        if os.path.exists(DATA_FILE):
            try:
                _replace_con_retry(DATA_FILE, BACKUP_FILE)
            except OSError as e:
                # Il backup e' un di piu': se non si aggiorna si prosegue
                # comunque (DATA_FILE resta valido finche' non lo sostituiamo).
                logger.warning(f"Impossibile aggiornare backup di stato: {e}")
        _replace_con_retry(tmp_file, DATA_FILE)
    except Exception:
        if os.path.exists(tmp_file):
            try:
                os.remove(tmp_file)
            except OSError:
                pass
        raise

# ========================= DATA LOCK =========================
data_lock = asyncio.Lock()

# Cache in memoria dello stato. Il bot e' l'UNICO scrittore di user_data.enc
# (garantito dal lock anti doppia-istanza), quindi dopo la prima lettura il
# disco non va piu' riletto: si rilegge solo alla partenza, si SCRIVE a ogni
# modifica (durabilita' invariata: scrittura atomica + fsync + backup).
# INVARIANTE: la cache non deve MAI essere aliasata da oggetti dati ai
# chiamanti: in v51 ogni lettura restituiva un dict fresco da json.loads e i
# chiamanti possono mutare il risultato senza effetti sullo stato. deepcopy
# in uscita preserva esattamente quella semantica.
_dati_cache: Optional[Dict[str, Any]] = None

def _copia_stato(d: Dict[str, Any]) -> Dict[str, Any]:
    return copy.deepcopy(d)

def invalida_cache_stato() -> None:
    """Forza la rilettura da disco alla prossima lettura (uso: test/manutenzione)."""
    global _dati_cache
    _dati_cache = None

async def carica_dati_async() -> Dict[str, Any]:
    global _dati_cache
    async with data_lock:
        # NON mascheriamo piu' l'eccezione: meglio fallire visibilmente che
        # operare su uno stato "vuoto" interpretando un file corrotto come
        # "primo avvio". carica_dati() gia' tenta il backup automaticamente.
        if _dati_cache is None:
            _dati_cache = carica_dati()
        return _copia_stato(_dati_cache)

async def leggi_chiave_async(chiave: str, default: Any = None) -> Any:
    """Legge UNA chiave di primo livello senza deepcopy dell'intero stato.

    carica_dati_async() copia tutto (trade_memos inclusi): per un controllo
    ripetuto a ogni click — es. guard_auth che verifica l'owner — e' spreco
    puro. I valori mutabili vengono comunque copiati, cosi' l'invariante
    "la cache non e' mai aliasata verso i chiamanti" resta intatta.
    """
    global _dati_cache
    async with data_lock:
        if _dati_cache is None:
            _dati_cache = carica_dati()
        valore = _dati_cache.get(chiave, default)
    return copy.deepcopy(valore) if isinstance(valore, (dict, list)) else valore

async def modifica_dati_async(
    modifier: Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]
) -> Dict[str, Any]:
    global _dati_cache
    async with data_lock:
        if _dati_cache is None:
            _dati_cache = carica_dati()
        dati = _copia_stato(_dati_cache)
        try:
            updated = modifier(dati)
            if updated is not None:
                if not isinstance(updated, dict):
                    raise TypeError("Il modifier deve restituire un dict o None")
                dati = updated
                salva_dati(dati)
                # La cache si aggiorna SOLO dopo un salvataggio riuscito: se
                # salva_dati solleva, disco (atomico) e cache restano coerenti
                # sul valore precedente.
                _dati_cache = _copia_stato(dati)
        except Exception:
            logger.exception("Errore durante modifica dati atomica")
            raise
        return dati

# ========================= MODIFIER TOP-LEVEL =========================
def modifier_set_owner_if_missing(d: dict, user_id: int) -> Optional[dict]:
    if d.get("owner_chat_id") is None:
        d["owner_chat_id"] = user_id
        return d
    return None

def modifier_set_owner_username(d: dict, username: Optional[str]) -> Optional[dict]:
    """Memorizza lo @username Telegram dell'owner (per mostrarlo in Stato Bot).
    Scrive solo se cambiato, per non generare salvataggi inutili a ogni /start."""
    uname = (username or "").strip().lstrip("@")
    if uname and d.get("owner_username") != uname:
        d["owner_username"] = uname
        return d
    return None

def modifier_sblocca_permanentemente(d: dict) -> dict:
    d["auth_permanente"] = True
    return d

def modifier_incrementa_magic(d: dict) -> dict:
    magic = d.get("next_magic", 1000)
    d["next_magic"] = magic + 1
    return d

def modifier_aggiungi_payout(d: dict, importo: float) -> dict:
    payouts = d.get("payouts", [])
    payouts.append({
        "data":    date.today().isoformat(),
        "importo": importo,
        "nota":    "",
    })
    d["payouts"] = payouts
    return d

def modifier_reset_password(d: dict, nuova_password: str) -> dict:
    d["password_bot"]    = nuova_password
    d["auth_permanente"] = False
    # Cambio password deliberato dall'owner: azzera l'eventuale lockout, cosi' chi
    # cambia la password non resta bloccato fuori da un lockout in corso.
    d["pwd_fail_count"]  = 0
    d["pwd_lock_until"]  = None
    return d

# ----- Autenticazione basata su PASSWORD (la password e' la chiave maestra) -----
PWD_MAX_ATTEMPTS    = 3      # tentativi errati consentiti prima del lockout
PWD_LOCKOUT_MINUTES = 60     # durata del blocco anti-forza-bruta (minuti)

def _modifier_imposta_password_e_owner(d: dict, password: str, user_id: int) -> dict:
    """Primo setup: imposta la password globale e rende owner chi la crea."""
    d["password_bot"]    = password
    d["owner_chat_id"]   = user_id
    d["auth_permanente"] = True
    d["pwd_fail_count"]  = 0
    d["pwd_lock_until"]  = None
    return d

def _modifier_claim_owner(d: dict, user_id: int) -> dict:
    """Login con password corretta: questo account diventa il (nuovo) owner.
    E' il meccanismo con cui il bot viene 'spostato' su un altro Telegram."""
    d["owner_chat_id"]   = user_id
    d["auth_permanente"] = True
    return d

def modifier_registra_tentativo_fallito(d: dict, max_attempts: int, lockout_minutes: int) -> dict:
    """Conta un tentativo password errato; al raggiungimento della soglia imposta
    un lockout temporale PERSISTENTE (non aggirabile con /start o riavvio)."""
    n = int(d.get("pwd_fail_count", 0) or 0) + 1
    if n >= max_attempts:
        d["pwd_lock_until"] = (datetime.now(timezone.utc) + timedelta(minutes=lockout_minutes)).isoformat()
        d["pwd_fail_count"] = 0
    else:
        d["pwd_fail_count"] = n
    return d

def modifier_reset_tentativi(d: dict) -> Optional[dict]:
    """Azzera contatore e lockout (dopo un login riuscito)."""
    if d.get("pwd_fail_count") or d.get("pwd_lock_until"):
        d["pwd_fail_count"] = 0
        d["pwd_lock_until"] = None
        return d
    return None

def _lockout_rimanente(dati: dict) -> int:
    """Minuti rimanenti di lockout password (0 se non bloccato)."""
    until = dati.get("pwd_lock_until")
    if not until:
        return 0
    try:
        t = datetime.fromisoformat(until)
        if t.tzinfo is None:
            t = t.replace(tzinfo=timezone.utc)
    except Exception:
        return 0
    rem_sec = (t - datetime.now(timezone.utc)).total_seconds()
    if rem_sec <= 0:
        return 0
    return int((rem_sec + 59) // 60)  # arrotonda per eccesso ai minuti

def modifier_set_key(d: dict, key: str, value: Any) -> dict:
    d[key] = value
    return d

def _scrivi_owner_sidecar(owner_chat_id) -> None:
    """
    Scrive l'owner_chat_id (numero della chat Telegram) in chiaro in
    OWNER_CHAT_SIDECAR. Serve al watchdog esterno per inviare gli avvisi:
    il watchdog non puo' leggere user_data.enc (cifrato), quindi gli passiamo
    solo questo identificativo. Il token vero resta nel .env.
    """
    try:
        if owner_chat_id is None:
            return
        tmp = OWNER_CHAT_SIDECAR + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(str(owner_chat_id))
        os.replace(tmp, OWNER_CHAT_SIDECAR)
    except OSError as e:
        logger.warning(f"Impossibile scrivere {OWNER_CHAT_SIDECAR}: {e}")
