"""Pool di worker MT5: un processo per terminale, connessioni sempre calde.

Instrada ogni operazione MT5 al worker del terminale giusto. Broker e Prop
lavorano IN PARALLELO (un asyncio.Lock per terminale, non piu' uno globale):
le due gambe dell'hedge possono partire simultaneamente e i loop non si
mettono piu' in coda dietro la UI.

Robustezza:
  - richieste con id univoco: una risposta rimasta orfana (per un timeout del
    chiamante) viene riconosciuta e scartata, MAI consegnata alla richiesta
    sbagliata;
  - un timeout del chiamante NON uccide il worker (l'ordine in volo potrebbe
    ancora eseguire: ci pensa il controllo anti-duplicato); dopo
    WORKER_TIMEOUTS_PRIMA_DEL_RESTART timeout consecutivi il worker viene
    riavviato (MT5 realmente bloccato);
  - worker morto/pipe rotta: respawn automatico e UN retry della chiamata;
  - fallback: se i worker sono disattivati (MT5_WORKERS=0) o non partono,
    si torna al modello v52 in-process (lock globale mt5_lock + to_thread),
    identico nei comportamenti.
"""
import asyncio
import contextlib
import functools
import logging
import multiprocessing
import os
import threading
import time as _t
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

from .config import MT5_BROKER_EXE, MT5_OP_TIMEOUT_SECONDS, MT5_PROP_EXE, MT5_WORKERS_ENABLED
from .mt5_worker import DISPATCH, STOP, worker_main

# Lock GLOBALE, identico alla v51/v52: serializza le operazioni MT5 quando si
# lavora in-process (fallback). In modalita' worker non viene usato per le
# operazioni (ogni terminale ha il suo lock) ma resta esportato per
# compatibilita'.
mt5_lock = asyncio.Lock()

# ---------------------------------------------------------------------------
# TIMEOUT — la regola: il worker deve arrendersi PRIMA del chiamante.
#
# I wrapper async passano da _mt5_timeout, che usa asyncio.wait_for con budget
# MT5_OP_TIMEOUT_SECONDS. Quando wait_for scade, la coroutine viene cancellata
# e il lock del terminale RILASCIATO — ma il thread sottostante NON e'
# cancellabile e continua a parlare sul pipe. Con un timeout del worker piu'
# LUNGO del wrapper, il chiamante successivo prendeva il lock ormai libero e
# scriveva sullo STESSO pipe da un secondo thread: multiprocessing.Connection
# non e' thread-safe -> risposte consegnate alla richiesta sbagliata, frame
# pickle spezzati, worker da respawnare. E con l'executor di default saturo di
# thread orfani, l'intero bot si fermava mentre l'heartbeat continuava a
# battere: il watchdog non se ne sarebbe mai accorto.
#
# Due difese, indipendenti: (1) questi timeout ordinati; (2) il lock di pipe
# dentro _Worker, che rende impossibile la scrittura concorrente comunque.
# ---------------------------------------------------------------------------
WORKER_CALL_TIMEOUT_S             = max(5, MT5_OP_TIMEOUT_SECONDS - 5)
# Per le operazioni NON avvolte in _mt5_timeout (invio ordini, verifica
# credenziali): li' il chiamante attende quanto serve, e un ordine merita
# pazienza.
WORKER_ORDER_TIMEOUT_S            = 90
WORKER_TIMEOUTS_PRIMA_DEL_RESTART = 2
# Thread dedicati alle chiamate MT5: isolano il resto del bot (Telegram,
# storage, loop) dai blocchi di un terminale. Sono 2 i terminali: 8 slot
# lasciano margine agli eventuali orfani senza mai affamare nessuno.
ESECUTORE_MAX_THREAD              = 8
_SPAWN_CTX = multiprocessing.get_context("spawn")


class Mt5PoolError(RuntimeError):
    """Errore di trasporto/esecuzione nel worker (non un esito MT5)."""


class _Worker:
    """Lato-padre di un processo worker: spawn, chiamate bloccanti id-matched."""

    def __init__(self, path: str, nome: str):
        self.path = path
        self.nome = nome
        self.proc = None
        self.conn = None
        self.timeout_consecutivi = 0
        # Lock di PIPE: garantisce che un solo thread per volta parli con
        # questo worker, ANCHE quando il lock asyncio e' gia' stato rilasciato
        # perche' il chiamante e' andato in timeout e ha abbandonato il thread.
        # multiprocessing.Connection non e' thread-safe: senza questo, due
        # send/recv sovrapposti corrompono il canale.
        self._pipe_lock = threading.Lock()

    def vivo(self) -> bool:
        return self.proc is not None and self.proc.is_alive()

    def spawn(self) -> None:
        parent_conn, child_conn = _SPAWN_CTX.Pipe(duplex=True)
        proc = _SPAWN_CTX.Process(
            target=worker_main, args=(child_conn, self.nome),
            name=f"mt5-worker-{self.nome}", daemon=True,
        )
        proc.start()
        child_conn.close()
        self.proc = proc
        self.conn = parent_conn
        self.timeout_consecutivi = 0
        logger.info(f"Worker MT5 '{self.nome}' avviato (pid {proc.pid}).")

    def kill(self) -> None:
        try:
            if self.conn is not None:
                self.conn.close()
        except Exception:
            pass
        try:
            if self.proc is not None and self.proc.is_alive():
                self.proc.terminate()
                self.proc.join(timeout=3)
        except Exception:
            pass
        self.proc = None
        self.conn = None

    def stop(self) -> None:
        try:
            if self.vivo() and self.conn is not None:
                self.conn.send(STOP)
                self.proc.join(timeout=5)
        except Exception:
            pass
        self.kill()

    # ---- chiamata bloccante (eseguita in un thread via asyncio.to_thread) ----
    def _drain_risposte_orfane(self) -> None:
        try:
            while self.conn.poll(0):
                orfana = self.conn.recv()
                logger.warning(f"Worker '{self.nome}': scartata risposta orfana {str(orfana)[:120]}")
        except (EOFError, OSError):
            pass

    def call(self, func: str, args: tuple, kwargs: dict, timeout: float) -> Any:
        # Il lock copre TUTTA la conversazione (send + attesa + recv). L'attesa
        # e' limitata dallo stesso budget della chiamata: se un thread orfano
        # sta ancora occupando il pipe oltre il tempo concesso, si fallisce in
        # modo pulito invece di accodarsi all'infinito.
        if not self._pipe_lock.acquire(timeout=max(0.1, timeout)):
            raise Mt5PoolError(
                f"worker '{self.nome}' occupato da una chiamata precedente "
                f"su {func} (attesa {timeout}s scaduta)"
            )
        try:
            return self._call_locked(func, args, kwargs, timeout)
        finally:
            self._pipe_lock.release()

    def _call_locked(self, func: str, args: tuple, kwargs: dict, timeout: float) -> Any:
        if not self.vivo():
            self.spawn()
        req_id = uuid.uuid4().hex
        try:
            self._drain_risposte_orfane()
            self.conn.send((req_id, func, args, kwargs))
            deadline = _t.monotonic() + timeout
            while True:
                resto = deadline - _t.monotonic()
                if resto <= 0:
                    self.timeout_consecutivi += 1
                    if self.timeout_consecutivi >= WORKER_TIMEOUTS_PRIMA_DEL_RESTART:
                        logger.error(
                            f"Worker '{self.nome}': {self.timeout_consecutivi} timeout "
                            f"consecutivi, lo riavvio (MT5 presumibilmente bloccato)."
                        )
                        self.kill()
                    raise Mt5PoolError(f"timeout worker '{self.nome}' su {func} ({timeout}s)")
                if self.conn.poll(min(resto, 1.0)):
                    rid, ok, payload = self.conn.recv()
                    if rid != req_id:
                        logger.warning(f"Worker '{self.nome}': risposta orfana per {rid}, scartata.")
                        continue
                    self.timeout_consecutivi = 0
                    if ok:
                        return payload
                    raise Mt5PoolError(f"errore nel worker '{self.nome}' su {func}: {payload}")
        except (EOFError, OSError, BrokenPipeError) as e:
            logger.error(f"Worker '{self.nome}': pipe rotta ({e}), respawn e retry.")
            self.kill()
            # UN solo retry: sicuro anche per gli ordini, perche' il chiamante
            # (esegui_ordine_async) fa comunque il controllo anti-duplicato.
            # Ogni guasto del retry viene tradotto in Mt5PoolError, cosi' i
            # chiamanti vedono SEMPRE lo stesso tipo di errore da assorbire.
            try:
                self.spawn()
                self._drain_risposte_orfane()
                self.conn.send((req_id, func, args, kwargs))
                if self.conn.poll(timeout):
                    rid, ok, payload = self.conn.recv()
                    if rid == req_id and ok:
                        return payload
                    raise Mt5PoolError(f"retry fallito nel worker '{self.nome}' su {func}")
                raise Mt5PoolError(f"timeout al retry nel worker '{self.nome}' su {func}")
            except Mt5PoolError:
                raise
            except Exception as e2:
                raise Mt5PoolError(
                    f"retry impossibile nel worker '{self.nome}' su {func}: {e2}"
                ) from e2


class Mt5Pool:
    def __init__(self):
        self.enabled = MT5_WORKERS_ENABLED
        self._workers: Dict[str, _Worker] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
        self._executor: Optional[ThreadPoolExecutor] = None

    # ---- esecuzione bloccante su thread DEDICATI ----
    def _esecutore(self) -> ThreadPoolExecutor:
        """Pool di thread riservato a MT5.

        asyncio.to_thread usa l'executor di DEFAULT, condiviso con tutto il
        resto del bot e dimensionato min(32, cpu+4): su una VPS a 2 vCPU sono
        6 slot. Bastavano pochi thread rimasti appesi su un terminale bloccato
        per esaurirlo — e da quel momento OGNI operazione in thread del bot si
        accodava, mentre l'heartbeat (che gira sul loop) continuava a battere e
        il watchdog non riavviava nulla. Con un executor separato il danno
        resta confinato a MT5.
        """
        if self._executor is None:
            self._executor = ThreadPoolExecutor(
                max_workers=ESECUTORE_MAX_THREAD, thread_name_prefix="mt5-pool",
            )
        return self._executor

    async def _in_thread(self, fn, *args: Any, **kwargs: Any) -> Any:
        loop = asyncio.get_running_loop()
        chiamata = functools.partial(fn, *args, **kwargs)
        return await loop.run_in_executor(self._esecutore(), chiamata)

    def chiudi_esecutore(self) -> None:
        """Rilascia i thread MT5. Solo a fine vita del processo: il fallback
        in-process continua a usarli anche dopo pool.stop()."""
        if self._executor is not None:
            self._executor.shutdown(wait=False, cancel_futures=True)
            self._executor = None

    @staticmethod
    def _nome(path: str) -> str:
        if path == MT5_BROKER_EXE:
            return "broker"
        if path == MT5_PROP_EXE:
            return "prop"
        return os.path.basename(os.path.dirname(path)) or "mt5"

    def lock(self, path: str) -> asyncio.Lock:
        """Lock del terminale: per-path in modalita' worker, GLOBALE in
        fallback (fedele alla serializzazione totale v51)."""
        if not self.enabled:
            return mt5_lock
        return self._locks.setdefault(path, asyncio.Lock())

    def _worker(self, path: str) -> _Worker:
        w = self._workers.get(path)
        if w is None:
            w = _Worker(path, self._nome(path))
            self._workers[path] = w
        return w

    async def avvia(self) -> None:
        """Spawn anticipato dei due worker + ping di verifica. Se lo spawn
        fallisce si degrada al fallback in-process (nessun blocco del bot)."""
        if not self.enabled:
            logger.info("Pool MT5: worker disattivati (MT5_WORKERS=0), modalita' in-process.")
            return
        try:
            for path in (MT5_BROKER_EXE, MT5_PROP_EXE):
                async with self.lock(path):
                    pid = await self._in_thread(
                        self._worker(path).call, "__ping__", (), {}, 30,
                    )
                    logger.info(f"Pool MT5: worker '{self._nome(path)}' pronto (pid {pid}).")
        except Exception:
            logger.exception(
                "Pool MT5: avvio worker fallito. Degrado al fallback in-process "
                "(comportamento v52, tutto continua a funzionare)."
            )
            await self.stop()
            self.enabled = False

    async def stop(self) -> None:
        for w in list(self._workers.values()):
            await self._in_thread(w.stop)
        self._workers.clear()

    @contextlib.asynccontextmanager
    async def sessione_esclusiva(self, path: str):
        """Tiene il terminale per l'INTERA durata del blocco.

        Serve ai flussi che devono vedere una sessione MT5 stabile su piu'
        chiamate consecutive — in pratica la verifica delle credenziali: senza,
        tra un tentativo e l'altro i loop di fondo (guardiano di coppia ogni 2s,
        baseline prop) riautenticano il terminale sul conto PRECEDENTE e il
        login del conto nuovo fallisce per pura interferenza. Dentro il blocco
        si usa exec_no_lock(), che NON riprende il lock.
        """
        async with self.lock(path):
            yield

    async def exec_no_lock(self, path: str, func: str, *args: Any,
                           timeout: float = WORKER_CALL_TIMEOUT_S, **kwargs: Any) -> Any:
        """Come exec ma SENZA prendere il lock del terminale: da usare solo
        quando il chiamante lo detiene gia' (sessione_esclusiva, riavvio
        terminale). Prenderlo di nuovo sarebbe un auto-deadlock."""
        if self.enabled:
            w = self._worker(path)
            return await self._in_thread(w.call, func, args, kwargs, timeout)
        fn = DISPATCH[func]
        return await self._in_thread(fn, *args, **kwargs)

    async def exec(self, path: str, func: str, *args: Any,
                   timeout: float = WORKER_CALL_TIMEOUT_S, **kwargs: Any) -> Any:
        """Esegue `func` (whitelist DISPATCH) sul terminale `path`.
        Solleva Mt5PoolError su problemi di trasporto; i chiamanti wrappati in
        _mt5_timeout la assorbono esattamente come gli errori v51."""
        if self.enabled:
            async with self.lock(path):
                w = self._worker(path)
                return await self._in_thread(w.call, func, args, kwargs, timeout)
        # Fallback in-process: identico alla v52 (lock globale + thread).
        fn = DISPATCH[func]
        async with mt5_lock:
            return await self._in_thread(fn, *args, **kwargs)


pool = Mt5Pool()
