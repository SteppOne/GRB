import asyncio
import logging
import uuid
from datetime import datetime, timezone
from functools import partial
from typing import Dict, Any, Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import NetworkError
from telegram.ext import (
    ConversationHandler,
    ContextTypes,
)

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    CHIUDI_CONFIRM,
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    PWD_CONFIRM,
    PWD_NEW,
    SIMBOLO_BROKER,
    SL,
    TEST_CONFIRM,
)
from .messaging import (
    _cancel_kb,
    _compose_trade_close_message,
    _mark_trade_pair_closed,
    ack,
    back_button,
    notifica_owner,
    safe_edit_message_text,
)
from .storage import carica_dati_async, modifica_dati_async, modifier_reset_password
from .state import modifier_chiudi_challenge_per_ticket
from .mt5_sync import MSG_AUTOTRADING_OFF
from .mt5_async import (
    _close_info_con_retry,
    chiudi_posizione_async,
    esegui_ordine_async,
    get_open_tickets_by_symbol_async,
    valida_simbolo_volume_async,
)
from .trade_core import _ora_italiana
from .hedge_journal import journal_put, journal_remove, journal_update
from .news import trading_bloccato_ora_o_news
from .handlers_base import guard_auth, mostra_menu_principale

# ========================= CHIUSURA TRADE =========================
async def chiudi_trade_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    dati = await carica_dati_async()
    broker = dati.get("broker")
    prop   = dati.get("prop")
    if not broker or not prop:
        await safe_edit_message_text(
            query, "❌ Credenziali mancanti.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    tickets_b = await get_open_tickets_by_symbol_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    )
    tickets_p = await get_open_tickets_by_symbol_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if tickets_b is None or tickets_p is None:
        await safe_edit_message_text(
            query, "❌ Impossibile verificare le posizioni aperte.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    tot = len(tickets_b) + len(tickets_p)
    if tot == 0:
        await safe_edit_message_text(
            query, "ℹ️ Nessun trade aperto da chiudere.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    context.user_data["chiudi_tickets_broker"] = tickets_b
    context.user_data["chiudi_tickets_prop"]   = tickets_p
    keyboard = [
        [InlineKeyboardButton("✅ Sì, chiudi tutto", callback_data="chiudi_si")],
        [InlineKeyboardButton("❌ No",              callback_data="chiudi_no")],
        [InlineKeyboardButton("⬅️ Indietro",        callback_data="manuale")],
    ]
    testo = (
        "Vuoi chiudere tutti i trade aperti?\n\n"
        f"🏦 Broker: {len(tickets_b)} posizione/i aperta/e\n"
        f"🏢 Prop: {len(tickets_p)} posizione/i aperta/e"
    )
    await safe_edit_message_text(query, testo, InlineKeyboardMarkup(keyboard))
    return CHIUDI_CONFIRM

async def chiudi_trade_conferma(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    # Ricontrollo anche al passo di CONFERMA: tra l'ingresso nel flusso e il
    # click possono passare minuti, e nel frattempo la sessione puo' non essere
    # piu' valida (cambio password, bot spostato su un altro Telegram).
    if not await guard_auth(update, context):
        return ConversationHandler.END
    if query.data == "chiudi_no":
        await safe_edit_message_text(
            query, "Operazione annullata.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    dati = await carica_dati_async()
    broker      = dati.get("broker")
    prop        = dati.get("prop")
    trade_memos = dati.get("trade_memos", {})
    if not broker or not prop:
        await safe_edit_message_text(
            query, "❌ Credenziali mancanti.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    tickets_b = await get_open_tickets_by_symbol_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    ) or []
    tickets_p = await get_open_tickets_by_symbol_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    ) or []
    if not tickets_b and not tickets_p:
        await safe_edit_message_text(
            query, "ℹ️ Nessun trade aperto da chiudere.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    await safe_edit_message_text(query, "⏳ Chiusura trade in corso...")

    # Giornale transazionale: la lista di chiusure va su disco PRIMA di
    # iniziare, cosi' un crash a meta' non lascia coppie mezze aperte
    # (il recovery riprende dalle chiusure rimanenti).
    journal_id  = uuid.uuid4().hex[:8]
    done_tokens: list = []
    await journal_put(
        journal_id, kind="close_pairs",
        tickets_broker=[int(t) for t in tickets_b],
        tickets_prop=[int(t) for t in tickets_p],
        done=[], nota="chiusura manuale",
    )

    chiusi_b = 0
    chiusi_p = 0
    memo_lines = []
    updates_to_save: Dict[Tuple[int, int], Dict[str, Any]] = {}

    for ticket in tickets_b:
        if await chiudi_posizione_async(
            MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], ticket,
        ):
            chiusi_b += 1
            done_tokens.append(f"broker:{int(ticket)}")
            await journal_update(journal_id, done=list(done_tokens))
            record = trade_memos.get(str(ticket), {}) or {}
            memo   = record.get("memo", "")
            if memo:
                memo_lines.append(f"🏦 Broker {ticket}: {memo}")
            close_info = await _close_info_con_retry(
                MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
                ticket, record.get("opened_at_utc"),
            )
            if close_info:
                pair_b = int(record.get("broker_ticket", ticket))
                pair_p = int(record.get("prop_ticket", ticket))
                updates_to_save[(pair_b, pair_p)] = {
                    **updates_to_save.get((pair_b, pair_p), {}),
                    "broker_close_info":   close_info,
                    "pair_closed_notified": True,
                    "closed_source":       "manuale",
                    "closed_at_utc":       datetime.now(timezone.utc).isoformat(),
                }

    for ticket in tickets_p:
        if await chiudi_posizione_async(
            MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], ticket,
        ):
            chiusi_p += 1
            done_tokens.append(f"prop:{int(ticket)}")
            await journal_update(journal_id, done=list(done_tokens))
            record = trade_memos.get(str(ticket), {}) or {}
            memo   = record.get("memo", "")
            if memo:
                memo_lines.append(f"🏢 Prop {ticket}: {memo}")
            close_info = await _close_info_con_retry(
                MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
                ticket, record.get("opened_at_utc"),
            )
            if close_info:
                pair_b = int(record.get("broker_ticket", ticket))
                pair_p = int(record.get("prop_ticket", ticket))
                updates_to_save[(pair_b, pair_p)] = {
                    **updates_to_save.get((pair_b, pair_p), {}),
                    "prop_close_info":     close_info,
                    "pair_closed_notified": True,
                    "closed_source":       "manuale",
                    "closed_at_utc":       datetime.now(timezone.utc).isoformat(),
                }

    for (pair_b, pair_p), upd in updates_to_save.items():
        await _mark_trade_pair_closed(pair_b, pair_p, upd)

    # Un eventuale TRADE-SFIDA sulla prop e' stato chiuso qui dentro: va
    # dichiarato, altrimenti il suo backstop continuerebbe a tentare di
    # richiudere un ticket che non esiste piu' (e ad avvisare l'owner ogni
    # minuto, per sempre).
    if tickets_p:
        await modifica_dati_async(partial(
            modifier_chiudi_challenge_per_ticket, tickets=[int(t) for t in tickets_p],
        ))

    if chiusi_b == len(tickets_b) and chiusi_p == len(tickets_p):
        await journal_remove(journal_id)   # tutto chiuso: intento concluso
    # altrimenti l'intento resta: il recovery ritenta le chiusure mancate.

    msg = (
        "✅ Trade chiusi con successo.\n\n"
        f"🏦 Broker chiusi: {chiusi_b}\n"
        f"🏢 Prop chiusi: {chiusi_p}"
    )
    if memo_lines:
        msg += "\n\n📝 Memo associati:\n" + "\n".join(f"• {line}" for line in memo_lines[:10])
    await safe_edit_message_text(
        query, msg, InlineKeyboardMarkup([back_button("manuale")]),
    )

    close_notes = []
    for (pair_b, pair_p), upd in updates_to_save.items():
        record = trade_memos.get(str(pair_b), {}) or trade_memos.get(str(pair_p), {}) or {}
        close_notes.append(
            _compose_trade_close_message(
                {**record, **upd},
                upd.get("broker_close_info"),
                upd.get("prop_close_info"),
                trigger_label="manualmente",
            )
        )
    if close_notes:
        await notifica_owner(context.application, "\n\n".join(close_notes))
    return ConversationHandler.END

# ========================= TEST TRADING =========================
async def test_trading_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    bloccato, motivo = await trading_bloccato_ora_o_news()
    if bloccato:
        await safe_edit_message_text(
            query, f"⛔ {motivo}",
            InlineKeyboardMarkup([back_button("diagnosi")]),
        )
        return ConversationHandler.END
    await safe_edit_message_text(
        query, "Avviare test? (0.01 lotti, chiusura dopo 10s)",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ Sì", callback_data="test_si"),
            InlineKeyboardButton("❌ No", callback_data="test_no"),
        ]]),
    )
    return TEST_CONFIRM

async def esegui_test(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    dati = await carica_dati_async()
    br = dati.get("broker")
    pr = dati.get("prop")
    if not br or not pr:
        await safe_edit_message_text(
            query, "Credenziali mancanti.",
            InlineKeyboardMarkup([back_button("diagnosi")]),
        )
        return ConversationHandler.END
    bloccato, motivo = await trading_bloccato_ora_o_news()
    if bloccato:
        await safe_edit_message_text(
            query, f"⛔ {motivo}",
            InlineKeyboardMarkup([back_button("diagnosi")]),
        )
        return ConversationHandler.END
    await safe_edit_message_text(query, "⏳ Test in corso... attendi 10 secondi.")
    # Volume minimo del test: validiamo prima su entrambi i conti, cosi' un
    # eventuale volume non valido viene segnalato chiaramente invece di far
    # fallire l'ordine in modo criptico.
    test_vol = 0.01
    valid_b, err_b = await valida_simbolo_volume_async(MT5_BROKER_EXE, SIMBOLO_BROKER, test_vol)
    if not valid_b:
        await safe_edit_message_text(
            query, f"❌ Test: volume {test_vol} non valido sul Broker: {err_b}",
            InlineKeyboardMarkup([back_button("diagnosi")]),
        )
        return ConversationHandler.END
    valid_p, err_p = await valida_simbolo_volume_async(MT5_PROP_EXE, cfg.SIMBOLO_PROP, test_vol)
    if not valid_p:
        await safe_edit_message_text(
            query, f"❌ Test: volume {test_vol} non valido sulla Prop: {err_p}",
            InlineKeyboardMarkup([back_button("diagnosi")]),
        )
        return ConversationHandler.END

    # Giornale transazionale anche per il TEST: apre due posizioni reali (per
    # quanto minime) in sequenza. Un crash tra la prima e la seconda le
    # lasciava a mercato, segnalate come "orfane" al boot ma MAI richiuse: era
    # l'unico percorso di mercato rimasto fuori dal giornale.
    magic_test = 9999
    journal_id = uuid.uuid4().hex[:8]
    await journal_put(
        journal_id, kind="test_open", status="ordering", magic=magic_test,
        lotti=test_vol,
    )
    # sl/tp = 0.0 FLOAT (no SL/TP). Passare interi farebbe tornare order_send=None.
    ticket_b, motivo_b = await esegui_ordine_async(
        MT5_BROKER_EXE, int(br["id"]), br["password"], br["server"],
        "BUY", SIMBOLO_BROKER, test_vol, 0.0, 0.0, magic=magic_test,
    )
    await journal_update(journal_id, ticket_broker=int(ticket_b) if ticket_b else None)
    ticket_p, motivo_p = await esegui_ordine_async(
        MT5_PROP_EXE, int(pr["id"]), pr["password"], pr["server"],
        "SELL", cfg.SIMBOLO_PROP, test_vol, 0.0, 0.0, magic=magic_test,
    )
    await journal_update(
        journal_id, ticket_prop=int(ticket_p) if ticket_p else None, status="opened",
    )
    if not ticket_b or not ticket_p:
        if ticket_b:
            await chiudi_posizione_async(MT5_BROKER_EXE, int(br["id"]), br["password"], br["server"], ticket_b)
        if ticket_p:
            await chiudi_posizione_async(MT5_PROP_EXE, int(pr["id"]), pr["password"], pr["server"], ticket_p)
        # L'intento resta SOLO se qualcosa e' rimasto davvero aperto: il
        # recovery se ne occupa. Altrimenti si chiude qui.
        await journal_remove(journal_id)
        dettaglio = motivo_b or motivo_p or "motivo non disponibile"
        # AutoTrading spento: mostro il pulsante di riavvio del/i terminale/i
        # interessato/i (qui conosco i motivi per lato: broker e prop separati).
        righe = []
        if motivo_b and MSG_AUTOTRADING_OFF in motivo_b:
            righe.append([InlineKeyboardButton("🔄 Riavvia terminale Broker", callback_data="riavvia_broker")])
        if motivo_p and MSG_AUTOTRADING_OFF in motivo_p:
            righe.append([InlineKeyboardButton("🔄 Riavvia terminale Prop", callback_data="riavvia_prop")])
        righe.append(back_button("diagnosi"))
        await safe_edit_message_text(
            query, f"❌ Test fallito.\nMotivo: {dettaglio}.",
            InlineKeyboardMarkup(righe),
        )
        return ConversationHandler.END
    await asyncio.sleep(10)
    chiuso_b = await chiudi_posizione_async(
        MT5_BROKER_EXE, int(br["id"]), br["password"], br["server"], ticket_b)
    chiuso_p = await chiudi_posizione_async(
        MT5_PROP_EXE, int(pr["id"]), pr["password"], pr["server"], ticket_p)
    if chiuso_b and chiuso_p:
        await journal_remove(journal_id)     # test concluso: intento consumato
        testo = "✅ Test completato, posizioni chiuse."
    else:
        # Intento lasciato nel giornale: il recovery riprova ogni minuto
        # finche' le posizioni di prova non sono davvero chiuse.
        await journal_update(journal_id, status="orphan")
        lato = "Broker" if not chiuso_b else "Prop"
        testo = (
            f"⚠️ Test eseguito, ma la posizione {lato} non si è chiusa.\n"
            f"Il recupero automatico riproverà a breve; se persiste, chiudila "
            f"a mano dal terminale."
        )
    await safe_edit_message_text(
        query, testo, InlineKeyboardMarkup([back_button("diagnosi")]),
    )
    return ConversationHandler.END

async def annulla_test(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "Test annullato.")
    return ConversationHandler.END

# ========================= CAMBIO PASSWORD =========================
async def cambia_password_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "Inserisci nuova password:", _cancel_kb())
    return PWD_NEW

async def ricevi_nuova_pwd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    nuova = update.message.text
    if not nuova or not nuova.strip():
        await update.message.reply_text("Password non valida. Riprova.", reply_markup=_cancel_kb())
        return PWD_NEW
    context.user_data["nuova_pwd"] = nuova
    await update.message.reply_text("Conferma password:", reply_markup=_cancel_kb())
    return PWD_CONFIRM

async def conferma_nuova_pwd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text != context.user_data.get("nuova_pwd"):
        await update.message.reply_text("Le password non corrispondono. Riprova.", reply_markup=_cancel_kb())
        return PWD_NEW
    await modifica_dati_async(
        partial(modifier_reset_password, nuova_password=context.user_data["nuova_pwd"])
    )
    context.user_data.pop("authenticated", None)
    context.user_data.pop("waiting_for_password", None)
    await update.message.reply_text("✅ Password aggiornata. Al prossimo accesso ti verrà richiesta.")
    await mostra_menu_principale(update, context)
    return ConversationHandler.END

# ========================= NOTIZIE / INFO BOT =========================
async def notizie(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    dati = await carica_dati_async()
    eventi = dati.get("news_events", [])
    blackout_until = dati.get("news_blackout_until")
    lines = ["📰 Calendario news", ""]
    if blackout_until:
        try:
            until = datetime.fromisoformat(blackout_until)
            if until.tzinfo is None:
                until = until.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) < until:
                lines.append(f"⛔ Blackout attivo fino a: {_ora_italiana(until).strftime('%Y-%m-%d %H:%M')} (ora italiana)")
                lines.append("")
        except Exception:
            pass
    now_utc = datetime.now(timezone.utc)
    if not eventi:
        lines.append("Nessuna notizia impattante fino a fine giornata di domani.")
        lines.append("")
        lines.append("Il monitor e' attivo ✅")
    else:
        prossima = eventi[0]
        try:
            ev_time = datetime.fromisoformat(prossima.get("time", ""))
            if ev_time.tzinfo is None:
                ev_time = ev_time.replace(tzinfo=timezone.utc)
            delta_min = (ev_time - now_utc).total_seconds() / 60.0
            ore      = int(delta_min // 60)
            min_rest = int(delta_min % 60)
            if delta_min <= 0:
                countdown = "IMMINENTE"
            elif ore > 0:
                countdown = f"tra {ore}h {min_rest}m"
            else:
                countdown = f"tra {min_rest}m"
            orario_str = _ora_italiana(ev_time).strftime("%d/%m %H:%M")
        except Exception:
            countdown  = ""
            orario_str = str(prossima.get("time", ""))[:16]
            ev_time    = None
        lines.append("PROSSIMA chiusura automatica:")
        lines.append(f"  Data:  {orario_str} (ora italiana)  ({countdown})")
        lines.append(f"  Valuta: {prossima.get('currency', '')} — {prossima.get('title', '')}")
        if len(eventi) > 1:
            lines.append("")
            lines.append("Successive:")
            for ev in eventi[1:4]:
                try:
                    t = datetime.fromisoformat(ev.get("time", ""))
                    if t.tzinfo is None:
                        t = t.replace(tzinfo=timezone.utc)
                    d_m  = (t - now_utc).total_seconds() / 60
                    ore_s = int(d_m // 60)
                    m_s   = int(d_m % 60)
                    cs = f"tra {ore_s}h {m_s}m" if ore_s > 0 else f"tra {m_s}m"
                    lines.append(
                        f"  {_ora_italiana(t).strftime('%d/%m %H:%M')} | "
                        f"{ev.get('currency','')} | {ev.get('title','')} ({cs})"
                    )
                except Exception:
                    lines.append(
                        f"  {ev.get('time','')[:16]} | "
                        f"{ev.get('currency','')} | {ev.get('title','')}"
                    )
    lines.append("")
    ###lines.append(f"Valute monitorate: {'  '.join(sorted(NEWS_XAUUSD_CURRENCIES))}")
    await safe_edit_message_text(
        query, "\n".join(lines),
        InlineKeyboardMarkup([back_button("gestisci")]),
    )

async def info_bot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    # Versione letta dal pacchetto: era scritta a mano ("0.5.1.1") e dopo ogni
    # aggiornamento OTA mostrava un numero che non esisteva piu'.
    from . import __version__
    testo = (
        "ℹ️ Info Bot\n\n💰💰💰🚂 GoldenRail ✨💰💰💰\n\n"
        f"• Autore: @thedowser \n• Versione: {__version__}"
    )
    await safe_edit_message_text(
        query, testo, InlineKeyboardMarkup([back_button("indietro")]),
    )

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    err = context.error
    # Errori di RETE transitori del polling Telegram (Bad Gateway, timeout...):
    # python-telegram-bot riprova da solo e il bot continua a funzionare.
    # Una riga di warning basta: il traceback completo ("Eccezione non
    # gestita") faceva sembrare il bot in errore grave (visto l'11/6/2026).
    if isinstance(err, NetworkError):
        logger.warning(f"Telegram: errore di rete transitorio (retry automatico): {err}")
        return
    logger.error("Eccezione non gestita:", exc_info=err)

async def conferma_no(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("memo", None)
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "Riproviamo. Inviami lo Stop Loss in $:", _cancel_kb())
    return SL

async def annulla_operazione(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("memo", None)
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "Operazione annullata.")
    await mostra_menu_principale(update, context)
    return ConversationHandler.END
