import logging
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple

# requests e' opzionale: senza, le sole funzioni di rete si disattivano da sole
# (vedi i controlli `if requests is None`). Qui l'import serve DAVVERO.
try:
    import requests
except ImportError:
    requests = None

logger = logging.getLogger(__name__)

from .config import (
    FINNHUB_API_KEY,
    FMP_API_KEY,
    NEWS_CLOSE_MINUTES_MAX,
    NEWS_SOURCE_URL,
    NEWS_XAUUSD_CURRENCIES,
    OPEN_BLOCK_END,
    OPEN_BLOCK_START,
)
from .storage import carica_dati_async
from .subscription import stato_abbonamento
from .trade_core import _ora_italiana, _time_in_range

# ========================= NEWS / CALENDARIO =========================
def _fine_di_domani_utc() -> datetime:
    """Limite superiore del calendario: le 23:59:59 di DOMANI in ORA ITALIANA,
    espresso in UTC. Prima la finestra era '24 ore mobili da adesso': il tasto
    Notizie tagliava fuori gli eventi di domani sera. Cosi' invece copre
    SEMPRE tutta la giornata di domani."""
    now_utc = datetime.now(timezone.utc)
    it_now  = _ora_italiana(now_utc)                      # naive, ora italiana
    offset  = it_now - now_utc.replace(tzinfo=None)       # +1h (CET) o +2h (CEST)
    fine_it = datetime.combine(
        it_now.date() + timedelta(days=2), datetime.min.time(),
    ) - timedelta(seconds=1)                              # domani 23:59:59 IT
    return (fine_it - offset).replace(tzinfo=timezone.utc)

def serializza_eventi_news(events: list) -> list:
    serializzati = []
    for ev in events:
        t = ev.get("time")
        if isinstance(t, datetime):
            t = t.isoformat()
        serializzati.append({
            "time":     t,
            "title":    ev.get("title", ""),
            "impact":   ev.get("impact", ""),
            "currency": ev.get("currency", ""),
        })
    return serializzati

def news_event_key(ev: dict) -> str:
    return f"{ev.get('time', '')}|{ev.get('currency', '')}|{ev.get('impact', '')}|{ev.get('title', '')}"

def is_xauusd_relevant(ev: dict) -> bool:
    if str(ev.get("impact", "")).lower() != "high":
        return False
    return str(ev.get("currency", "")).strip().upper() in NEWS_XAUUSD_CURRENCIES

def _scarica_da_fmp() -> Optional[list]:
    """
    Fallback su Financial Modeling Prep (/api/v3/economic_calendar).

    Restituisce:
      - list[dict] con gli eventi (anche vuota: nessuna news High rilevante);
      - None se la chiamata e' fallita per problemi tecnici (timeout, errore HTTP,
        JSON malformato). Il chiamante usa None per decidere se fallire la news
        fetch o accettare un calendario vuoto come risposta valida.

    Piano gratuito: 250 chiamate/giorno. Chiamato solo come fallback di Finnhub.
    """
    if requests is None:
        logger.warning("FMP: libreria requests non disponibile.")
        return None

    today_utc = datetime.now(timezone.utc).date()
    to_date   = today_utc + timedelta(days=2)   # copre TUTTA la giornata di domani
    url    = "https://financialmodelingprep.com/api/v3/economic_calendar"
    params = {"from": today_utc.isoformat(), "to": to_date.isoformat(), "apikey": FMP_API_KEY}
    try:
        resp = requests.get(url, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.error(f"FMP: errore chiamata API economic_calendar: {e}")
        return None

    if not isinstance(data, list):
        # FMP segnala errori (rate limit, key invalida) con un dict {"Error Message": ...}
        logger.error(f"FMP: risposta inattesa (atteso list, ricevuto {type(data).__name__}): {data!r}")
        return None

    now_utc = datetime.now(timezone.utc)
    parsed: list = []
    for ev in data:
        if not isinstance(ev, dict):
            continue
        ts_str = str(ev.get("date", "")).strip()
        if not ts_str:
            continue
        try:
            ev_time = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            try:
                ev_time = datetime.fromisoformat(ts_str)
            except Exception:
                logger.debug(f"FMP: impossibile parsare date='{ts_str}', evento saltato.")
                continue
        # FMP documenta i timestamp come UTC.
        if ev_time.tzinfo is None:
            ev_time = ev_time.replace(tzinfo=timezone.utc)
        if ev_time <= now_utc - timedelta(minutes=1) or ev_time > _fine_di_domani_utc():
            continue
        impact = str(ev.get("impact", "")).strip().capitalize()
        if impact != "High":
            continue
        currency = str(ev.get("currency", "")).strip().upper()
        if currency not in NEWS_XAUUSD_CURRENCIES:
            continue
        title = str(ev.get("event", "")).strip() or "Evento sconosciuto"
        parsed.append({"time": ev_time, "title": title, "impact": impact, "currency": currency})

    parsed.sort(key=lambda x: x["time"])
    dedup, seen = [], set()
    for ev in parsed:
        k = news_event_key(ev)
        if k not in seen:
            seen.add(k)
            dedup.append(ev)
    logger.info(f"FMP: caricati {len(dedup)} eventi futuri (UTC).")
    return dedup[:50]

# Country code → valuta (Finnhub)
_COUNTRY_TO_CURRENCY: dict = {
    "US": "USD", "EU": "EUR", "UK": "GBP", "JP": "JPY",
    "CA": "CAD", "AU": "AUD", "NZ": "NZD", "CH": "CHF",
    "CN": "CNY", "HK": "HKD", "SG": "SGD", "MX": "MXN",
    "NO": "NOK", "SE": "SEK", "DK": "DKK", "DE": "EUR",
    "FR": "EUR", "IT": "EUR", "ES": "EUR", "RU": "RUB",
}

def _scarica_da_finnhub() -> Optional[list]:
    """
    Sorgente primaria del calendario economico.

    Restituisce:
      - list[dict] con gli eventi (anche vuota: nessuna news High rilevante
        nelle prossime 24h);
      - None se la chiamata e' fallita per problemi tecnici (libreria mancante,
        timeout, errore HTTP, JSON malformato). Il chiamante usa None per
        decidere se attivare il fallback FMP, evitando di sprecare quota FMP
        quando Finnhub ha risposto correttamente con zero eventi.
    """
    if requests is None:
        logger.warning("Finnhub: libreria requests non disponibile.")
        return None

    today_utc = datetime.now(timezone.utc).date()
    to_date   = today_utc + timedelta(days=2)   # copre TUTTA la giornata di domani
    url    = "https://finnhub.io/api/v1/calendar/economic"
    params = {"from": today_utc.isoformat(), "to": to_date.isoformat(), "token": FINNHUB_API_KEY}
    try:
        resp = requests.get(url, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.error(f"Finnhub: errore chiamata API calendar/economic: {e}")
        return None

    raw_events = data.get("economicCalendar", []) if isinstance(data, dict) else None
    if raw_events is None:
        logger.error(f"Finnhub: risposta inattesa: {data!r}")
        return None
    if not raw_events:
        logger.info("Finnhub: risposta vuota, nessun evento trovato.")
        return []
    now_utc = datetime.now(timezone.utc)
    parsed  = []
    for ev in raw_events:
        ts_str = str(ev.get("time", "")).strip()
        if not ts_str:
            continue
        try:
            ev_time = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            try:
                ev_time = datetime.fromisoformat(ts_str)
            except Exception:
                logger.debug(f"Finnhub: impossibile parsare time='{ts_str}', evento saltato.")
                continue
        ev_time = ev_time.replace(tzinfo=timezone.utc)
        if ev_time <= now_utc - timedelta(minutes=1) or ev_time > _fine_di_domani_utc():
            continue
        impact = str(ev.get("impact", "")).strip().capitalize()
        if impact != "High":
            continue
        title = str(ev.get("event", "")).strip() or "Evento sconosciuto"
        country  = str(ev.get("country", "")).upper().strip()
        currency = _COUNTRY_TO_CURRENCY.get(country, country)
        if not currency:
            currency = country
        if currency not in NEWS_XAUUSD_CURRENCIES:
            continue
        parsed.append({"time": ev_time, "title": title, "impact": impact, "currency": currency})
    parsed.sort(key=lambda x: x["time"])
    dedup, seen = [], set()
    for ev in parsed:
        k = news_event_key(ev)
        if k not in seen:
            seen.add(k)
            dedup.append(ev)
    logger.info(f"Finnhub: caricati {len(dedup)} eventi futuri (UTC).")
    return dedup[:50]

# Eta' in minuti dell'ultimo feed centrale letto con successo (None = ignota).
# Scritta da _scarica_da_fonte_centrale (gira in thread; assegnazione atomica),
# letta dal news_monitor_loop per l'avviso "feed stantio" al canale admin.
_news_feed_eta_min: Optional[float] = None

def _scarica_da_fonte_centrale() -> Optional[list]:
    """
    Legge il calendario gia' pronto da una fonte CENTRALE (NEWS_SOURCE_URL):
    un solo fetcher scarica il calendario e pubblica un JSON condiviso da TUTTI
    i bot, cosi' serve una sola chiave API totale (vedi news_fetcher.py + GitHub Actions).

    Formato atteso: {"updated_utc": "...", "events": [{"time","title","impact","currency"}]}.
    Ritorna list (anche vuota = nessuna news) oppure None su errore tecnico
    (rete/JSON): None significa "tieni l'ultimo calendario noto", non azzerarlo.
    """
    if requests is None:
        logger.warning("News centrale: libreria requests non disponibile.")
        return None
    try:
        resp = requests.get(NEWS_SOURCE_URL, timeout=20)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.error(f"News centrale: errore fetch da {NEWS_SOURCE_URL}: {e}")
        return None

    events = data.get("events") if isinstance(data, dict) else None
    if not isinstance(events, list):
        logger.error("News centrale: JSON inatteso (manca la lista 'events').")
        return None

    # Avviso di freschezza: non blocca, ma segnala un feed troppo vecchio.
    # L'eta' viene esposta in _news_feed_eta_min per l'avviso al canale admin.
    global _news_feed_eta_min
    _news_feed_eta_min = None
    upd = data.get("updated_utc") if isinstance(data, dict) else None
    if upd:
        try:
            upd_dt = datetime.fromisoformat(str(upd).replace("Z", "+00:00"))
            if upd_dt.tzinfo is None:
                upd_dt = upd_dt.replace(tzinfo=timezone.utc)
            eta_min = (datetime.now(timezone.utc) - upd_dt).total_seconds() / 60.0
            _news_feed_eta_min = eta_min
            if eta_min > 90:
                logger.warning(f"News centrale: feed vecchio di {int(eta_min)} min (updated_utc={upd}).")
        except Exception:
            pass

    now_utc = datetime.now(timezone.utc)
    parsed: list = []
    for ev in events:
        if not isinstance(ev, dict):
            continue
        try:
            ev_time = datetime.fromisoformat(str(ev.get("time", "")).replace("Z", "+00:00"))
        except Exception:
            continue
        if ev_time.tzinfo is None:
            ev_time = ev_time.replace(tzinfo=timezone.utc)
        if ev_time <= now_utc - timedelta(minutes=1) or ev_time > _fine_di_domani_utc():
            continue
        impact = str(ev.get("impact", "")).strip().capitalize()
        if impact != "High":
            continue
        currency = str(ev.get("currency", "")).strip().upper()
        if currency not in NEWS_XAUUSD_CURRENCIES:
            continue
        title = str(ev.get("title", "")).strip() or "Evento sconosciuto"
        parsed.append({"time": ev_time, "title": title, "impact": impact, "currency": currency})

    parsed.sort(key=lambda x: x["time"])
    dedup, seen = [], set()
    for ev in parsed:
        k = news_event_key(ev)
        if k not in seen:
            seen.add(k)
            dedup.append(ev)
    logger.info(f"News centrale: caricati {len(dedup)} eventi futuri (UTC).")
    return dedup[:50]

def scarica_eventi_news() -> Optional[list]:
    """
    Se NEWS_SOURCE_URL e' impostata -> legge dalla fonte centrale (una sola chiave
    per tutti i bot). Altrimenti: Finnhub primaria, FMP solo come fallback tecnico.

    Ritorna list (anche vuota = nessuna news High nelle 24h) oppure None se TUTTE le
    sorgenti hanno fallito tecnicamente: None dice al loop di NON sovrascrivere la
    cache (sicurezza: durante una news il blocco deve restare basato sull'ultimo dato noto).
    """
    if NEWS_SOURCE_URL:
        return _scarica_da_fonte_centrale()
    eventi = _scarica_da_finnhub()
    if eventi is not None:
        return eventi
    logger.warning("Finnhub non disponibile → fallback FMP.")
    eventi_fmp = _scarica_da_fmp()
    if eventi_fmp is None:
        logger.error("News: sia Finnhub che FMP hanno fallito, calendario non aggiornato.")
        return None
    return eventi_fmp

async def _blocco_news_o_abbonamento() -> Tuple[bool, str]:
    """Blocchi NON legati alla fascia oraria 23:00-01:00: abbonamento scaduto e
    news ad alto impatto imminenti. Si usa all'INGRESSO della configurazione trade,
    cosi' durante le 23-01 il cliente puo' comunque configurare e PROGRAMMARE un
    trade per un orario successivo (l'apertura IMMEDIATA resta invece bloccata
    nella fascia 23-01 dentro conferma_esegui)."""
    now_utc = datetime.now(timezone.utc)
    dati    = await carica_dati_async()

    # Abbonamento scaduto: si bloccano SOLO le nuove aperture. Chiusure, hedge,
    # stop, monitor news e watchdog restano sempre attivi (vedi monitor di chiusura).
    st_sub = stato_abbonamento(dati)
    if st_sub["scaduto"]:
        return True, (
            f"Abbonamento scaduto il {st_sub['until'].strftime('%d/%m/%Y')}. "
            "Nuove operazioni sospese. La gestione delle posizioni gia' aperte "
            "resta attiva.\n\n"
            "Se hai già pagato il rinnovo, segnalalo da: "
            "/start → 🔧 Diagnosi → 🤖 Stato bot → 💳 Rinnova."
        )

    blackout_until = dati.get("news_blackout_until")
    if blackout_until:
        try:
            until = datetime.fromisoformat(blackout_until)
            if until.tzinfo is None:
                until = until.replace(tzinfo=timezone.utc)
            if now_utc < until:
                mins = int((until - now_utc).total_seconds() // 60)
                return True, f"Blocco news attivo per altri {mins} minuti."
        except Exception:
            pass

    eventi = dati.get("news_events", [])
    for ev in eventi:
        try:
            ev_time = ev.get("time")
            if isinstance(ev_time, str):
                ev_time = datetime.fromisoformat(ev_time)
            if not isinstance(ev_time, datetime):
                continue
            if ev_time.tzinfo is None:
                ev_time = ev_time.replace(tzinfo=timezone.utc)
            if ev_time <= now_utc:
                continue
            if not is_xauusd_relevant(ev):
                continue
            minuti = (ev_time - now_utc).total_seconds() / 60.0
            if minuti <= NEWS_CLOSE_MINUTES_MAX:
                currency = ev.get("currency", "")
                title    = ev.get("title", "news")
                return True, f"Blocco news {currency} High-impact tra {int(minuti)} min: {title}"
        except Exception:
            continue
    return False, ""

async def trading_bloccato_ora_o_news() -> Tuple[bool, str]:
    """Blocco completo per l'apertura IMMEDIATA: fascia oraria 23:00-01:00 +
    news/abbonamento. Comportamento invariato per tutti i chiamanti esistenti."""
    if _time_in_range(datetime.now().time(), OPEN_BLOCK_START, OPEN_BLOCK_END):
        return True, "Aperture bloccate tra le 23:00 e le 01:00."
    return await _blocco_news_o_abbonamento()
