import logging
from datetime import datetime, timedelta, time as dt_time, timezone
from decimal import Decimal, ROUND_UP
from typing import Optional

from telegram import Update, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes,
)

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    INCASSO_DEFAULT,
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    RAPPORTO_LOTTO_INCASSO,
    SIMBOLO_BROKER,
)
from .messaging import ack, back_button, safe_edit_message_text
from .storage import carica_dati_async, modifica_dati_async, modifier_incrementa_magic
from .mt5_async import _get_open_positions_snapshot_async
from .handlers_base import guard_auth

# ========================= MAGIC ATOMICO + LOTTI =========================
async def genera_magic() -> int:
    dati = await modifica_dati_async(modifier_incrementa_magic)
    return dati["next_magic"] - 1

def arrotonda_lotti_verso_su(valore: float, step: str = "0.01") -> float:
    d = Decimal(str(valore))
    q = Decimal(step)
    return float(d.quantize(q, rounding=ROUND_UP))

def _incasso_corrente(dati: dict) -> float:
    """Incasso configurato (incasso_target, o legacy incasso_se_bruciata).
    Se non configurato o non valido -> INCASSO_DEFAULT (630)."""
    pa = dati.get("prop_avanzata", {}) or {}
    try:
        v = float(pa.get("incasso_target", pa.get("incasso_se_bruciata", 0)) or 0)
    except (TypeError, ValueError):
        v = 0.0
    return v if v > 0 else INCASSO_DEFAULT

def calcola_lotti_broker(lotti_prop: float, incasso_target: float) -> float:
    """Formula: lotti_broker = lotti_prop * (incasso_target / RAPPORTO_LOTTO_INCASSO)."""
    return arrotonda_lotti_verso_su(
        lotti_prop * (incasso_target / RAPPORTO_LOTTO_INCASSO),
        "0.01",
    )

def _time_in_range(now_t: dt_time, start: dt_time, end: dt_time) -> bool:
    if start <= end:
        return start <= now_t <= end
    return now_t >= start or now_t <= end

def _ora_italiana(dt_in: datetime) -> datetime:
    """Converte un datetime in ora italiana (Europe/Rome) gestendo l'ora legale.

    NON usa zoneinfo/tzdata (assente su Windows) ma applica la regola UE,
    deterministica e stabile: ora legale (CEST, UTC+2) dall'ultima domenica di
    marzo all'ultima domenica di ottobre (transizioni alle 01:00 UTC), altrimenti
    ora solare (CET, UTC+1). Ritorna un datetime naive in ora locale italiana,
    pensato solo per la visualizzazione.
    """
    if dt_in.tzinfo is None:
        dt_in = dt_in.replace(tzinfo=timezone.utc)
    dt_utc = dt_in.astimezone(timezone.utc)

    def _ultima_domenica(anno: int, mese: int) -> datetime:
        d = datetime(anno, mese, 31, 1, 0, tzinfo=timezone.utc)
        while d.weekday() != 6:   # 6 = domenica
            d -= timedelta(days=1)
        return d

    inizio_dst = _ultima_domenica(dt_utc.year, 3)
    fine_dst   = _ultima_domenica(dt_utc.year, 10)
    offset     = 2 if (inizio_dst <= dt_utc < fine_dst) else 1
    return (dt_utc + timedelta(hours=offset)).replace(tzinfo=None)

# ========================= STATO TRADE =========================
def _tipo_ita(t) -> str:
    return "Compra" if str(t).upper() == "BUY" else "Vendi"

def _fmt_sl_tp(v) -> str:
    """Prezzo SL/TP formattato, o 'non impostato' se assente (0)."""
    try:
        return f"{float(v):.2f}$" if float(v) else "non impostato"
    except (TypeError, ValueError):
        return "non impostato"

def _blocco_posizione(p: dict) -> str:
    return (
        f"• Tipo: {_tipo_ita(p.get('type'))}\n"
        f"• Lotti: {float(p.get('volume', 0)):.2f}\n"
        f"• SL: {_fmt_sl_tp(p.get('sl'))}\n"
        f"• TP: {_fmt_sl_tp(p.get('tp'))}\n"
        f"• Guadagno/Perdita attuale: {float(p.get('profit', 0)):+.2f}$"
    )

def _componi_stato_trade(
    pos_b: Optional[list], pos_p: Optional[list], trade_memos: Optional[dict] = None,
) -> str:
    """Costruisce il messaggio 'Stato Trade Manuale' (Prop prima, poi Broker)."""
    pos_b = pos_b or []
    pos_p = pos_p or []
    if not pos_b and not pos_p:
        return "ℹ️ Nessun trade aperto."
    rif = (pos_p or pos_b)[0]   # riferimento per Asset/Prezzo attuale: prima la Prop
    msg = "📋 Stato Trade Manuale\n\n"
    msg += f"• Asset: {rif.get('symbol', '—')}\n"
    prezzo = rif.get("price_current")
    if prezzo:
        msg += f"• Prezzo attuale: {float(prezzo):.2f}$\n"

    def _sezione(nome: str, posizioni: list) -> str:
        if not posizioni:
            return f"\n{nome}\n• Nessuna posizione aperta"
        blocchi = [f"\n{nome}"]
        for i, p in enumerate(posizioni):
            if i > 0:
                blocchi.append("")  # riga vuota tra piu' posizioni dello stesso conto
            blocchi.append(_blocco_posizione(p))
        return "\n".join(blocchi)

    msg += _sezione("Prop", pos_p)
    msg += "\n"
    msg += _sezione("Broker", pos_b)

    # Memo: nota scritta dall'utente all'apertura. E' la stessa per la coppia
    # Prop+Broker (salvata sotto entrambi i ticket); raccogliamo i memo distinti
    # delle posizioni aperte e li mostriamo come ultima riga.
    memos: list = []
    if trade_memos:
        for p in list(pos_p) + list(pos_b):
            rec  = trade_memos.get(str(p.get("ticket")), {}) or {}
            memo = (rec.get("memo") or "").strip()
            if memo and memo not in memos:
                memos.append(memo)
    if not memos:
        msg += "\n\n📝 Memo: —"
    elif len(memos) == 1:
        msg += f"\n\n📝 Memo: {memos[0]}"
    else:
        msg += "\n\n📝 Memo:\n" + "\n".join(f"• {m}" for m in memos)
    return msg

async def stato_trade(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)

    dati = await carica_dati_async()
    broker      = dati.get("broker")
    prop        = dati.get("prop")
    trade_memos = dati.get("trade_memos", {})

    if not broker or not prop:
        await safe_edit_message_text(
            query, "❌ Credenziali mancanti.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    pos_b = await _get_open_positions_snapshot_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    )
    pos_p = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if pos_b is None or pos_p is None:
        await safe_edit_message_text(
            query, "❌ Impossibile leggere le posizioni aperte.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    msg = _componi_stato_trade(pos_b, pos_p, trade_memos)
    await safe_edit_message_text(
        query, msg, InlineKeyboardMarkup([back_button("manuale")]),
    )

async def stato_trade_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    dati        = await carica_dati_async()
    broker      = dati.get("broker")
    prop        = dati.get("prop")
    trade_memos = dati.get("trade_memos", {})

    if not broker or not prop:
        await update.message.reply_text("❌ Credenziali mancanti.")
        return

    pos_b = await _get_open_positions_snapshot_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    )
    pos_p = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if pos_b is None or pos_p is None:
        await update.message.reply_text("❌ Impossibile leggere le posizioni aperte.")
        return

    msg = _componi_stato_trade(pos_b, pos_p, trade_memos)
    await update.message.reply_text(msg)
