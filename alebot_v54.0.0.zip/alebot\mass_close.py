import logging
import uuid
from datetime import datetime, timezone
from functools import partial
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import MT5_BROKER_EXE, MT5_PROP_EXE, SIMBOLO_BROKER
from .messaging import _mark_trade_pair_closed
from .state import modifier_chiudi_challenge_per_ticket
from .storage import carica_dati_async, modifica_dati_async
from .mt5_async import (
    _close_all_lock,
    _get_open_positions_snapshot_async,
    chiudi_posizione_async,
    get_position_close_info_async,
)
from .hedge_journal import journal_put, journal_remove, journal_update

# ========================= CHIUSURA DI MASSA =========================
async def chiudi_tutti_trade_aperti(nota_chiusura: str = "") -> Tuple[int, str]:
    """Chiude tutte le posizioni Broker/Prop. Serializzata da _close_all_lock.
    'nota_chiusura' viene accodata alla riga di intestazione (es. avviso sessione)."""
    async with _close_all_lock:
        dati        = await carica_dati_async()
        broker      = dati.get("broker")
        prop        = dati.get("prop")
        trade_memos = dati.get("trade_memos", {})
        if not broker or not prop:
            logger.error("Chiusura automatica: credenziali mancanti.")
            return 0, "❌ Chiusura fallita: credenziali mancanti."

        pos_b = await _get_open_positions_snapshot_async(
            MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
        ) or []
        pos_p = await _get_open_positions_snapshot_async(
            MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
        ) or []
        if not pos_b and not pos_p:
            return 0, "ℹ️ Nessuna posizione aperta."

        # ── Giornale transazionale: la LISTA dei ticket da chiudere va su disco
        # PRIMA di iniziare. Se il processo muore a meta', il recovery riprende
        # ESATTAMENTE dalle chiusure rimanenti (niente coppie mezze aperte fino
        # alla chiusura serale successiva).
        journal_id = uuid.uuid4().hex[:8]
        done_tokens: list = []
        await journal_put(
            journal_id, kind="close_pairs",
            tickets_broker=[int(p["ticket"]) for p in pos_b],
            tickets_prop=[int(p["ticket"]) for p in pos_p],
            done=[], nota=nota_chiusura,
        )

        updates_to_save: Dict[Tuple[int, int], Dict[str, Any]] = {}
        now_utc = datetime.now(timezone.utc).isoformat()
        n_ok_b = n_err_b = n_ok_p = n_err_p = 0
        pl_b = pl_p = 0.0
        memos: list = []

        def _pair_keys(rec: dict, ticket: int) -> Tuple[int, int]:
            return (
                int(rec.get("broker_ticket", ticket)),
                int(rec.get("prop_ticket", ticket)),
            )

        def _aggiungi_memo(rec: dict) -> None:
            m = (rec.get("memo") or "").strip()
            if m and m not in memos:
                memos.append(m)

        for p in pos_b:
            ticket = int(p["ticket"])
            record = trade_memos.get(str(ticket), {}) or {}
            success = await chiudi_posizione_async(
                MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], ticket,
            )
            if success:
                n_ok_b += 1
                done_tokens.append(f"broker:{ticket}")
                await journal_update(journal_id, done=list(done_tokens))
                _aggiungi_memo(record)
                close_info = await get_position_close_info_async(
                    MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
                    ticket, record.get("opened_at_utc"),
                )
                # P/L realizzato (netto) se disponibile, altrimenti il flottante pre-chiusura.
                prof = (close_info or {}).get("profit")
                pl_b += float(prof if prof is not None else (p.get("profit", 0.0) or 0.0))
                key = _pair_keys(record, ticket)
                if close_info:
                    updates_to_save[key] = {
                        **updates_to_save.get(key, {}),
                        "broker_close_info":   close_info,
                        "pair_closed_notified": True,
                        "closed_source":       "automatico",
                        "closed_at_utc":       now_utc,
                    }
            else:
                n_err_b += 1

        for p in pos_p:
            ticket = int(p["ticket"])
            record = trade_memos.get(str(ticket), {}) or {}
            success = await chiudi_posizione_async(
                MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], ticket,
            )
            if success:
                n_ok_p += 1
                done_tokens.append(f"prop:{ticket}")
                await journal_update(journal_id, done=list(done_tokens))
                _aggiungi_memo(record)
                close_info = await get_position_close_info_async(
                    MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
                    ticket, record.get("opened_at_utc"),
                )
                prof = (close_info or {}).get("profit")
                pl_p += float(prof if prof is not None else (p.get("profit", 0.0) or 0.0))
                key = _pair_keys(record, ticket)
                if close_info:
                    updates_to_save[key] = {
                        **updates_to_save.get(key, {}),
                        "prop_close_info":     close_info,
                        "pair_closed_notified": True,
                        "closed_source":       "automatico",
                        "closed_at_utc":       now_utc,
                    }
            else:
                n_err_p += 1

        for (pair_b, pair_p), upd in updates_to_save.items():
            await _mark_trade_pair_closed(pair_b, pair_p, upd)

        # Un TRADE-SFIDA aperto sulla prop viene chiuso da questa spazzata
        # insieme a tutto il resto. Senza dichiararlo, il suo record restava
        # "open" e il backstop tentava all'infinito di richiudere un ticket
        # inesistente: chiudi_posizione() ritorna False anche per le posizioni
        # gia' chiuse, quindi ne usciva un avviso all'owner OGNI MINUTO. E'
        # esattamente lo scenario che si verificava a ogni chiusura serale.
        if pos_p:
            await modifica_dati_async(partial(
                modifier_chiudi_challenge_per_ticket,
                tickets=[int(p["ticket"]) for p in pos_p],
            ))

        if n_err_b == 0 and n_err_p == 0:
            # Tutte chiuse: intento concluso.
            await journal_remove(journal_id)
        # Altrimenti l'intento RESTA nel giornale: il recovery periodico
        # ritentera' le chiusure fallite ogni minuto finche' non riescono.

        n_closed = n_ok_b + n_ok_p
        nota = f" {nota_chiusura}" if nota_chiusura else ""
        msg  = f"🔒 Chiusura automatica eseguita.{nota}\n\n"
        msg += f"🏦 Broker, posizioni: {n_ok_b}\n"
        msg += f"• Guadagno/Perdita Broker: {pl_b:+.2f}$"
        if n_err_b:
            msg += f"\n⚠️ {n_err_b} posizioni Broker NON chiuse (errore)"
        msg += f"\n\n🏢 Prop, posizioni: {n_ok_p}\n"
        msg += f"• Guadagno/Perdita Prop: {pl_p:+.2f}$"
        if n_err_p:
            msg += f"\n⚠️ {n_err_p} posizioni Prop NON chiuse (errore)"
        if memos:
            msg += f"\n\n\n• Memo: {', '.join(memos)}"
        return n_closed, msg
