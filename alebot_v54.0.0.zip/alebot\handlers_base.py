import logging
from functools import partial
from typing import Optional, Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ConversationHandler,
    ContextTypes,
)

logger = logging.getLogger(__name__)

from .messaging import ack, safe_edit_message_text
from .storage import (
    PWD_LOCKOUT_MINUTES,
    PWD_MAX_ATTEMPTS,
    _lockout_rimanente,
    _modifier_claim_owner,
    _modifier_imposta_password_e_owner,
    _scrivi_owner_sidecar,
    carica_dati_async,
    leggi_chiave_async,
    modifica_dati_async,
    modifier_registra_tentativo_fallito,
    modifier_reset_tentativi,
    modifier_set_owner_username,
)

# ========================= FALLBACK GLOBALE =========================
async def annulla_conversazione(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message:
        await update.message.reply_text("Operazione annullata. Torno al menu.")
    elif update.callback_query:
        await ack(update.callback_query)
        await safe_edit_message_text(update.callback_query, "Operazione annullata. Torno al menu.")
    await mostra_menu_principale(update, context)
    return ConversationHandler.END

# ========================= TIMEOUT CONVERSAZIONI =========================
CONV_TIMEOUT_SECONDS = 300  # 5 minuti

async def conversazione_scaduta(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id: Optional[int] = None
    try:
        if update is not None and update.effective_chat is not None:
            chat_id = update.effective_chat.id
    except Exception:
        chat_id = None
    for k in (
        "memo", "sl", "tp", "lotti_prop", "lotti_broker", "direzione",
        "sl_price_prop", "tp_price_prop", "sl_price_broker", "tp_price_broker",
        "nuova_pwd",
    ):
        context.user_data.pop(k, None)
    if chat_id is not None:
        try:
            await context.bot.send_message(
                chat_id=chat_id,
                text=(
                    f"⌛ Operazione interrotta per inattività "
                    f"({CONV_TIMEOUT_SECONDS // 60} min).\n"
                    f"Torna al menu con /start o /help."
                ),
            )
        except Exception as e:
            logger.debug(f"conversazione_scaduta: invio messaggio fallito: {e}")
    return ConversationHandler.END

# ========================= AUTENTICAZIONE =========================
async def _diventa_owner(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int):
    """Rende questo account il proprietario corrente del bot (primo setup o
    spostamento): aggiorna sidecar per il watchdog e lo @username per Stato Bot."""
    context.user_data["authenticated"] = True
    context.user_data.pop("waiting_for_password", None)
    _scrivi_owner_sidecar(user_id)
    if update.effective_user and update.effective_user.username:
        await modifica_dati_async(
            partial(modifier_set_owner_username, username=update.effective_user.username)
        )

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    dati    = await carica_dati_async()
    pwd     = dati.get("password_bot")
    owner   = dati.get("owner_chat_id")

    # CASO 1 — Nessuna password impostata: PRIMO SETUP (creazione password).
    if not pwd:
        # Sicurezza legacy: se esiste gia' un owner ma manca la password, solo
        # l'owner originale puo' impostarla (evita il "furto" di un bot senza password).
        if owner is not None and owner != user_id:
            await update.message.reply_text(
                "🔒 Questo bot non ha ancora una password. Va impostata dall'account "
                "proprietario originale; poi potrai spostarlo su un altro Telegram."
            )
            return
        context.user_data.pop("waiting_for_password", None)
        context.user_data["setting_password_step"] = "new"
        await update.message.reply_text(
            "👋 Benvenuto in GoldenRail.\n\n"
            "Imposta una password per il bot: servira' per accedere e per spostare "
            "il bot su un altro account Telegram.\n\n"
            "Inserisci la nuova password:"
        )
        return

    # CASO 2 — Owner gia' stabilito su QUESTO account: accesso diretto (no password).
    if user_id == owner and dati.get("auth_permanente"):
        await _diventa_owner(update, context, user_id)
        await mostra_menu_principale(update, context)
        return

    # CASO 3 — Serve la password (account diverso, o dopo un cambio password).
    rem = _lockout_rimanente(dati)
    if rem > 0:
        await update.message.reply_text(
            f"🚫 Troppi tentativi errati. Bot bloccato: riprova tra ~{rem} minuti."
        )
        return
    context.user_data.pop("setting_password_step", None)
    context.user_data["waiting_for_password"] = True
    await update.message.reply_text("🔒 Inserisci la password per utilizzare il bot.")

async def password_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    # ---- FLUSSO CREAZIONE PASSWORD (primo setup) ----
    step = context.user_data.get("setting_password_step")
    if step == "new":
        nuova = (update.message.text or "").strip()
        if len(nuova) < 4:
            await update.message.reply_text("Password troppo corta (minimo 4 caratteri). Reinseriscila:")
            return
        context.user_data["pending_new_password"] = nuova
        context.user_data["setting_password_step"] = "confirm"
        await update.message.reply_text("Conferma la password reinserendola:")
        return
    if step == "confirm":
        if (update.message.text or "").strip() != context.user_data.get("pending_new_password"):
            context.user_data["setting_password_step"] = "new"
            context.user_data.pop("pending_new_password", None)
            await update.message.reply_text("Le password non coincidono. Inserisci di nuovo la nuova password:")
            return
        nuova = context.user_data.pop("pending_new_password")
        context.user_data.pop("setting_password_step", None)
        await modifica_dati_async(partial(_modifier_imposta_password_e_owner, password=nuova, user_id=user_id))
        await _diventa_owner(update, context, user_id)
        await update.message.reply_text(
            "✅ Password impostata. Da ora serve questa password per accedere e per "
            "spostare il bot su un altro account Telegram."
        )
        await mostra_menu_principale(update, context)
        return

    # ---- FLUSSO LOGIN (inserimento password esistente) ----
    if not context.user_data.get("waiting_for_password"):
        return
    dati = await carica_dati_async()
    rem  = _lockout_rimanente(dati)
    if rem > 0:
        context.user_data.pop("waiting_for_password", None)
        await update.message.reply_text(f"🚫 Troppi tentativi. Riprova tra ~{rem} minuti.")
        return
    pwd_inserita = update.message.text or ""
    if pwd_inserita == dati.get("password_bot"):
        # Password corretta -> questo account diventa il (nuovo) owner = "spostamento".
        await modifica_dati_async(partial(_modifier_claim_owner, user_id=user_id))
        await modifica_dati_async(modifier_reset_tentativi)
        await _diventa_owner(update, context, user_id)
        await update.message.reply_text("✅ Accesso consentito.")
        await mostra_menu_principale(update, context)
    else:
        dati = await modifica_dati_async(partial(
            modifier_registra_tentativo_fallito,
            max_attempts=PWD_MAX_ATTEMPTS, lockout_minutes=PWD_LOCKOUT_MINUTES,
        ))
        rem = _lockout_rimanente(dati)
        if rem > 0:
            context.user_data.pop("waiting_for_password", None)
            await update.message.reply_text(
                f"🚫 Troppi tentativi errati. Bot bloccato: riprova tra ~{rem} minuti."
            )
        else:
            left = PWD_MAX_ATTEMPTS - int(dati.get("pwd_fail_count", 0) or 0)
            await update.message.reply_text(f"❌ Password errata. Tentativi rimasti: {left}")

async def guard_auth(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Cancello di ingresso di OGNI funzione del bot.

    Due verifiche, non una:
      1) la sessione ha superato la password (context.user_data, in memoria);
      2) chi scrive e' ANCORA l'owner registrato nello stato.

    Il punto 2 non c'era. Ma "authenticated" e' un flag per-utente che vive
    quanto il processo, mentre l'owner puo' CAMBIARE mentre il bot gira: basta
    che qualcuno acceda con la password per diventare owner ("spostamento del
    bot"), o che l'owner cambi password. In entrambi i casi la sessione
    precedente restava pienamente operativa — comandi di trading compresi —
    fino al riavvio del processo. Ora decade all'istante.
    """
    if not context.user_data.get("authenticated"):
        if update.callback_query:
            await ack(update.callback_query, "🚫 Non autenticato. Usa /start per accedere.", show_alert=True)
        return False

    owner = await leggi_chiave_async("owner_chat_id")
    uid   = update.effective_user.id if update.effective_user else None
    if owner is not None and uid is not None and uid != owner:
        context.user_data.pop("authenticated", None)
        avviso = (
            "🚫 Sessione non più valida: il bot è ora associato a un altro "
            "account Telegram. Usa /start e la password per riprendere il controllo."
        )
        if update.callback_query:
            await ack(update.callback_query, avviso, show_alert=True)
        elif update.message:
            try:
                await update.message.reply_text(avviso)
            except Exception as e:
                logger.debug(f"guard_auth: avviso non consegnato ({e}).")
        logger.warning(
            f"Accesso rifiutato: utente {uid} non e' piu' l'owner ({owner})."
        )
        return False
    return True

# ========================= MENU PRINCIPALE =========================

def _nome_utente(update: Update) -> str:
    """Nome leggibile per il saluto: 'Nome Cognome' se disponibile, altrimenti
    @username, altrimenti vuoto."""
    u = getattr(update, "effective_user", None)
    if not u:
        return ""
    nome = (getattr(u, "full_name", "") or "").strip()
    if not nome and getattr(u, "username", None):
        nome = f"@{u.username}"
    return nome

def _menu_principale_testo_kb(nome: str = "") -> Tuple[str, InlineKeyboardMarkup]:
    """Testo + tastiera del menu principale (condivisi tra /start, /help e il
    pulsante 'Indietro' delle notifiche di chiusura)."""
    keyboard = [
        [InlineKeyboardButton("📈 Gestisci posizioni",    callback_data="gestisci")],
        [InlineKeyboardButton("🔧 Diagnosi",              callback_data="diagnosi")],
        [InlineKeyboardButton("⚙️ Configura Operatività", callback_data="configura_op")],
        [InlineKeyboardButton("ℹ️ Info bot",              callback_data="info")],
    ]
    saluto = f"Ciao {nome}," if nome else "Ciao,"
    testo = (
        f"{saluto}\nBenvenuto nel bot GoldenRail.\n\n"
        "📌 Per gestire le posizioni, usa la funzione \"Gestisci Posizioni\".\n"
        "📌 Per cambiare la password o in caso di problemi, usa la funzione \"Diagnosi\".\n"
        "📌 Per gestire la configurazione, usa la funzione \"Configura Operatività\".\n\n"
        "ℹ️ Puoi rivedere questo menu quando vuoi digitando /help\n"
        "🔴 Per annullare un'operazione in corso digita /annulla\n"
        "🔄 Se non sai cosa fare o il bot sembra bloccato, digita /start"
    )
    return testo, InlineKeyboardMarkup(keyboard)

async def mostra_menu_principale(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    testo, kb = _menu_principale_testo_kb(_nome_utente(update))
    if update.callback_query:
        await safe_edit_message_text(update.callback_query, testo, kb)
    elif update.message:
        await update.message.reply_text(testo, reply_markup=kb)

async def menu_da_notifica(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Pulsante 'Indietro' sulle notifiche di chiusura: apre il menu principale come
    NUOVO messaggio, lasciando INTATTA la notifica (cosi' il memo resta leggibile).
    Toglie solo la tastiera dalla notifica, per evitare click ripetuti."""
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    try:
        await query.edit_message_reply_markup(reply_markup=None)
    except Exception as e:
        logger.debug(f"menu_da_notifica: rimozione tastiera ignorata ({e}).")
    testo, kb = _menu_principale_testo_kb(_nome_utente(update))
    try:
        await context.bot.send_message(chat_id=query.message.chat_id, text=testo, reply_markup=kb)
    except Exception as e:
        logger.warning(f"menu_da_notifica: invio menu fallito ({e}).")
