"""Processo WORKER MT5: un terminale, una connessione, sempre calda.

Il pacchetto MetaTrader5 dialoga con UN terminale per processo. Facendo
girare un worker dedicato per il Broker e uno per la Prop, le due
connessioni restano aperte IN PARALLELO: niente piu' alternanza
broker<->prop, e le due gambe dell'hedge possono partire simultaneamente.

Il worker riceve richieste (nome_funzione, args, kwargs) su una pipe,
esegue la funzione corrispondente di mt5_sync (whitelist DISPATCH) e
risponde (True, risultato) oppure (False, "errore"). Il layer di sessione
persistente di mt5_sync vive DENTRO il worker: dato che ogni worker serve
un solo terminale, la sessione non cambia mai -> riuso massimo.

Questo modulo viene importato anche dal processo figlio (spawn): tiene
solo dipendenze leggere (config + mt5_sync), niente telegram/storage.
"""
import logging
import os
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

from . import mt5_sync as ms


def _pos_to_dict(p) -> Optional[Dict[str, Any]]:
    """Le TradePosition di MT5 non attraversano la pipe: si convertono in dict.
    I consumatori usano solo la veridicita'/campi base, quindi e' trasparente."""
    if p is None:
        return None
    return {
        "ticket":        int(getattr(p, "ticket", 0) or 0),
        "symbol":        getattr(p, "symbol", ""),
        "volume":        float(getattr(p, "volume", 0.0) or 0.0),
        "profit":        float(getattr(p, "profit", 0.0) or 0.0),
        "type":          int(getattr(p, "type", 0) or 0),
        "magic":         int(getattr(p, "magic", 0) or 0),
        "sl":            float(getattr(p, "sl", 0.0) or 0.0),
        "tp":            float(getattr(p, "tp", 0.0) or 0.0),
        "price_open":    float(getattr(p, "price_open", 0.0) or 0.0),
        "price_current": float(getattr(p, "price_current", 0.0) or 0.0),
    }


def _get_position_by_ticket_dict(*args, **kwargs):
    return _pos_to_dict(ms._get_position_by_ticket_sync(*args, **kwargs))


def _probe_terminale_sync(path: str, credenziali: Optional[Dict[str, str]] = None) -> bool:
    """UN tentativo di aggancio post-riavvio terminale: initialize (+ login se
    fornite credenziali) con teardown completo. Riproduce il probing che
    riavvia_terminale faceva inline nella v51. Il ciclo di attesa resta nel
    chiamante (async), il singolo tentativo e' bloccante qui."""
    try:
        if not ms.mt5.initialize(path=path):
            return False
        try:
            if credenziali:
                ok = ms.mt5.login(
                    int(credenziali["id"]),
                    credenziali["password"],
                    credenziali["server"],
                )
                if not ok:
                    return False
            return True
        finally:
            try:
                ms.mt5.shutdown()
            except Exception:
                pass
    except Exception:
        return False
    finally:
        # Il probing usa initialize/shutdown grezzi: la sessione persistente
        # del worker va resettata per ripartire pulita alla prossima chiamata.
        ms._mt5_session["path"] = None


# --- funzioni diagnostiche/di test (non toccano MT5) ---
def _ping() -> int:
    return os.getpid()

def _sleep(sec: float) -> float:
    time.sleep(float(sec))
    return float(sec)

def _die() -> None:
    os._exit(1)


# Whitelist delle funzioni eseguibili nel worker. SOLO queste.
DISPATCH: Dict[str, Any] = {
    "info_account":                       ms.info_account,
    "_autotrading_attivo_sync":           ms._autotrading_attivo_sync,
    "esegui_ordine":                      ms.esegui_ordine,
    "_verifica_ordine_esistente_sync":    ms._verifica_ordine_esistente_sync,
    "chiudi_posizione":                   ms.chiudi_posizione,
    "posizione_aperta_sync":              ms.posizione_aperta_sync,
    "stato_metatrader":                   ms.stato_metatrader,
    "calcola_margine_wrapper":            ms.calcola_margine_wrapper,
    "get_symbol_info_wrapper":            ms.get_symbol_info_wrapper,
    "valida_simbolo_volume":              ms.valida_simbolo_volume,
    "_trova_posizione_sync":              ms._trova_posizione_sync,
    "_get_position_by_ticket_sync":       _get_position_by_ticket_dict,
    "_extract_close_deal_sync":           ms._extract_close_deal_sync,
    "_get_open_positions_snapshot_sync":  ms._get_open_positions_snapshot_sync,
    "_get_open_tickets_by_symbol_sync":   ms._get_open_tickets_by_symbol_sync,
    "_get_trade_history_sync":            ms._get_trade_history_sync,
    "_prop_daily_realized_pnl_sync":      ms._prop_daily_realized_pnl_sync,
    "get_server_date":                    ms.get_server_date,
    "info_account_prop_sync":             ms.info_account_prop_sync,
    "verifica_mt5_credenziali_sync":      ms.verifica_mt5_credenziali_sync,
    "verifica_e_identifica_broker_sync":  ms.verifica_e_identifica_broker_sync,
    "verifica_credenziali_dettagliata_sync":            ms.verifica_credenziali_dettagliata_sync,
    "verifica_e_identifica_broker_dettagliata_sync":    ms.verifica_e_identifica_broker_dettagliata_sync,
    "_mt5_disconnect":                    ms._mt5_disconnect,
    "_probe_terminale_sync":              _probe_terminale_sync,
    "__ping__":                           _ping,
    "__sleep__":                          _sleep,
    "__die__":                            _die,
}

STOP = "__stop__"


def worker_main(conn, nome: str) -> None:
    """Loop del processo worker: (req_id, func, args, kwargs) ->
    (req_id, ok, risultato). L'id di richiesta permette al padre di scartare
    risposte rimaste orfane dopo un timeout del chiamante."""
    logger.info(f"Worker MT5 '{nome}' avviato (pid {os.getpid()}).")
    while True:
        try:
            msg = conn.recv()
        except (EOFError, OSError):
            break                      # il padre e' morto/ha chiuso: usciamo
        if msg == STOP:
            break
        req_id = None
        try:
            req_id, func_name, args, kwargs = msg
            fn = DISPATCH[func_name]
            risultato = fn(*args, **kwargs)
            conn.send((req_id, True, risultato))
        except Exception as e:
            logger.exception(f"Worker '{nome}': errore in {msg!r}")
            try:
                conn.send((req_id, False, f"{type(e).__name__}: {e}"))
            except (OSError, BrokenPipeError):
                break
    try:
        ms._mt5_disconnect()
    except Exception:
        pass
    logger.info(f"Worker MT5 '{nome}' terminato.")
