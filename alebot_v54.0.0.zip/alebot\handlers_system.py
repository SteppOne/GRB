import asyncio
import logging
import os
import subprocess
from datetime import datetime, timezone
from typing import Dict, Optional

import psutil
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ConversationHandler,
    ContextTypes,
)

logger = logging.getLogger(__name__)

from .config import (
    MT5_BROKER_DIR,
    MT5_BROKER_EXE,
    MT5_PROP_DIR,
    MT5_PROP_EXE,
    RENEW_ALTRO,
    RENEW_CONFIRM,
    RENEW_METODO,
)
from .messaging import _cancel_kb, ack, back_button, safe_edit_message_text
from .storage import carica_dati_async
from .subscription import (
    RENEW_MAX_REPORTS_DAY,
    _invia_segnalazione_pagamento,
    _segnalazioni_pagamento_oggi,
    stato_abbonamento,
)
from .mt5_sync import _config_autotrading_arg
from .mt5_pool import pool
from .mt5_async import stato_metatrader_async
from .fleet import (
    esegui_ota_da_documento_privato,
    esegui_riavvio_bot,
    watchdog_attivo,
)
from .trade_core import _ora_italiana
from .handlers_base import guard_auth

# ========================= DIAGNOSI =========================
async def menu_diagnosi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    keyboard = [
        [InlineKeyboardButton("🏦 Broker",           callback_data="diag_broker")],
        [InlineKeyboardButton("📊 Prop",             callback_data="diag_prop")],
        [InlineKeyboardButton("🔏 Cambia password bot", callback_data="cambia_pwd")],
        [InlineKeyboardButton("🤖 Stato bot",        callback_data="stato_bot")],
        [InlineKeyboardButton("🧪 Test trading",     callback_data="test_trading")],
        [InlineKeyboardButton("♻️ Riavvia bot",      callback_data="riavvia_bot")],
        [InlineKeyboardButton("⬅️ Indietro",         callback_data="indietro")],
    ]
    await safe_edit_message_text(query, "Diagnosi", InlineKeyboardMarkup(keyboard))

async def diag_broker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    s = await stato_metatrader_async(MT5_BROKER_EXE)
    await safe_edit_message_text(
        query, f"Stato Broker: {s}",
        InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Riavvia",  callback_data="riavvia_broker")],
            [InlineKeyboardButton("⬅️ Indietro", callback_data="diagnosi")],
        ]),
    )

async def diag_prop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    s = await stato_metatrader_async(MT5_PROP_EXE)
    await safe_edit_message_text(
        query, f"Stato Prop: {s}",
        InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Riavvia",  callback_data="riavvia_prop")],
            [InlineKeyboardButton("⬅️ Indietro", callback_data="diagnosi")],
        ]),
    )

async def riavvia_terminale(
    dir_path: str, exe_path: str,
    credenziali: Optional[Dict[str, str]] = None,
) -> bool:
    # Lock del SOLO terminale interessato (pool.lock): il riavvio del Broker
    # non blocca piu' le operazioni sulla Prop, e viceversa. In fallback
    # in-process il lock e' quello globale, come in v51.
    async with pool.lock(exe_path):
        # Il terminale sta per essere ucciso: la sessione MT5 persistente che
        # lo riguarda (nel worker o in-process) va chiusa e resettata PRIMA,
        # altrimenti resterebbe un riferimento IPC morto.
        try:
            await asyncio.wait_for(
                _esegui_senza_lock(exe_path, "_mt5_disconnect"), timeout=15,
            )
        except Exception:
            logger.warning("riavvia_terminale: disconnessione sessione ignorata (worker/terminale gia' giu').")
        exe_name = os.path.basename(exe_path)
        for proc in psutil.process_iter(["pid", "name", "cwd"]):
            try:
                if proc.info["name"] and exe_name.lower() in proc.info["name"].lower():
                    if proc.info["cwd"] and dir_path.lower() in proc.info["cwd"].lower():
                        proc.terminate()
                        try:
                            proc.wait(timeout=5)
                        except psutil.TimeoutExpired:
                            proc.kill()
                            proc.wait(timeout=3)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        # Avvio CON /config per forzare l'AutoTrading (Algo Trading) ON: cosi'
        # il riavvio dal bot riattiva l'algo trading senza aprire la VPS.
        cfg_arg = _config_autotrading_arg()
        args = [exe_path] + ([cfg_arg] if cfg_arg else [])
        try:
            subprocess.Popen(args, cwd=dir_path, shell=False)
        except Exception:
            logger.exception("Avvio terminale con /config fallito; riprovo senza /config.")
            # Meglio un terminale attivo (anche senza AutoTrading forzato) che
            # nessun terminale: fallback all'avvio semplice.
            try:
                subprocess.Popen([exe_path], cwd=dir_path, shell=False)
            except Exception:
                logger.exception("Impossibile avviare il terminale")
                return False
        # Probing post-riavvio: un tentativo al secondo per 15s, eseguito nel
        # worker del terminale (o in-process in fallback), MAI nel processo
        # principale (che non deve toccare MT5 direttamente).
        for _ in range(15):
            await asyncio.sleep(1)
            try:
                ok = await _esegui_senza_lock(
                    exe_path, "_probe_terminale_sync", exe_path, credenziali,
                )
                if ok:
                    return True
            except Exception:
                continue
        return False

async def _esegui_senza_lock(path: str, func: str, *args):
    """Esecuzione pool SENZA riprendere il lock del terminale: riavvia_terminale
    lo detiene gia' per l'intera procedura (kill -> start -> probe).

    Delega a pool.exec_no_lock: prima raggiungeva _worker() e to_thread a mano,
    scavalcando l'executor dedicato e il lock di pipe del worker."""
    return await pool.exec_no_lock(path, func, *args, timeout=30)

async def riavvia_broker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    dati    = await carica_dati_async()
    success = await riavvia_terminale(MT5_BROKER_DIR, MT5_BROKER_EXE, dati.get("broker"))
    msg     = "✅ Broker riavviato." if success else "❌ Riavvio Broker fallito."
    await safe_edit_message_text(query, msg, InlineKeyboardMarkup([back_button("diagnosi")]))

async def riavvia_prop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    dati    = await carica_dati_async()
    success = await riavvia_terminale(MT5_PROP_DIR, MT5_PROP_EXE, dati.get("prop"))
    msg     = "✅ Prop riavviata." if success else "❌ Riavvio Prop fallito."
    await safe_edit_message_text(query, msg, InlineKeyboardMarkup([back_button("diagnosi")]))

async def stato_bot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    dati  = await carica_dati_async()
    br    = dati.get("broker", {})
    pr    = dati.get("prop",   {})
    s_br  = await stato_metatrader_async(MT5_BROKER_EXE)
    s_pr  = await stato_metatrader_async(MT5_PROP_EXE)

    # Sezione abbonamento (si aggiorna con i comandi /rinnova dal canale admin)
    st = stato_abbonamento(dati)
    if not st["configurato"]:
        pagamento = "💳 Pagamento\nStato: ➖ Non impostato\n"
    elif st["scaduto"]:
        pagamento = (
            f"💳 Pagamento\nStato: ⛔ Scaduto\n"
            f"Scadenza: {st['until'].strftime('%d/%m/%Y')}\n"
        )
    else:
        pagamento = (
            f"💳 Pagamento\nStato: ✅ Valido\n"
            f"Scadenza: {st['until'].strftime('%d/%m/%Y')}\n"
        )

    # Ultima segnalazione di pagamento inviata (renew_last_report): cosi' chi
    # non ricorda se ha gia' segnalato il rinnovo lo vede qui. Riga assente se
    # non e' mai stata inviata una segnalazione o se il dato e' illeggibile.
    rep = dati.get("renew_last_report") or {}
    if rep.get("quando"):
        try:
            t = datetime.fromisoformat(rep["quando"])
            if t.tzinfo is None:
                t = t.replace(tzinfo=timezone.utc)
            quando_it = _ora_italiana(t).strftime("%d/%m/%Y %H:%M")
            metodo    = str(rep.get("metodo") or "n/d")
            pagamento += f"Ultima segnalazione: {metodo} — {quando_it}\n"
        except Exception as e:
            logger.debug(f"stato_bot: renew_last_report illeggibile, riga omessa ({e}).")

    # Sezione utente (lo @username viene catturato in automatico allo /start)
    uname  = dati.get("owner_username")
    uid    = dati.get("owner_chat_id")
    utente = f"@{uname}" if uname else "(nessun @username impostato su Telegram)"
    utenti = f"👥 Utenti\n- {utente}"
    if uid:
        utenti += f" (id: {uid})"

    msg = (
        f"📡 Stato Bot\n\n"
        f"🏦 Broker\nProcesso: {'✅' if s_br == 'Connesso' else '❌'}\n"
        f"Login: {br.get('id')}\nServer: {br.get('server')}\n\n"
        f"🏢 Prop\nProcesso: {'✅' if s_pr == 'Connesso' else '❌'}\n"
        f"Login: {pr.get('id')}\nServer: {pr.get('server')}\n\n"
        f"{pagamento}\n"
        f"{utenti}"
    )
    # "💳 Rinnova" (segnalazione pagamento) solo se un abbonamento e' impostato:
    # senza scadenza non c'e' nulla da rinnovare.
    righe_kb = []
    if st["configurato"]:
        righe_kb.append([InlineKeyboardButton("💳 Rinnova", callback_data="renew_start")])
    righe_kb.append(back_button("diagnosi"))
    await safe_edit_message_text(query, msg, InlineKeyboardMarkup(righe_kb))

# ========================= RINNOVO ABBONAMENTO (segnalazione pagamento) =========================
# Flusso: "Hai rinnovato? Sì/No" -> scelta metodo -> segnalazione al canale
# admin. Nessun pagamento passa dal bot: e' solo una notifica; il rinnovo
# effettivo lo fa il gestore dal canale (/rinnova <cliente> <giorni>) dopo
# aver verificato l'accredito. Entry: pulsante "💳 Rinnova" in Stato Bot
# (renew_start) oppure i pulsanti direttamente sugli avvisi di scadenza
# (renew_yes / renew_no, vedi _kb_alert_rinnovo).
RENEW_METODI = [
    ("paypal",    "PayPal"),
    ("revolut",   "Revolut"),
    ("satispay",  "Satispay"),
    ("cryptocom", "Crypto.com"),
]
RENEW_METODI_LABEL = dict(RENEW_METODI)

def _kb_renew_metodi() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("PayPal",   callback_data="renew_via|paypal"),
         InlineKeyboardButton("Revolut",  callback_data="renew_via|revolut")],
        [InlineKeyboardButton("Satispay", callback_data="renew_via|satispay"),
         InlineKeyboardButton("Crypto.com", callback_data="renew_via|cryptocom")],
        [InlineKeyboardButton("✏️ Altro",  callback_data="renew_via|altro")],
        [InlineKeyboardButton("❌ Annulla", callback_data="annulla")],
    ])

_RENEW_ESITO_OK = (
    "✅ Segnalazione inviata!\n\n"
    "Verificheremo il pagamento e attiveremo il rinnovo a breve. Grazie!"
)
_RENEW_ESITO_KO = (
    "⚠️ Non sono riuscito a inviare la segnalazione (canale non raggiungibile "
    "o non configurato).\nRiprova più tardi oppure contatta l'assistenza."
)

async def renew_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Pulsante '💳 Rinnova' in Stato Bot: chiede se il pagamento e' gia' stato fatto."""
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Sì, ho pagato", callback_data="renew_yes"),
         InlineKeyboardButton("❌ Non ancora",    callback_data="renew_no")],
    ])
    await safe_edit_message_text(
        query,
        "💳 Rinnovo abbonamento\n\nHai già effettuato il pagamento del rinnovo?",
        keyboard,
    )
    return RENEW_CONFIRM

async def renew_yes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """'Sì, ho pagato' (da Stato Bot o direttamente dall'avviso di scadenza)."""
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    dati = await carica_dati_async()
    if _segnalazioni_pagamento_oggi(dati) >= RENEW_MAX_REPORTS_DAY:
        await safe_edit_message_text(
            query,
            f"⚠️ Hai già inviato {RENEW_MAX_REPORTS_DAY} segnalazioni oggi.\n"
            "La verifica è in corso: se serve, contatta l'assistenza.",
            InlineKeyboardMarkup([back_button("vai_menu")]),
        )
        return ConversationHandler.END
    await safe_edit_message_text(
        query, "💳 Con quale metodo hai pagato?", _kb_renew_metodi(),
    )
    return RENEW_METODO

async def renew_no(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """'Non ancora': spiega dove segnalare il pagamento in seguito."""
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(
        query,
        "Ok! Quando avrai rinnovato, segnalalo da:\n"
        "/start → 🔧 Diagnosi → 🤖 Stato bot → 💳 Rinnova",
        InlineKeyboardMarkup([back_button("vai_menu")]),
    )
    return ConversationHandler.END

async def renew_metodo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Scelta del metodo di pagamento: invia subito, oppure chiede il testo per 'Altro'."""
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    data = query.data or ""
    mid  = data.split("|", 1)[1] if "|" in data else ""
    if mid == "altro":
        await safe_edit_message_text(
            query,
            "✏️ Scrivi con quale metodo hai pagato (es. bonifico):",
            _cancel_kb(),
        )
        return RENEW_ALTRO
    label = RENEW_METODI_LABEL.get(mid)
    if label is None:
        await ack(query, "Selezione non valida.", show_alert=True)
        return RENEW_METODO
    await safe_edit_message_text(query, "⏳ Invio segnalazione in corso...")
    ok = await _invia_segnalazione_pagamento(context.bot, label)
    await safe_edit_message_text(
        query, _RENEW_ESITO_OK if ok else _RENEW_ESITO_KO,
        InlineKeyboardMarkup([back_button("vai_menu")]),
    )
    return ConversationHandler.END

async def renew_altro_ricevi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Metodo 'Altro': riceve il testo libero e invia la segnalazione."""
    metodo = (update.message.text or "").strip()
    if not metodo:
        await update.message.reply_text(
            "Il metodo non può essere vuoto. Scrivi con cosa hai pagato:",
            reply_markup=_cancel_kb(),
        )
        return RENEW_ALTRO
    if len(metodo) > 100:
        await update.message.reply_text(
            "Testo troppo lungo (max 100 caratteri). Riprova:",
            reply_markup=_cancel_kb(),
        )
        return RENEW_ALTRO
    ok = await _invia_segnalazione_pagamento(context.bot, metodo)
    await update.message.reply_text(
        _RENEW_ESITO_OK if ok else _RENEW_ESITO_KO,
        reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
    )
    return ConversationHandler.END

# ========================= RIAVVIO BOT (gestito dal watchdog) =========================
# Il riavvio vive in fleet (lo usa anche l'aggiornamento OTA): qui l'alias
# storico per i handler del menu Diagnosi.
_esegui_riavvio_bot = esegui_riavvio_bot

async def riavvia_bot_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /riavvia o pulsante 'Riavvia bot': chiede conferma."""
    if not await guard_auth(update, context):
        return
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Sì, riavvia ora", callback_data="riavvia_bot_si")],
        [InlineKeyboardButton("❌ No",              callback_data="riavvia_bot_no")],
    ])
    testo = (
        "♻️ Riavvio del bot\n\n"
        "Il bot verrà chiuso e riaperto entro pochi secondi. Attendi messaggio di riavvio. Poi fai /start\n\n"
        "Confermi il riavvio?"
    )
    if update.callback_query:
        await ack(update.callback_query)
        await safe_edit_message_text(update.callback_query, testo, keyboard)
    elif update.message:
        await update.message.reply_text(testo, reply_markup=keyboard)

async def riavvia_bot_conferma(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    if query.data == "riavvia_bot_no":
        await safe_edit_message_text(
            query, "Riavvio annullato.",
            InlineKeyboardMarkup([back_button("diagnosi")]),
        )
        return
    # Chi ci riaccende? Senza watchdog vivo l'uscita lascerebbe il bot spento
    # e irraggiungibile da Telegram: meglio rifiutare che suicidarsi.
    vivo, motivo = watchdog_attivo()
    if not vivo:
        await safe_edit_message_text(
            query,
            f"⚠️ Riavvio ANNULLATO: {motivo}\n\n"
            "Se uscissi ora il bot resterebbe SPENTO e non potresti più "
            "comandarlo da Telegram.",
            InlineKeyboardMarkup([back_button("diagnosi")]),
        )
        return
    await safe_edit_message_text(query, "♻️ Riavvio in corso… torno operativo tra pochi secondi.")
    logger.warning("Riavvio richiesto via Telegram (/riavvia). Esco; il watchdog rilancerà il bot.")
    asyncio.create_task(_esegui_riavvio_bot())


# ========================= OTA DA CHAT PRIVATA =========================
async def ota_documento_privato(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Aggiornamento OTA inviando lo zip del pacchetto DIRETTAMENTE al bot in
    chat privata, con didascalia '/aggiorna' (sha256 opzionale in coda).

    Via di riserva quando il canale admin non collabora (client Telegram che
    si chiude durante l'invio nel canale, permessi, ecc.). Riservato
    all'owner autenticato: aggiorna SOLO questo bot."""
    msg = update.effective_message
    if msg is None or msg.document is None:
        return
    parts = (msg.caption or "").strip().split()
    if not parts:
        return
    if parts[0].lstrip("/").split("@", 1)[0].lower() != "aggiorna":
        return
    if not context.user_data.get("authenticated"):
        await msg.reply_text("🚫 Non autenticato. Usa /start per accedere, poi rimanda il file.")
        return
    dati = await carica_dati_async()
    uid  = update.effective_user.id if update.effective_user else None
    if uid is None or uid != dati.get("owner_chat_id"):
        await msg.reply_text("🚫 Solo il proprietario del bot può aggiornarlo.")
        return

    async def _rispondi(_bot, testo: str) -> bool:
        await msg.reply_text(testo)
        return True

    await esegui_ota_da_documento_privato(context, msg.document, parts, _rispondi)
