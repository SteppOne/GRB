"""AleBot - bot Telegram di hedging broker/prop (pacchetto)."""

__version__ = "54.0.0"
