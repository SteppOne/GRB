import asyncio
import logging
import os
from functools import partial
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ConversationHandler,
    ContextTypes,
)

logger = logging.getLogger(__name__)

from .config import (
    BR_CONFIRM,
    BR_ID,
    BR_PSW,
    BR_RETRY,
    BR_SERVER,
    CFG_PR_CONFIRM,
    CFG_PR_CONS,
    CFG_PR_COSTO,
    CFG_PR_COSTO_RESET,
    CFG_PR_DDDAILY,
    CFG_PR_DDMAX,
    CFG_PR_FIRM,
    CFG_PR_INCASSO,
    CFG_PR_MODE,
    CFG_PR_SALDO,
    CFG_PR_TARGET,
    CFG_PR_TIPDD,
    CFG_PR_TIPINC,
    INCASSO_TARGET,
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    PROP_FIRMS,
    PR_CONFIRM,
    PR_ID,
    PR_PSW,
    PR_RETRY,
    PR_SERVER,
    SIMBOLO_BROKER,
    _attiva_simbolo_prop,
    _prop_firm_by_id,
)
from . import config as cfg
from .messaging import _cancel_kb, ack, back_button, safe_edit_message_text
from .state import modifier_reset_metriche_prop
from .storage import carica_dati_async, modifica_dati_async, modifier_set_key
from .mt5_pool import pool
from .mt5_async import info_account_async
from .trade_core import _incasso_corrente
from .handlers_base import guard_auth, mostra_menu_principale

# ========================= VERIFICA CREDENZIALI (robusta) =========================
# PROBLEMA REALE segnalato dai clienti: "cambio account sulla STESSA prop e mi
# dà errore, ma la password è giusta". Non era un errore dell'utente. Tre cause,
# tutte tecniche:
#
#  1. INTERFERENZA DEI LOOP. Mentre l'utente digita le nuove credenziali, il
#     guardiano di coppia (ogni 2s), la baseline prop (ogni 5 min) e il monitor
#     chiusure continuano a chiamare connessione_mt5() con le credenziali
#     VECCHIE, riautenticando il terminale sul conto precedente. Il login del
#     conto nuovo si infilava tra due riautenticazioni del vecchio.
#  2. NESSUN RITENTATIVO. Il cambio di account su un terminale gia' connesso
#     richiede a MT5 di scollegarsi e ricollegarsi: il primo tentativo puo'
#     fallire per motivi puramente transitori.
#  3. MESSAGGIO INDISTINGUIBILE. Sia "password sbagliata" sia "terminale
#     occupato" producevano "❌ Connessione fallita. Verifica credenziali." —
#     e il cliente, con la password giusta in mano, non poteva capire.
#
# Rimedio: sessione ESCLUSIVA sul terminale per tutta la verifica (i loop non
# possono intromettersi), fino a 3 tentativi sui soli guasti tecnici, e
# messaggi che dicono cosa e' successo davvero.
VERIFICA_TENTATIVI   = 3
VERIFICA_PAUSA_S     = 2.0
VERIFICA_TIMEOUT_S   = 60

async def _verifica_credenziali_robusta(
    path: str, login: int, password: str, server: str, identifica: bool = False,
):
    """Verifica le credenziali tenendo il terminale per se'.

    Ritorna (esito, server_reale, company, dettaglio) con esito in
    "ok" / "credenziali" / "tecnico". Con identifica=True legge anche
    server e company REALI riportati dal broker dopo il login.
    """
    func = (
        "verifica_e_identifica_broker_dettagliata_sync" if identifica
        else "verifica_credenziali_dettagliata_sync"
    )
    ultimo = ("tecnico", "", "", "nessun tentativo eseguito")
    # Sessione esclusiva: per tutta la durata, NESSUN loop puo' riautenticare
    # il terminale sull'account precedente.
    async with pool.sessione_esclusiva(path):
        for tentativo in range(VERIFICA_TENTATIVI):
            try:
                risultato = await pool.exec_no_lock(
                    path, func, path, int(login), password, server,
                    timeout=VERIFICA_TIMEOUT_S,
                )
            except Exception as e:
                logger.exception("Verifica credenziali: errore worker MT5")
                ultimo = ("tecnico", "", "", f"comunicazione con MT5 fallita ({e})")
                risultato = None

            if risultato is not None:
                if identifica:
                    esito, server_reale, company, dettaglio = risultato
                else:
                    esito, dettaglio = risultato
                    server_reale = company = ""
                ultimo = (esito, server_reale, company, dettaglio)
                # "credenziali" = rifiuto definitivo del broker: insistere e'
                # inutile e rischia di far scattare i blocchi anti-bruteforce.
                if esito in ("ok", "credenziali"):
                    return ultimo

            if tentativo < VERIFICA_TENTATIVI - 1:
                logger.warning(
                    f"Verifica credenziali su {os.path.basename(os.path.dirname(path))}: "
                    f"tentativo {tentativo + 1}/{VERIFICA_TENTATIVI} non concluso "
                    f"({ultimo[3]}), riprovo tra {VERIFICA_PAUSA_S}s."
                )
                await asyncio.sleep(VERIFICA_PAUSA_S)
    return ultimo

async def _reset_sessione_terminale(path: str) -> None:
    """Chiude la sessione MT5 sul terminale, cosi' la PROSSIMA operazione
    riparte con initialize+login puliti sulle credenziali appena salvate.
    Senza, la sessione persistente resterebbe agganciata all'account vecchio
    finche' qualcuno non chiede esplicitamente un login diverso."""
    try:
        await pool.exec(path, "_mt5_disconnect", timeout=30)
    except Exception as e:
        logger.warning(f"Reset sessione MT5 su {path} non riuscito ({e}); non blocca.")

def _msg_verifica_fallita(esito: str, dettaglio: str, lato: str) -> str:
    """Messaggio che distingue il rifiuto del broker dal guasto tecnico."""
    if esito == "credenziali":
        return (
            f"❌ Il broker ha RIFIUTATO queste credenziali {lato}.\n\n"
            "Controlla, nell'ordine:\n"
            "• il numero di conto (solo cifre);\n"
            "• la password — dev'essere quella del conto, non quella del bot;\n"
            "• il nome del SERVER, identico a quello che vedi in MT5 "
            "(spazi e trattini compresi).\n\n"
            "Poi riprova."
        )
    return (
        f"⚠️ Non sono riuscito a completare l'accesso {lato}: il terminale non "
        f"ha risposto in tempo.\n\nDettaglio tecnico: {dettaglio}\n\n"
        "Le credenziali NON sono state scartate: ho già riprovato "
        f"{VERIFICA_TENTATIVI} volte. Verifica che il terminale MT5 {lato} sia "
        "aperto e connesso, poi premi 🔄 Riprova."
    )

# ========================= CONFIGURA OP =========================
async def menu_configura_op(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    keyboard = [
        [InlineKeyboardButton("🔑 Gestisci Credenziali",   callback_data="configura_credenziali")],
        [InlineKeyboardButton("🏦 Configurazione Broker",  callback_data="config_broker")],
        [InlineKeyboardButton("📊 Configurazione Prop",    callback_data="config_prop")],
        [InlineKeyboardButton("⬅️ Indietro",               callback_data="indietro")],
    ]
    await safe_edit_message_text(query, "⚙️ Configura Operatività", InlineKeyboardMarkup(keyboard))

async def menu_config_credenziali(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    keyboard = [
        [InlineKeyboardButton("🏦 Broker",    callback_data="cfg_broker_cred")],
        [InlineKeyboardButton("📊 Prop",      callback_data="cfg_prop_cred")],
        [InlineKeyboardButton("🔍 Visualizza", callback_data="visualizza_cred")],
        [InlineKeyboardButton("⬅️ Indietro",  callback_data="configura_op")],
    ]
    await safe_edit_message_text(query, "🔑 Gestisci Credenziali\n\nScegli account:", InlineKeyboardMarkup(keyboard))

async def visualizza_credenziali(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    dati = await carica_dati_async()
    br   = dati.get("broker", {})
    pr   = dati.get("prop",   {})
    msg  = "📋 Account configurati\n\n"
    if br:
        msg += f"🏦 Broker\nLogin: {br.get('id')}\nPassword: {str(br.get('password'))[:2]}***\nServer: {br.get('server')}\n\n"
    if pr:
        msg += f"🏢 Prop\nLogin: {pr.get('id')}\nPassword: {str(pr.get('password'))[:2]}***\nServer: {pr.get('server')}"
    keyboard = [
        [InlineKeyboardButton("🔓 Mostra password", callback_data="mostra_pwd")],
        [InlineKeyboardButton("⬅️ Indietro",        callback_data="configura_credenziali")],
    ]
    await safe_edit_message_text(query, msg, InlineKeyboardMarkup(keyboard))

async def mostra_password_temp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    dati = await carica_dati_async()
    br   = dati.get("broker", {})
    pr   = dati.get("prop", {})
    msg  = "🔓 Password visibili 5 sec:\n\n"
    if br:
        msg += f"Broker: {br.get('password')}\n"
    if pr:
        msg += f"Prop: {pr.get('password')}"
    # Nessun tasto durante la visualizzazione: il timer qui sotto riscrive il
    # messaggio dopo 5s e sovrascriverebbe la navigazione (era questo il bug del
    # tasto "Indietro" che sembrava non funzionare). Il tasto torna nella
    # schermata finale, dove funziona senza interferenze.
    await safe_edit_message_text(query, msg)
    try:
        await asyncio.sleep(5)
        await safe_edit_message_text(
            query, "🔒 Password nuovamente nascoste.",
            InlineKeyboardMarkup([back_button("visualizza_cred")]),
        )
    except Exception as e:
        logger.debug(f"mostra_password_temp: edit finale ignorato ({e}).")

# ========================= MODIFICA INCASSO =========================
async def inizia_modifica_incasso(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    dati          = await carica_dati_async()
    prop_avanzata = dati.get("prop_avanzata", {})
    # Valore effettivo: incasso_target con priorita', fallback legacy.
    incasso_target = prop_avanzata.get("incasso_target", prop_avanzata.get("incasso_se_bruciata"))
    msg = (
        "💰 Inserisci l'incasso target ($):\n"
        "Valori accettati: maggiore di 0"
    )
    if incasso_target is not None:
        try:
            msg += f"\n\n📌 Valore attuale: {float(incasso_target):.2f}$"
        except (TypeError, ValueError):
            pass
    await safe_edit_message_text(query, msg, _cancel_kb())
    return INCASSO_TARGET

async def ricevi_incasso_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
        if val <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "Valore non valido. Inserisci un numero maggiore di 0.",
            reply_markup=_cancel_kb(),
        )
        return INCASSO_TARGET

    def update_incasso(d):
        if "prop_avanzata" not in d:
            d["prop_avanzata"] = {}
        # Chiavi gemelle SEMPRE allineate (stesso concetto, due chiavi storiche):
        # cosi' le schermate che leggono incasso_se_bruciata restano coerenti.
        d["prop_avanzata"]["incasso_target"]      = val
        d["prop_avanzata"]["incasso_se_bruciata"] = val
        return d

    await modifica_dati_async(update_incasso)
    await update.message.reply_text(f"✅ Incasso Target aggiornato a {val}$.\nLa formula calcolerà il broker usando questo target.")
    await mostra_menu_principale(update, context)
    return ConversationHandler.END

# ========================= BROKER CREDENZIALI =========================
async def br_id_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    context.user_data.pop("br_id", None)
    context.user_data.pop("br_psw", None)
    context.user_data.pop("br_server", None)
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "Inserisci Account ID Broker: (numero conto, es: 60110292)", _cancel_kb())
    return BR_ID

async def br_id_ricevi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text(
            "Account ID non valido. Inserisci un numero intero.",
            reply_markup=_cancel_kb(),
        )
        return BR_ID
    context.user_data["br_id"] = text
    await update.message.reply_text("Password Broker: (password del conto)", reply_markup=_cancel_kb())
    return BR_PSW

async def br_psw_ricevi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["br_psw"] = update.message.text.strip()
    await update.message.reply_text("Server Broker: (esattamente il nome del SERVER del broker, senza spazi, es: TradeMaxGlobal-Demo)", reply_markup=_cancel_kb())
    return BR_SERVER

async def br_server_ricevi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["br_server"] = update.message.text.strip()
    msg = (
        "🔍 Verifica i dati Broker:\n\n"
        f"Account ID: {context.user_data['br_id']}\n"
        f"Password: {'*' * max(3, len(context.user_data.get('br_psw', '')))}\n"
        f"Server: {context.user_data['br_server']}\n\n"
        "I dati sono corretti?"
    )
    keyboard = [
        [
            InlineKeyboardButton("✅ Sì", callback_data="br_confirm_yes"),
            InlineKeyboardButton("✏️ Modifica", callback_data="br_confirm_edit"),
        ],
        [InlineKeyboardButton("❌ Annulla", callback_data="annulla")],
    ]
    await update.message.reply_text(msg, reply_markup=InlineKeyboardMarkup(keyboard))
    return BR_CONFIRM

async def br_confirm_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    if query.data == "br_confirm_edit":
        context.user_data.pop("br_id", None)
        context.user_data.pop("br_psw", None)
        context.user_data.pop("br_server", None)
        await safe_edit_message_text(query, "Inserisci Account ID Broker:", _cancel_kb())
        return BR_ID
    if query.data != "br_confirm_yes":
        await ack(query, "Scelta non valida.", show_alert=True)
        return BR_CONFIRM
    await safe_edit_message_text(query, "⏳ Connessione a MT5 Broker in corso...")
    retry_kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 Riprova", callback_data="br_retry")],
        [InlineKeyboardButton("⬅️ Indietro", callback_data="configura_credenziali")],
    ])
    # Verifica in sessione ESCLUSIVA sul terminale Broker, con ritentativi sui
    # soli guasti tecnici: vedi la nota in cima al modulo (cambio account sullo
    # stesso terminale).
    esito, server_reale, company, dettaglio = await _verifica_credenziali_robusta(
        MT5_BROKER_EXE,
        int(context.user_data["br_id"]),
        context.user_data["br_psw"],
        context.user_data["br_server"],
        identifica=True,
    )
    if esito != "ok":
        await safe_edit_message_text(
            query, _msg_verifica_fallita(esito, dettaglio, "Broker"), retry_kb,
        )
        return BR_RETRY

    # Vincolo broker: l'account deve appartenere a un broker autorizzato (server/company REALI)
    matched = _identifica_broker_whitelist(server_reale, company)
    nomi_ok = ", ".join(b["label"] for b in BROKER_WHITELIST)
    if matched is None:
        await safe_edit_message_text(
            query,
            f"⛔ Broker non autorizzato.\n\nQuesto account risulta sul server "
            f"\"{server_reale}\", che non appartiene ai broker consentiti ({nomi_ok}).\n\n"
            "Per usare il bot devi avere un conto con uno dei broker indicati.",
            retry_kb,
        )
        return BR_RETRY

    # Se l'utente aveva selezionato un broker nel menu, deve coincidere con quello reale
    dati  = await carica_dati_async()
    sel   = dati.get("broker_config") or {}
    sel_id = sel.get("cb")
    if sel_id and matched["id"] != sel_id:
        sel_label = next((b["label"] for b in BROKER_WHITELIST if b["id"] == sel_id), sel_id)
        await safe_edit_message_text(
            query,
            f"⛔ Broker diverso da quello selezionato.\n\nHai selezionato \"{sel_label}\" "
            f"ma questo account è di \"{matched['label']}\" (server \"{server_reale}\").\n\n"
            f"Inserisci un account {sel_label}, oppure cambia la selezione del broker.",
            retry_kb,
        )
        return BR_RETRY

    broker_data = {
        "id":       context.user_data["br_id"],
        "password": context.user_data["br_psw"],
        "server":   context.user_data["br_server"],
    }
    id_precedente = str((dati.get("broker") or {}).get("id") or "")
    await modifica_dati_async(partial(modifier_set_key, key="broker", value=broker_data))
    await modifica_dati_async(partial(
        modifier_set_key, key="broker_config",
        value={"name": matched["label"], "cb": matched["id"]},
    ))
    # Sessione MT5 azzerata: la prossima operazione si autentica da zero sulle
    # credenziali appena salvate, senza ereditare l'aggancio al conto vecchio.
    await _reset_sessione_terminale(MT5_BROKER_EXE)

    msg_ok = f"✅ Account Broker configurato con successo.\n🏦 Broker: {matched['label']}"
    if id_precedente and id_precedente != str(broker_data["id"]):
        msg_ok += (
            f"\n\nℹ️ Account cambiato ({id_precedente} → {broker_data['id']}).\n"
            "Eventuali posizioni ancora aperte sul conto precedente NON sono "
            "più gestite dal bot: verificale a mano dal terminale."
        )
    await safe_edit_message_text(
        query, msg_ok, InlineKeyboardMarkup([back_button("configura_credenziali")]),
    )
    return ConversationHandler.END

async def br_retry_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    context.user_data.pop("br_id", None)
    context.user_data.pop("br_psw", None)
    context.user_data.pop("br_server", None)
    await safe_edit_message_text(query, "Inserisci Account ID Broker:", _cancel_kb())
    return BR_ID

# ========================= PROP CREDENZIALI =========================
async def pr_id_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    context.user_data.pop("pr_id", None)
    context.user_data.pop("pr_psw", None)
    context.user_data.pop("pr_server", None)
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "Inserisci Account ID Prop: (numero conto, es. 62302916)", _cancel_kb())
    return PR_ID

async def pr_id_ricevi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text(
            "Account ID non valido. Inserisci un numero intero.",
            reply_markup=_cancel_kb(),
        )
        return PR_ID
    context.user_data["pr_id"] = text
    await update.message.reply_text("Password Prop: (password del conto)", reply_markup=_cancel_kb())
    return PR_PSW

async def pr_psw_ricevi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["pr_psw"] = update.message.text.strip()
    await update.message.reply_text("Server Prop: (esattamente il SERVER della prop, es. FundedNext-Server 2, occhio che per fundednext ci va lo spazio prima del 2 ", reply_markup=_cancel_kb())
    return PR_SERVER

async def pr_server_ricevi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["pr_server"] = update.message.text.strip()
    msg = (
        "🔍 Verifica i dati Prop:\n\n"
        f"Account ID: {context.user_data['pr_id']}\n"
        f"Password: {'*' * max(3, len(context.user_data.get('pr_psw', '')))}\n"
        f"Server: {context.user_data['pr_server']}\n\n"
        "I dati sono corretti?"
    )
    keyboard = [
        [
            InlineKeyboardButton("✅ Sì", callback_data="pr_confirm_yes"),
            InlineKeyboardButton("✏️ Modifica", callback_data="pr_confirm_edit"),
        ],
        [InlineKeyboardButton("❌ Annulla", callback_data="annulla")],
    ]
    await update.message.reply_text(msg, reply_markup=InlineKeyboardMarkup(keyboard))
    return PR_CONFIRM

async def pr_confirm_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    if query.data == "pr_confirm_edit":
        context.user_data.pop("pr_id", None)
        context.user_data.pop("pr_psw", None)
        context.user_data.pop("pr_server", None)
        await safe_edit_message_text(query, "Inserisci Account ID Prop:", _cancel_kb())
        return PR_ID
    if query.data != "pr_confirm_yes":
        await ack(query, "Scelta non valida.", show_alert=True)
        return PR_CONFIRM
    await safe_edit_message_text(query, "⏳ Connessione a MT5 Prop in corso...")
    esito, _srv, _cmp, dettaglio = await _verifica_credenziali_robusta(
        MT5_PROP_EXE,
        int(context.user_data["pr_id"]),
        context.user_data["pr_psw"],
        context.user_data["pr_server"],
    )
    if esito != "ok":
        await safe_edit_message_text(
            query, _msg_verifica_fallita(esito, dettaglio, "Prop"),
            InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Riprova", callback_data="pr_retry")],
                [InlineKeyboardButton("⬅️ Indietro", callback_data="configura_credenziali")],
            ]),
        )
        return PR_RETRY

    prop_data = {
        "id":       context.user_data["pr_id"],
        "password": context.user_data["pr_psw"],
        "server":   context.user_data["pr_server"],
    }
    dati_attuali  = await carica_dati_async()
    id_precedente = str((dati_attuali.get("prop") or {}).get("id") or "")
    cambio_conto  = bool(id_precedente) and id_precedente != str(prop_data["id"])

    await modifica_dati_async(partial(modifier_set_key, key="prop", value=prop_data))
    if cambio_conto:
        # Le metriche giornaliere e il saldo massimo appartengono al conto
        # PRECEDENTE: tenerle falserebbe la "Perdita giornaliera rimasta" sul
        # conto nuovo — cioe' proprio il numero su cui l'utente decide quanto
        # rischiare. Si riparte dal conto attuale alla prima lettura.
        await modifica_dati_async(modifier_reset_metriche_prop)
        logger.info(
            f"Cambio account prop {id_precedente} → {prop_data['id']}: "
            f"metriche giornaliere azzerate."
        )
    await _reset_sessione_terminale(MT5_PROP_EXE)

    msg_ok = "✅ Account Prop configurato con successo."
    if cambio_conto:
        msg_ok += (
            f"\n\nℹ️ Account cambiato ({id_precedente} → {prop_data['id']}).\n"
            "• Perdita giornaliera e saldo massimo ripartono dal conto nuovo.\n"
            "• Guadagni, payout e costi cumulati restano invariati "
            "(azzerali da Info Account → ♻️ Reset Guadagni/Perdite se inizi un ciclo nuovo).\n"
            "• Eventuali posizioni aperte sul conto precedente NON sono più "
            "gestite dal bot: verificale a mano dal terminale."
        )
    await safe_edit_message_text(
        query, msg_ok, InlineKeyboardMarkup([back_button("configura_credenziali")]),
    )
    return ConversationHandler.END

async def pr_retry_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    context.user_data.pop("pr_id", None)
    context.user_data.pop("pr_psw", None)
    context.user_data.pop("pr_server", None)
    await safe_edit_message_text(query, "Inserisci Account ID Prop:", _cancel_kb())
    return PR_ID

# ========================= CONFIG PROP AVANZATA =========================
TIPINC_MAP = {"tipinc_statico": "statico", "tipinc_dinamico": "dinamico"}
TIPDD_MAP  = {"tipdd_statico":  "statico", "tipdd_dinamico":  "dinamico"}

def _parse_positive_float(text: str) -> Optional[float]:
    try:
        val = float(text.replace(",", "."))
        if val < 0:
            return None
        return val
    except (TypeError, ValueError):
        return None

async def menu_config_prop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    keyboard = [
        [InlineKeyboardButton("⚙️ Configura",                 callback_data="cfg_prop_av")],
        [InlineKeyboardButton("💰 Modifica Incasso",          callback_data="cfg_incasso")],
        [InlineKeyboardButton("🔄 Aggiungi costo reset Prop", callback_data="cfg_costo_reset")],
        [InlineKeyboardButton("🔍 Visualizza",                callback_data="vis_prop_av")],
        [InlineKeyboardButton("⬅️ Indietro",                  callback_data="configura_op")],
    ]
    await safe_edit_message_text(query, "🏢 Configurazione Prop", InlineKeyboardMarkup(keyboard))

async def cfg_prop_av_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    keyboard = [
        [InlineKeyboardButton(f"🏢 {f['label']}", callback_data=f"prop_firm|{f['id']}")]
        for f in PROP_FIRMS
    ]
    keyboard.append([InlineKeyboardButton("❌ Annulla", callback_data="cfg_prop_av_annulla")])
    await safe_edit_message_text(
        query, "📊 Configura Prop\n\nSeleziona la società prop:",
        InlineKeyboardMarkup(keyboard),
    )
    return CFG_PR_FIRM

async def ricevi_cfg_pr_firm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    data = query.data or ""
    fid  = data.split("|", 1)[1] if "|" in data else ""
    firm = _prop_firm_by_id(fid)
    if not firm:
        await ack(query, "Selezione non valida.", show_alert=True)
        return CFG_PR_FIRM
    context.user_data["pr_firm_id"]    = firm["id"]
    context.user_data["pr_firm_label"] = firm["label"]
    context.user_data["pr_simbolo"]    = firm["simbolo"]
    keyboard = [
        [
            InlineKeyboardButton("🏆 Sfida", callback_data="prop_mode_sfida"),
            InlineKeyboardButton("💰 Reale", callback_data="prop_mode_reale"),
        ],
        [InlineKeyboardButton("❌ Annulla", callback_data="cfg_prop_av_annulla")],
    ]
    await safe_edit_message_text(
        query,
        f"📊 Configura Prop\n\nProp: {firm['label']} (simbolo {firm['simbolo']})\n\n"
        "Seleziona la modalità:",
        InlineKeyboardMarkup(keyboard),
    )
    return CFG_PR_MODE

async def ricevi_cfg_pr_mode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    context.user_data["pr_mode"] = "sfida" if query.data == "prop_mode_sfida" else "reale"
    await safe_edit_message_text(
        query, "📊 Configura Prop\n\nInserisci il saldo di partenza in $:",
        _cancel_kb("cfg_prop_av_annulla"),
    )
    return CFG_PR_SALDO

async def ricevi_cfg_pr_saldo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    val = _parse_positive_float(update.message.text)
    if val is None or val <= 0:
        await update.message.reply_text(
            "⚠️ Valore non valido. Inserisci un numero maggiore di 0.",
            reply_markup=_cancel_kb("cfg_prop_av_annulla"),
        )
        return CFG_PR_SALDO
    context.user_data["pr_saldo"] = val
    if context.user_data.get("pr_mode") == "reale":
        prompt = (
            "Inserisci il target (%):\n"
            "(0 = nessun obiettivo — tipico dei conti reali/funded)"
        )
    else:
        prompt = "Inserisci il target (%):"
    await update.message.reply_text(prompt, reply_markup=_cancel_kb("cfg_prop_av_annulla"))
    return CFG_PR_TARGET

async def ricevi_cfg_pr_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    val = _parse_positive_float(update.message.text)
    # In modalita' reale/funded e' ammesso 0 = "nessun obiettivo"; in Sfida il
    # target deve essere > 0 (serve come riferimento dell'obiettivo da raggiungere).
    reale = context.user_data.get("pr_mode") == "reale"
    minimo_ok = (val is not None) and (val >= 0 if reale else val > 0) and val <= 1000
    if not minimo_ok:
        await update.message.reply_text(
            "⚠️ Valore non valido. Inserisci una percentuale (≥0)."
            if reale else
            "⚠️ Valore non valido. Inserisci una percentuale (>0).",
            reply_markup=_cancel_kb("cfg_prop_av_annulla"),
        )
        return CFG_PR_TARGET
    context.user_data["pr_target"] = val
    await update.message.reply_text("Inserisci la perdita massima totale (%):", reply_markup=_cancel_kb("cfg_prop_av_annulla"))
    return CFG_PR_DDMAX

async def ricevi_cfg_pr_ddmax(update: Update, context: ContextTypes.DEFAULT_TYPE):
    val = _parse_positive_float(update.message.text)
    if val is None or val <= 0 or val > 100:
        await update.message.reply_text(
            "⚠️ Valore non valido. Inserisci una percentuale (0 < x ≤ 100).",
            reply_markup=_cancel_kb("cfg_prop_av_annulla"),
        )
        return CFG_PR_DDMAX
    context.user_data["pr_ddmax"] = val
    await update.message.reply_text("Inserisci la perdita massima giornaliera (%):", reply_markup=_cancel_kb("cfg_prop_av_annulla"))
    return CFG_PR_DDDAILY

async def ricevi_cfg_pr_dddaily(update: Update, context: ContextTypes.DEFAULT_TYPE):
    val = _parse_positive_float(update.message.text)
    if val is None or val <= 0 or val > 100:
        await update.message.reply_text(
            "⚠️ Valore non valido. Inserisci una percentuale (0 < x ≤ 100).",
            reply_markup=_cancel_kb("cfg_prop_av_annulla"),
        )
        return CFG_PR_DDDAILY
    context.user_data["pr_dddaily"] = val
    await update.message.reply_text("Inserisci il costo della prop ($):", reply_markup=_cancel_kb("cfg_prop_av_annulla"))
    return CFG_PR_COSTO

async def ricevi_cfg_pr_costo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    val = _parse_positive_float(update.message.text)
    if val is None:
        await update.message.reply_text(
            "⚠️ Valore non valido. Inserisci un numero ≥ 0.",
            reply_markup=_cancel_kb("cfg_prop_av_annulla"),
        )
        return CFG_PR_COSTO
    context.user_data["pr_costo"] = val
    # NB: il "costo reset" NON viene chiesto qui per evitare duplicazione.
    # Si configura dal pulsante dedicato "🔄 Aggiungi costo reset Prop" nel menu Prop.
    dati = await carica_dati_async()
    prop_avanzata = dati.get("prop_avanzata", {})
    # Mostra il valore EFFETTIVO usato dalla formula dei lotti broker:
    # incasso_target ha priorita' (vedi _incasso_corrente), incasso_se_bruciata
    # e' il fallback legacy. Mostrare solo incasso_se_bruciata poteva far vedere
    # un valore diverso da quello realmente applicato.
    incasso_attuale = prop_avanzata.get("incasso_target", prop_avanzata.get("incasso_se_bruciata"))
    msg = "💸 Inserisci l'incasso se la prop viene bruciata ($):"
    if incasso_attuale is not None:
        try:
            msg += f"\n\n💰 Valore attuale: {float(incasso_attuale):.2f}$"
        except (ValueError, TypeError):
            pass
    msg += "\n\nValori accettati: maggiore di 0"
    await update.message.reply_text(msg, reply_markup=_cancel_kb("cfg_prop_av_annulla"))
    return CFG_PR_INCASSO

async def ricevi_cfg_pr_incasso(update: Update, context: ContextTypes.DEFAULT_TYPE):
    val = _parse_positive_float(update.message.text)
    if val is None or val <= 0:
        await update.message.reply_text(
            "⚠️ Valore non valido. Inserisci un numero maggiore di 0.",
            reply_markup=_cancel_kb("cfg_prop_av_annulla"),
        )
        return CFG_PR_INCASSO
    context.user_data["pr_incasso"] = val
    keyboard = [
        [
            InlineKeyboardButton("📌 Statico", callback_data="tipinc_statico"),
            InlineKeyboardButton("📌 Dinamico", callback_data="tipinc_dinamico"),
        ],
        [InlineKeyboardButton("❌ Annulla", callback_data="cfg_prop_av_annulla")],
    ]
    await update.message.reply_text(
        "📊 Configura Prop\n\nScegli la tipologia di incasso:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )
    return CFG_PR_TIPINC

async def ricevi_cfg_pr_tipinc_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    choice = TIPINC_MAP.get(query.data)
    if choice is None:
        await ack(query, "Selezione non valida.", show_alert=True)
        return CFG_PR_TIPINC
    context.user_data["pr_tipinc"] = choice
    keyboard = [
        [
            InlineKeyboardButton("📌 Statico", callback_data="tipdd_statico"),
            InlineKeyboardButton("📌 Dinamico", callback_data="tipdd_dinamico"),
        ],
        [InlineKeyboardButton("❌ Annulla", callback_data="cfg_prop_av_annulla")],
    ]
    await safe_edit_message_text(
        query, "📊 Configura Prop\n\nScegli la tipologia di drawdown:",
        InlineKeyboardMarkup(keyboard),
    )
    return CFG_PR_TIPDD

async def ricevi_cfg_pr_tipdd_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    choice = TIPDD_MAP.get(query.data)
    if choice is None:
        await ack(query, "Selezione non valida.", show_alert=True)
        return CFG_PR_TIPDD
    context.user_data["pr_tipdd"] = choice
    await safe_edit_message_text(
        query,
        "📊 Configura Prop\n\nInserisci la consistenza (%):\n\n"
        "È il rapporto tra il PROFITTO GIORNALIERO MASSIMO concesso dalla prop "
        "e il TARGET.\n\n"
        "Esempio: target 6%, profitto massimo giornaliero 3% → scrivi 50\n\n"
        "Serve al bot per calcolare il \"Profitto giornaliero rimasto\" in "
        "Info Prop.\n"
        "Scrivi 0 se la tua prop non ha un limite giornaliero di profitto.",
        _cancel_kb("cfg_prop_av_annulla"),
    )
    return CFG_PR_CONS

async def ricevi_cfg_pr_cons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    val = _parse_positive_float(update.message.text)
    if val is None or val < 0 or val > 100:
        await update.message.reply_text(
            "⚠️ Valore non valido. Inserisci una percentuale 0–100.",
            reply_markup=_cancel_kb("cfg_prop_av_annulla"),
        )
        return CFG_PR_CONS
    context.user_data["pr_cons"] = val
    msg = (
        "📊 Riepilogo configurazione Prop\n\n"
        f"Prop: {context.user_data.get('pr_firm_label', 'N/D')} "
        f"(simbolo {context.user_data.get('pr_simbolo', 'N/D')})\n"
        f"Modalità: {str(context.user_data.get('pr_mode', 'sfida')).capitalize()}\n"
        f"Saldo partenza: {context.user_data.get('pr_saldo', 'N/D')}$\n"
        f"Target: {('Nessun obiettivo' if context.user_data.get('pr_target') == 0 else str(context.user_data.get('pr_target', 'N/D')) + '%')}\n"
        f"Perdita massima totale: {context.user_data.get('pr_ddmax', 'N/D')}%\n"
        f"Perdita massima giornaliera: {context.user_data.get('pr_dddaily', 'N/D')}%\n"
        f"Costo prop: {context.user_data.get('pr_costo', 'N/D')}$\n"
        f"Incasso se la prop viene bruciata: {context.user_data.get('pr_incasso', 'N/D')}$\n"
        f"Tipologia incasso: {context.user_data.get('pr_tipinc', 'N/D')}\n"
        f"Tipologia drawdown: {context.user_data.get('pr_tipdd', 'N/D')}\n"
        f"Consistenza: {context.user_data.get('pr_cons', 'N/D')}%\n\n"
        "ℹ️ Il costo reset si configura dal pulsante dedicato \"🔄 Aggiungi costo reset Prop\".\n\n"
        "I dati sono corretti?"
    )
    keyboard = [
        [
            InlineKeyboardButton("✅ Sì", callback_data="prop_confirm_yes"),
            InlineKeyboardButton("✏️ Modifica", callback_data="prop_confirm_edit"),
        ],
        [InlineKeyboardButton("❌ Annulla", callback_data="cfg_prop_av_annulla")],
    ]
    await update.message.reply_text(msg, reply_markup=InlineKeyboardMarkup(keyboard))
    return CFG_PR_CONFIRM

async def cfg_prop_confirm_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    if query.data == "prop_confirm_edit":
        keyboard = [
            [InlineKeyboardButton(f"🏢 {f['label']}", callback_data=f"prop_firm|{f['id']}")]
            for f in PROP_FIRMS
        ]
        keyboard.append([InlineKeyboardButton("❌ Annulla", callback_data="cfg_prop_av_annulla")])
        await safe_edit_message_text(
            query, "📊 Configura Prop\n\nSeleziona la società prop:",
            InlineKeyboardMarkup(keyboard),
        )
        return CFG_PR_FIRM
    if query.data != "prop_confirm_yes":
        await ack(query, "Scelta non valida.", show_alert=True)
        return CFG_PR_CONFIRM

    # MERGE con la configurazione esistente: preserva campi gestiti FUORI da
    # questo flusso (es. costo_reset impostato dal pulsante dedicato).
    # NB: incasso_target viene AGGIORNATO qui insieme a incasso_se_bruciata.
    # Sono lo STESSO concetto su due chiavi storiche e la formula dei lotti
    # broker legge incasso_target con priorita' (_incasso_corrente): se qui si
    # scrivesse solo incasso_se_bruciata, un incasso_target preesistente
    # MASCHEREREBBE per sempre il valore appena inserito dall'utente (bug
    # "modifico l'incasso ma il riepilogo mostra il vecchio").
    def _aggiorna_prop_av(d: dict) -> dict:
        prev = dict(d.get("prop_avanzata", {}) or {})
        prev.update({
            "modalita":           context.user_data.get("pr_mode", "sfida"),
            "saldo_partenza":     context.user_data.get("pr_saldo"),
            "target":             context.user_data.get("pr_target"),
            "dd_max_perc":        context.user_data.get("pr_ddmax"),
            "dd_daily_perc":      context.user_data.get("pr_dddaily"),
            "costo":              context.user_data.get("pr_costo"),
            "incasso_se_bruciata": context.user_data.get("pr_incasso"),
            "incasso_target":     context.user_data.get("pr_incasso"),
            "tip_incasso":        context.user_data.get("pr_tipinc"),
            "tip_drawdown":       context.user_data.get("pr_tipdd"),
            "consistenza":        context.user_data.get("pr_cons"),
        })
        # Società prop scelta + simbolo abbinato (sovrascrive il .env).
        if context.user_data.get("pr_simbolo"):
            prev["simbolo"]         = context.user_data["pr_simbolo"]
            prev["prop_firm"]       = context.user_data.get("pr_firm_id")
            prev["prop_firm_label"] = context.user_data.get("pr_firm_label")
        d["prop_avanzata"] = prev
        return d

    await modifica_dati_async(_aggiorna_prop_av)
    # Attiva SUBITO il simbolo scelto per la sessione corrente (oltre che a ogni
    # avvio via post_init), cosi' i trade successivi usano gia' quello giusto.
    _attiva_simbolo_prop(context.user_data.get("pr_simbolo"))
    await safe_edit_message_text(
        query, "✅ Configurazione Prop salvata con successo.",
        InlineKeyboardMarkup([back_button("config_prop")]),
    )
    return ConversationHandler.END

async def cfg_costo_reset_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    dati = await carica_dati_async()
    prop_avanzata = dati.get("prop_avanzata", {})
    costo_reset_attuale = prop_avanzata.get("costo_reset")
    msg = "🔄 Configura Prop\n\nInserisci il costo del reset prop ($):"
    if costo_reset_attuale is not None:
        try:
            msg += f"\n\n💰 Valore attuale: {float(costo_reset_attuale):.2f}$"
        except (ValueError, TypeError):
            pass
    msg += "\n\nValori accettati: maggiore di 0"
    cancel_kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Annulla", callback_data="annulla_costo_reset")]])
    await safe_edit_message_text(query, msg, cancel_kb)
    return CFG_PR_COSTO_RESET

async def ricevi_costo_reset_standalone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    val = _parse_positive_float(update.message.text)
    if val is None or val <= 0:
        cancel_kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Annulla", callback_data="annulla_costo_reset")]])
        await update.message.reply_text(
            "⚠️ Valore non valido. Inserisci un numero maggiore di 0.",
            reply_markup=cancel_kb,
        )
        return CFG_PR_COSTO_RESET

    def _update_costo_reset(d: dict) -> dict:
        if "prop_avanzata" not in d:
            d["prop_avanzata"] = {}
        d["prop_avanzata"]["costo_reset"] = val
        return d

    await modifica_dati_async(_update_costo_reset)
    await update.message.reply_text(f"✅ Costo reset Prop aggiornato: {val:.2f}$")
    await mostra_menu_principale(update, context)
    return ConversationHandler.END

# ========================= MENU CONFIG BROKER =========================
BROKER_WHITELIST: list = [
    {"id": "broker_fptrading", "label": "FPTrading", "match": ["fptrading"]},
    {"id": "broker_tmgm",      "label": "TMGM",      "match": ["trademaxglobal", "tmgm"]},
]

def _norm_broker(s: str) -> str:
    return "".join(c for c in (s or "").lower() if c.isalnum())

def _identifica_broker_whitelist(server_reale: str, company: str):
    """Ritorna il broker della whitelist a cui appartiene l'account (in base a
    server/company riportati da MT5), oppure None se non e' tra quelli consentiti."""
    chiave = _norm_broker(server_reale) + "|" + _norm_broker(company)
    for b in BROKER_WHITELIST:
        if any(_norm_broker(tok) in chiave for tok in b.get("match", [])):
            return b
    return None

async def menu_config_broker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    keyboard = [
        [InlineKeyboardButton("⚙️ Configura",   callback_data="cfg_broker_scelta")],
        [InlineKeyboardButton("🔍 Visualizza",  callback_data="vis_broker_av")],
        [InlineKeyboardButton("⬅️ Indietro",    callback_data="configura_op")],
    ]
    await safe_edit_message_text(query, "🏦 Configurazione Broker", InlineKeyboardMarkup(keyboard))

async def scegli_broker_whitelist(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    keyboard = [
        [InlineKeyboardButton(f"✅ {b['label']}", callback_data=f"set_broker|{b['id']}")]
        for b in BROKER_WHITELIST
    ]
    keyboard.append([InlineKeyboardButton("⬅️ Indietro", callback_data="config_broker")])
    await safe_edit_message_text(
        query,
        "🏦 Seleziona il broker:\n",
        InlineKeyboardMarkup(keyboard),
    )

async def salva_broker_whitelist(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    parts = query.data.split("|", 1)
    if len(parts) != 2:
        await ack(query, "Selezione non valida.", show_alert=True)
        return
    cb_id = parts[1]
    label = next((b["label"] for b in BROKER_WHITELIST if b["id"] == cb_id), None)
    if label is None:
        await ack(query, "Broker non autorizzato.", show_alert=True)
        return
    await ack(query)
    broker_config = {"name": label, "cb": cb_id}
    await modifica_dati_async(partial(modifier_set_key, key="broker_config", value=broker_config))
    await safe_edit_message_text(
        query, f"✅ Configurazione salvata con successo.\n\n🏦 Broker selezionato: {label}",
        InlineKeyboardMarkup([back_button("config_broker")]),
    )

async def vis_broker_av(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "⏳ Recupero dati broker in corso...")
    dati = await carica_dati_async()
    broker_config = dati.get("broker_config", {})
    broker_name   = broker_config.get("name", "Non configurato")
    info_b   = await info_account_async(MT5_BROKER_EXE)
    leva_acc = info_b.get("leverage", "N/D") if info_b else "N/D"
    leva_str = f"1:{leva_acc}" if isinstance(leva_acc, int) else str(leva_acc)
    leva_sym_str = leva_str
    msg = (
        f"🏦 Configurazione Broker\n\n"
        f"• Broker: {broker_name}\n"
        f"• Leva: {leva_str}\n"
        f"• Leva {SIMBOLO_BROKER}: {leva_sym_str}"
    )
    await safe_edit_message_text(query, msg, InlineKeyboardMarkup([back_button("config_broker")]))

async def vis_prop_av(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "⏳ Recupero configurazione Prop...")
    dati = await carica_dati_async()
    # NB: NON chiamare questa variabile "cfg": oscurerebbe l'alias del modulo
    # config (usato sotto come cfg.SIMBOLO_PROP) e autoflake arriverebbe pure
    # a rimuovere l'import "inutilizzato". Gia' successo: handler congelato
    # su "⏳" per AttributeError sul dict.
    cfg_prop = dati.get("prop_avanzata", {})
    if not cfg_prop:
        await safe_edit_message_text(
            query, "ℹ️ Nessuna configurazione Prop salvata.",
            InlineKeyboardMarkup([back_button("config_prop")]),
        )
        return
    modalita = str(cfg_prop.get("modalita", "sfida")).capitalize()

    def _money(key: str, default: float = 0.0) -> str:
        try:
            return f"{float(cfg_prop.get(key, default)):.2f}"
        except (TypeError, ValueError):
            return "N/D"

    def _perc(key: str) -> str:
        try:
            return f"{float(cfg_prop.get(key, 0)):.2f}"
        except (TypeError, ValueError):
            return str(cfg_prop.get(key, "N/D"))

    info_p   = await info_account_async(MT5_PROP_EXE)
    leva_acc = info_p.get("leverage", "N/D") if info_p else "N/D"
    leva_str = f"1:{leva_acc}" if isinstance(leva_acc, int) else str(leva_acc)

    riga_costo_reset = ""
    costo_reset_raw  = cfg_prop.get("costo_reset")
    if costo_reset_raw is not None:
        try:
            riga_costo_reset = f"• Costo reset prop: ${float(costo_reset_raw):.2f}\n"
        except (TypeError, ValueError):
            riga_costo_reset = f"• Costo reset prop: {costo_reset_raw}\n"

    # Società prop + simbolo abbinato (fallback al simbolo attivo se config vecchia).
    firm_label  = cfg_prop.get("prop_firm_label")
    simbolo_cfg = cfg_prop.get("simbolo", cfg.SIMBOLO_PROP)
    riga_prop   = (
        f"• Prop: {firm_label} (simbolo {simbolo_cfg})\n"
        if firm_label else f"• Simbolo: {simbolo_cfg}\n"
    )
    # Target a 0 (conti reali/funded) = nessun obiettivo.
    try:
        _target_vis = float(cfg_prop.get("target", 0) or 0)
    except (TypeError, ValueError):
        _target_vis = 0.0
    riga_target = (
        "• Target: nessun obiettivo\n"
        if _target_vis <= 0 else f"• Target: {_perc('target')}%\n"
    )

    msg = (
        "📊 Configurazione Prop\n\n"
        f"{riga_prop}"
        f"• Modalità: {modalita}\n"
        f"• Saldo di partenza: ${_money('saldo_partenza')}\n"
        f"{riga_target}"
        f"• Perdita massima: {_perc('dd_max_perc')}%\n"
        f"• Perdita massima giornaliera: {_perc('dd_daily_perc')}%\n"
        f"• Costo prop: ${_money('costo')}\n"
        f"{riga_costo_reset}"
        f"• Incasso se la prop viene bruciata: ${_incasso_corrente(dati):.2f}\n"
        f"• Tipologia di incasso: {cfg_prop.get('tip_incasso', 'N/D')}\n"
        f"• Tipologia di draw-down: {cfg_prop.get('tip_drawdown', 'N/D')}\n"
        f"• Consistenza: {_perc('consistenza')}%\n\n"
        f"• Leva: {leva_str}\n"
        f"• Leva {cfg.SIMBOLO_PROP}: {leva_str}"
    )
    await safe_edit_message_text(query, msg, InlineKeyboardMarkup([back_button("config_prop")]))
