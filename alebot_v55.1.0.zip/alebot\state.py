import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, Iterable, Optional

logger = logging.getLogger(__name__)

from .config import MEMO_CLEANUP_DAYS, MODALITA_DEFAULT
from .modalita import CHIAVE_MODALITA, ETICHETTE

# ========================= MODALITÀ OPERATIVA =========================
def modifier_set_modalita(d: dict, modalita: str) -> Optional[dict]:
    """Cambia la modalita' operativa (vedi alebot/modalita.py).

    Ritorna None se la modalita' e' gia' quella richiesta: cosi' un /modalita
    ripetuto non produce una scrittura su disco inutile.
    """
    if modalita not in ETICHETTE:
        return None
    attuale = d.get(CHIAVE_MODALITA) or MODALITA_DEFAULT
    if attuale == modalita:
        return None
    d[CHIAVE_MODALITA] = modalita
    return d

# ========================= SEMI-AUTOMATICA: OPERAZIONE IN CORSO =========================
# L'apertura semi-automatica e' fatta di attese UMANE: il bot dice cosa aprire,
# poi l'utente prende il telefono, apre MetaTrader, digita, torna sul bot. Puo'
# passare un minuto come dieci. Per questo l'operazione in corso NON vive nella
# conversazione Telegram (che scade dopo 5 minuti e muore a ogni riavvio del
# bot) ma qui, nello stato cifrato: sopravvive al timeout, al riavvio e persino
# a un aggiornamento OTA a meta' flusso.
SEMIAUTO_PENDING_KEY = "semiauto_pending"

def modifier_semiauto_put_pending(d: dict, pending: Dict[str, Any]) -> dict:
    d[SEMIAUTO_PENDING_KEY] = dict(pending)
    return d

def modifier_semiauto_update_pending(
    d: dict, pending_id: str, updates: Dict[str, Any],
) -> Optional[dict]:
    """Aggiorna l'operazione in corso SOLO se e' ancora quella attesa.

    Il controllo sull'id non e' pignoleria: l'utente puo' avere in chat il
    messaggio di un flusso vecchio e premerne i pulsanti. Senza questo
    confronto, un click su una schermata scaduta riscriverebbe l'operazione
    nuova.
    """
    corrente = d.get(SEMIAUTO_PENDING_KEY)
    if not isinstance(corrente, dict) or corrente.get("id") != pending_id:
        return None
    corrente = dict(corrente)
    corrente.update(updates)
    d[SEMIAUTO_PENDING_KEY] = corrente
    return d

def modifier_semiauto_clear_pending(d: dict, pending_id: Optional[str] = None) -> Optional[dict]:
    """Chiude l'operazione in corso. Con pending_id chiude solo quella."""
    corrente = d.get(SEMIAUTO_PENDING_KEY)
    if not isinstance(corrente, dict):
        return None
    if pending_id is not None and corrente.get("id") != pending_id:
        return None
    d.pop(SEMIAUTO_PENDING_KEY, None)
    return d

# ========================= SEMI-AUTOMATICA: PROP SCOPERTA =========================
# Caso peggiore della semi-automatica: la gamba BROKER si chiude (SL/TP) e
# quella PROP resta aperta. In automatica il bot la chiuderebbe in due secondi;
# qui non puo' — ha la sola lettura — quindi l'unica arma e' insistere con
# l'utente. Questo registro tiene il conto di quali posizioni sono scoperte e
# di quando e' partito l'ultimo sollecito, cosi' i solleciti sopravvivono ai
# riavvii e non diventano una raffica.
SEMIAUTO_ALERT_KEY = "semiauto_prop_scoperta"

def modifier_semiauto_alert_registra(
    d: dict, prop_ticket: int, broker_ticket: int, motivo: str, ora_iso: str,
) -> dict:
    reg = d.get(SEMIAUTO_ALERT_KEY) or {}
    chiave = str(int(prop_ticket))
    prec   = reg.get(chiave) if isinstance(reg.get(chiave), dict) else {}
    reg[chiave] = {
        "prop_ticket":   int(prop_ticket),
        "broker_ticket": int(broker_ticket or 0),
        "motivo":        motivo,
        "dal_utc":       prec.get("dal_utc") or ora_iso,
        "ultimo_utc":    ora_iso,
    }
    d[SEMIAUTO_ALERT_KEY] = reg
    return d

def modifier_semiauto_alert_rimuovi(d: dict, prop_ticket: int) -> Optional[dict]:
    reg = d.get(SEMIAUTO_ALERT_KEY) or {}
    chiave = str(int(prop_ticket))
    if chiave not in reg:
        return None
    del reg[chiave]
    d[SEMIAUTO_ALERT_KEY] = reg
    return d

def modifier_semiauto_alert_purga(d: dict, ticket_ancora_aperti: Iterable[int]) -> Optional[dict]:
    """Toglie dal registro le posizioni che NON risultano piu' aperte.

    Va chiamato solo con una fotografia CERTA delle posizioni prop: se MT5 non
    risponde, cancellare qui significherebbe smettere di sollecitare proprio
    mentre una posizione e' scoperta.
    """
    reg = d.get(SEMIAUTO_ALERT_KEY) or {}
    if not reg:
        return None
    vivi = {str(int(t)) for t in ticket_ancora_aperti}
    tenuti = {k: v for k, v in reg.items() if k in vivi}
    if len(tenuti) == len(reg):
        return None
    d[SEMIAUTO_ALERT_KEY] = tenuti
    return d

def modifier_save_trade_memo(d: dict, ticket_b: int, ticket_p: int, payload: Dict[str, Any]) -> dict:
    trade_memos = d.get("trade_memos", {})
    record = dict(payload)
    record["broker_ticket"] = ticket_b
    record["prop_ticket"]   = ticket_p
    trade_memos[str(ticket_b)] = record
    trade_memos[str(ticket_p)] = record
    d["trade_memos"] = trade_memos
    return d

def modifier_update_trade_memo(d: dict, ticket_b: int, ticket_p: int, updates: Dict[str, Any]) -> dict:
    trade_memos = d.get("trade_memos", {})

    # --- Accumulo del P/L BROKER realizzato (esatto, una sola volta per trade) ---
    # I due ticket (broker e prop) puntano allo STESSO trade logico, quindi
    # calcoliamo lo stato risultante UNA volta sola. Appena il deal di chiusura
    # broker (broker_close_info, write-once) e' disponibile e non e' ancora stato
    # contato, sommiamo il suo profit NETTO al contatore cumulato. Questo punto e'
    # attraversato da TUTTI i percorsi di chiusura (monitor, riconciliazione boot,
    # chiusura manuale, nightly), quindi copre ogni caso senza doppi conteggi.
    base = dict(trade_memos.get(str(ticket_b), trade_memos.get(str(ticket_p), {})))
    base.update(updates)
    extra: Dict[str, Any] = {}
    bci = base.get("broker_close_info")
    if bci and not base.get("broker_pl_counted"):
        try:
            profit = float(bci.get("profit", 0) or 0)
        except (TypeError, ValueError, AttributeError):
            profit = 0.0
        d["pl_broker_realizzato"] = float(d.get("pl_broker_realizzato", 0) or 0) + profit
        d["pl_broker_ultimo"]     = profit
        extra["broker_pl_counted"] = True

    for key in (str(ticket_b), str(ticket_p)):
        record = dict(trade_memos.get(key, {}))
        record.update(updates)
        if extra:
            record.update(extra)
        trade_memos[key] = record
    d["trade_memos"] = trade_memos
    return d

def modifier_aggiungi_costo_prop(d: dict, importo: float) -> dict:
    """Aggiunge un costo prop (acquisto o reset) al totale cumulato."""
    lst = d.get("costi_prop", [])
    lst.append({
        "data":    date.today().isoformat(),
        "importo": importo,
        "nota":    "",
    })
    d["costi_prop"] = lst
    return d

def modifier_set_pl_broker_iniziale(d: dict, valore: float) -> dict:
    """
    Imposta (sovrascrive) il P/L broker realizzato cumulato. Serve per il
    seeding su una nuova VPS/prop (es. 0 se parti pulito, oppure il valore
    storico attuale) o per correzioni manuali.
    """
    d["pl_broker_realizzato"] = float(valore)
    return d

def modifier_append_news_processed(d: dict, event_key: str) -> dict:
    processed = d.get("news_processed_events", [])
    if event_key not in processed:
        processed.append(event_key)
    d["news_processed_events"] = processed[-100:]
    return d

# ---- Apertura programmata (scheduled_trades) ----
def modifier_add_scheduled_trade(d: dict, trade: dict) -> dict:
    lst = d.get("scheduled_trades", [])
    lst.append(trade)
    d["scheduled_trades"] = lst
    return d

def modifier_remove_scheduled_trade(d: dict, trade_id: str) -> Optional[dict]:
    lst = d.get("scheduled_trades", [])
    nuovi = [t for t in lst if isinstance(t, dict) and t.get("id") != trade_id]
    if len(nuovi) == len(lst):
        return None
    d["scheduled_trades"] = nuovi
    return d

def modifier_set_scheduled_status(d: dict, trade_id: str, status: str) -> Optional[dict]:
    lst = d.get("scheduled_trades", [])
    changed = False
    for t in lst:
        if isinstance(t, dict) and t.get("id") == trade_id:
            t["status"] = status
            changed = True
    if not changed:
        return None
    d["scheduled_trades"] = lst
    return d

def modifier_cleanup_scheduled(d: dict) -> Optional[dict]:
    """Rimuove gli ordini programmati in stato terminale piu' vecchi di 1 giorno."""
    lst = d.get("scheduled_trades", [])
    if not lst:
        return None
    cutoff   = datetime.now(timezone.utc) - timedelta(days=1)
    terminal = {"done", "failed", "skipped", "cancelled"}
    kept = []
    for t in lst:
        if not isinstance(t, dict):
            continue
        if t.get("status") in terminal:
            try:
                created = datetime.fromisoformat(t.get("created_at_utc", ""))
                if created.tzinfo is None:
                    created = created.replace(tzinfo=timezone.utc)
                if created < cutoff:
                    continue  # scarta: terminale e vecchio
            except Exception:
                continue  # data illeggibile e terminale: scarta
        kept.append(t)
    if len(kept) == len(lst):
        return None
    d["scheduled_trades"] = kept
    return d

# ---- Trade minimo per giorno (challenge_trades: singolo, solo Prop) ----
def modifier_add_challenge_trade(d: dict, trade: dict) -> dict:
    lst = d.get("challenge_trades", [])
    lst.append(trade)
    d["challenge_trades"] = lst
    return d

def modifier_set_challenge_status(d: dict, trade_id: str, status: str) -> Optional[dict]:
    lst = d.get("challenge_trades", [])
    changed = False
    for t in lst:
        if isinstance(t, dict) and t.get("id") == trade_id:
            t["status"] = status
            changed = True
    if not changed:
        return None
    d["challenge_trades"] = lst
    return d

def modifier_chiudi_challenge_per_ticket(
    d: dict, tickets: Iterable[int], status: str = "closed",
) -> Optional[dict]:
    """Marca come chiusi i trade-sfida i cui ticket sono stati chiusi ALTROVE.

    Una chiusura di massa (serale, news, manuale) chiude TUTTE le posizioni sul
    simbolo, trade-sfida compreso, ma non ne conosceva lo stato: il record
    restava "open" e il backstop tentava all'infinito di richiudere un ticket
    ormai inesistente. Poiche' chiudi_posizione() ritorna False anche quando la
    posizione non c'e' piu', ne nasceva un avviso all'owner OGNI MINUTO, per
    sempre. Qui la chiusura di massa dichiara cosa ha chiuso e il ciclo si spezza.
    """
    lst = d.get("challenge_trades", [])
    if not lst:
        return None
    chiusi = {int(t) for t in tickets}
    if not chiusi:
        return None
    cambiato = False
    for t in lst:
        if not isinstance(t, dict) or t.get("status") not in ("open", "closing"):
            continue
        if int(t.get("prop_ticket", 0) or 0) in chiusi:
            t["status"] = status
            t["close_at_utc"] = t.get("close_at_utc") or datetime.now(timezone.utc).isoformat()
            cambiato = True
    if not cambiato:
        return None
    d["challenge_trades"] = lst
    return d

def modifier_reset_metriche_prop(d: dict) -> dict:
    """Azzera le metriche prop legate al CONTO (non ai guadagni cumulati).

    Va chiamato quando cambia l'account prop: il saldo di inizio giornata e il
    saldo massimo appartengono al conto PRECEDENTE e, se conservati, falsano la
    "Perdita giornaliera rimasta" sul conto nuovo — la metrica piu' delicata
    che il bot mostra. Alla prima lettura successiva si re-inizializzano dal
    conto attuale. NON tocca payout, costi prop e P/L cumulato: quelli sono il
    conteggio economico dell'utente, non del singolo conto.
    """
    d.pop("daily_start_date",    None)
    d.pop("daily_start_balance", None)
    d.pop("prop_massimo_saldo",  None)
    return d

def modifier_cleanup_challenge(d: dict) -> Optional[dict]:
    """Rimuove i trade-sfida in stato terminale piu' vecchi di 1 giorno."""
    lst = d.get("challenge_trades", [])
    if not lst:
        return None
    cutoff   = datetime.now(timezone.utc) - timedelta(days=1)
    terminal = {"closed", "cancelled", "failed"}
    kept = []
    for t in lst:
        if not isinstance(t, dict):
            continue
        if t.get("status") in terminal:
            try:
                ref = datetime.fromisoformat(t.get("close_at_utc") or t.get("opened_at_utc", ""))
                if ref.tzinfo is None:
                    ref = ref.replace(tzinfo=timezone.utc)
                if ref < cutoff:
                    continue
            except Exception:
                continue
        kept.append(t)
    if len(kept) == len(lst):
        return None
    d["challenge_trades"] = kept
    return d

def modifier_cleanup_old_memos(d: dict) -> Optional[dict]:
    """Rimuove i memo con chiusura completata piu' vecchia di MEMO_CLEANUP_DAYS."""
    memos = d.get("trade_memos", {})
    if not memos:
        return None
    cutoff = datetime.now(timezone.utc) - timedelta(days=MEMO_CLEANUP_DAYS)
    kept: Dict[str, Any] = {}
    removed = 0
    for k, v in memos.items():
        if not isinstance(v, dict):
            continue
        if not v.get("pair_closed_notified"):
            kept[k] = v
            continue
        closed_at = v.get("closed_at_utc")
        if not closed_at:
            kept[k] = v
            continue
        try:
            t = datetime.fromisoformat(closed_at)
            if t.tzinfo is None:
                t = t.replace(tzinfo=timezone.utc)
            if t > cutoff:
                kept[k] = v
            else:
                removed += 1
        except Exception:
            kept[k] = v
    if removed == 0:
        return None
    d["trade_memos"] = kept
    logger.info(f"Cleanup memo: rimossi {removed} record chiusi piu' vecchi di {MEMO_CLEANUP_DAYS}gg.")
    return d

def modifier_reset_pnl(d: dict) -> dict:
    """
    Reset completo del conteggio Guadagni/Perdite: azzera payout, P/L broker
    realizzato (cumulato e ultimo) e costi prop. Marca il timestamp di reset.

    Azzera anche le metriche prop del ciclo (giornaliere e saldo massimo): il
    reset si fa tipicamente quando si cambia conto prop / si inizia un nuovo
    ciclo, e i valori del conto precedente falserebbero i calcoli. Alla prima
    lettura successiva (info_account_prop_async) si re-inizializzano dal conto
    attuale: "Perdita giornaliera rimasta" riparte dal limite pieno configurato
    (dd_daily_perc * saldo_partenza / 100) e "Saldo massimo raggiunto" dal
    saldo corrente.
    """
    d["payouts"]              = []
    d["pl_broker_realizzato"] = 0.0
    d["pl_broker_ultimo"]     = 0.0
    d["costi_prop"]           = []
    d["pnl_reset_at"]         = datetime.now(timezone.utc).isoformat()
    d.pop("daily_start_date",   None)
    d.pop("daily_start_balance", None)
    d.pop("prop_massimo_saldo",  None)
    return d

def _inizio_ciclo_utc(dati: dict) -> Optional[datetime]:
    """Inizio del ciclo in corso = timestamp dell'ultimo 'Reset Guadagni/Perdite'
    (pnl_reset_at). Ritorna None se non e' mai stato fatto un reset o se il
    valore non e' leggibile: in quel caso i chiamanti usano il fallback 30gg."""
    raw = dati.get("pnl_reset_at")
    if not raw:
        return None
    try:
        t = datetime.fromisoformat(raw)
        return t.replace(tzinfo=timezone.utc) if t.tzinfo is None else t
    except Exception:
        return None
