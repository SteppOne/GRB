"""PATERNITA' DELLE POSIZIONI: il bot tocca solo cio' che ha aperto lui.

REGOLA DI FONDO: non esiste piu' un "chiudi tutto". Ogni posizione aperta dal
bot porta la sua firma — un magic number nello spazio riservato a questa
installazione — e viene registrata nei suoi archivi con un ticket preciso. Le
chiusure di massa (serale, news, pulsante "Chiudi trade") lavorano su
QUELL'ELENCO, non su "tutte le posizioni del simbolo".

PERCHE' — due motivi, uno di oggi e uno di domani.

  OGGI, il conto broker condiviso. Un cliente puo' far girare due bot su due VPS,
  due prop distinte, ma UN SOLO conto broker per la gamba di copertura. Il conto
  e' visto identico da entrambi, e prima ciascuno credeva che tutto cio' che vi
  trovava fosse roba sua:

    A) la chiusura di massa prendeva TUTTE le posizioni del simbolo. Il primo
       bot che scattava (la serale ha un orario casuale, quindi diverso per
       ognuno) chiudeva anche le gambe broker degli altri, che restavano con la
       PROP SCOPERTA — e il loro guardiano di coppia, trovando la gamba
       superstite, chiudeva pure quella. Trade chiusi a caso, su clienti diversi.

    B) il contatore dei magic partiva da 1000 su OGNI installazione: due bot
       generavano presto gli stessi numeri, e il controllo anti-duplicato del
       retry (`posizione_aperta_sync`) o il recovery del giornale
       (`_ticket_per_magic`) potevano adottare la posizione di un altro bot. Da
       li' in poi i memo puntavano a ticket sbagliati.

  DOMANI, l'apertura manuale sulla prop. Il piano e' che sul broker si apra
  sempre e solo dal bot, mentre sulla prop l'utente possa aprire anche a mano.
  Una posizione aperta a mano non ha la firma del bot e il bot NON deve
  chiudergliela: e' per questo che il filtro vale su ENTRAMBI i conti e non solo
  sul broker.

COME SI RICONOSCE UNA POSIZIONE PROPRIA — due criteri in OR, non uno solo:

  - il TICKET risulta nei registri del bot (memo, trade-sfida, giornale). E'
    questo che rende indolore l'aggiornamento: le posizioni gia' a mercato hanno
    ancora i magic vecchi, ma il bot se le ricorda perche' le ha aperte lui;
  - oppure il MAGIC cade nel blocco riservato a questa installazione. Copre le
    posizioni aperte ma non ancora registrate (crash tra l'ordine e il
    salvataggio del memo).

Il vecchio spazio 1000-99.999 NON conta come proprio: e' esattamente il numero
che tutti i bot generavano, e attribuirselo rimetterebbe in piedi il guasto B.

REGOLA D'ORO, la stessa del giornale: nel dubbio non si chiude. Una posizione
lasciata aperta la chiude chi l'ha aperta; una posizione chiusa per errore non
la riapre nessuno.
"""
import logging
from typing import Any, Iterable, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

# Alias del modulo e NON "from .config import MAGIC_BASE": cosi' esiste UN SOLO
# posto da cui i valori vengono letti (e da cui i test li possono spostare),
# invece di una copia congelata in ogni modulo che li importa.
from . import config as cfg

# Chiavi dello stato da cui si ricavano i ticket "noti" (vedi tickets_noti).
_CAMPI_TICKET_MEMO = ("broker_ticket", "prop_ticket", "ticket_broker", "ticket_prop")


# ========================= MAGIC =========================
def magic_e_mio(magic: Any) -> bool:
    """Il magic appartiene al blocco riservato a QUESTO bot?"""
    try:
        m = int(magic or 0)
    except (TypeError, ValueError):
        return False
    return cfg.MAGIC_BASE <= m < cfg.MAGIC_BASE + cfg.MAGIC_BLOCCO


def intervallo_magic() -> Tuple[int, int]:
    """(primo, ultimo+1) del blocco di questo bot."""
    return cfg.MAGIC_BASE, cfg.MAGIC_BASE + cfg.MAGIC_BLOCCO


def intervalli_magic_storico() -> List[Tuple[int, int]]:
    """Intervalli di magic da tenere quando si legge lo STORICO del broker.

    Il blocco di questo bot, piu' il vecchio spazio pre-numerazione (0-99.999).
    Quest'ultimo va incluso o l'aggiornamento cancellerebbe dallo storico tutti
    i trade chiusi PRIMA — che per la quasi totalita' dei clienti (conto broker
    dedicato) sono semplicemente i propri. Sui pochi conti condivisi qualche
    riga vecchia di troppo e' un prezzo molto piu' basso che nascondere
    all'utente meta' del suo storico.
    """
    return [(0, cfg.MAGIC_BLOCCO), intervallo_magic()]


# ========================= TICKET NOTI =========================
def _agg(dest: Set[int], valore: Any) -> None:
    try:
        t = int(valore or 0)
    except (TypeError, ValueError):
        return
    if t > 0:
        dest.add(t)


def tickets_noti(dati: Optional[dict]) -> Set[int]:
    """Tutti i ticket che questo bot SA essere suoi.

    Sorgenti: i memo dei trade (chiave del dizionario piu' i ticket delle due
    gambe), i trade-sfida sulla prop e gli intenti ancora aperti nel giornale
    transazionale. E' la rete che rende il passaggio a questa versione indolore
    per le posizioni gia' a mercato, che hanno ancora i magic vecchi.
    """
    noti: Set[int] = set()
    # Ogni sorgente e' verificata per tipo: da questo insieme dipende COSA IL BOT
    # CHIUDE, quindi un pezzo di stato malformato deve al massimo restringere la
    # lista, mai far saltare la funzione con un'eccezione.
    d = dati if isinstance(dati, dict) else {}

    memos = d.get("trade_memos")
    if isinstance(memos, dict):
        for chiave, rec in memos.items():
            _agg(noti, chiave)
            if isinstance(rec, dict):
                for campo in _CAMPI_TICKET_MEMO:
                    _agg(noti, rec.get(campo))

    sfide = d.get("challenge_trades")
    if isinstance(sfide, (list, tuple)):
        for t in sfide:
            if isinstance(t, dict):
                _agg(noti, t.get("prop_ticket"))

    giornale = d.get("op_journal")
    if isinstance(giornale, dict):
        for entry in giornale.values():
            if not isinstance(entry, dict):
                continue
            for campo in ("ticket", "ticket_broker", "ticket_prop"):
                _agg(noti, entry.get(campo))
            for campo in ("tickets_broker", "tickets_prop"):
                lista = entry.get(campo)
                if isinstance(lista, (list, tuple)):
                    for t in lista:
                        _agg(noti, t)

    return noti


def posizione_propria(posizione: dict, noti: Set[int]) -> bool:
    """La posizione e' stata aperta da questo bot? (ticket noto OPPURE magic mio)"""
    if not isinstance(posizione, dict):
        return False
    try:
        ticket = int(posizione.get("ticket", 0) or 0)
    except (TypeError, ValueError):
        ticket = 0
    if ticket and ticket in noti:
        return True
    return magic_e_mio(posizione.get("magic"))


# ========================= FILTRI =========================
def separa_posizioni(
    posizioni: Optional[Iterable[dict]], dati: Optional[dict],
) -> Tuple[List[dict], List[dict]]:
    """Divide uno snapshot in (mie, non mie). Vale su broker E su prop."""
    tutte = [p for p in (posizioni or []) if isinstance(p, dict)]
    noti = tickets_noti(dati)
    mie:    List[dict] = []
    altrui: List[dict] = []
    for p in tutte:
        (mie if posizione_propria(p, noti) else altrui).append(p)
    return mie, altrui


def solo_mie(posizioni: Optional[Iterable[dict]], dati: Optional[dict]) -> List[dict]:
    return separa_posizioni(posizioni, dati)[0]


def nota_altrui(n_broker: int, n_prop: int = 0) -> str:
    """Riga da accodare ai messaggi quando restano aperte posizioni non del bot.

    Va SEMPRE detto: "non ho chiuso tutto" e' la scelta corretta, ma l'utente
    deve saperlo — altrimenti apre il terminale, vede una posizione aperta e
    pensa che il bot abbia fallito una chiusura.
    """
    pezzi = []
    if n_broker > 0:
        pezzi.append(f"{n_broker} sul Broker")
    if n_prop > 0:
        pezzi.append(f"{n_prop} sulla Prop")
    if not pezzi:
        return ""
    coda = (
        "posizioni non aperte da questo bot: lasciate come sono."
        if n_broker + n_prop > 1 else
        "posizione non aperta da questo bot: lasciata com'è."
    )
    return f"\n\nℹ️ {' e '.join(pezzi)}, {coda}"
