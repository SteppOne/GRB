import logging
from datetime import datetime, timedelta, time as dt_time, timezone
from decimal import Decimal, ROUND_DOWN
from typing import Optional

from telegram import Update, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes,
)

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    INCASSO_DEFAULT,
    LOTTO_MINIMO,
    MARGINE_COPERTURA_BROKER,
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    RAPPORTO_LOTTO_INCASSO,
    SIMBOLO_BROKER,
)
from .broker_condiviso import nota_altrui, separa_posizioni
from .messaging import ack, back_button, safe_edit_message_text
from .storage import carica_dati_async, modifica_dati_async, modifier_incrementa_magic
from .mt5_async import _get_open_positions_snapshot_async
from .handlers_base import guard_auth

# ========================= MAGIC ATOMICO + LOTTI =========================
async def genera_magic() -> int:
    dati = await modifica_dati_async(modifier_incrementa_magic)
    return dati["next_magic"] - 1

def tronca_lotti(valore: float, step: str = "0.01") -> float:
    """Taglia il volume allo step del broker, SENZA arrotondare in su.

    Fino alla v55.0 si arrotondava per eccesso, perche' la formula puntava
    all'incasso esatto e uno scalino in piu' era il modo prudente di non
    restare mai sotto. Da quando i lotti si dimensionano col margine del 5%
    (MARGINE_COPERTURA_BROKER) quel cuscinetto c'e' gia', e arrotondare
    ancora in su lo raddoppierebbe: si taglia e basta.
    """
    d = Decimal(str(valore))
    q = Decimal(step)
    return float(d.quantize(q, rounding=ROUND_DOWN))

def _incasso_corrente(dati: dict) -> float:
    """Incasso configurato (incasso_target, o legacy incasso_se_bruciata).
    Se non configurato o non valido -> INCASSO_DEFAULT (630)."""
    pa = dati.get("prop_avanzata", {}) or {}
    try:
        v = float(pa.get("incasso_target", pa.get("incasso_se_bruciata", 0)) or 0)
    except (TypeError, ValueError):
        v = 0.0
    return v if v > 0 else INCASSO_DEFAULT

def divisore_incasso(dati: dict) -> float:
    """Divisore della formula dei lotti = PERDITA MASSIMA TOTALE in dollari.

    COS'E' DAVVERO IL "6000" DELLA v51: non una costante magica, ma la perdita
    massima totale di un conto da 100.000 al 6% (100.000 x 6% = 6000). Chi
    scrisse la v51 aveva quella prop in mente e ne congelo' il risultato.

    PERCHE' IL DIVISORE E' IL DD MASSIMO — la matematica dell'hedge:
      il broker e' opposto, quindi quando la prop perde, il broker guadagna:
          guadagno_broker = perdita_prop x (lotti_broker / lotti_prop)
      Nella griglia gli SL dei singoli step SOMMANO fino al DD massimo, quindi
      a prop bruciata:
          guadagno totale = DD_max x (incasso / DD_max) = incasso   ✓ esatto
      Con un divisore fisso a 6000 su una prop al 3% si aprivano META' dei
      lotti necessari e si incassava meta' del dovuto. La prova sul campo:
      i clienti con prop 100k al 6% non hanno mai avuto problemi, quelli
      passati alle prop 100k al 3% si sono lamentati tutti.

    Ricavato dalla configurazione prop che ogni cliente ha gia' inserito, cosi'
    si adatta da solo a qualsiasi taglio di conto e a qualsiasi regola:
      100k al 6% -> 6000 (identico a prima)   200k al 3% -> 6000
      100k al 3% -> 3000                       50k al 6% -> 3000
    Se la prop non e' configurata si torna al valore storico: nessuna
    regressione per chi non ha compilato quei campi.
    """
    pa = dati.get("prop_avanzata", {}) or {}
    try:
        saldo = float(pa.get("saldo_partenza", 0) or 0)
        ddmax = float(pa.get("dd_max_perc", 0) or 0)
    except (TypeError, ValueError):
        return float(RAPPORTO_LOTTO_INCASSO)
    divisore = saldo * ddmax / 100.0
    return divisore if divisore > 0 else float(RAPPORTO_LOTTO_INCASSO)

def calcola_lotti_broker(
    lotti_prop: float, incasso_target: float, divisore: Optional[float] = None,
) -> float:
    """lotti_broker = TRONCA( lotti_prop x (incasso / divisore) x 1.05 )

    `divisore` e' la perdita massima totale in dollari (vedi divisore_incasso).
    Omesso -> RAPPORTO_LOTTO_INCASSO, il valore storico.

    IL 5% (MARGINE_COPERTURA_BROKER): l'incasso teorico non e' quello che
    arriva in tasca. Sulla gamba broker si pagano spread, commissioni e swap
    su ogni operazione della griglia: dimensionare sull'incasso nudo significa
    incassare meno del configurato. Il margine copre quei costi, il
    troncamento evita di gonfiarlo ancora.

    IL CONTO SI FA IN DECIMAL, e l'ordine non e' un dettaglio: prima si
    MOLTIPLICA (operazioni esatte) e solo alla fine si DIVIDE. Con i float, un
    risultato come 0.49 puo' essere in realta' 0.48999999999999994, e il
    troncamento gli mangerebbe uno scalino intero: proprio l'errore nella
    direzione peggiore, quella che scopre l'hedge.
    """
    d = Decimal(str(divisore)) if divisore and float(divisore) > 0 else Decimal(str(RAPPORTO_LOTTO_INCASSO))
    esatto = (
        Decimal(str(lotti_prop))
        * Decimal(str(incasso_target))
        * Decimal(str(MARGINE_COPERTURA_BROKER))
    ) / d
    lotti = tronca_lotti(esatto, "0.01")
    # Con lotti prop piccolissimi il troncamento puo' arrivare a ZERO: un
    # ordine a volume 0 verrebbe rifiutato dal broker e la prop resterebbe
    # SCOPERTA. Il volume minimo negoziabile e' il pavimento: o si apre quello,
    # o non si copre affatto.
    return max(lotti, LOTTO_MINIMO)

def _time_in_range(now_t: dt_time, start: dt_time, end: dt_time) -> bool:
    if start <= end:
        return start <= now_t <= end
    return now_t >= start or now_t <= end

def _ora_italiana(dt_in: datetime) -> datetime:
    """Converte un datetime in ora italiana (Europe/Rome) gestendo l'ora legale.

    NON usa zoneinfo/tzdata (assente su Windows) ma applica la regola UE,
    deterministica e stabile: ora legale (CEST, UTC+2) dall'ultima domenica di
    marzo all'ultima domenica di ottobre (transizioni alle 01:00 UTC), altrimenti
    ora solare (CET, UTC+1). Ritorna un datetime naive in ora locale italiana,
    pensato solo per la visualizzazione.
    """
    if dt_in.tzinfo is None:
        dt_in = dt_in.replace(tzinfo=timezone.utc)
    dt_utc = dt_in.astimezone(timezone.utc)

    def _ultima_domenica(anno: int, mese: int) -> datetime:
        d = datetime(anno, mese, 31, 1, 0, tzinfo=timezone.utc)
        while d.weekday() != 6:   # 6 = domenica
            d -= timedelta(days=1)
        return d

    inizio_dst = _ultima_domenica(dt_utc.year, 3)
    fine_dst   = _ultima_domenica(dt_utc.year, 10)
    offset     = 2 if (inizio_dst <= dt_utc < fine_dst) else 1
    return (dt_utc + timedelta(hours=offset)).replace(tzinfo=None)

# ========================= STATO TRADE =========================
def _tipo_ita(t) -> str:
    return "Compra" if str(t).upper() == "BUY" else "Vendi"

def _fmt_sl_tp(v) -> str:
    """Prezzo SL/TP formattato, o 'non impostato' se assente (0)."""
    try:
        return f"{float(v):.2f}$" if float(v) else "non impostato"
    except (TypeError, ValueError):
        return "non impostato"

def _blocco_posizione(p: dict) -> str:
    return (
        f"• Tipo: {_tipo_ita(p.get('type'))}\n"
        f"• Lotti: {float(p.get('volume', 0)):.2f}\n"
        f"• SL: {_fmt_sl_tp(p.get('sl'))}\n"
        f"• TP: {_fmt_sl_tp(p.get('tp'))}\n"
        f"• Guadagno/Perdita attuale: {float(p.get('profit', 0)):+.2f}$"
    )

def _componi_stato_trade(
    pos_b: Optional[list], pos_p: Optional[list], trade_memos: Optional[dict] = None,
) -> str:
    """Costruisce il messaggio 'Stato Trade Manuale' (Prop prima, poi Broker)."""
    pos_b = pos_b or []
    pos_p = pos_p or []
    if not pos_b and not pos_p:
        return "ℹ️ Nessun trade aperto."
    rif = (pos_p or pos_b)[0]   # riferimento per Asset/Prezzo attuale: prima la Prop
    msg = "📋 Stato Trade Manuale\n\n"
    msg += f"• Asset: {rif.get('symbol', '—')}\n"
    prezzo = rif.get("price_current")
    if prezzo:
        msg += f"• Prezzo attuale: {float(prezzo):.2f}$\n"

    def _sezione(nome: str, posizioni: list) -> str:
        if not posizioni:
            return f"\n{nome}\n• Nessuna posizione aperta"
        blocchi = [f"\n{nome}"]
        for i, p in enumerate(posizioni):
            if i > 0:
                blocchi.append("")  # riga vuota tra piu' posizioni dello stesso conto
            blocchi.append(_blocco_posizione(p))
        return "\n".join(blocchi)

    msg += _sezione("Prop", pos_p)
    msg += "\n"
    msg += _sezione("Broker", pos_b)

    # Memo: nota scritta dall'utente all'apertura. E' la stessa per la coppia
    # Prop+Broker (salvata sotto entrambi i ticket); raccogliamo i memo distinti
    # delle posizioni aperte e li mostriamo come ultima riga.
    memos: list = []
    if trade_memos:
        for p in list(pos_p) + list(pos_b):
            rec  = trade_memos.get(str(p.get("ticket")), {}) or {}
            memo = (rec.get("memo") or "").strip()
            if memo and memo not in memos:
                memos.append(memo)
    if not memos:
        msg += "\n\n📝 Memo: —"
    elif len(memos) == 1:
        msg += f"\n\n📝 Memo: {memos[0]}"
    else:
        msg += "\n\n📝 Memo:\n" + "\n".join(f"• {m}" for m in memos)
    return msg

async def stato_trade(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)

    dati = await carica_dati_async()
    broker      = dati.get("broker")
    prop        = dati.get("prop")
    trade_memos = dati.get("trade_memos", {})

    if not broker or not prop:
        await safe_edit_message_text(
            query, "❌ Credenziali mancanti.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    pos_b = await _get_open_positions_snapshot_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    )
    pos_p = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if pos_b is None or pos_p is None:
        await safe_edit_message_text(
            query, "❌ Impossibile leggere le posizioni aperte.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    # Sul BROKER le posizioni di un altro bot non vanno mostrate come se fossero
    # dell'utente: si dichiara solo quante sono. La PROP si mostra intera —
    # li' cio' che il bot non ha aperto e' comunque dell'utente.
    pos_b, altrui_b = separa_posizioni(pos_b, dati)
    msg = _componi_stato_trade(pos_b, pos_p, trade_memos) + nota_altrui(len(altrui_b))
    await safe_edit_message_text(
        query, msg, InlineKeyboardMarkup([back_button("manuale")]),
    )

async def stato_trade_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    dati        = await carica_dati_async()
    broker      = dati.get("broker")
    prop        = dati.get("prop")
    trade_memos = dati.get("trade_memos", {})

    if not broker or not prop:
        await update.message.reply_text("❌ Credenziali mancanti.")
        return

    pos_b = await _get_open_positions_snapshot_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    )
    pos_p = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if pos_b is None or pos_p is None:
        await update.message.reply_text("❌ Impossibile leggere le posizioni aperte.")
        return

    # Sul BROKER le posizioni di un altro bot non vanno mostrate come se fossero
    # dell'utente: si dichiara solo quante sono. La PROP si mostra intera —
    # li' cio' che il bot non ha aperto e' comunque dell'utente.
    pos_b, altrui_b = separa_posizioni(pos_b, dati)
    msg = _componi_stato_trade(pos_b, pos_p, trade_memos) + nota_altrui(len(altrui_b))
    await update.message.reply_text(msg)
