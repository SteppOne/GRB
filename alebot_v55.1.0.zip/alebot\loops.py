﻿import asyncio
import logging
import os
import random
import time
from datetime import datetime, timedelta, timezone
from functools import partial
from typing import Any, Dict, Optional, Tuple

# Istante di avvio del PROCESSO bot: serve a non intervenire da soli sui
# terminali nei primi minuti, quando MT5 puo' ancora star sincronizzando.
_AVVIO_BOT_UTC = datetime.now(timezone.utc)

import psutil
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
)

logger = logging.getLogger(__name__)

from . import config as cfg
from . import news
from .config import (
    BOOT_RECONCILIATION_DELAY_SECONDS,
    BOT_LOCK_FILE,
    CLIENT_NOME,
    CLOSE_INFO_MAX_WAIT_MIN,
    ENTRY_SCRIPT_NAME,
    HEARTBEAT_FILE,
    HEARTBEAT_INTERVAL_SECONDS,
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    NEWS_BLACKOUT_MINUTES,
    NEWS_CLOSE_MINUTES_MAX,
    NEWS_CLOSE_MINUTES_MIN,
    NEWS_FEED_STALE_ALERT_MIN,
    NEWS_FETCH_FAIL_ALERT_STREAK,
    NEWS_REFRESH_SECONDS,
    NIGHT_CLOSE_END,
    NIGHT_CLOSE_START,
    PAIR_GUARD_SECONDS,
    PAIR_GUARD_SECONDS_FALLBACK,
    PROP_DAILY_BASELINE_SECONDS,
    SCHEDULED_LATE_GRACE_MINUTES,
    SCHEDULED_OPEN_CHECK_SECONDS,
    SEMIAUTO_ALERT_SECONDS,
    SEMIAUTO_PREAVVISI_MINUTI,
    SEMIAUTO_PREAVVISO_RITARDO_MAX_S,
    SIMBOLO_BROKER,
    TRADE_CLOSE_MONITOR_SECONDS,
    _attiva_simbolo_prop,
)
from .messaging import (
    _compose_trade_close_message,
    _kb_errore_ordine,
    _mark_trade_pair_closed,
    _trade_pair_key,
    back_button,
    notifica_owner,
)
from .storage import (
    _scrivi_owner_sidecar,
    carica_dati_async,
    data_lock,
    modifica_dati_async,
    modifier_set_key,
)
from .broker_condiviso import separa_posizioni
from .modalita import prop_sola_lettura, semiauto_attiva
from .subscription import _invia_canale_admin, subscription_loop
from .state import (
    SEMIAUTO_ALERT_KEY,
    SEMIAUTO_PENDING_KEY,
    modifier_append_news_processed,
    modifier_cleanup_challenge,
    modifier_cleanup_old_memos,
    modifier_cleanup_scheduled,
    modifier_semiauto_alert_purga,
    modifier_semiauto_alert_registra,
    modifier_semiauto_clear_pending,
    modifier_set_challenge_status,
    modifier_set_scheduled_status,
)
from .mt5_async import (
    _get_open_positions_snapshot_async,
    _mt5_timeout,
    autotrading_attivo_async,
    chiudi_posizione_async,
    get_position_by_ticket_async,
    get_position_close_info_async,
    info_account_prop_async,
)
from .news import (
    is_xauusd_relevant,
    news_event_key,
    scarica_eventi_news,
    serializza_eventi_news,
    trading_bloccato_ora_o_news,
)
from .mt5_sync import _mt5_disconnect
from .mt5_pool import pool
from .mass_close import chiudi_tutti_trade_aperti
from .hedge_journal import (
    JOURNAL_KEY,
    journal_put,
    journal_remove,
    journal_update,
    recover_journal,
)
from .fleet import conferma_ota_al_boot, segnala_rollback_al_boot
from .handlers_trade import _esegui_hedge
from .handlers_challenge import _chiudi_challenge, _close_challenge_after
from .semiauto_core import ALERT_BROKER_CHIUSO, ALERT_COPERTURA_KO, ALERT_DA_CHIUDERE
from .handlers_semiauto import (
    ST_ATTESA_MODIFICA,
    ST_COPERTURA_KO,
    ripristina_semiauto_al_boot,
)

# ========================= PROP SCOPERTA (semi-automatica) =========================
# In semi-automatica il bot NON puo' chiudere la gamba prop. Quando quella
# broker sparisce (SL/TP) la prop resta esposta al mercato e l'unica arma
# rimasta e' insistere con l'utente: un messaggio subito e poi uno ogni
# SEMIAUTO_ALERT_SECONDS finche' la posizione non e' chiusa davvero.
_TESTO_PROP_SCOPERTA = {
    ALERT_BROKER_CHIUSO: (
        "🚨 URGENTE: la posizione broker è stata chiusa!\n\n"
        "⚠️ La posizione prop è ora scoperta: chiudila SUBITO manualmente dal "
        "tuo MetaTrader.\n\n"
        "Ogni minuto di ritardo mette a rischio la strategia. Chiudi la "
        "posizione prop il prima possibile."
    ),
    ALERT_COPERTURA_KO: (
        "🚨 URGENTE: la posizione prop è SCOPERTA!\n\n"
        "⚠️ Non sono riuscito ad aprire la copertura sul broker: chiudi SUBITO "
        "la posizione prop dal tuo MetaTrader, oppure premi «Riprova copertura» "
        "nel messaggio precedente.\n\n"
        "Ogni minuto di ritardo mette a rischio la strategia."
    ),
    ALERT_DA_CHIUDERE: (
        "🚨 URGENTE: c'è una posizione prop da CHIUDERE!\n\n"
        "⚠️ Era stata avviata una chiusura che non posso portare a termine "
        "(la Prop è in sola lettura): chiudila SUBITO dal tuo MetaTrader.\n\n"
        "Ogni minuto di ritardo mette a rischio la strategia."
    ),
}
# Ogni quanto si CONTROLLA se una prop scoperta e' stata chiusa. Il sollecito
# vero e proprio resta a SEMIAUTO_ALERT_SECONDS: questo e' solo il battito con
# cui si guarda il mercato (e con cui si smette di sollecitare appena l'utente
# ha chiuso, senza fargli arrivare un messaggio ormai inutile).
SEMIAUTO_ALERT_TICK_SECONDS = 30


def _alert_da_inviare(record: Optional[Dict[str, Any]], adesso: datetime) -> bool:
    """E' ora di (ri)mandare il sollecito per questa posizione scoperta?"""
    if not record or not record.get("ultimo_utc"):
        return True                      # mai avvisato: si parte subito
    try:
        ultimo = datetime.fromisoformat(record["ultimo_utc"])
        if ultimo.tzinfo is None:
            ultimo = ultimo.replace(tzinfo=timezone.utc)
    except Exception:
        return True
    return (adesso - ultimo).total_seconds() >= SEMIAUTO_ALERT_SECONDS


async def segnala_prop_scoperta(
    app: Application, prop_ticket: int, broker_ticket: int = 0,
    motivo: str = ALERT_BROKER_CHIUSO,
) -> bool:
    """Registra (o rinnova) l'emergenza 'prop scoperta' e avvisa se e' ora.

    Ritorna True se il messaggio e' stato inviato. Idempotente: puo' essere
    chiamata dal guardiano ogni due secondi senza trasformarsi in una raffica.
    """
    dati   = await carica_dati_async()
    reg    = dati.get(SEMIAUTO_ALERT_KEY) or {}
    record = reg.get(str(int(prop_ticket)))
    adesso = datetime.now(timezone.utc)
    if not _alert_da_inviare(record if isinstance(record, dict) else None, adesso):
        return False
    await modifica_dati_async(partial(
        modifier_semiauto_alert_registra,
        prop_ticket=int(prop_ticket), broker_ticket=int(broker_ticket or 0),
        motivo=motivo, ora_iso=adesso.isoformat(),
    ))
    await notifica_owner(
        app, _TESTO_PROP_SCOPERTA.get(motivo, _TESTO_PROP_SCOPERTA[ALERT_BROKER_CHIUSO]),
        reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
    )
    return True


async def _semiauto_alert_tick(app: Application) -> None:
    """UN giro del sollecitatore e della manutenzione semi-automatica.

    Due mestieri, un solo giro di MT5 perche' guardano la stessa cosa (quali
    posizioni prop sono ancora aperte):
      • i SOLLECITI sulle posizioni scoperte, e la loro fine;
      • la chiusura dell'operazione in corso quando la posizione prop non c'e'
        piu'. Senza, un trade concluso a mercato lascerebbe il flusso "appeso"
        e la regola "un trade alla volta" bloccherebbe per sempre le aperture
        successive.
    """
    dati    = await carica_dati_async()
    reg     = dati.get(SEMIAUTO_ALERT_KEY) or {}
    pending = dati.get(SEMIAUTO_PENDING_KEY)
    pending = pending if isinstance(pending, dict) else {}
    # Solo gli stati con denaro GIA' a mercato: quello di attesa apertura ha la
    # sua scadenza e non va toccato qui.
    pending_ticket = (
        int(pending.get("prop_ticket", 0) or 0)
        if pending.get("stato") in (ST_ATTESA_MODIFICA, ST_COPERTURA_KO) else 0
    )
    if not reg and not pending_ticket:
        return
    prop = dati.get("prop")
    if not prop or not all(prop.get(k) for k in ("id", "password", "server")):
        return
    snap = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if snap is None:
        return          # MT5 incerto: non si smette di sollecitare al buio
    aperti = {int(p["ticket"]) for p in snap if isinstance(p, dict)}
    chiusi = [int(k) for k in reg.keys() if int(k) not in aperti]
    if chiusi:
        # L'utente ha chiuso: i solleciti finiscono qui. La ricevuta con i due
        # P/L la manda il monitor di chiusura, come per ogni altro trade.
        logger.info(f"Semiauto: posizioni prop {chiusi} ora chiuse, solleciti terminati.")
        await modifica_dati_async(partial(
            modifier_semiauto_alert_purga, ticket_ancora_aperti=sorted(aperti),
        ))
    if pending_ticket and pending_ticket not in aperti:
        logger.info(
            f"Semiauto: la posizione prop {pending_ticket} non e' piu' aperta, "
            f"chiudo l'operazione in corso."
        )
        await modifica_dati_async(partial(
            modifier_semiauto_clear_pending, pending_id=pending.get("id"),
        ))
    adesso = datetime.now(timezone.utc)
    for chiave, record in reg.items():
        if not isinstance(record, dict) or int(chiave) not in aperti:
            continue
        if _alert_da_inviare(record, adesso):
            await segnala_prop_scoperta(
                app, int(chiave), int(record.get("broker_ticket", 0) or 0),
                record.get("motivo", ALERT_BROKER_CHIUSO),
            )


async def semiauto_alert_loop(app: Application):
    while True:
        try:
            if await semiauto_attiva():
                await _semiauto_alert_tick(app)
        except Exception:
            logger.exception("semiauto_alert_loop: errore (riprovo al prossimo giro).")
        await asyncio.sleep(SEMIAUTO_ALERT_TICK_SECONDS)

# ========================= LOOPS =========================
async def prop_daily_baseline_loop(app: Application):
    """Aggancia il saldo di INIZIO GIORNATA della prop (daily_start_balance) poco
    dopo la mezzanotte del server prop, INDIPENDENTEMENTE dal fatto che l'utente
    apra Info Prop o dal canale da cui parte un trade.

    Perche' serve: prima il saldo di inizio giornata veniva fotografato SOLO alla
    prima lettura prop del giorno (Info Prop o controllo SL in apertura manuale).
    Se un trade PROGRAMMATO apriva e chiudeva (SL/TP) PRIMA che l'utente
    guardasse, la fotografia veniva presa DOPO, sul saldo gia' mosso: quel P/L
    del giorno NON entrava nel conteggio e la 'Perdita giornaliera rimasta'
    restava ferma a PPP anche dopo uno stop loss. Questo loop forza la cattura
    poco dopo la mezzanotte server, riusando info_account_prop_async, che al
    cambio data persiste daily_start_balance/daily_start_date. Solo lettura:
    nessuna azione di trading."""
    while True:
        try:
            dati = await carica_dati_async()
            # "cfg_prop" e NON "cfg": la locale oscurerebbe l'alias del modulo config.
            cfg_prop = dati.get("prop_avanzata") or {}
            cred = dati.get("prop") or {}
            if cfg_prop and cred.get("id") and cred.get("password") and cred.get("server"):
                # La lettura, al primo giro del nuovo giorno server, aggancia e
                # PERSISTE il saldo di inizio giornata (vedi info_account_prop_async).
                await info_account_prop_async(MT5_PROP_EXE, cfg_prop)
        except Exception:
            logger.exception("prop_daily_baseline_loop: errore (ignorato, riprovo al prossimo giro).")
        await asyncio.sleep(PROP_DAILY_BASELINE_SECONDS)

def durata_finestra_chiusura() -> int:
    """Ampiezza in secondi della finestra di chiusura serale (22:45 -> 23:00).

    Il calcolo e' in modulo 24 ore e non una sottrazione diretta: cosi' la
    finestra si puo' spostare anche a cavallo della mezzanotte senza che il
    risultato diventi negativo (con la sottrazione diretta e il vecchio
    max(...,1) la finestra sarebbe collassata a UN SECONDO, e tutti i bot
    avrebbero chiuso allo stesso istante spaccato).
    """
    inizio = NIGHT_CLOSE_START.hour * 3600 + NIGHT_CLOSE_START.minute * 60 + NIGHT_CLOSE_START.second
    fine   = NIGHT_CLOSE_END.hour   * 3600 + NIGHT_CLOSE_END.minute   * 60 + NIGHT_CLOSE_END.second
    return (fine - inizio) % 86400 or 1

def pianifica_chiusura_serale(
    now: datetime, finestra_gia_eseguita: Optional[datetime] = None,
) -> Tuple[datetime, datetime]:
    """(inizio_finestra, istante_di_chiusura) per la prossima chiusura serale.

    L'orario preciso e' CASUALE dentro la finestra: nessun pattern riconoscibile
    dalla prop, e due bot dello stesso cliente non chiudono mai insieme.

    Tre casi:

      1) siamo DENTRO una finestra ancora da onorare (il bot si e' riavviato
         alle 22:50) -> si estrae un istante tra ADESSO e la fine. Prima il bot
         rimandava alla sera dopo e le posizioni restavano aperte tutta la notte;
      2) siamo dentro una finestra GIA' onorata -> si salta alla successiva,
         altrimenti il bot programmerebbe una seconda chiusura nella stessa
         finestra;
      3) siamo fuori finestra -> istante casuale nella prossima.

    'finestra_gia_eseguita' e' l'inizio dell'ultima finestra gia' servita.
    """
    durata = durata_finestra_chiusura()

    inizio_corrente = datetime.combine(now.date(), NIGHT_CLOSE_START)
    if inizio_corrente > now:
        inizio_corrente -= timedelta(days=1)   # la finestra e' iniziata IERI sera
    fine_corrente = inizio_corrente + timedelta(seconds=durata)

    if now < fine_corrente and inizio_corrente != finestra_gia_eseguita:
        restanti = int((fine_corrente - now).total_seconds())
        return inizio_corrente, now + timedelta(seconds=random.randint(0, max(restanti, 0)))

    inizio_prossimo = datetime.combine(now.date(), NIGHT_CLOSE_START)
    if inizio_prossimo <= now:
        inizio_prossimo += timedelta(days=1)
    return inizio_prossimo, inizio_prossimo + timedelta(seconds=random.randint(0, durata))

# ========================= PREAVVISI (semi-automatica) =========================
# In semi-automatica il bot non chiude nulla ne' la sera ne' prima di una
# notizia: chiuderebbe solo la gamba broker e lascerebbe la prop scoperta,
# cioe' il contrario di cio' che serve. Quindi AVVISA, due volte, e lascia
# fare all'utente. Il momento e' scelto in modo da dargli tempo materiale di
# prendere il telefono.

async def _dormi_fino_a(istante: datetime) -> None:
    await asyncio.sleep(max(0.0, (istante - datetime.now()).total_seconds()))


def _preavviso_ancora_utile(istante: datetime) -> bool:
    """Un preavviso ha senso solo vicino al suo istante.

    Se il bot riparte alle 22:50 non deve sparare in fila i preavvisi delle
    22:15 e delle 22:30: sono passati, e l'utente riceverebbe due messaggi che
    lo mandano fuori strada."""
    return (datetime.now() - istante).total_seconds() <= SEMIAUTO_PREAVVISO_RITARDO_MAX_S


async def _c_e_qualcosa_da_chiudere() -> bool:
    """Vale la pena disturbare l'utente? (posizioni aperte sui due conti)

    Sulla PROP conta QUALSIASI posizione: in semi-automatica le apre lui, e
    anche una che il bot non conosce va chiusa prima di una notizia. Sul
    BROKER contano solo le proprie. Nel dubbio (MT5 muto) si avvisa: un
    messaggio di troppo costa meno di un trade lasciato aperto su un NFP.
    """
    dati = await carica_dati_async()
    for chiave, exe, simbolo, solo_mie in (
        ("prop",   MT5_PROP_EXE,   cfg.SIMBOLO_PROP, False),
        ("broker", MT5_BROKER_EXE, SIMBOLO_BROKER,   True),
    ):
        cred = dati.get(chiave)
        if not cred or not all(cred.get(k) for k in ("id", "password", "server")):
            continue
        snap = await _get_open_positions_snapshot_async(
            exe, int(cred["id"]), cred["password"], cred["server"], simbolo,
        )
        if snap is None:
            return True
        if solo_mie:
            snap = separa_posizioni(snap, dati)[0]
        if snap:
            return True
    return False


async def _avvisa_di_chiudere_a_mano(
    app: Application, titolo: str, dettaglio: str, minuti: int,
) -> None:
    if not await _c_e_qualcosa_da_chiudere():
        logger.info(f"Preavviso semi-automatica ({titolo}): nessuna posizione aperta, soppresso.")
        return
    testo = f"{titolo} tra ~{minuti} minuti"
    if dettaglio:
        testo += f"\n{dettaglio}"
    testo += (
        "\n\n⚠️ In modalità semi-automatica il bot NON chiude nulla: chiuderebbe "
        "solo la gamba broker, sbilanciando l'hedge.\n\n"
        "👉 Chiudi tutti i trade dal tuo MetaTrader."
    )
    await notifica_owner(app, testo, reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]))


async def nightly_close_loop(app: Application):
    finestra_eseguita: Optional[datetime] = None
    while True:
        now = datetime.now()
        inizio_finestra, target = pianifica_chiusura_serale(now, finestra_eseguita)
        logger.info(
            f"Chiusura serale pianificata alle {target.strftime('%d/%m %H:%M:%S')} "
            f"(finestra {NIGHT_CLOSE_START.strftime('%H:%M')}-{NIGHT_CLOSE_END.strftime('%H:%M')})"
        )
        # I preavvisi si valutano al RISVEGLIO, non adesso: la modalita' puo'
        # cambiare durante l'attesa (che dura ore).
        for anticipo in sorted(SEMIAUTO_PREAVVISI_MINUTI, reverse=True):
            istante = target - timedelta(minutes=int(anticipo))
            await _dormi_fino_a(istante)
            if _preavviso_ancora_utile(istante) and await semiauto_attiva():
                await _avvisa_di_chiudere_a_mano(
                    app, "🌙 Chiusura serale",
                    "La sessione di mercato sta per terminare.", int(anticipo),
                )
        await _dormi_fino_a(target)
        # Marcata PRIMA di eseguire: se la chiusura fallisce non si deve
        # ripianificare un secondo giro nella stessa notte (ci pensa il giornale
        # a ritentare le singole chiusure rimaste indietro).
        finestra_eseguita = inizio_finestra
        if await semiauto_attiva():
            logger.info(
                "Chiusura serale: modalità semi-automatica, nessuna chiusura "
                "automatica (sono partiti i preavvisi)."
            )
            continue
        try:
            n_closed, riepilogo = await chiudi_tutti_trade_aperti(
                nota_chiusura="La sessione di mercato sta per terminare.",
            )
            if n_closed > 0:
                await notifica_owner(
                    app, f"🌙 Chiusura serale\n\n{riepilogo}",
                    reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
                )
            else:
                logger.info("Chiusura serale: nessun trade aperto, notifica soppressa.")
        except Exception:
            logger.exception("Errore nella chiusura serale automatica.")

# Fetch del feed news falliti CONSECUTIVI (si azzera al primo successo).
_news_fetch_fail_streak: int = 0

async def _avvisa_news_degradate(app: Application, testo: str, tipo: str = "stale") -> None:
    """Avvisa il canale admin che la protezione news e' degradata, al massimo
    UNA volta al giorno (de-dup persistente). Nei soli log l'allarme passava
    inosservato: il 10-11/6/2026 il feed e' rimasto fermo ~24h senza che
    nessuno se ne accorgesse.

    Il de-dup e' PER TIPO di guasto: "feed fermo" e "non riesco a scaricare"
    sono problemi diversi, con cause e rimedi diversi. Con una chiave sola, il
    primo che scattava zittiva l'altro per tutta la giornata.
    """
    oggi   = datetime.now(timezone.utc).date().isoformat()
    chiave = f"news_alert_day_{tipo}"
    dati   = await carica_dati_async()
    if dati.get(chiave) == oggi:
        return
    await modifica_dati_async(partial(modifier_set_key, key=chiave, value=oggi))
    await _invia_canale_admin(app.bot, f"⚠️ {CLIENT_NOME}: {testo}")

async def _news_preavvisi_semiauto(
    app: Application, eventi: list, processed: set, now_utc: datetime,
) -> None:
    """Preavvisi news in semi-automatica: uno a ~30 min, uno a ~15 min.

    Il de-dup riusa la lista degli eventi gia' processati, con una chiave per
    soglia: cosi' i due avvisi partono una volta ciascuno e sopravvivono ai
    riavvii del bot, esattamente come la chiusura automatica.
    """
    soglia_finale = min(int(m) for m in SEMIAUTO_PREAVVISI_MINUTI)
    for ev in eventi:
        minuti = (ev["time"] - now_utc).total_seconds() / 60.0
        if minuti > max(int(m) for m in SEMIAUTO_PREAVVISI_MINUTI):
            continue
        k        = news_event_key(ev)
        currency = ev.get("currency", "")
        title    = ev.get("title", "")
        for anticipo in sorted((int(m) for m in SEMIAUTO_PREAVVISI_MINUTI), reverse=True):
            if minuti > anticipo:
                continue
            chiave = f"{k}|semi{anticipo}"
            if chiave in processed:
                continue
            logger.info(
                f"News monitor (semi-automatica): [{currency}] '{title}' tra "
                f"{minuti:.1f} min, preavviso {anticipo} min."
            )
            await _avvisa_di_chiudere_a_mano(
                app, "📰 Notizia ad alto impatto su XAUUSD",
                f"{currency} | {title}", max(1, int(round(minuti))),
            )
            await modifica_dati_async(partial(modifier_append_news_processed, event_key=chiave))
            processed.add(chiave)
            # Col preavviso piu' vicino scatta anche il blocco delle NUOVE
            # aperture, come fa la chiusura automatica: quello che il bot puo'
            # ancora impedire, lo impedisce.
            if anticipo == soglia_finale:
                blackout_until = ev["time"] + timedelta(minutes=NEWS_BLACKOUT_MINUTES)
                await modifica_dati_async(partial(
                    modifier_set_key, key="news_blackout_until", value=blackout_until.isoformat(),
                ))
        break   # un evento alla volta: e' sempre il primo in ordine di tempo


async def news_monitor_loop(app: Application):
    global _news_fetch_fail_streak
    while True:
        try:
            eventi  = await asyncio.to_thread(scarica_eventi_news)
            if eventi is None:
                # Fallimento tecnico di TUTTE le sorgenti: NON azzerare la cache.
                # Il blocco aperture continua a basarsi sull'ultimo calendario noto.
                logger.warning("News: fetch fallito, mantengo l'ultimo calendario noto.")
                _news_fetch_fail_streak += 1
                if _news_fetch_fail_streak >= NEWS_FETCH_FAIL_ALERT_STREAK:
                    ore = _news_fetch_fail_streak * NEWS_REFRESH_SECONDS / 3600.0
                    await _avvisa_news_degradate(
                        app,
                        f"non riesco a scaricare il feed news da ~{ore:.1f} ore. "
                        "La protezione news usa l'ultimo calendario noto. "
                        "Controlla la VPS (rete) o l'URL del feed.",
                        tipo="fetch",
                    )
                await asyncio.sleep(NEWS_REFRESH_SECONDS)
                continue
            _news_fetch_fail_streak = 0
            # Feed scaricato ma STANTIO (fetcher GitHub fermo): avviso giornaliero.
            eta_feed = news._news_feed_eta_min
            if eta_feed is not None and eta_feed > NEWS_FEED_STALE_ALERT_MIN:
                await _avvisa_news_degradate(
                    app,
                    f"il feed news centrale è FERMO da {eta_feed / 60.0:.1f} ore. "
                    "La protezione news sta usando un calendario vecchio. "
                    "Controlla GitHub → repo news → tab Actions (run falliti o cron fermo).",
                    tipo="stale",
                )
            now_utc = datetime.now(timezone.utc)
            eventi_rilevanti = [
                ev for ev in eventi
                if ev["time"] > now_utc and is_xauusd_relevant(ev)
            ]
            eventi_da_mostrare = serializza_eventi_news(eventi_rilevanti[:5])
            await modifica_dati_async(partial(modifier_set_key, key="news_events", value=eventi_da_mostrare))

            dati = await carica_dati_async()
            processed = set(dati.get("news_processed_events", []))

            # In semi-automatica non si chiude: si avvisa (due volte) e si
            # lascia agire l'utente. Il resto del ciclo — cache eventi, blackout
            # sulle nuove aperture — resta identico.
            if await semiauto_attiva():
                await _news_preavvisi_semiauto(app, eventi_rilevanti, processed, now_utc)
                await asyncio.sleep(NEWS_REFRESH_SECONDS)
                continue

            for ev in eventi_rilevanti:
                ev_time = ev["time"]
                minuti  = (ev_time - now_utc).total_seconds() / 60.0
                if minuti > NEWS_CLOSE_MINUTES_MAX:
                    continue
                k = news_event_key(ev)
                if k in processed:
                    continue
                if minuti > NEWS_CLOSE_MINUTES_MIN:
                    delay_sec = random.randint(0, int(max(1, (minuti - NEWS_CLOSE_MINUTES_MIN) * 60)))
                else:
                    delay_sec = 0
                # CAP: evita di bloccarsi piu' a lungo del ciclo di refresh
                delay_sec = min(delay_sec, NEWS_REFRESH_SECONDS - 5)
                currency = ev.get("currency", "")
                title    = ev.get("title", "")
                logger.info(
                    f"News monitor: [{currency}] '{title}' tra {minuti:.1f} min "
                    f"(rilevante per XAUUSD), chiusura tra {delay_sec} sec."
                )
                await asyncio.sleep(delay_sec)
                n_closed, riepilogo = await chiudi_tutti_trade_aperti()
                if n_closed > 0:
                    header = f"📰 News XAUUSD — trade chiusi\n{currency} | {title}\n"
                    await notifica_owner(
                        app, f"{header}tra ~{int(minuti)} min\n\n{riepilogo}",
                        reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
                    )
                else:
                    logger.info(
                        f"News monitor: evento '{title}' rilevato ma nessun trade "
                        f"aperto. Notifica soppressa; evento marcato come processato."
                    )
                blackout_until = ev_time + timedelta(minutes=NEWS_BLACKOUT_MINUTES)
                await modifica_dati_async(
                    partial(modifier_set_key, key="news_blackout_until", value=blackout_until.isoformat())
                )
                await modifica_dati_async(partial(modifier_append_news_processed, event_key=k))
                break
        except Exception:
            logger.exception("Errore nel monitor news.")
        await asyncio.sleep(NEWS_REFRESH_SECONDS)

async def trade_close_monitor_loop(app: Application):
    while True:
        try:
            dati        = await carica_dati_async()
            trade_memos = dati.get("trade_memos", {})
            broker      = dati.get("broker")
            prop        = dati.get("prop")
            if not trade_memos or not broker or not prop:
                await asyncio.sleep(TRADE_CLOSE_MONITOR_SECONDS)
                continue
            seen_pairs = set()
            for record in list(trade_memos.values()):
                if not isinstance(record, dict):
                    continue
                pair_key = _trade_pair_key(record)
                if pair_key in seen_pairs:
                    continue
                seen_pairs.add(pair_key)
                broker_ticket = int(record.get("broker_ticket", 0) or 0)
                prop_ticket   = int(record.get("prop_ticket", 0) or 0)
                if broker_ticket <= 0 or prop_ticket <= 0:
                    continue
                if record.get("pair_closed_notified"):
                    continue

                if record.get("broker_close_info") and record.get("prop_close_info"):
                    broker_open, prop_open = None, None
                    skip_mt5 = True
                else:
                    skip_mt5 = False

                if not skip_mt5:
                    broker_open = await get_position_by_ticket_async(
                        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], broker_ticket,
                    )
                    await asyncio.sleep(0.3)
                    prop_open = await get_position_by_ticket_async(
                        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], prop_ticket,
                    )
                    await asyncio.sleep(0.3)

                # Con la hedge i due lati hanno SL/TP a prezzi simmetrici:
                # quando un lato chiude per TP/SL, l'altro chiude (quasi) nello
                # stesso istante. Quindi se ANCHE UN SOLO lato e' sparito dalle
                # posizioni attive, tentiamo di leggere il deal di chiusura su
                # ENTRAMBI i lati. L'estrazione su una posizione ancora aperta e'
                # innocua: ritorna None perche' in history non c'e' un deal di
                # uscita per quel ticket.
                some_side_closed = skip_mt5 or (not broker_open) or (not prop_open)

                updates: Dict[str, Any] = {}
                if some_side_closed:
                    if not record.get("broker_close_info"):
                        broker_close_info = await get_position_close_info_async(
                            MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
                            broker_ticket, record.get("opened_at_utc"),
                        )
                        await asyncio.sleep(0.3)
                        if broker_close_info:
                            updates["broker_close_info"] = broker_close_info
                    if not record.get("prop_close_info"):
                        prop_close_info = await get_position_close_info_async(
                            MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
                            prop_ticket, record.get("opened_at_utc"),
                        )
                        await asyncio.sleep(0.3)
                        if prop_close_info:
                            updates["prop_close_info"] = prop_close_info

                current_record = dict(record); current_record.update(updates)
                broker_info = current_record.get("broker_close_info")
                prop_info   = current_record.get("prop_close_info")
                if updates:
                    await _mark_trade_pair_closed(broker_ticket, prop_ticket, updates)

                # Notifichiamo appena UN lato risulta chiuso E ne abbiamo il deal
                # di chiusura confermato in history (have_any_info). Quest'ultimo
                # requisito evita falsi positivi quando MT5 e' irraggiungibile:
                # in quel caso get_position_by_ticket_async ritorna None (sembra
                # "chiuso") ma non avremmo alcun close_info reale da mostrare.
                have_any_info = bool(broker_info) or bool(prop_info)
                if some_side_closed and have_any_info and not current_record.get("pair_closed_notified"):
                    # HEDGE SCOPERTO: una gamba e' chiusa per DAVVERO (close_info reale
                    # in history) ma l'ALTRA e' ANCORA APERTA -> la chiudo SUBITO al
                    # mercato. I due broker hanno feed di prezzo diversi: gli SL/TP
                    # simmetrici non scattano sempre insieme, quindi NON ci si puo'
                    # affidare all'auto-chiusura della seconda gamba.
                    # Il GUARDIANO DI COPPIA (ogni 2s) e' molto piu' rapido di
                    # questo monitor (60s) e, quando interviene, lascia il suo
                    # intento "surv-<ticket>" nel giornale finche' non ha
                    # finito. Se e' al lavoro sulla stessa gamba, il monitor si
                    # tira indietro: altrimenti i due manderebbero all'owner
                    # due messaggi diversi per lo stesso evento — e, nel caso
                    # peggiore, due ordini di chiusura sovrapposti.
                    journal_ora = (await carica_dati_async()).get(JOURNAL_KEY) or {}
                    guardiano_su = {
                        int(e.get("ticket", 0) or 0)
                        for e in journal_ora.values()
                        if isinstance(e, dict) and e.get("kind") == "close_survivor"
                    }
                    gamba_forzata = None
                    # In semi-automatica la prop non si tocca: se e' lei a
                    # restare aperta si passa ai solleciti (vedi
                    # segnala_prop_scoperta) e si aspetta l'utente.
                    attesa_utente = False
                    if broker_ticket in guardiano_su or prop_ticket in guardiano_su:
                        logger.info(
                            f"Monitor chiusura: pair Broker={broker_ticket}/"
                            f"Prop={prop_ticket} gia' in carico al guardiano di "
                            f"coppia, non intervengo."
                        )
                        await asyncio.sleep(0.2)
                        continue
                    if prop_info and broker_open:
                        logger.warning(f"Hedge scoperto: chiudo BROKER {broker_ticket} (prop gia' chiusa).")
                        if await chiudi_posizione_async(
                            MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], broker_ticket,
                        ):
                            await asyncio.sleep(0.3)
                            broker_open = None
                            gamba_forzata = "Broker"
                            nuovo = await get_position_close_info_async(
                                MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
                                broker_ticket, current_record.get("opened_at_utc"),
                            )
                            if not nuovo:
                                # I fill della chiusura appena inviata potrebbero non
                                # essere ancora tutti in history: un solo retry breve.
                                await asyncio.sleep(2.0)
                                nuovo = await get_position_close_info_async(
                                    MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
                                    broker_ticket, current_record.get("opened_at_utc"),
                                )
                            if nuovo:
                                broker_info = nuovo
                                current_record["broker_close_info"] = nuovo
                                await _mark_trade_pair_closed(broker_ticket, prop_ticket, {"broker_close_info": nuovo})
                    elif broker_info and prop_open and await prop_sola_lettura():
                        logger.warning(
                            f"Hedge scoperto (semi-automatica): la PROP {prop_ticket} "
                            f"resta aperta e non posso chiuderla. Sollecito l'utente."
                        )
                        await segnala_prop_scoperta(
                            app, prop_ticket, broker_ticket, ALERT_BROKER_CHIUSO,
                        )
                        attesa_utente = True
                    elif broker_info and prop_open:
                        logger.warning(f"Hedge scoperto: chiudo PROP {prop_ticket} (broker gia' chiuso).")
                        if await chiudi_posizione_async(
                            MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], prop_ticket,
                        ):
                            await asyncio.sleep(0.3)
                            prop_open = None
                            gamba_forzata = "Prop"
                            nuovo = await get_position_close_info_async(
                                MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
                                prop_ticket, current_record.get("opened_at_utc"),
                            )
                            if not nuovo:
                                # Vedi sopra: history potenzialmente in ritardo di un attimo.
                                await asyncio.sleep(2.0)
                                nuovo = await get_position_close_info_async(
                                    MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
                                    prop_ticket, current_record.get("opened_at_utc"),
                                )
                            if nuovo:
                                prop_info = nuovo
                                current_record["prop_close_info"] = nuovo
                                await _mark_trade_pair_closed(broker_ticket, prop_ticket, {"prop_close_info": nuovo})

                    ancora_aperto = bool(broker_open) or bool(prop_open)
                    if ancora_aperto and attesa_utente:
                        # Semi-automatica: la palla e' all'utente e i solleciti
                        # sono gia' partiti. La coppia resta NON notificata: la
                        # ricevuta arrivera' quando la prop sara' chiusa davvero.
                        logger.info(
                            f"Monitor chiusura: pair Broker={broker_ticket}/Prop={prop_ticket} "
                            f"in attesa che l'utente chiuda la Prop (semi-automatica)."
                        )
                    elif ancora_aperto:
                        # Chiusura forzata NON riuscita: non marcare la coppia come
                        # chiusa, cosi' il monitor RIPROVA al prossimo ciclo. Avvisa
                        # l'owner una sola volta (flag hedge_orfano_avvisato).
                        if not current_record.get("hedge_orfano_avvisato"):
                            lato = "BROKER" if broker_open else "PROP"
                            await notifica_owner(
                                app,
                                f"⚠️ ATTENZIONE: la gamba {lato} non si e' chiusa (hedge scoperto). "
                                f"Riprovo automaticamente ogni minuto; se persiste, chiudila a mano.",
                                reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
                            )
                            await _mark_trade_pair_closed(
                                broker_ticket, prop_ticket, {"hedge_orfano_avvisato": True},
                            )
                    elif not (broker_info and prop_info):
                        # Entrambe le gambe sono FLAT ma il deal di chiusura di un
                        # lato non e' ancora leggibile in history: i due server MT5
                        # (broker e prop) la scrivono con qualche secondo di
                        # sfasamento, oppure il fill e' ancora parziale. NOTIFICARE
                        # ORA stamperebbe "n/d" su quel lato e, con il write-once
                        # 'pair_closed_notified', lo congelerebbe PER SEMPRE. Quindi
                        # NON notifico e NON marco: il close_info gia' letto e' stato
                        # persistito sopra, al prossimo giro (~60s) leggo solo quello
                        # mancante e invio la ricevuta COMPLETA. Salvaguardia: se dopo
                        # CLOSE_INFO_MAX_WAIT_MIN il lato resta illeggibile, notifico
                        # comunque (con n/d) per non lasciare l'owner senza ricevuta.
                        lato_mancante = "Prop" if not prop_info else "Broker"
                        first_seen = current_record.get("close_info_pending_since")
                        if not first_seen:
                            first_seen = datetime.now(timezone.utc).isoformat()
                            await _mark_trade_pair_closed(
                                broker_ticket, prop_ticket,
                                {"close_info_pending_since": first_seen},
                            )
                        try:
                            atteso_min = (
                                datetime.now(timezone.utc)
                                - datetime.fromisoformat(first_seen)
                            ).total_seconds() / 60.0
                        except Exception:
                            atteso_min = 0.0
                        if atteso_min >= CLOSE_INFO_MAX_WAIT_MIN:
                            logger.warning(
                                f"Monitor chiusura: close_info {lato_mancante} per pair "
                                f"Broker={broker_ticket}/Prop={prop_ticket} illeggibile da "
                                f"{atteso_min:.0f} min: notifico comunque (lato n/d)."
                            )
                            close_msg = _compose_trade_close_message(
                                current_record, broker_info, prop_info, trigger_label="automaticamente",
                            )
                            if gamba_forzata:
                                close_msg += (
                                    f"\n\nℹ️ La gamba {gamba_forzata} era rimasta aperta: "
                                    "l'ho chiusa automaticamente per mantenere l'hedge."
                                )
                            await notifica_owner(
                                app, close_msg,
                                reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
                            )
                            await _mark_trade_pair_closed(
                                broker_ticket, prop_ticket,
                                {
                                    "pair_closed_notified": True,
                                    "closed_source":        "monitor",
                                    "closed_at_utc":        datetime.now(timezone.utc).isoformat(),
                                },
                            )
                        else:
                            logger.info(
                                f"Monitor chiusura: pair Broker={broker_ticket}/Prop={prop_ticket} "
                                f"flat ma manca il close_info {lato_mancante}: rimando la notifica "
                                f"(in attesa da {atteso_min:.1f} min)."
                            )
                    else:
                        logger.info(
                            f"Monitor chiusura: pair Broker={broker_ticket}/Prop={prop_ticket} "
                            f"chiuso (forzata={gamba_forzata})."
                        )
                        close_msg = _compose_trade_close_message(
                            current_record, broker_info, prop_info, trigger_label="automaticamente",
                        )
                        if gamba_forzata:
                            close_msg += (
                                f"\n\nℹ️ La gamba {gamba_forzata} era rimasta aperta: "
                                "l'ho chiusa automaticamente per mantenere l'hedge."
                            )
                        await notifica_owner(
                            app, close_msg,
                            reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
                        )
                        await _mark_trade_pair_closed(
                            broker_ticket, prop_ticket,
                            {
                                "pair_closed_notified": True,
                                "closed_source":        "monitor",
                                "closed_at_utc":        datetime.now(timezone.utc).isoformat(),
                            },
                        )
                await asyncio.sleep(0.2)
        except Exception:
            logger.exception("Errore nel monitor delle chiusure trade.")
        await asyncio.sleep(TRADE_CLOSE_MONITOR_SECONDS)

# ========================= GUARDIANO DI COPPIA =========================
# I feed di prezzo di broker e prop NON sono identici: il TP scatta su un
# lato e lo SL "gemello" sull'altro puo' mancare il livello per pochi
# centesimi. La gamba superstite resta a mercato e PERDE soldi veri finche'
# qualcuno non la chiude. Il monitor storico interveniva entro ~60s; questo
# guardiano, coi worker sempre connessi, controlla ogni pochi SECONDI e
# chiude subito la superstite. Il monitor resta il "contabile" (ricevute,
# P/L, memo); il guardiano e' il riflesso.

async def _pair_guard_tick(app: Application) -> None:
    """UN giro del guardiano (estratto dal loop per i test)."""
    dati        = await carica_dati_async()
    broker      = dati.get("broker")
    prop        = dati.get("prop")
    trade_memos = dati.get("trade_memos", {}) or {}
    if not broker or not prop or not trade_memos:
        return

    # Coppie vive (registrate e non ancora notificate come chiuse).
    vivi, visti = [], set()
    for record in trade_memos.values():
        if not isinstance(record, dict) or record.get("pair_closed_notified"):
            continue
        tb = int(record.get("broker_ticket", 0) or 0)
        tp = int(record.get("prop_ticket", 0) or 0)
        if tb <= 0 or tp <= 0 or (tb, tp) in visti:
            continue
        visti.add((tb, tp))
        vivi.append((tb, tp))
    if not vivi:
        return                    # nessuna coppia aperta: ZERO chiamate MT5

    # Ticket gia' in mano a una chiusura pianificata (manuale/serale/news):
    # il giornale fa da coordinamento, il guardiano non deve intromettersi.
    # DUE insiemi separati, non uno solo: broker e prop sono conti diversi e i
    # numeri di ticket possono coincidere. Mescolandoli, una chiusura di massa
    # sul broker disattivava per caso la protezione sulla gamba prop.
    journal = dati.get(JOURNAL_KEY) or {}
    in_chiusura = {"broker": set(), "prop": set()}
    for e in journal.values():
        if isinstance(e, dict) and e.get("kind") == "close_pairs":
            for lato, chiave in (("broker", "tickets_broker"), ("prop", "tickets_prop")):
                in_chiusura[lato].update(int(t) for t in (e.get(chiave) or []))

    snap_b, snap_p = await asyncio.gather(
        _get_open_positions_snapshot_async(
            MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
            SIMBOLO_BROKER),
        _get_open_positions_snapshot_async(
            MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
            cfg.SIMBOLO_PROP),
    )
    if snap_b is None or snap_p is None:
        return                    # MT5 non certo: MAI chiudere alla cieca
    aperti_b = {int(p["ticket"]) for p in snap_b if isinstance(p, dict)}
    aperti_p = {int(p["ticket"]) for p in snap_p if isinstance(p, dict)}

    sola_lettura = await prop_sola_lettura()

    for tb, tp in vivi:
        b_open, p_open = tb in aperti_b, tp in aperti_p
        if b_open == p_open:
            continue              # coppia integra, o gia' tutta chiusa
        if tb in in_chiusura["broker"] or tp in in_chiusura["prop"]:
            continue              # chiusura pianificata gia' in corso
        # ── SEMI-AUTOMATICA: la superstite e' la PROP ────────────────────────
        # Qui il guardiano non ha le chiavi: la prop e' in sola lettura e un
        # ordine di chiusura verrebbe rifiutato dal server. L'unica cosa utile
        # che puo' fare e' suonare l'allarme, subito e poi ogni 5 minuti,
        # finche' l'utente non chiude dal telefono.
        if p_open and sola_lettura:
            logger.warning(
                f"Guardiano hedge (semi-automatica): gamba Prop {tp} SUPERSTITE. "
                f"Non posso chiuderla (sola lettura): sollecito l'utente."
            )
            await segnala_prop_scoperta(app, tp, tb, ALERT_BROKER_CHIUSO)
            continue
        lato    = "broker" if b_open else "prop"
        etich   = "Broker" if b_open else "Prop"
        ticket  = tb if b_open else tp
        path    = MT5_BROKER_EXE if b_open else MT5_PROP_EXE
        cred    = broker if b_open else prop

        # Intento su disco PRIMA di agire: id deterministico (surv-<ticket>),
        # cosi' i tick successivi non creano duplicati e un crash a meta'
        # viene completato dal recovery del giornale.
        entry_id = f"surv-{ticket}"
        gia = journal.get(entry_id)
        if gia is None:
            await journal_put(entry_id, kind="close_survivor", lato=lato,
                              ticket=ticket, pair=[tb, tp])
        logger.warning(
            f"Guardiano hedge: gamba {etich} {ticket} SUPERSTITE "
            f"(l'altra e' chiusa), la chiudo subito."
        )
        chiuso = False
        for _ in range(2):
            chiuso = await chiudi_posizione_async(
                path, int(cred["id"]), cred["password"], cred["server"], ticket,
            )
            if chiuso:
                break
            await asyncio.sleep(0.5)
        if chiuso:
            await journal_remove(entry_id)
            await notifica_owner(app, (
                f"⚡ PROTEZIONE HEDGE: la gamba {etich} (ticket {ticket}) era "
                f"rimasta APERTA dopo la chiusura dell'altra gamba — l'ho "
                f"RICHIUSA immediatamente.\n"
                f"La ricevuta con i P/L dei due lati arriva tra poco."
            ))
        else:
            if not (gia or {}).get("alerted"):
                await notifica_owner(app, (
                    f"‼️ PROTEZIONE HEDGE: la gamba {etich} (ticket {ticket}) e' "
                    f"rimasta aperta e NON riesco a chiuderla. Riprovo ogni "
                    f"pochi secondi; se persiste chiudila a mano dal terminale."
                ))
            await journal_update(entry_id, alerted=True)


# ========================= SALUTE DEI TERMINALI =========================
# Quando un terminale rifiuta l'autenticazione piu' volte di fila (caso tipico:
# MT5 si aggiorna, riparte e chiede la password del conto — quella salvata non
# vale piu'), mt5_sync lo mette in QUARANTENA e smette di martellarlo. Senza un
# avviso, pero', l'owner vede solo un bot che "non fa piu' niente" e non ha
# modo di capire perche'. Questo loop traduce la quarantena in un messaggio
# che dice esattamente cosa fare — e uno solo, non uno al minuto.
TERMINALI_HEALTH_SECONDS = 120

# ---------------------------- RECUPERO AUTOMATICO ----------------------------
# Riavviare un terminale da soli significa UCCIDERE un processo che potrebbe
# stare lavorando. Si fa solo quando e' l'unica cosa che puo' funzionare, e
# solo se TUTTE le guardie qui sotto sono soddisfatte. In caso di dubbio: non
# si tocca niente e si avvisa l'owner. Meglio un intervento manuale in piu'
# che un terminale ucciso a sproposito.
AUTO_RECOVERY_DOPO_MINUTI   = 6    # guasto ininterrotto da almeno N minuti
AUTO_RECOVERY_COOLDOWN_MIN  = 30   # mai due tentativi ravvicinati
AUTO_RECOVERY_MAX_AL_GIORNO = 3    # oltre, e' un problema che va guardato a mano
AUTO_RECOVERY_UPTIME_MIN    = 5    # non nei primi minuti di vita del bot

_auto_recovery_ultimo: Dict[str, float] = {}


def _modifier_conta_auto_recovery(d: dict, chiave: str, giorno: str) -> dict:
    rec = d.get("auto_recovery_mt5") or {}
    if rec.get("giorno") != giorno:
        rec = {"giorno": giorno}
    rec[chiave] = int(rec.get(chiave, 0) or 0) + 1
    d["auto_recovery_mt5"] = rec
    return d


def _auto_recovery_oggi(dati: dict, chiave: str, giorno: str) -> int:
    rec = dati.get("auto_recovery_mt5") or {}
    if rec.get("giorno") != giorno:
        return 0
    try:
        return int(rec.get(chiave, 0) or 0)
    except (TypeError, ValueError):
        return 0


def _terminale_e_acceso(exe_path: str) -> Optional[bool]:
    """Il processo del terminale esiste? True/False, None se non verificabile.

    E' la guardia PIU' IMPORTANTE. Se il processo NON c'e', potremmo essere in
    piena finestra di auto-aggiornamento di MT5 (nei log reali: il terminale
    esce, l'updater lavora ~27 secondi, poi riparte da solo). Lanciarlo li' in
    mezzo significherebbe correre contro l'updater e ritrovarsi due istanze che
    litigano sulla stessa porta. Si interviene SOLO su un processo vivo che non
    risponde: e' esattamente il caso della finestra password bloccata.
    """
    nome = os.path.basename(exe_path).lower()
    cartella = os.path.dirname(exe_path).lower()
    try:
        for proc in psutil.process_iter(["name", "exe"]):
            try:
                if (proc.info["name"] or "").lower() != nome:
                    continue
                exe = (proc.info["exe"] or "").lower()
                if exe and exe.startswith(cartella):
                    return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return False
    except Exception:
        logger.exception("_terminale_e_acceso: verifica non riuscita")
        return None


async def _valuta_auto_recovery(app: Application, etichetta: str, exe_path: str,
                                stato: Dict[str, Any]) -> None:
    """Decide se riavviare da solo un terminale muto. Ogni 'return' e' una
    guardia: si arriva in fondo solo se l'intervento e' davvero l'unica strada."""
    chiave = etichetta.lower()

    # 1) Il guasto dev'essere PERSISTENTE, non un intoppo di passaggio.
    if stato.get("secondi_di_guasto", 0) < AUTO_RECOVERY_DOPO_MINUTI * 60:
        return

    # 2) Se il terminale risponde ma RIFIUTA le credenziali, riavviarlo e'
    #    inutile: serve una password nuova, e l'owner e' gia' stato avvisato.
    if stato.get("credenziali_rifiutate"):
        return

    # 3) Il bot dev'essere avviato da un po' (all'avvio i terminali possono
    #    ancora essere in fase di sincronizzazione).
    if (datetime.now(timezone.utc) - _AVVIO_BOT_UTC).total_seconds() < AUTO_RECOVERY_UPTIME_MIN * 60:
        return

    # 4) Il processo del terminale deve ESISTERE (vedi _terminale_e_acceso).
    acceso = await asyncio.to_thread(_terminale_e_acceso, exe_path)
    if acceso is not True:
        logger.info(
            f"Auto-recovery {etichetta}: processo del terminale assente o non "
            f"verificabile: NON intervengo (potrebbe essere un aggiornamento MT5 in corso)."
        )
        return

    # 5) Nessuna operazione a mercato in volo: il giornale dev'essere vuoto.
    #    Uccidere un terminale mentre si apre un hedge sarebbe il danno peggiore.
    dati = await carica_dati_async()
    if dati.get(JOURNAL_KEY):
        logger.warning(
            f"Auto-recovery {etichetta}: c'e' un'operazione in corso nel giornale, rimando."
        )
        return

    # 6) Credenziali disponibili: senza, il terminale ripartirebbe di nuovo
    #    sulla finestra di login e non avremmo risolto niente.
    cred = dati.get(chiave)
    if not cred or not all(cred.get(k) for k in ("id", "password", "server")):
        return

    # 7) Cooldown e tetto giornaliero.
    ultimo = _auto_recovery_ultimo.get(exe_path, 0.0)
    if ultimo and (time.monotonic() - ultimo) < AUTO_RECOVERY_COOLDOWN_MIN * 60:
        return
    giorno = datetime.now(timezone.utc).date().isoformat()
    if _auto_recovery_oggi(dati, chiave, giorno) >= AUTO_RECOVERY_MAX_AL_GIORNO:
        logger.warning(
            f"Auto-recovery {etichetta}: raggiunto il tetto di "
            f"{AUTO_RECOVERY_MAX_AL_GIORNO} tentativi per oggi, mi fermo."
        )
        return

    # ---- Tutte le guardie superate: si interviene. ----
    _auto_recovery_ultimo[exe_path] = time.monotonic()
    await modifica_dati_async(partial(
        _modifier_conta_auto_recovery, chiave=chiave, giorno=giorno,
    ))
    minuti = stato.get("secondi_di_guasto", 0) // 60
    logger.warning(
        f"Auto-recovery {etichetta}: terminale acceso ma muto da {minuti} min, "
        f"lo riavvio con le credenziali salvate."
    )
    await notifica_owner(app, (
        f"🔧 Terminale {etichetta} bloccato da {minuti} minuti: lo sto "
        f"riavviando automaticamente.\n\n"
        f"Ripartirà già collegato al conto giusto. Nessuna operazione era in "
        f"corso, quindi non c'è alcun rischio per i trade."
    ))

    from .handlers_system import riavvia_terminale   # lazy: handlers_system usa loops
    dir_path = os.path.dirname(exe_path)
    try:
        ok, motivo = await riavvia_terminale(dir_path, exe_path, cred)
    except Exception:
        logger.exception(f"Auto-recovery {etichetta}: riavvio fallito con eccezione.")
        ok, motivo = False, "errore imprevisto durante il riavvio"
    if ok:
        await notifica_owner(app, (
            f"✅ Terminale {etichetta}: risolto da solo, connessione ripristinata.\n"
            f"Non devi fare nulla."
        ))
    else:
        await notifica_owner(app, (
            f"❌ Terminale {etichetta}: il riavvio automatico NON ha risolto.\n"
            f"Motivo: {motivo}\n\n"
            f"👉 Serve un intervento sulla VPS. Non riproverò da solo prima di "
            f"{AUTO_RECOVERY_COOLDOWN_MIN} minuti."
        ))


async def terminali_health_loop(app: Application):
    gia_avvisato: Dict[str, bool] = {}
    while True:
        await asyncio.sleep(TERMINALI_HEALTH_SECONDS)
        for etichetta, exe in (("Broker", MT5_BROKER_EXE), ("Prop", MT5_PROP_EXE)):
            try:
                stato = await _mt5_timeout(
                    pool.exec(exe, "stato_sessione_sync", exe, timeout=10),
                    f"stato_sessione({etichetta})", timeout=15,
                )
                if not isinstance(stato, dict):
                    continue
                in_quarantena = bool(stato.get("in_quarantena"))
                if in_quarantena and not gia_avvisato.get(exe):
                    gia_avvisato[exe] = True
                    conto  = stato.get("login") or "?"
                    motivo = str(stato.get("motivo") or "")
                    rifiutato = "rifiutato" in motivo.lower()
                    testo = (
                        f"⚠️ Terminale {etichetta}: non riesco ad autenticarmi "
                        f"sul conto {conto}.\n\n"
                    )
                    if rifiutato:
                        testo += (
                            "Il terminale è ACCESO ma il login viene RIFIUTATO: "
                            "quasi sempre significa che la password di quel conto "
                            "è cambiata (succede dopo un aggiornamento di MT5, che "
                            "cancella la password salvata).\n\n"
                            "👉 Aggiornala da:\n"
                            "⚙️ Configura Operatività → 🔑 Gestisci Credenziali\n\n"
                            "Riavviare il terminale NON risolve."
                        )
                    else:
                        testo += (
                            "Il terminale non risponde: probabilmente è chiuso "
                            "o bloccato su una finestra di login.\n\n"
                            "👉 Prova: 🔧 Diagnosi → "
                            f"{'🏦' if etichetta == 'Broker' else '📊'} {etichetta} → 🔄 Riavvia"
                        )
                    testo += (
                        "\n\nℹ️ Nel frattempo il bot resta REATTIVO e non apre "
                        "nuove operazioni su questo conto: nessun rischio di "
                        "ordini alla cieca."
                    )
                    await notifica_owner(app, testo)
                elif not in_quarantena and gia_avvisato.get(exe):
                    gia_avvisato[exe] = False
                    await notifica_owner(
                        app, f"✅ Terminale {etichetta}: connessione ripristinata.",
                    )

                # Guasto che dura: valuta se riavviare il terminale da soli.
                # Tutte le guardie sono dentro _valuta_auto_recovery, che nel
                # caso normale (terminale sano) esce alla prima riga.
                if in_quarantena:
                    await _valuta_auto_recovery(app, etichetta, exe, stato)
            except Exception:
                logger.exception(f"terminali_health_loop ({etichetta}): errore ignorato.")


async def pair_guard_loop(app: Application):
    intervallo = PAIR_GUARD_SECONDS if pool.enabled else PAIR_GUARD_SECONDS_FALLBACK
    logger.info(f"Guardiano di coppia attivo (controllo ogni {intervallo}s).")
    while True:
        try:
            await _pair_guard_tick(app)
        except Exception:
            logger.exception("pair_guard_loop: errore (riprovo al prossimo giro).")
        await asyncio.sleep(intervallo)


async def scheduled_open_loop(app: Application):
    """
    Esegue gli ordini ad apertura programmata (scheduled_trades) all'orario
    indicato. Politiche (scelte dall'owner):
      - orario interpretato in ORA LOCALE (gia' convertito in UTC alla creazione);
      - se il bot torna online entro SCHEDULED_LATE_GRACE_MINUTES dall'orario apre,
        oltre salta e avvisa;
      - se il trading e' bloccato (fascia di blocco aperture o blackout news)
        salta e avvisa;
      - persistente: gli ordini sopravvivono al riavvio del bot.
    """
    # Pulizia all'avvio: ordini lasciati in "firing" da un riavvio a meta'
    # esecuzione non vanno ritentati (rischio doppia apertura). Avvisa l'owner.
    try:
        dati = await carica_dati_async()
        for t in list(dati.get("scheduled_trades", [])):
            if isinstance(t, dict) and t.get("status") == "firing":
                await modifica_dati_async(
                    partial(modifier_set_scheduled_status, trade_id=t.get("id", ""), status="failed")
                )
                await notifica_owner(
                    app,
                    f"⚠️ Apertura programmata interrotta da un riavvio del bot "
                    f"(orario {t.get('scheduled_for_local', '?')}). "
                    f"Verifica manualmente se la posizione è stata aperta."
                )
    except Exception:
        logger.exception("scheduled_open_loop: errore nella pulizia 'firing' iniziale.")

    # Re-arm dei timer di chiusura trade-sfida persi a un riavvio: i trade gia'
    # scaduti vengono chiusi subito, quelli futuri ottengono un nuovo timer
    # preciso. Eventuali "closing" (crash a meta' chiusura) tornano "open".
    try:
        dati = await carica_dati_async()
        for t in list(dati.get("challenge_trades", [])):
            if not isinstance(t, dict):
                continue
            if t.get("status") == "closing":
                await modifica_dati_async(
                    partial(modifier_set_challenge_status, trade_id=t.get("id", ""), status="open")
                )
            if t.get("status") not in ("open", "closing"):
                continue
            try:
                close_at = datetime.fromisoformat(t["close_at_utc"])
                if close_at.tzinfo is None:
                    close_at = close_at.replace(tzinfo=timezone.utc)
            except Exception:
                continue
            remaining = (close_at - datetime.now(timezone.utc)).total_seconds()
            if remaining <= 0:
                await _chiudi_challenge(app, t.get("id", ""))
            else:
                app.create_task(_close_challenge_after(app, t.get("id", ""), remaining))
    except Exception:
        logger.exception("scheduled_open_loop: errore nel re-arm trade-sfida al boot.")

    while True:
        try:
            # Retry periodico del giornale transazionale: quando il giornale e'
            # vuoto (sempre, salvo incidenti) costa una lettura di cache e basta.
            # solo_stantii=True ignora le operazioni legittimamente in corso.
            try:
                await recover_journal(app, solo_stantii=True)
            except Exception:
                logger.exception("Retry periodico recovery giornale fallito.")

            dati    = await carica_dati_async()
            now_utc = datetime.now(timezone.utc)
            for t in list(dati.get("scheduled_trades", [])):
                if not isinstance(t, dict) or t.get("status") != "pending":
                    continue
                trade_id = t.get("id", "")
                label    = t.get("scheduled_for_local", "?")
                try:
                    sched = datetime.fromisoformat(t["scheduled_for_utc"])
                    if sched.tzinfo is None:
                        sched = sched.replace(tzinfo=timezone.utc)
                except Exception:
                    await modifica_dati_async(
                        partial(modifier_set_scheduled_status, trade_id=trade_id, status="failed")
                    )
                    logger.error(f"Apertura programmata {trade_id}: scheduled_for_utc illeggibile, scartata.")
                    continue

                if now_utc < sched:
                    continue  # non ancora maturo

                ritardo_min = (now_utc - sched).total_seconds() / 60.0
                if ritardo_min > SCHEDULED_LATE_GRACE_MINUTES:
                    await modifica_dati_async(
                        partial(modifier_set_scheduled_status, trade_id=trade_id, status="skipped")
                    )
                    await notifica_owner(
                        app,
                        f"⏰ Apertura programmata SALTATA ({label}).\n"
                        f"Il bot era offline oltre {SCHEDULED_LATE_GRACE_MINUTES} min dopo l'orario "
                        f"(ritardo {int(ritardo_min)} min). Nessun ordine inviato."
                    )
                    continue

                bloccato, motivo = await trading_bloccato_ora_o_news()
                if not bloccato and await semiauto_attiva():
                    # Programmazione ereditata da prima del passaggio a
                    # semi-automatica: aprirebbe da sola la gamba prop, che ora
                    # e' in sola lettura. Si salta dichiarandolo.
                    bloccato = True
                    motivo = (
                        "Modalità semi-automatica attiva: il bot non può aprire "
                        "da solo la posizione sulla Prop. Apri il trade a mano "
                        "dal menu quando vuoi."
                    )
                if bloccato:
                    await modifica_dati_async(
                        partial(modifier_set_scheduled_status, trade_id=trade_id, status="skipped")
                    )
                    await notifica_owner(
                        app,
                        f"⏰ Apertura programmata SALTATA ({label}).\n⛔ {motivo}\n"
                        f"Nessun ordine inviato."
                    )
                    continue

                # Claim atomico: marca "firing" SOLO se ancora "pending". Il
                # controllo-e-set avviene nella stessa transazione sotto
                # data_lock, cosi' un annullamento dell'utente arrivato nel
                # frattempo (tra la maturazione e qui) impedisce l'apertura.
                claim = {"ok": False}
                def _claim_pending(d):
                    for st in d.get("scheduled_trades", []):
                        if isinstance(st, dict) and st.get("id") == trade_id:
                            if st.get("status") == "pending":
                                st["status"] = "firing"
                                claim["ok"] = True
                                return d
                            return None
                    return None
                await modifica_dati_async(_claim_pending)
                if not claim["ok"]:
                    logger.info(
                        f"Apertura programmata {trade_id}: non più 'pending' "
                        f"(annullata o già in corso), salto."
                    )
                    continue
                # Trade salvati PRIMA del fix direzione hanno solo "direzione_broker":
                # quel campo conteneva comunque la scelta dell'utente (Compra/Vendi),
                # che ora viene correttamente applicata alla PROP.
                ok, msg, _tb, _tp = await _esegui_hedge(
                    t.get("direzione_prop", t.get("direzione_broker", "BUY")),
                    float(t.get("sl_dol", 0) or 0),
                    float(t.get("tp_dol", 0) or 0),
                    float(t.get("lotti_prop", 0) or 0),
                    float(t.get("lotti_broker", 0) or 0),
                    t.get("memo", ""),
                )
                await modifica_dati_async(
                    partial(modifier_set_scheduled_status, trade_id=trade_id,
                            status="done" if ok else "failed")
                )
                # Su fallimento per AutoTrading spento: includo il pulsante per
                # riavviare il terminale giusto (cosi' il prossimo trade funziona).
                kb_sched = _kb_errore_ordine(msg, "vai_menu") if not ok else None
                await notifica_owner(app, f"⏰ Apertura programmata ({label})\n\n{msg}", reply_markup=kb_sched)

            # Backstop trade-sfida: chiude quelli ancora "open" oltre l'orario
            # (timer perso a un riavvio, o chiusura precedente fallita e
            # ripristinata a "open"). Il claim atomico in _chiudi_challenge
            # evita doppie chiusure col timer preciso.
            now_chk = datetime.now(timezone.utc)
            for t in list(dati.get("challenge_trades", [])):
                if not isinstance(t, dict) or t.get("status") != "open":
                    continue
                try:
                    close_at = datetime.fromisoformat(t["close_at_utc"])
                    if close_at.tzinfo is None:
                        close_at = close_at.replace(tzinfo=timezone.utc)
                except Exception:
                    continue
                if now_chk >= close_at:
                    await _chiudi_challenge(app, t.get("id", ""))
        except Exception:
            logger.exception("Errore nel loop apertura programmata.")
        await asyncio.sleep(SCHEDULED_OPEN_CHECK_SECONDS)

async def memo_cleanup_loop():
    """Pulizia ciclica memo chiusi + ordini programmati + trade-sfida terminati (giornaliera)."""
    while True:
        try:
            await modifica_dati_async(modifier_cleanup_old_memos)
            await modifica_dati_async(modifier_cleanup_scheduled)
            await modifica_dati_async(modifier_cleanup_challenge)
        except Exception:
            logger.exception("Errore cleanup memo.")
        await asyncio.sleep(24 * 3600)

def _acquire_single_instance_lock() -> bool:
    """
    Impedisce che due istanze del bot girino contemporaneamente (cosa che
    causerebbe un conflitto getUpdates su Telegram). Scrive il PID corrente
    in BOT_LOCK_FILE. Se esiste gia' un lock il cui PID e' ancora vivo ed
    esegue questo stesso script, rifiuta l'avvio.

    Un lock "stale" (PID morto, o sopravvissuto a un kill brutale del
    watchdog) viene semplicemente sovrascritto.
    """
    my_pid = os.getpid()
    script_name = ENTRY_SCRIPT_NAME.lower()
    try:
        if os.path.exists(BOT_LOCK_FILE):
            try:
                with open(BOT_LOCK_FILE, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                old_pid = int(content) if content.isdigit() else None
            except (OSError, ValueError):
                old_pid = None
            if old_pid and old_pid != my_pid and psutil.pid_exists(old_pid):
                try:
                    p = psutil.Process(old_pid)
                    cmdline = " ".join(p.cmdline()).lower()
                    if script_name in cmdline:
                        logger.error(
                            f"Un'altra istanza del bot risulta gia' attiva (PID {old_pid}). "
                            f"Avvio annullato."
                        )
                        return False
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass  # non verificabile -> trattiamo il lock come stale
        with open(BOT_LOCK_FILE, "w", encoding="utf-8") as f:
            f.write(str(my_pid))
        return True
    except Exception:
        # In caso di errore imprevisto non blocchiamo l'avvio: meglio un bot
        # in piu' che un bot in meno. Il watchdog killa eventuali doppioni.
        logger.exception("Errore nell'acquisizione del lock single-instance; proseguo comunque.")
        return True


def _release_single_instance_lock() -> None:
    """Rimuove BOT_LOCK_FILE solo se contiene il nostro PID."""
    try:
        if os.path.exists(BOT_LOCK_FILE):
            with open(BOT_LOCK_FILE, "r", encoding="utf-8") as f:
                content = f.read().strip()
            if content == str(os.getpid()):
                os.remove(BOT_LOCK_FILE)
    except OSError:
        pass


async def heartbeat_loop():
    """
    Aggiorna periodicamente HEARTBEAT_FILE con un timestamp UTC.
    Il watchdog esterno puo' usarlo per decidere se il bot e' fermo: se il
    timestamp e' piu' vecchio di una soglia (es. 3 minuti), considera il
    processo bloccato e lo termina/riavvia.

    La scrittura usa tmp + os.replace per essere atomica anche se il
    watchdog killa proprio durante il flush. Su Windows os.replace puo'
    fallire con PermissionError se un altro processo (antivirus, indicizzatore,
    lettura del watchdog) tiene momentaneamente un handle sul file di
    destinazione: in quel caso si ritenta qualche volta con una breve pausa
    invece di saltare del tutto l'aggiornamento dell'heartbeat.
    """
    while True:
        try:
            tmp = HEARTBEAT_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(datetime.now(timezone.utc).isoformat())
                f.flush()
                os.fsync(f.fileno())
            for _tentativo in range(4):
                try:
                    os.replace(tmp, HEARTBEAT_FILE)
                    break
                except PermissionError:
                    if _tentativo < 3:
                        await asyncio.sleep(0.3)
                    else:
                        raise
        except Exception as e:
            logger.warning(f"Heartbeat: scrittura fallita: {e}")
        await asyncio.sleep(HEARTBEAT_INTERVAL_SECONDS)


async def _reconcile_at_boot(app: Application):
    """
    Riconciliazione post-restart:

      1) Per ogni pair in trade_memos NON ancora notificato come chiuso:
         se entrambi i ticket non sono piu' aperti su MT5, recupera le
         close_info e invia una notifica di chiusura recuperata.

      2) Per ogni posizione MT5 aperta SENZA memo corrispondente, segnala
         all'owner: potrebbe essere apertura manuale o un crash subito dopo
         l'invio dell'ordine.
    """
    dati = await carica_dati_async()
    broker = dati.get("broker")
    prop   = dati.get("prop")
    trade_memos = dati.get("trade_memos", {})
    if not broker or not prop:
        logger.info("Riconciliazione boot saltata: credenziali assenti.")
        return

    # Piccolo delay perche' i terminali MT5 potrebbero non essere ancora pronti.
    await asyncio.sleep(BOOT_RECONCILIATION_DELAY_SECONDS)

    # PRIMA di tutto: recovery del giornale transazionale. Richiude gambe
    # orfane, registra hedge/trade-sfida completati ma non salvati e riprende
    # chiusure di massa interrotte. Va eseguito prima della riconciliazione
    # memo, cosi' le posizioni recuperate risultano gia' registrate qui sotto.
    try:
        await recover_journal(app)
    except Exception:
        logger.exception("Recovery giornale al boot fallito (riprovera' il retry periodico).")

    # Serve lo SNAPSHOT e non la sola lista di ticket: il magic e' l'unico modo
    # di distinguere le posizioni che questo bot NON ha aperto — quelle di un
    # altro bot sul conto broker condiviso — che altrimenti verrebbero segnalate
    # come "orfane" a ogni singolo avvio.
    open_broker = await _get_open_positions_snapshot_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    )
    open_prop = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if open_broker is None or open_prop is None:
        logger.warning("Riconciliazione boot: MT5 non raggiungibile, rimandata.")
        return

    altrui_broker = separa_posizioni(open_broker, dati)[1]
    set_broker = {int(p["ticket"]) for p in open_broker}
    set_prop   = {int(p["ticket"]) for p in open_prop}

    # 1) Pair chiusi durante l'offline ma non ancora notificati ----------------
    seen_pairs: set = set()
    pair_notificati = 0
    for record in list(trade_memos.values()):
        if not isinstance(record, dict):
            continue
        pair = (int(record.get("broker_ticket", 0) or 0),
                int(record.get("prop_ticket",   0) or 0))
        if pair in seen_pairs or pair == (0, 0):
            continue
        seen_pairs.add(pair)
        if record.get("pair_closed_notified"):
            continue
        ticket_b, ticket_p = pair
        if ticket_b in set_broker or ticket_p in set_prop:
            continue  # ancora aperto, lascia fare al trade_close_monitor_loop

        updates: Dict[str, Any] = {}
        if not record.get("broker_close_info"):
            info = await get_position_close_info_async(
                MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
                ticket_b, record.get("opened_at_utc"),
            )
            if info:
                updates["broker_close_info"] = info
        if not record.get("prop_close_info"):
            info = await get_position_close_info_async(
                MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
                ticket_p, record.get("opened_at_utc"),
            )
            if info:
                updates["prop_close_info"] = info

        merged = dict(record); merged.update(updates)
        broker_info = merged.get("broker_close_info")
        prop_info   = merged.get("prop_close_info")
        if updates:
            await _mark_trade_pair_closed(ticket_b, ticket_p, updates)
        # Qui entrambi i ticket sono gia' confermati NON aperti (vedi pre-skip
        # sopra). Notifichiamo SOLO con la ricevuta COMPLETA (entrambi i lati):
        # con un solo lato l'altro stamperebbe "n/d" e il write-once
        # 'pair_closed_notified' lo congelerebbe per sempre. Il close_info gia'
        # letto e' comunque persistito sopra; se ne manca uno, lascio la coppia
        # NON notificata e ci pensa trade_close_monitor_loop a completarla e
        # inviare la ricevuta corretta al prossimo giro.
        if broker_info and prop_info:
            logger.info(
                f"Riconciliazione: pair Broker={ticket_b}/Prop={ticket_p} chiuso offline -> "
                f"broker_info=si, prop_info=si."
            )
            msg = _compose_trade_close_message(
                merged, broker_info, prop_info,
                trigger_label="(recupero post-riavvio bot)",
            )
            await notifica_owner(
                app, msg,
                reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
            )
            await _mark_trade_pair_closed(
                ticket_b, ticket_p,
                {
                    "pair_closed_notified": True,
                    "closed_source":        "reconcile",
                    "closed_at_utc":        datetime.now(timezone.utc).isoformat(),
                },
            )
            pair_notificati += 1

    # 2) Posizioni MT5 aperte senza memo (orfane) ------------------------------
    known_b = {int(r.get("broker_ticket", 0) or 0)
               for r in trade_memos.values() if isinstance(r, dict)}
    known_p = {int(r.get("prop_ticket", 0) or 0)
               for r in trade_memos.values() if isinstance(r, dict)}
    # I trade-sfida (singoli sulla Prop) NON sono in trade_memos: vanno comunque
    # riconosciuti, altrimenti risulterebbero falsi "orfani".
    known_p |= {
        int(t.get("prop_ticket", 0) or 0)
        for t in dati.get("challenge_trades", [])
        if isinstance(t, dict) and t.get("status") in ("open", "closing")
    }
    # Le posizioni di un altro bot sul conto broker condiviso non sono orfane:
    # sono semplicemente di qualcun altro. Segnalarle a ogni avvio era rumore che
    # spingeva l'utente a chiudere a mano il trade di un altro cliente. Sulla
    # PROP invece si segnala tutto: li' un trade non riconosciuto e' dell'utente,
    # ed e' giusto che se lo veda elencato.
    ticket_altrui = {int(p["ticket"]) for p in altrui_broker}
    orfani_broker = sorted(
        t for t in set_broker if t not in known_b and t not in ticket_altrui
    )
    orfani_prop   = sorted(t for t in set_prop   if t not in known_p)
    if orfani_broker or orfani_prop:
        msg = "⚠️ Riconciliazione boot: trade non riconosciuti dal bot.\n\n"
        if orfani_broker:
            msg += "🏦 Broker (ticket): " + ", ".join(str(t) for t in orfani_broker) + "\n"
        if orfani_prop:
            msg += "🏢 Prop (ticket): "   + ", ".join(str(t) for t in orfani_prop) + "\n"
        msg += (
            "\nPossibili cause: apertura manuale dal terminale, oppure crash "
            "del bot subito dopo l'invio dell'ordine. Verifica e chiudi "
            "manualmente se necessario."
        )
        await notifica_owner(app, msg)
        logger.warning(f"Riconciliazione: orfani broker={orfani_broker}, prop={orfani_prop}")

    if pair_notificati:
        logger.info(f"Riconciliazione: notificati {pair_notificati} pair chiusi offline.")
    else:
        logger.info("Riconciliazione boot: nessun pair chiuso da recuperare.")

async def _check_autotrading_al_boot(app: Application):
    """Dopo ogni avvio del bot (tipicamente dopo un REBOOT della VPS) verifica
    che l'AutoTrading (Algo Trading) sia ON su entrambi i terminali. Se risulta
    SPENTO avvisa l'owner UNA volta, col pulsante per riavviare il terminale
    giusto (che riaccende l'Algo Trading). SOLO avviso: nessun riavvio
    automatico (scelta dell'owner, massima prudenza con denaro reale).

    Robustezza:
      • una lettura 'spento' viene RICONFERMATA dopo qualche secondo: subito
        dopo l'avvio del terminale lo stato puo' essere momentaneamente non
        attendibile, e non vogliamo falsi allarmi;
      • None (terminale non raggiungibile / timeout) -> si SALTA, niente avviso;
      • gira come task in background: non rallenta l'avvio degli altri loop.
    """
    try:
        # I terminali potrebbero non essere ancora pronti subito dopo il boot:
        # la riconciliazione ha gia' un suo delay, qui aggiungiamo un margine.
        await asyncio.sleep(BOOT_RECONCILIATION_DELAY_SECONDS)
        dati = await carica_dati_async()
        terminali = [
            ("Broker", MT5_BROKER_EXE, dati.get("broker"), "riavvia_broker"),
            ("Prop",   MT5_PROP_EXE,   dati.get("prop"),   "riavvia_prop"),
        ]
        for nome, exe, cred, cb in terminali:
            if not cred or not cred.get("id") or not cred.get("password") or not cred.get("server"):
                continue
            login = int(cred["id"])
            attivo = await autotrading_attivo_async(exe, login, cred["password"], cred["server"])
            if attivo is False:
                # Riconferma: evita falsi allarmi da stato transitorio post-avvio.
                await asyncio.sleep(8)
                attivo = await autotrading_attivo_async(exe, login, cred["password"], cred["server"])
            if attivo is not False:
                continue  # True (ON) o None (non determinabile) -> nessun avviso
            logger.warning(f"AutoTrading SPENTO sul terminale {nome} all'avvio: avviso owner.")
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton(f"🔄 Riavvia terminale {nome}", callback_data=cb)],
                back_button("vai_menu"),
            ])
            await notifica_owner(
                app,
                f"⚠️ AutoTrading SPENTO sul terminale {nome}.\n\n"
                f"Le nuove operazioni verrebbero rifiutate. Premi il pulsante qui "
                f"sotto per riavviare il terminale {nome}: al riavvio l'Algo Trading "
                f"viene riacceso automaticamente.",
                reply_markup=kb,
            )
    except Exception:
        logger.exception("Errore nel controllo AutoTrading al boot (ignorato, non blocca l'avvio).")

async def _sequenza_di_avvio(app: Application):
    """Tutto cio' che al boot richiede MT5, eseguito FUORI dal percorso critico.

    Prima girava dentro post_init, che PTB attende PRIMA di far partire il
    polling: tra spawn dei worker (fino a 30s ciascuno), delay di
    riconciliazione e chiamate MT5 col loro timeout, il bot poteva restare
    muto su Telegram per minuti — l'utente premeva /start e non succedeva
    nulla. Ora il polling parte subito e questa sequenza procede in parallelo.

    L'ORDINE interno resta identico e vincolante: i loop operativi (guardiano
    di coppia, monitor chiusure) partono SOLO dopo il recovery del giornale e
    la riconciliazione, altrimenti agirebbero su uno stato non ancora sanato.
    """
    # Worker MT5 paralleli (uno per terminale). Se lo spawn fallisce, il pool
    # degrada da solo al modello in-process: il bot parte comunque.
    try:
        await pool.avvia()
    except Exception:
        logger.exception("Avvio pool MT5 fallito (fallback in-process).")

    # Se questo e' il primo avvio dopo un aggiornamento OTA, il codice nuovo
    # sta girando: consuma il pending (disinnesca il rollback) e conferma
    # l'esito al canale admin.
    try:
        await conferma_ota_al_boot(app)
    except Exception:
        logger.exception("Conferma OTA al boot fallita (non blocca l'avvio).")

    # Un rollback avvenuto mentre eravamo giu' va dichiarato: e' l'unico modo
    # per sapere che la flotta NON sta girando la versione che credi.
    try:
        await segnala_rollback_al_boot(app)
    except Exception:
        logger.exception("Segnalazione rollback OTA fallita (non blocca l'avvio).")

    # Cleanup immediato al boot
    try:
        await modifica_dati_async(modifier_cleanup_old_memos)
    except Exception:
        logger.exception("Errore cleanup memo al boot.")

    # Riconciliazione MT5 vs trade_memos (gestisce crash a meta' apertura).
    try:
        await _reconcile_at_boot(app)
    except Exception:
        logger.exception("Errore durante la riconciliazione al boot.")

    # Avviso proattivo se l'AutoTrading e' spento dopo un reboot della VPS
    # (task in background: ha sleep di riconferma e non deve rallentare gli altri).
    app.create_task(_check_autotrading_al_boot(app))

    # Un'apertura semi-automatica interrotta da un riavvio va ripresentata:
    # l'utente ha in mano un telefono e nessun modo di sapere che il bot e'
    # ripartito. Dopo la riconciliazione, cosi' lo stato e' gia' sano.
    try:
        await ripristina_semiauto_al_boot(app)
    except Exception:
        logger.exception("Ripristino operazione semi-automatica al boot fallito.")

    app.create_task(nightly_close_loop(app))
    app.create_task(news_monitor_loop(app))
    app.create_task(trade_close_monitor_loop(app))
    app.create_task(pair_guard_loop(app))
    app.create_task(scheduled_open_loop(app))
    app.create_task(memo_cleanup_loop())
    app.create_task(subscription_loop(app))
    app.create_task(prop_daily_baseline_loop(app))
    app.create_task(terminali_health_loop(app))
    app.create_task(semiauto_alert_loop(app))
    logger.info("Sequenza di avvio completata: tutti i loop operativi sono attivi.")


async def post_init(app: Application):
    # Esponi l'owner al watchdog (per gli avvisi Telegram).
    try:
        dati_iniziali = await carica_dati_async()
        _scrivi_owner_sidecar(dati_iniziali.get("owner_chat_id"))
        # Riattiva il simbolo prop salvato (override del .env) a ogni avvio.
        _attiva_simbolo_prop((dati_iniziali.get("prop_avanzata", {}) or {}).get("simbolo"))
    except Exception:
        logger.exception("Errore nella scrittura del sidecar owner per il watchdog.")

    # Avvia SUBITO l'heartbeat: cosi' il watchdog vede il bot vivo gia' durante
    # la sequenza di avvio (che puo' richiedere decine di secondi per via di MT5).
    app.create_task(heartbeat_loop())
    # ...e SUBITO la sequenza pesante, in background: post_init ritorna in
    # pochi millisecondi e PTB puo' iniziare il polling. Il bot risponde ai
    # comandi mentre si riconcilia.
    app.create_task(_sequenza_di_avvio(app))


async def post_shutdown(app: Application):
    """
    Eseguito da PTB dopo l'arresto del polling. Aspetta il rilascio di
    data_lock per garantire che eventuali scritture in corso terminino
    prima dell'exit. Cosi' un SIGTERM "buono" del watchdog porta a uno
    shutdown pulito; un SIGKILL e' invece coperto dalla scrittura atomica
    in salva_dati() (vedi DATA_FILE / BACKUP_FILE).
    """
    async def _wait_lock():
        async with data_lock:
            return True
    try:
        await asyncio.wait_for(_wait_lock(), timeout=10)
    except asyncio.TimeoutError:
        logger.warning("post_shutdown: timeout in attesa di data_lock.")
    except Exception:
        logger.exception("post_shutdown: errore.")
    # Rimuovi heartbeat per segnalare al watchdog che siamo usciti volutamente.
    try:
        if os.path.exists(HEARTBEAT_FILE):
            os.remove(HEARTBEAT_FILE)
    except OSError:
        pass
    # Spegnimento ordinato dei worker MT5 (chiudono le loro sessioni) e della
    # eventuale sessione in-process (fallback).
    try:
        await pool.stop()
    except Exception:
        logger.exception("Stop pool MT5: errore ignorato in shutdown.")
    # _mt5_disconnect e' BLOCCANTE (parla con il terminale via IPC): eseguirlo
    # sul loop poteva far superare il timeout di terminate del watchdog, che
    # allora passava al kill duro proprio durante la chiusura pulita.
    try:
        await asyncio.wait_for(asyncio.to_thread(_mt5_disconnect), timeout=10)
    except Exception:
        logger.warning("Disconnessione MT5 in shutdown non completata (ignorata).")
    # Ultimo passo: rilascia i thread dedicati a MT5 (dopo, nessuno li usa).
    try:
        pool.chiudi_esecutore()
    except Exception:
        pass
    logger.info("Shutdown completato in modo pulito.")
