"""Flusso di APERTURA in modalita' semi-automatica.

Sulla prop il bot ha la sola lettura: non puo' aprire, non puo' chiudere, non
puo' modificare. Puo' solo GUARDARE e PARLARE. Da qui nasce una danza a quattro
schermate, che e' il cuore di questa modalita':

  1) ISTRUZIONI    "apri tu questa posizione sulla prop, con questi numeri".
                   I livelli sono PROVVISORI: calcolati sul prezzo di adesso,
                   invecchieranno mentre l'utente prende il telefono.

  2) VERIFICA      l'utente dice "l'ho aperta". Il bot ritrova la posizione
                   nuova, controlla che sia QUELLA (direzione, lotti) e che i
                   livelli reggano. Se non reggono: dice i valori ESATTI e fa
                   correggere.

  3) COPERTURA     appena la posizione e' accettabile il bot apre SUBITO la
                   gamba broker — ogni secondo in piu' la prop e' scoperta — e
                   solo dopo chiede la rifinitura ai valori esatti.

  4) AVVIATA       riepilogo delle due gambe. Da qui in poi il trade e' un
                   trade normale: monitor, guardiano di coppia e ricevute
                   funzionano come sempre.

DUE SCELTE STRUTTURALI, entrambe pagate care in altri punti del bot:

  • l'operazione in corso NON vive in `context.user_data` ma nello stato su
    disco (`semiauto_pending`). Una conversazione Telegram scade in 5 minuti e
    muore a ogni riavvio: aprire una posizione dal telefono puo' richiedere di
    piu', e un riavvio nel mezzo lascerebbe l'utente con una posizione prop
    aperta e un bot che non sa nulla;

  • il trade viene REGISTRATO (trade_memos) nell'istante in cui la gamba broker
    entra a mercato, non al click finale. Se l'utente sparisce dopo la
    copertura, il guardiano di coppia e il monitor devono comunque vedere la
    coppia: la rifinitura dei livelli e' cosmesi, la sorveglianza no.
"""
import logging
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial
from typing import Any, Dict, List, Optional, Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
import MetaTrader5 as mt5

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    SEMIAUTO_PENDING_TTL_MINUTES,
    SEMIAUTO_TOLLERANZA_PERC,
    SEMIAUTO_TOLLERANZA_POINT,
    SIMBOLO_BROKER,
)
from .messaging import ack, back_button, notifica_owner, safe_edit_message_text
from .storage import carica_dati_async, modifica_dati_async
from .state import (
    SEMIAUTO_PENDING_KEY,
    modifier_save_trade_memo,
    modifier_semiauto_alert_registra,
    modifier_semiauto_alert_rimuovi,
    modifier_semiauto_clear_pending,
    modifier_semiauto_put_pending,
    modifier_semiauto_update_pending,
)
from .mt5_sync import DatiSimboloNonValidi, MSG_AUTOTRADING_OFF, calcola_prezzi_sl_tp
from .mt5_async import (
    _get_open_positions_snapshot_async,
    autotrading_attivo_async,
    calcola_margine_wrapper_async,
    esegui_ordine_async,
    get_symbol_info_wrapper_async,
    get_position_by_ticket_async,
    info_account_async,
    valida_simbolo_volume_async,
)
from .semiauto_core import (
    ALERT_COPERTURA_KO,
    ESITO_DA_CORREGGERE,
    ESITO_NON_SISTEMABILE,
    MOTIVO_DIREZIONE,
    MOTIVO_LOTTI,
    livelli_broker_da_prop,
    livelli_gia_esatti,
    offset_feed,
    valuta_posizione_prop,
)
from .trade_core import genera_magic
from .hedge_journal import journal_put, journal_remove, journal_update
from .handlers_base import guard_auth
from .handlers_trade import _controlla_livelli_broker

# Stati dell'operazione in corso.
ST_ATTESA_APERTURA  = "attesa_apertura"    # istruzioni date, si aspetta l'utente
ST_ATTESA_MODIFICA  = "attesa_modifica"    # copertura aperta, manca la rifinitura
ST_COPERTURA_KO     = "copertura_fallita"  # prop aperta e SCOPERTA: emergenza


# ========================= FORMATTAZIONE =========================
def _dir_ita(direzione: str) -> str:
    return "Compra" if str(direzione).upper() == "BUY" else "Vendi"


def _fmt_prezzo(valore: float, digits: int = 2) -> str:
    return f"{float(valore):.{max(0, int(digits))}f}$"


def _fmt_lotti(valore: float) -> str:
    return f"{float(valore):g}"


# ========================= ACCESSO ALL'OPERAZIONE IN CORSO =========================
async def pending_corrente() -> Optional[Dict[str, Any]]:
    dati = await carica_dati_async()
    p = dati.get(SEMIAUTO_PENDING_KEY)
    return p if isinstance(p, dict) else None


def pending_scaduto(pending: Dict[str, Any]) -> bool:
    """Un'istruzione mai raccolta scade: i prezzi indicati non valgono piu' e
    la regola 'un trade alla volta' resterebbe bloccata per sempre. Scade solo
    lo stato di ATTESA APERTURA: dopo la copertura c'e' denaro a mercato e
    l'operazione non puo' semplicemente evaporare."""
    if pending.get("stato") != ST_ATTESA_APERTURA:
        return False
    try:
        creato = datetime.fromisoformat(pending.get("creato_utc", ""))
        if creato.tzinfo is None:
            creato = creato.replace(tzinfo=timezone.utc)
    except Exception:
        return True
    return datetime.now(timezone.utc) - creato > timedelta(minutes=SEMIAUTO_PENDING_TTL_MINUTES)


async def blocco_semiauto_in_corso() -> Tuple[bool, str]:
    """C'e' gia' un'apertura semi-automatica a meta'? (regola 'un trade alla volta')

    Le posizioni non ancora aperte non compaiono in MT5, quindi il controllo
    classico (_blocco_nuovo_trade) non le vedrebbe: due istruzioni in volo
    porterebbero l'utente ad aprire due posizioni sulla stessa prop.
    """
    pending = await pending_corrente()
    if not pending or pending_scaduto(pending):
        return False, ""
    if pending.get("stato") == ST_ATTESA_APERTURA:
        return True, (
            "⛔ C'è già un'apertura semi-automatica in attesa.\n"
            "Completala (o annullala) prima di avviarne un'altra."
        )
    return True, (
        "⛔ C'è già un trade semi-automatico in corso.\n"
        "Attendi la chiusura prima di aprirne un altro."
    )


# ========================= SCHERMATE =========================
def _kb(*righe: List[InlineKeyboardButton]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([r for r in righe if r])


def schermata_istruzioni(pending: Dict[str, Any]) -> Tuple[str, InlineKeyboardMarkup]:
    d = int(pending.get("digits", 2) or 2)
    testo = (
        "📲 Apri la posizione prop su MetaTrader\n\n"
        f"Apri manualmente una posizione su {pending.get('simbolo_prop', '')} "
        "con questi parametri:\n\n"
        f"• Direzione: {_dir_ita(pending['direzione_prop'])}\n"
        f"• Lotti: {_fmt_lotti(pending['lotti_prop'])}\n"
        f"• Stop Loss: {_fmt_prezzo(pending['sl_provvisorio'], d)} "
        f"(perdita di circa {float(pending['sl_dol']):.0f}$)\n"
        f"• Take Profit: {_fmt_prezzo(pending['tp_provvisorio'], d)} "
        f"(guadagno di circa {float(pending['tp_dol']):.0f}$)\n\n"
        "ℹ️ Lo Stop Loss e il Take Profit sono provvisori (calcolati sul prezzo "
        "attuale): dopo l'apertura il bot ti darà i valori esatti da impostare.\n\n"
        "Quando l'hai aperta, premi «Ho aperto la posizione»."
    )
    return testo, _kb(
        [InlineKeyboardButton("✅ Ho aperto la posizione", callback_data="semi_aperta")],
        [InlineKeyboardButton("❌ Annulla",                callback_data="semi_annulla")],
    )


def schermata_da_correggere(
    pending: Dict[str, Any], sl_esatto: float, tp_esatto: float, motivo: str,
) -> Tuple[str, InlineKeyboardMarkup]:
    d = int(pending.get("digits", 2) or 2)
    testa = "⚠️ Lo Stop Loss / Take Profit della posizione prop non sono corretti."
    if motivo == "mancanti":
        testa = "⚠️ Alla posizione prop mancano lo Stop Loss e/o il Take Profit."
    elif motivo == "lato":
        testa = ("⚠️ Lo Stop Loss / Take Profit della posizione prop sono dal lato "
                 "SBAGLIATO del prezzo.")
    testo = (
        f"{testa}\n\n"
        "Modifica la posizione impostando:\n\n"
        f"• Stop Loss: {_fmt_prezzo(sl_esatto, d)} "
        f"(perdita di circa {float(pending['sl_dol']):.0f}$)\n"
        f"• Take Profit: {_fmt_prezzo(tp_esatto, d)} "
        f"(guadagno di circa {float(pending['tp_dol']):.0f}$)\n\n"
        "Poi premi «Controlla di nuovo»."
    )
    return testo, _kb(
        [InlineKeyboardButton("🔄 Controlla di nuovo", callback_data="semi_ricontrolla")],
        [InlineKeyboardButton("❌ Annulla",            callback_data="semi_annulla")],
    )


def schermata_rifinitura(
    pending: Dict[str, Any], avviso: str = "",
) -> Tuple[str, InlineKeyboardMarkup]:
    d = int(pending.get("digits", 2) or 2)
    testo = (
        f"{avviso}✅ Posizione verificata e copertura broker aperta.\n\n"
        f"Ora modifica la posizione prop {_dir_ita(pending['direzione_prop'])} su "
        f"{pending.get('simbolo_prop', '')} ({_fmt_lotti(pending['lotti_prop'])} lotti) "
        "impostando i valori esatti:\n\n"
        f"• Stop Loss: {_fmt_prezzo(pending['sl_esatto'], d)}\n"
        f"• Take Profit: {_fmt_prezzo(pending['tp_esatto'], d)}\n\n"
        "Quando l'hai fatto premi «Ho modificato la posizione», oppure Annulla "
        "per chiudere l'operazione."
    )
    return testo, _kb(
        [InlineKeyboardButton("✅ Ho modificato la posizione", callback_data="semi_modificata")],
        [InlineKeyboardButton("❌ Annulla",                    callback_data="semi_annulla")],
    )


def schermata_copertura_fallita(
    pending: Dict[str, Any], motivo: str,
) -> Tuple[str, InlineKeyboardMarkup]:
    testo = (
        "🚨 NON sono riuscito ad aprire la copertura sul broker.\n\n"
        f"Motivo: {motivo}\n\n"
        "⚠️ La posizione prop è APERTA e SCOPERTA. Puoi:\n"
        "• premere «Riprova copertura», oppure\n"
        "• chiudere SUBITO la posizione prop dal tuo MetaTrader.\n\n"
        "Continuerò ad avvisarti ogni 5 minuti finché la posizione prop resta scoperta."
    )
    righe = [[InlineKeyboardButton("🔄 Riprova copertura", callback_data="semi_copertura_retry")]]
    if MSG_AUTOTRADING_OFF in (motivo or ""):
        righe.append([InlineKeyboardButton("🔄 Riavvia terminale Broker", callback_data="riavvia_broker")])
    righe.append([InlineKeyboardButton("❌ Ho chiuso la prop, annulla", callback_data="semi_annulla")])
    return testo, InlineKeyboardMarkup(righe)


def schermata_avviata(
    pending: Dict[str, Any], broker_pos: Optional[Dict[str, Any]],
) -> Tuple[str, InlineKeyboardMarkup]:
    d  = int(pending.get("digits", 2) or 2)
    db = int(pending.get("digits_broker", d) or d)
    dir_broker = "SELL" if str(pending["direzione_prop"]).upper() == "BUY" else "BUY"
    # Se la posizione broker e' leggibile si mostrano i valori VERI a mercato
    # (fill e arrotondamenti del broker compresi), non quelli richiesti.
    lotti_b = float((broker_pos or {}).get("volume") or pending["lotti_broker"])
    sl_b    = float((broker_pos or {}).get("sl") or pending.get("sl_broker", 0) or 0)
    tp_b    = float((broker_pos or {}).get("tp") or pending.get("tp_broker", 0) or 0)
    testo = (
        "🚀 Trade semi-automatico avviato\n\n"
        f"Asset: {pending.get('simbolo_prop', '')}\n\n"
        "🏢 Prop\n"
        f"• Tipo: {_dir_ita(pending['direzione_prop'])}\n"
        f"• Lotti: {_fmt_lotti(pending['lotti_prop'])}\n"
        f"• SL: {_fmt_prezzo(pending['sl_esatto'], d)}\n"
        f"• TP: {_fmt_prezzo(pending['tp_esatto'], d)}\n\n"
        "🏦 Broker\n"
        f"• Tipo: {_dir_ita(dir_broker)}\n"
        f"• Lotti: {_fmt_lotti(lotti_b)}\n"
        f"• SL: {_fmt_prezzo(sl_b, db)}\n"
        f"• TP: {_fmt_prezzo(tp_b, db)}\n\n"
        "ℹ️ Il bot chiuderà la posizione broker quando la prop verrà chiusa."
    )
    return testo, InlineKeyboardMarkup([back_button("gestisci")])


def schermata_pending(
    pending: Dict[str, Any],
) -> Optional[Tuple[str, InlineKeyboardMarkup]]:
    """Schermata che corrisponde allo stato attuale (usata al riavvio del bot)."""
    stato = pending.get("stato")
    if stato == ST_ATTESA_APERTURA:
        return schermata_istruzioni(pending)
    if stato == ST_ATTESA_MODIFICA:
        return schermata_rifinitura(pending)
    if stato == ST_COPERTURA_KO:
        return schermata_copertura_fallita(pending, pending.get("motivo_ko", "non disponibile"))
    return None


# ========================= 1) ISTRUZIONI =========================
async def avvia_flusso_semiauto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Chiamata da conferma_esegui quando la modalita' e' semi-automatica.

    Non invia NIENTE al mercato: fotografa le posizioni prop gia' presenti
    (per riconoscere poi quella nuova), calcola i livelli provvisori e passa la
    palla all'utente. Chiude la conversazione: da qui in avanti si lavora sui
    pulsanti globali, senza timeout.
    """
    query = update.callback_query
    bloccato, motivo = await blocco_semiauto_in_corso()
    if bloccato:
        await safe_edit_message_text(query, motivo, InlineKeyboardMarkup([back_button("manuale")]))
        return ConversationHandler.END

    dati = await carica_dati_async()
    prop = dati.get("prop")
    if not prop or not all(prop.get(k) for k in ("id", "password", "server")):
        await safe_edit_message_text(
            query, "❌ Credenziali Prop mancanti.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    direzione_prop = context.user_data["direzione"]
    sl_dol         = float(context.user_data["sl"])
    tp_dol         = float(context.user_data["tp"])
    lotti_prop     = float(context.user_data["lotti_prop"])
    lotti_broker   = float(context.user_data["lotti_broker"])
    memo           = (context.user_data.pop("memo", "") or "").strip()

    await safe_edit_message_text(query, "⏳ Preparo le istruzioni…")

    # Fotografia PRIMA: tutto cio' che c'e' adesso sulla prop NON e' la
    # posizione che l'utente sta per aprire. E' cosi' che dopo la riconosciamo,
    # senza dipendere da magic o commenti (una posizione aperta a mano dal
    # telefono non porta ne' l'uno ne' l'altro).
    snap_p = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    info_sym_prop = await get_symbol_info_wrapper_async(
        MT5_PROP_EXE, cfg.SIMBOLO_PROP, direzione_prop,
    )
    if snap_p is None or not info_sym_prop:
        await safe_edit_message_text(
            query,
            "❌ Non riesco a leggere il conto Prop in questo momento "
            "(terminale non raggiungibile o mercato chiuso). Riprova tra poco.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    try:
        sl_prov, tp_prov = calcola_prezzi_sl_tp(
            direzione_prop, info_sym_prop["prezzo_entrata"], sl_dol, tp_dol,
            lotti_prop, info_sym_prop["point"], info_sym_prop["tick_value"],
        )
    except DatiSimboloNonValidi as e:
        logger.error(f"Semiauto: livelli provvisori non calcolabili — {e}")
        await safe_edit_message_text(
            query,
            f"❌ Il terminale Prop non espone dati validi per {cfg.SIMBOLO_PROP} "
            "(mercato chiuso o simbolo non pronto). Riprova tra poco.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    pending = {
        "id":              uuid.uuid4().hex[:8],
        "stato":           ST_ATTESA_APERTURA,
        "creato_utc":      datetime.now(timezone.utc).isoformat(),
        "chat_id":         update.effective_chat.id if update.effective_chat else None,
        "simbolo_prop":    cfg.SIMBOLO_PROP,
        "direzione_prop":  direzione_prop,
        "sl_dol":          sl_dol,
        "tp_dol":          tp_dol,
        "lotti_prop":      lotti_prop,
        "lotti_broker":    lotti_broker,
        "incasso_target":  float(context.user_data.get("incasso_target", 0) or 0),
        "memo":            memo,
        "digits":          int(info_sym_prop.get("digits", 2) or 2),
        "prezzo_rif":      float(info_sym_prop["prezzo_entrata"]),
        "sl_provvisorio":  sl_prov,
        "tp_provvisorio":  tp_prov,
        "tickets_prima":   sorted(int(p["ticket"]) for p in snap_p),
    }
    await modifica_dati_async(partial(modifier_semiauto_put_pending, pending=pending))
    for k in ("memo", "sl", "tp", "lotti_prop", "lotti_broker", "direzione",
              "incasso_target", "riepilogo_text"):
        context.user_data.pop(k, None)

    testo, kb = schermata_istruzioni(pending)
    await safe_edit_message_text(query, testo, kb)
    return ConversationHandler.END


# ========================= 2) VERIFICA =========================
async def _trova_posizione_nuova(
    pending: Dict[str, Any], prop: Dict[str, Any],
) -> Tuple[Optional[List[Dict[str, Any]]], Optional[str]]:
    """Posizioni comparse sulla prop DOPO le istruzioni. (lista, errore)"""
    snap = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
        pending.get("simbolo_prop") or cfg.SIMBOLO_PROP,
    )
    if snap is None:
        return None, (
            "⚠️ Non riesco a leggere il conto Prop in questo momento "
            "(terminale non raggiungibile). Riprova tra qualche secondo."
        )
    prima = {int(t) for t in pending.get("tickets_prima", [])}
    return [p for p in snap if int(p.get("ticket", 0) or 0) not in prima], None


async def _verifica_e_copri(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cuore dei pulsanti «Ho aperto la posizione» e «Controlla di nuovo»."""
    query = update.callback_query
    pending = await pending_corrente()
    if not pending or pending.get("stato") != ST_ATTESA_APERTURA:
        await safe_edit_message_text(
            query, "ℹ️ Questa operazione non è più in corso.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    dati = await carica_dati_async()
    prop = dati.get("prop")
    if not prop:
        await safe_edit_message_text(query, "❌ Credenziali Prop mancanti.",
                                     InlineKeyboardMarkup([back_button("manuale")]))
        return

    await safe_edit_message_text(query, "⏳ Controllo la posizione sulla Prop…")
    nuove, errore = await _trova_posizione_nuova(pending, prop)
    if errore:
        testo, kb = schermata_istruzioni(pending)
        await safe_edit_message_text(query, f"{errore}\n\n{testo}", kb)
        return
    if not nuove:
        testo, kb = schermata_istruzioni(pending)
        await safe_edit_message_text(
            query,
            "⚠️ Non trovo nessuna posizione NUOVA sulla Prop.\n"
            "Controlla di averla davvero aperta sul tuo MetaTrader, poi riprova.\n\n"
            + testo, kb,
        )
        return
    if len(nuove) > 1:
        tickets = ", ".join(str(int(p["ticket"])) for p in nuove)
        await safe_edit_message_text(
            query,
            f"⛔ Ho trovato {len(nuove)} posizioni nuove sulla Prop (ticket {tickets}).\n\n"
            "La strategia lavora con UN trade alla volta: chiudi quelle di troppo "
            "dal tuo MetaTrader, poi premi «Controlla di nuovo».",
            _kb(
                [InlineKeyboardButton("🔄 Controlla di nuovo", callback_data="semi_ricontrolla")],
                [InlineKeyboardButton("❌ Annulla",            callback_data="semi_annulla")],
            ),
        )
        return

    pos = nuove[0]
    info_sym_prop = await get_symbol_info_wrapper_async(
        MT5_PROP_EXE, pending.get("simbolo_prop") or cfg.SIMBOLO_PROP,
        pending["direzione_prop"],
    )
    if not info_sym_prop:
        testo, kb = schermata_istruzioni(pending)
        await safe_edit_message_text(
            query,
            "⚠️ Il terminale Prop non espone i dati del simbolo in questo momento. "
            "Riprova tra poco.\n\n" + testo, kb,
        )
        return

    esito = valuta_posizione_prop(
        pending["direzione_prop"], float(pending["lotti_prop"]),
        float(pending["sl_dol"]), float(pending["tp_dol"]),
        pos, float(info_sym_prop["point"]), float(info_sym_prop["tick_value"]),
        SEMIAUTO_TOLLERANZA_PERC,
    )

    if esito["esito"] == ESITO_NON_SISTEMABILE:
        await _chiudi_pending(pending["id"])
        await safe_edit_message_text(
            query, _testo_non_sistemabile(pending, esito),
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    if esito["esito"] == ESITO_DA_CORREGGERE:
        # I livelli esatti dipendono dal prezzo di ingresso REALE: sono gia'
        # definitivi, non cambieranno al prossimo controllo. Si memorizzano ora
        # cosi' la schermata successiva non deve ricalcolarli.
        await _aggiorna_pending(pending["id"], {
            "prop_ticket":     int(pos["ticket"]),
            "prezzo_apertura": float(pos.get("price_open") or 0),
            "sl_esatto":       esito["sl_esatto"],
            "tp_esatto":       esito["tp_esatto"],
        })
        pending.update({"sl_esatto": esito["sl_esatto"], "tp_esatto": esito["tp_esatto"]})
        testo, kb = schermata_da_correggere(
            pending, esito["sl_esatto"], esito["tp_esatto"], esito.get("motivo", ""),
        )
        await safe_edit_message_text(query, testo, kb)
        return

    # ── Livelli accettabili: si copre SUBITO. ────────────────────────────────
    await safe_edit_message_text(query, "⏳ Posizione verificata: apro la copertura sul Broker…")
    pending.update({
        "prop_ticket":     int(pos["ticket"]),
        "prezzo_apertura": float(pos.get("price_open") or 0),
        "sl_esatto":       esito["sl_esatto"],
        "tp_esatto":       esito["tp_esatto"],
    })
    await _aggiorna_pending(pending["id"], {
        "prop_ticket":     pending["prop_ticket"],
        "prezzo_apertura": pending["prezzo_apertura"],
        "sl_esatto":       pending["sl_esatto"],
        "tp_esatto":       pending["tp_esatto"],
    })
    await _copri_e_mostra(query, context, pending)


def _testo_non_sistemabile(pending: Dict[str, Any], esito: Dict[str, Any]) -> str:
    motivo = esito.get("motivo")
    if motivo == MOTIVO_DIREZIONE:
        return (
            "⛔ La posizione aperta sulla Prop ha la DIREZIONE sbagliata.\n\n"
            f"• Richiesta: {_dir_ita(pending['direzione_prop'])}\n"
            f"• Trovata: {_dir_ita(esito.get('tipo_trovato', ''))}\n\n"
            "Non è sistemabile: chiudi quella posizione dal tuo MetaTrader e "
            "riapri il trade dal bot."
        )
    if motivo == MOTIVO_LOTTI:
        return (
            "⛔ La posizione aperta sulla Prop ha un VOLUME diverso da quello richiesto.\n\n"
            f"• Richiesti: {_fmt_lotti(pending['lotti_prop'])} lotti\n"
            f"• Trovati: {_fmt_lotti(esito.get('lotti_trovati', 0))} lotti\n\n"
            "Non è sistemabile: con lotti diversi cambiano sia il rischio sia la "
            "copertura da aprire sul broker. Chiudi quella posizione dal tuo "
            "MetaTrader e riapri il trade dal bot."
        )
    return (
        "⛔ Non riesco a leggere i dati della posizione Prop in modo affidabile.\n\n"
        "Chiudi quella posizione dal tuo MetaTrader e riapri il trade dal bot."
    )


# ========================= 3) COPERTURA BROKER =========================
async def _copri_e_mostra(query, context, pending: Dict[str, Any]) -> None:
    ok, motivo, ticket_b, broker_pos = await apri_copertura_broker(pending)
    if ok:
        pending["stato"] = ST_ATTESA_MODIFICA
        testo, kb = schermata_rifinitura(pending)
        await safe_edit_message_text(query, testo, kb)
        return
    # QUALUNQUE motivo di fallimento lascia la prop APERTA e SCOPERTA: lo stato
    # d'emergenza si segna qui, in un punto solo, e non in ognuno dei rami di
    # errore della funzione sotto (dimenticarne uno significherebbe una prop
    # scoperta senza solleciti).
    await _segna_copertura_fallita(pending, motivo)
    testo, kb = schermata_copertura_fallita(pending, motivo)
    await safe_edit_message_text(query, testo, kb)


async def apri_copertura_broker(
    pending: Dict[str, Any],
) -> Tuple[bool, str, Optional[int], Optional[Dict[str, Any]]]:
    """Apre la gamba BROKER a copertura della posizione prop gia' a mercato.

    Ritorna (ok, motivo, ticket_broker, posizione_broker).

    Differenza rispetto all'hedge automatico: i livelli non sono lo specchio
    "nudo" di quelli della prop, ma lo specchio CORRETTO dello scarto tra i due
    feed (vedi semiauto_core.livelli_broker_da_prop). In automatica le due
    gambe partono nello stesso istante e lo scarto e' quasi tutto spread; qui in
    mezzo c'e' un essere umano col telefono, e il prezzo si e' mosso: senza la
    correzione i due livelli scatterebbero in momenti di mercato diversi, che e'
    esattamente il guasto che si vuole evitare.
    """
    dati   = await carica_dati_async()
    broker = dati.get("broker")
    if not broker or not all(broker.get(k) for k in ("id", "password", "server")):
        return False, "credenziali Broker mancanti", None, None

    direzione_prop   = str(pending["direzione_prop"]).upper()
    direzione_broker = "SELL" if direzione_prop == "BUY" else "BUY"
    lotti_broker     = float(pending["lotti_broker"])

    valido, err = await valida_simbolo_volume_async(MT5_BROKER_EXE, SIMBOLO_BROKER, lotti_broker)
    if not valido:
        return False, f"volume Broker non valido ({lotti_broker}): {err}", None, None

    autotrading = await autotrading_attivo_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
    )
    if autotrading is False:
        return False, MSG_AUTOTRADING_OFF, None, None

    info_b = await get_symbol_info_wrapper_async(MT5_BROKER_EXE, SIMBOLO_BROKER, direzione_broker)
    info_p = await get_symbol_info_wrapper_async(
        MT5_PROP_EXE, pending.get("simbolo_prop") or cfg.SIMBOLO_PROP, direzione_prop,
    )
    if not info_b:
        return False, "il terminale Broker non espone il prezzo (mercato chiuso?)", None, None

    offset = offset_feed(info_b, info_p)
    sl_broker, tp_broker = livelli_broker_da_prop(
        float(pending["sl_esatto"]), float(pending["tp_esatto"]), offset,
    )
    errore_livelli = _controlla_livelli_broker(direzione_broker, info_b, sl_broker, tp_broker)
    if errore_livelli:
        return False, (
            f"{errore_livelli} Molto probabilmente il prezzo si è mosso troppo "
            f"tra l'apertura sulla Prop e adesso."
        ), None, None

    # Margine: stesso criterio dell'hedge automatico (+5% di sicurezza).
    tipo_ord = mt5.ORDER_TYPE_BUY if direzione_broker == "BUY" else mt5.ORDER_TYPE_SELL
    margine  = await calcola_margine_wrapper_async(
        MT5_BROKER_EXE, tipo_ord, SIMBOLO_BROKER, lotti_broker, info_b["prezzo_entrata"],
    )
    acc = await info_account_async(MT5_BROKER_EXE)
    if margine is not None and acc:
        disponibile = float(acc.get("free_margin", 0) or 0)
        if float(margine) * 1.05 > disponibile:
            return False, (
                f"margine Broker insufficiente: servono ~{float(margine):.2f}$ "
                f"(+5% di sicurezza), disponibili {disponibile:.2f}$"
            ), None, None

    magic = await genera_magic()
    uid   = f"semi-{pending['id']}"
    await journal_put(
        uid, kind="semiauto_cover", status="ordering", magic=magic,
        ticket_prop=int(pending["prop_ticket"]),
        direzione_broker=direzione_broker, direzione_prop=direzione_prop,
        lotti_broker=lotti_broker, lotti_prop=float(pending["lotti_prop"]),
        sl_dol=float(pending["sl_dol"]), tp_dol=float(pending["tp_dol"]),
        memo=pending.get("memo", ""),
    )
    ticket_b, motivo = await esegui_ordine_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
        direzione_broker, SIMBOLO_BROKER, lotti_broker,
        sl_broker, tp_broker, "", magic,
    )
    if not ticket_b:
        # L'intento NON si cancella: una risposta persa puo' nascondere un
        # ordine accettato davvero. Resta li' come "failed" e, se dopo qualche
        # minuto nessuno ha rimediato (l'utente ha il pulsante «Riprova
        # copertura»), il recovery del giornale va a cercare per magic una
        # posizione broker fantasma e la registra o la richiude.
        await journal_update(uid, status="failed", motivo=motivo or "")
        return False, (motivo or "non disponibile"), None, None

    await journal_update(uid, ticket_broker=int(ticket_b), status="opened")
    await registra_trade_semiauto(pending, int(ticket_b), sl_broker, tp_broker, offset)
    await journal_remove(uid)
    # L'eventuale emergenza "prop scoperta" e' rientrata.
    await modifica_dati_async(partial(
        modifier_semiauto_alert_rimuovi, prop_ticket=int(pending["prop_ticket"]),
    ))
    await _aggiorna_pending(pending["id"], {
        "stato":         ST_ATTESA_MODIFICA,
        "broker_ticket": int(ticket_b),
        "sl_broker":     sl_broker,
        "tp_broker":     tp_broker,
        "offset_feed":   offset,
        "digits_broker": int(info_b.get("digits", 2) or 2),
        "motivo_ko":     "",
    })
    pending.update({
        "stato": ST_ATTESA_MODIFICA, "broker_ticket": int(ticket_b),
        "sl_broker": sl_broker, "tp_broker": tp_broker, "offset_feed": offset,
        "digits_broker": int(info_b.get("digits", 2) or 2),
    })
    broker_pos = await get_position_by_ticket_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], int(ticket_b),
    )
    return True, "", int(ticket_b), _posizione_dict(broker_pos)


def _posizione_dict(pos: Any) -> Optional[Dict[str, Any]]:
    """La posizione letta per ticket arriva come oggetto MT5 (o dict dalla
    pipe del worker): qui diventa sempre un dict, o None."""
    if pos is None:
        return None
    if isinstance(pos, dict):
        return pos
    return {
        "ticket": getattr(pos, "ticket", 0),
        "volume": getattr(pos, "volume", 0.0),
        "sl":     getattr(pos, "sl", 0.0),
        "tp":     getattr(pos, "tp", 0.0),
    }


async def registra_trade_semiauto(
    pending: Dict[str, Any], ticket_broker: int,
    sl_broker: float, tp_broker: float, offset: float,
) -> None:
    """Registra la coppia in trade_memos: da qui il trade e' sorvegliato.

    Si fa nell'ISTANTE in cui la gamba broker entra a mercato — non al click
    finale dell'utente — perche' da quel momento esiste una coppia da
    proteggere. Il campo "modalita" e' cio' che, piu' tardi, dira' al guardiano
    di coppia di NON provare a chiudere la prop e alla ricevuta di chiusura di
    usare le parole della semi-automatica.
    """
    payload = {
        "memo":                 pending.get("memo", ""),
        "timestamp":            datetime.now().isoformat(),
        "opened_at_utc":        datetime.now(timezone.utc).isoformat(),
        "modalita":             "semiauto",
        "direzione_broker":     "SELL" if str(pending["direzione_prop"]).upper() == "BUY" else "BUY",
        "direzione_prop":       str(pending["direzione_prop"]).upper(),
        "lotti_broker":         float(pending["lotti_broker"]),
        "lotti_prop":           float(pending["lotti_prop"]),
        "sl_dol":               float(pending["sl_dol"]),
        "tp_dol":               float(pending["tp_dol"]),
        "sl_price_prop":        float(pending["sl_esatto"]),
        "tp_price_prop":        float(pending["tp_esatto"]),
        "sl_price_broker":      float(sl_broker),
        "tp_price_broker":      float(tp_broker),
        "offset_feed":          float(offset),
        "ticket_broker":        int(ticket_broker),
        "ticket_prop":          int(pending["prop_ticket"]),
        "broker_close_info":    None,
        "prop_close_info":      None,
        "pair_closed_notified": False,
        "closed_source":        None,
    }
    await modifica_dati_async(partial(
        modifier_save_trade_memo,
        ticket_b=int(ticket_broker), ticket_p=int(pending["prop_ticket"]), payload=payload,
    ))


async def _segna_copertura_fallita(pending: Dict[str, Any], motivo: str) -> None:
    """La prop e' aperta e SCOPERTA: stato d'emergenza + solleciti ogni 5 min."""
    await _aggiorna_pending(pending["id"], {"stato": ST_COPERTURA_KO, "motivo_ko": motivo})
    pending["stato"] = ST_COPERTURA_KO
    pending["motivo_ko"] = motivo
    await modifica_dati_async(partial(
        modifier_semiauto_alert_registra,
        prop_ticket=int(pending["prop_ticket"]), broker_ticket=0,
        motivo=ALERT_COPERTURA_KO,
        ora_iso=datetime.now(timezone.utc).isoformat(),
    ))


# ========================= 4) RIFINITURA E CHIUSURA DEL FLUSSO =========================
async def _aggiorna_pending(pending_id: str, updates: Dict[str, Any]) -> None:
    await modifica_dati_async(partial(
        modifier_semiauto_update_pending, pending_id=pending_id, updates=updates,
    ))


async def _chiudi_pending(pending_id: str) -> None:
    """Chiude l'operazione e con essa l'eventuale intento nel giornale.

    Se la copertura era fallita, l'intento e' rimasto li' apposta (vedi
    apri_copertura_broker): quando l'utente chiude il flusso non ha piu' senso
    che il recovery vada a cercare una posizione che non deve esistere.
    """
    await modifica_dati_async(partial(modifier_semiauto_clear_pending, pending_id=pending_id))
    await journal_remove(f"semi-{pending_id}")


# ========================= HANDLER DEI PULSANTI =========================
async def semi_aperta_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    await ack(update.callback_query)
    await _verifica_e_copri(update, context)


async def semi_modificata_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """«Ho modificato la posizione»: si verifica, non si crede sulla parola."""
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    pending = await pending_corrente()
    if not pending or pending.get("stato") != ST_ATTESA_MODIFICA:
        await safe_edit_message_text(
            query, "ℹ️ Questa operazione non è più in corso.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    dati = await carica_dati_async()
    prop = dati.get("prop")
    if not prop:
        await safe_edit_message_text(query, "❌ Credenziali Prop mancanti.",
                                     InlineKeyboardMarkup([back_button("manuale")]))
        return

    await safe_edit_message_text(query, "⏳ Verifico i livelli sulla posizione Prop…")
    snap = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
        pending.get("simbolo_prop") or cfg.SIMBOLO_PROP,
    )
    ticket_p = int(pending.get("prop_ticket", 0) or 0)
    pos = next((p for p in (snap or []) if int(p.get("ticket", 0) or 0) == ticket_p), None)

    if snap is None:
        testo, kb = schermata_rifinitura(
            pending, "⚠️ Terminale Prop non raggiungibile: riprova tra poco.\n\n")
        await safe_edit_message_text(query, testo, kb)
        return
    if pos is None:
        # La posizione prop non c'e' piu': l'utente l'ha chiusa. La copertura
        # broker viene richiusa dal guardiano di coppia entro pochi secondi.
        await _chiudi_pending(pending["id"])
        await safe_edit_message_text(
            query,
            "ℹ️ La posizione Prop risulta CHIUSA.\n\n"
            "Chiudo automaticamente anche la copertura sul Broker: riceverai la "
            "ricevuta con i due P/L tra pochi istanti.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    info_sym_prop = await get_symbol_info_wrapper_async(
        MT5_PROP_EXE, pending.get("simbolo_prop") or cfg.SIMBOLO_PROP,
        pending["direzione_prop"],
    )
    point = float((info_sym_prop or {}).get("point", 0) or 0)
    if point <= 0 or not livelli_gia_esatti(
        pos, float(pending["sl_esatto"]), float(pending["tp_esatto"]),
        point, SEMIAUTO_TOLLERANZA_POINT,
    ):
        d = int(pending.get("digits", 2) or 2)
        avviso = (
            "⚠️ La posizione Prop non risulta ancora impostata sui valori esatti "
            f"(ora ha SL {_fmt_prezzo(pos.get('sl') or 0, d)} e "
            f"TP {_fmt_prezzo(pos.get('tp') or 0, d)}).\n\n"
        )
        testo, kb = schermata_rifinitura(pending, avviso)
        await safe_edit_message_text(query, testo, kb)
        return

    # Livelli esatti confermati: si allineano i valori registrati e si chiude
    # il flusso. Il trade resta vivo e sorvegliato come ogni altro.
    broker_pos = None
    broker = dati.get("broker")
    if broker and pending.get("broker_ticket"):
        broker_pos = _posizione_dict(await get_position_by_ticket_async(
            MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"],
            int(pending["broker_ticket"]),
        ))
    await _chiudi_pending(pending["id"])
    testo, kb = schermata_avviata(pending, broker_pos)
    await safe_edit_message_text(query, testo, kb)


async def semi_copertura_retry_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    pending = await pending_corrente()
    if not pending or pending.get("stato") != ST_COPERTURA_KO:
        await safe_edit_message_text(
            query, "ℹ️ Questa operazione non è più in corso.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return
    await safe_edit_message_text(query, "⏳ Riprovo ad aprire la copertura sul Broker…")

    # La posizione da coprire c'e' ANCORA? Tra il fallimento e questo click
    # possono essere passati minuti, e nel frattempo l'utente puo' aver chiuso
    # la prop (era anzi cio' che gli avevamo chiesto di fare). Aprire adesso la
    # copertura significherebbe lasciare una gamba BROKER nuda a mercato: il
    # danno opposto, e altrettanto vero.
    dati = await carica_dati_async()
    prop = dati.get("prop") or {}
    ticket_p = int(pending.get("prop_ticket", 0) or 0)
    snap = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop.get("id", 0) or 0), prop.get("password", ""),
        prop.get("server", ""), pending.get("simbolo_prop") or cfg.SIMBOLO_PROP,
    ) if prop else None
    if snap is None:
        testo, kb = schermata_copertura_fallita(
            pending, "terminale Prop non raggiungibile: non verifico al buio")
        await safe_edit_message_text(query, testo, kb)
        return
    if ticket_p not in {int(p.get("ticket", 0) or 0) for p in snap}:
        await _chiudi_pending(pending["id"])
        await modifica_dati_async(partial(
            modifier_semiauto_alert_rimuovi, prop_ticket=ticket_p,
        ))
        await safe_edit_message_text(
            query,
            "✅ La posizione Prop risulta CHIUSA: non apro nessuna copertura.\n\n"
            "Non c'è più niente di scoperto, l'operazione è chiusa.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    await _copri_e_mostra(query, context, pending)


async def semi_annulla_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Annulla, con conseguenze diverse a seconda di cosa c'e' gia' a mercato."""
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    pending = await pending_corrente()
    if not pending:
        await safe_edit_message_text(
            query, "ℹ️ Nessuna operazione da annullare.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    stato = pending.get("stato")
    await _chiudi_pending(pending["id"])

    if stato == ST_ATTESA_APERTURA:
        # Niente e' stato aperto da nessuno: si annulla e basta.
        await safe_edit_message_text(
            query, "❌ Operazione annullata. Non è stata aperta nessuna posizione.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    if stato == ST_COPERTURA_KO:
        await safe_edit_message_text(
            query,
            "❌ Operazione annullata.\n\n"
            "⚠️ Verifica che la posizione Prop sia davvero CHIUSA sul tuo "
            "MetaTrader: non essendo coperta, resta esposta al mercato.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    # ST_ATTESA_MODIFICA: la copertura broker E' a mercato. Il bot NON la chiude
    # per primo: lascerebbe la prop scoperta proprio mentre l'utente sta
    # chiudendo. Ordine corretto = prima la prop (a mano), poi il broker (che il
    # guardiano di coppia richiude da solo in un paio di secondi).
    await safe_edit_message_text(
        query,
        "❌ Chiusura dell'operazione.\n\n"
        "👉 Chiudi la posizione Prop dal tuo MetaTrader.\n"
        "Appena la vedo chiusa, chiudo io la copertura sul Broker e ti mando la "
        "ricevuta con i due P/L.\n\n"
        "ℹ️ Non chiudo il Broker per primo: lascerebbe la Prop scoperta.",
        InlineKeyboardMarkup([back_button("manuale")]),
    )


# ========================= RIPRESA DOPO UN RIAVVIO =========================
async def ripristina_semiauto_al_boot(app) -> None:
    """Dopo un riavvio: l'operazione a meta' viene ripresentata all'utente.

    Il messaggio con i pulsanti e' rimasto nella chat ma il bot e' un processo
    nuovo: piuttosto che sperare che l'utente ritrovi quel messaggio, gliene
    mandiamo uno identico e aggiornato. Le istruzioni troppo vecchie invece si
    buttano: i prezzi indicati non valgono piu'.
    """
    pending = await pending_corrente()
    if not pending:
        return
    if pending_scaduto(pending):
        await _chiudi_pending(pending["id"])
        await notifica_owner(app, (
            "⌛ L'apertura semi-automatica in attesa è scaduta "
            f"({SEMIAUTO_PENDING_TTL_MINUTES} minuti senza conferma): i prezzi "
            "indicati non erano più validi.\n\n"
            "Se hai aperto comunque la posizione sulla Prop, chiudila o riapri "
            "il trade dal bot."
        ))
        return
    schermata = schermata_pending(pending)
    if not schermata:
        return
    testo, kb = schermata
    await notifica_owner(app, "🔄 Riprendo l'operazione semi-automatica in corso.\n\n" + testo,
                         reply_markup=kb)
