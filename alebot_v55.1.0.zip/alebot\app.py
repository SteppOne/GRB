import atexit
import logging
import re

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ConversationHandler,
    ContextTypes,
)

logger = logging.getLogger(__name__)

from .config import (
    BR_CONFIRM,
    BR_ID,
    BR_PSW,
    BR_RETRY,
    BR_SERVER,
    CFG_PR_CONFIRM,
    CFG_PR_CONS,
    CFG_PR_COSTO,
    CFG_PR_COSTO_RESET,
    CFG_PR_DDDAILY,
    CFG_PR_DDMAX,
    CFG_PR_FIRM,
    CFG_PR_INCASSO,
    CFG_PR_MODE,
    CFG_PR_SALDO,
    CFG_PR_TARGET,
    CFG_PR_TIPDD,
    CFG_PR_TIPINC,
    CHALLENGE_CONFERMA,
    CHALLENGE_DIREZIONE,
    CHALLENGE_LOTTI,
    CHALLENGE_MINUTI,
    CHIUDI_CONFIRM,
    CONCURRENT_UPDATES,
    CONFERMA,
    COSTO_PROP_AMOUNT,
    INCASSO_MODIFICA_CHIEDI,
    INCASSO_MODIFICA_NUOVO,
    INCASSO_TARGET,
    LOTTI,
    MEMO,
    PAYOUT_AMOUNT,
    PL_BROKER_INIT,
    PROGRAMMA_ORARIO,
    PR_CONFIRM,
    PR_ID,
    PR_PSW,
    PR_RETRY,
    PR_SERVER,
    PWD_CONFIRM,
    PWD_NEW,
    RENEW_ALTRO,
    RENEW_CONFIRM,
    RENEW_METODO,
    RESET_PNL_CONFIRM,
    SIMBOLO_BROKER,
    SL,
    SL_RISCHIO_CONFERMA,
    TEST_CONFIRM,
    TOKEN,
    TP,
    TP_RISCHIO_CONFERMA,
)
from .messaging import ack
from .subscription import admin_channel_document_handler, admin_channel_handler
from .trade_core import stato_trade, stato_trade_cmd
from .loops import (
    _acquire_single_instance_lock,
    _release_single_instance_lock,
    post_init,
    post_shutdown,
)
from .handlers_base import (
    CONV_TIMEOUT_SECONDS,
    annulla_conversazione,
    conversazione_scaduta,
    menu_da_notifica,
    mostra_menu_principale,
    password_message_handler,
    start_handler,
)
from .handlers_menu import (
    apritrade_menu,
    automatico_sviluppo,
    menu_gestisci,
    menu_manuale,
    scegli_direzione,
    sched_cancel_handler,
    storico_menu,
    storico_show_handler,
    trade_programmati_menu,
)
from .handlers_trade import (
    conferma_esegui,
    conferma_programma,
    incasso_modifica_chiedi,
    inizia_compra,
    inizia_vendi,
    programma_indietro,
    ricevi_lotti,
    ricevi_memo,
    ricevi_nuovo_incasso,
    ricevi_orario_programmato,
    ricevi_sl,
    ricevi_tp,
    sl_rischio_conferma,
    tp_rischio_conferma,
)
from .handlers_semiauto import (
    semi_annulla_handler,
    semi_aperta_handler,
    semi_copertura_retry_handler,
    semi_modificata_handler,
)
from .handlers_modalita import (
    menu_comando,
    modalita_comando,
    modalita_set_handler,
)
from .handlers_challenge import (
    challenge_back_to_dir,
    challenge_back_to_lotti,
    challenge_conferma,
    challenge_direzione,
    challenge_exit_menu,
    challenge_lotti,
    challenge_minuti,
    challenge_no,
    challenge_start,
)
from .handlers_account import (
    aggiungi_costo_prop_start,
    imposta_pl_broker_start,
    info_broker,
    info_prop,
    inserisci_payout_start,
    menu_info_account,
    pnl_totale,
    reset_pnl_conferma,
    reset_pnl_start,
    ricevi_costo_prop,
    ricevi_payout,
    ricevi_pl_broker,
)
from .handlers_config import (
    br_confirm_handler,
    br_id_ricevi,
    br_id_start,
    br_psw_ricevi,
    br_retry_handler,
    br_server_ricevi,
    cfg_costo_reset_start,
    cfg_prop_av_start,
    cfg_prop_confirm_handler,
    inizia_modifica_incasso,
    menu_config_broker,
    menu_config_credenziali,
    menu_config_prop,
    menu_configura_op,
    mostra_password_temp,
    pr_confirm_handler,
    pr_id_ricevi,
    pr_id_start,
    pr_psw_ricevi,
    pr_retry_handler,
    pr_server_ricevi,
    ricevi_cfg_pr_cons,
    ricevi_cfg_pr_costo,
    ricevi_cfg_pr_dddaily,
    ricevi_cfg_pr_ddmax,
    ricevi_cfg_pr_firm,
    ricevi_cfg_pr_incasso,
    ricevi_cfg_pr_mode,
    ricevi_cfg_pr_saldo,
    ricevi_cfg_pr_target,
    ricevi_cfg_pr_tipdd_callback,
    ricevi_cfg_pr_tipinc_callback,
    ricevi_costo_reset_standalone,
    ricevi_incasso_target,
    salva_broker_whitelist,
    scegli_broker_whitelist,
    vis_broker_av,
    vis_prop_av,
    visualizza_credenziali,
)
from .handlers_system import (
    diag_broker,
    diag_prop,
    menu_diagnosi,
    ota_documento_privato,
    renew_altro_ricevi,
    renew_metodo,
    renew_no,
    renew_start,
    renew_yes,
    riavvia_bot_conferma,
    riavvia_bot_start,
    riavvia_broker,
    riavvia_prop,
    stato_bot,
)
from .handlers_ops import (
    annulla_operazione,
    annulla_test,
    cambia_password_start,
    chiudi_trade_conferma,
    chiudi_trade_start,
    conferma_no,
    conferma_nuova_pwd,
    error_handler,
    esegui_test,
    info_bot,
    notizie,
    ricevi_nuova_pwd,
    test_trading_start,
)

# ========================= MAIN =========================
# ===== Uscita pulita dalle conversazioni (anti "conversazione appesa") =====
# Se premi un pulsante di NAVIGAZIONE del menu (o /start) mentre un flusso e'
# aperto a meta', la conversazione DEVE terminare: altrimenti resta "appesa" e
# ruba l'input testuale di un altro flusso (es. apertura trade che intercetta i
# numeri della modifica incasso / configura prop). Mappa callback -> menu.
NAV_HANDLERS = {
    "indietro":              mostra_menu_principale,
    "gestisci":              menu_gestisci,
    "manuale":               menu_manuale,
    "configura_op":          menu_configura_op,
    "config_prop":           menu_config_prop,
    "config_broker":         menu_config_broker,
    "configura_credenziali": menu_config_credenziali,
    "diagnosi":              menu_diagnosi,
    "info":                  info_bot,
    "info_account_menu":     menu_info_account,
    "apritrade":             apritrade_menu,
    "vai_menu":              menu_da_notifica,
}
NAV_PATTERN = "^(" + "|".join(NAV_HANDLERS.keys()) + ")$"

async def _esci_e_naviga(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Fallback comune: termina la conversazione attiva e mostra il menu richiesto."""
    q = update.callback_query
    handler = NAV_HANDLERS.get(q.data) if q else None
    if handler is not None:
        await handler(update, context)
    elif q:
        await ack(q)
    return ConversationHandler.END

async def _esci_e_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Fallback comune: /start termina qualsiasi conversazione e riparte pulito."""
    await start_handler(update, context)
    return ConversationHandler.END

async def _esci_e_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Fallback comune: /help termina la conversazione e mostra il menu principale."""
    await mostra_menu_principale(update, context)
    return ConversationHandler.END

async def _esci_e_stato(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Fallback comune: /stato termina la conversazione e mostra lo Stato Trade."""
    await stato_trade_cmd(update, context)
    return ConversationHandler.END

async def _esci_e_riavvia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Fallback comune: /riavvia termina la conversazione e avvia la procedura di riavvio."""
    await riavvia_bot_start(update, context)
    return ConversationHandler.END

async def _esci_e_modalita(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Fallback comune: /modalita termina la conversazione e mostra/cambia la modalità."""
    await modalita_comando(update, context)
    return ConversationHandler.END

def _escape_fallbacks() -> list:
    """Fallback aggiunti a OGNI conversazione: /start, /help, /menu, /stato,
    /riavvia, /modalita e i pulsanti di navigazione del menu chiudono il flusso
    corrente, cosi' non resta appeso a rubare l'input testuale di un altro flusso."""
    return [
        CommandHandler("start",    _esci_e_start,    filters=filters.ChatType.PRIVATE),
        CommandHandler("help",     _esci_e_help,     filters=filters.ChatType.PRIVATE),
        CommandHandler("menu",     _esci_e_help,     filters=filters.ChatType.PRIVATE),
        CommandHandler("stato",    _esci_e_stato,    filters=filters.ChatType.PRIVATE),
        CommandHandler("riavvia",  _esci_e_riavvia,  filters=filters.ChatType.PRIVATE),
        CommandHandler("modalita", _esci_e_modalita, filters=filters.ChatType.PRIVATE),
        CallbackQueryHandler(_esci_e_naviga, pattern=NAV_PATTERN),
    ]

def _stato_timeout() -> list:
    """Blocco TIMEOUT standard, identico per ogni conversazione."""
    return [
        MessageHandler(filters.ALL, conversazione_scaduta),
        CallbackQueryHandler(conversazione_scaduta),
    ]

def _fallbacks_standard(annulla_cb=None, pattern: str = "^annulla$") -> list:
    """Fallbacks comuni a ogni conversazione: pulsante Annulla (se il flusso lo
    prevede), comando /annulla e i fallback di uscita (_escape_fallbacks)."""
    righe = []
    if annulla_cb is not None:
        righe.append(CallbackQueryHandler(annulla_cb, pattern=pattern))
    righe.append(CommandHandler("annulla", annulla_conversazione))
    return righe + _escape_fallbacks()

def main():
    if not _acquire_single_instance_lock():
        return
    atexit.register(_release_single_instance_lock)
    from . import __version__
    logger.info(f"AleBot v{__version__} in avvio.")

    # concurrent_updates: SENZA questo python-telegram-bot processa UN update
    # alla volta. Bastava quindi un solo handler lento su MT5 (un riavvio
    # terminale, una lettura con il terminale che chiede la password) per
    # bloccare TUTTO il bot: /start compreso. E' esattamente cio' che vedevano
    # gli utenti — "il bot non risponde piu' a niente" — dopo aver premuto
    # Riavvia terminale. Con piu' slot, un comando lento non mette in coda
    # gli altri. Il valore resta basso di proposito: il bot ha un solo
    # proprietario, non serve parallelismo, serve non congelarsi mai.
    app = (
        Application.builder()
        .token(TOKEN)
        .concurrent_updates(CONCURRENT_UPDATES)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )

    # Comandi privati (start/help/stato/riavvia): solo in chat 1-1, mai dai canali.
    # Sono registrati DOPO le conversazioni (vedi piu' sotto): cosi', se arrivano
    # durante un flusso attivo, vengono intercettati dai fallback della conversazione
    # (_esci_e_*) che la chiudono, invece di lasciarla appesa a rubare input.
    _priv = filters.ChatType.PRIVATE

    # Apertura trade
    apri_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(inizia_compra, pattern="^compra$"),
            CallbackQueryHandler(inizia_vendi,  pattern="^vendi$"),
        ],
        states={
            SL:    [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_sl)],
            SL_RISCHIO_CONFERMA: [
                CallbackQueryHandler(sl_rischio_conferma, pattern="^slrisk_(si|no)$"),
            ],
            TP:    [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_tp)],
            TP_RISCHIO_CONFERMA: [
                CallbackQueryHandler(tp_rischio_conferma, pattern="^tprisk_(si|no)$"),
            ],
            LOTTI: [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_lotti)],
            INCASSO_MODIFICA_CHIEDI: [
                CallbackQueryHandler(incasso_modifica_chiedi, pattern="^incmod_(si|no)$"),
            ],
            INCASSO_MODIFICA_NUOVO: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_nuovo_incasso),
            ],
            MEMO:  [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_memo)],
            CONFERMA: [
                CallbackQueryHandler(conferma_esegui,    "^conferma_si$"),
                CallbackQueryHandler(conferma_programma, "^conferma_programma$"),
                CallbackQueryHandler(conferma_no,        "^conferma_no$"),
            ],
            PROGRAMMA_ORARIO: [
                CallbackQueryHandler(programma_indietro, "^programma_indietro$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_orario_programmato),
            ],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_operazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(apri_conv)

    # Trade minimo per giorno (trade-sfida: singolo, solo Prop, no hedge)
    challenge_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(challenge_start, pattern="^trademin$")],
        states={
            CHALLENGE_DIREZIONE: [
                CallbackQueryHandler(challenge_direzione,  pattern="^chal_(buy|sell)$"),
                CallbackQueryHandler(challenge_exit_menu,  pattern="^chal_back_menu$"),
            ],
            CHALLENGE_LOTTI: [
                CallbackQueryHandler(challenge_back_to_dir, pattern="^chal_back_dir$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, challenge_lotti),
            ],
            CHALLENGE_MINUTI: [
                CallbackQueryHandler(challenge_back_to_lotti, pattern="^chal_back_lotti$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, challenge_minuti),
            ],
            CHALLENGE_CONFERMA: [
                CallbackQueryHandler(challenge_conferma, pattern="^chal_si$"),
                CallbackQueryHandler(challenge_no,       pattern="^chal_no$"),
            ],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_operazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(challenge_conv)

    # Credenziali Broker
    br_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(br_id_start, pattern="^cfg_broker_cred$")],
        states={
            BR_ID:     [MessageHandler(filters.TEXT & ~filters.COMMAND, br_id_ricevi)],
            BR_PSW:    [MessageHandler(filters.TEXT & ~filters.COMMAND, br_psw_ricevi)],
            BR_SERVER: [MessageHandler(filters.TEXT & ~filters.COMMAND, br_server_ricevi)],
            BR_CONFIRM: [CallbackQueryHandler(br_confirm_handler, pattern="^br_confirm_")],
            BR_RETRY:   [CallbackQueryHandler(br_retry_handler,   pattern="^br_retry$")],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_conversazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(br_conv)

    # Credenziali Prop
    pr_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(pr_id_start, pattern="^cfg_prop_cred$")],
        states={
            PR_ID:     [MessageHandler(filters.TEXT & ~filters.COMMAND, pr_id_ricevi)],
            PR_PSW:    [MessageHandler(filters.TEXT & ~filters.COMMAND, pr_psw_ricevi)],
            PR_SERVER: [MessageHandler(filters.TEXT & ~filters.COMMAND, pr_server_ricevi)],
            PR_CONFIRM: [CallbackQueryHandler(pr_confirm_handler, pattern="^pr_confirm_")],
            PR_RETRY:   [CallbackQueryHandler(pr_retry_handler,   pattern="^pr_retry$")],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_conversazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(pr_conv)

    # Modifica incasso
    incasso_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(inizia_modifica_incasso, pattern="^cfg_incasso$")],
        states={
            INCASSO_TARGET: [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_incasso_target)],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_conversazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(incasso_conv)

    # Configurazione Prop avanzata
    cfg_pr_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cfg_prop_av_start, pattern="^cfg_prop_av$")],
        states={
            CFG_PR_FIRM:    [CallbackQueryHandler(ricevi_cfg_pr_firm, pattern=r"^prop_firm\|")],
            CFG_PR_MODE:    [CallbackQueryHandler(ricevi_cfg_pr_mode, pattern="^prop_mode_")],
            CFG_PR_SALDO:   [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_cfg_pr_saldo)],
            CFG_PR_TARGET:  [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_cfg_pr_target)],
            CFG_PR_DDMAX:   [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_cfg_pr_ddmax)],
            CFG_PR_DDDAILY: [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_cfg_pr_dddaily)],
            CFG_PR_COSTO:   [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_cfg_pr_costo)],
            CFG_PR_INCASSO: [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_cfg_pr_incasso)],
            CFG_PR_TIPINC:  [CallbackQueryHandler(ricevi_cfg_pr_tipinc_callback, pattern="^tipinc_")],
            CFG_PR_TIPDD:   [CallbackQueryHandler(ricevi_cfg_pr_tipdd_callback,  pattern="^tipdd_")],
            CFG_PR_CONS:    [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_cfg_pr_cons)],
            CFG_PR_CONFIRM: [CallbackQueryHandler(cfg_prop_confirm_handler, pattern="^prop_confirm_")],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_conversazione, "^cfg_prop_av_annulla$"),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(cfg_pr_conv)

    # Costo reset standalone
    costo_reset_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cfg_costo_reset_start, pattern="^cfg_costo_reset$")],
        states={
            CFG_PR_COSTO_RESET: [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_costo_reset_standalone)],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_conversazione, "^annulla_costo_reset$"),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(costo_reset_conv)

    # Payout
    payout_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(inserisci_payout_start, "^inserisci_payout$")],
        states={
            PAYOUT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_payout)],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_conversazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(payout_conv)

    # Aggiungi costo prop (cumulativo)
    costo_prop_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(aggiungi_costo_prop_start, "^aggiungi_costo_prop$")],
        states={
            COSTO_PROP_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_costo_prop)],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_conversazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(costo_prop_conv)

    # Imposta P/L broker realizzato (seeding/correzione)
    pl_broker_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(imposta_pl_broker_start, "^imposta_pl_broker$")],
        states={
            PL_BROKER_INIT: [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_pl_broker)],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_conversazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(pl_broker_conv)

    # Reset P/L
    reset_pnl_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(reset_pnl_start, pattern="^reset_pnl$")],
        states={
            RESET_PNL_CONFIRM: [
                CallbackQueryHandler(reset_pnl_conferma, pattern="^reset_pnl_si$"),
                CallbackQueryHandler(reset_pnl_conferma, pattern="^reset_pnl_no$"),
            ],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(reset_pnl_conv)

    # Cambio password
    pwd_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cambia_password_start, "^cambia_pwd$")],
        states={
            PWD_NEW:     [MessageHandler(filters.TEXT & ~filters.COMMAND, ricevi_nuova_pwd)],
            PWD_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, conferma_nuova_pwd)],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_conversazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(pwd_conv)

    # Test trading
    test_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(test_trading_start, "^test_trading$")],
        states={
            TEST_CONFIRM: [
                CallbackQueryHandler(esegui_test,  "^test_si$"),
                CallbackQueryHandler(annulla_test, "^test_no$"),
            ],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(test_conv)

    # Chiudi trade
    chiudi_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(chiudi_trade_start, pattern="^chiuditrade$")],
        states={
            CHIUDI_CONFIRM: [
                CallbackQueryHandler(chiudi_trade_conferma, pattern="^chiudi_si$"),
                CallbackQueryHandler(chiudi_trade_conferma, pattern="^chiudi_no$"),
            ],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_operazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(chiudi_conv)

    # Rinnovo abbonamento (segnalazione pagamento). Registrata per ULTIMA tra le
    # conversazioni: l'unico suo stato testuale (RENEW_ALTRO) non deve mai avere
    # priorita' sull'input dei flussi di trading in caso di conversazioni appese.
    renew_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(renew_start, pattern="^renew_start$"),
            # Entry diretti dai pulsanti sugli avvisi di scadenza:
            CallbackQueryHandler(renew_yes,   pattern="^renew_yes$"),
            CallbackQueryHandler(renew_no,    pattern="^renew_no$"),
        ],
        states={
            RENEW_CONFIRM: [
                CallbackQueryHandler(renew_yes, pattern="^renew_yes$"),
                CallbackQueryHandler(renew_no,  pattern="^renew_no$"),
            ],
            RENEW_METODO: [
                CallbackQueryHandler(renew_metodo, pattern=r"^renew_via\|"),
                # Click ripetuto su un vecchio avviso mentre si e' gia' qui:
                # rimostra la scelta del metodo invece di restare muto.
                CallbackQueryHandler(renew_yes,    pattern="^renew_yes$"),
            ],
            RENEW_ALTRO: [MessageHandler(filters.TEXT & ~filters.COMMAND, renew_altro_ricevi)],
            ConversationHandler.TIMEOUT: _stato_timeout(),
        },
        fallbacks=_fallbacks_standard(annulla_operazione),
        conversation_timeout=CONV_TIMEOUT_SECONDS,
    )
    app.add_handler(renew_conv)

    # Comandi globali registrati DOPO le conversazioni: durante un flusso attivo
    # vengono intercettati dai fallback della conversazione (_esci_e_*) che la
    # chiudono; fuori da ogni conversazione ricadono qui sui rispettivi handler.
    app.add_handler(CommandHandler("start",    start_handler,          filters=_priv))
    app.add_handler(CommandHandler("help",     mostra_menu_principale, filters=_priv))
    # /menu: stesso menu di /help. E' il nome usato dai messaggi della modalita'
    # semi-automatica ("digitando /menu") e resta valido in entrambe.
    app.add_handler(CommandHandler("menu",     menu_comando,           filters=_priv))
    app.add_handler(CommandHandler("stato",    stato_trade_cmd,        filters=_priv))
    app.add_handler(CommandHandler("riavvia",  riavvia_bot_start,      filters=_priv))
    app.add_handler(CommandHandler("modalita", modalita_comando,       filters=_priv))

    # Callback semplici
    app.add_handler(CallbackQueryHandler(menu_gestisci,           pattern="^gestisci$"))
    app.add_handler(CallbackQueryHandler(menu_manuale,            pattern="^manuale$"))
    app.add_handler(CallbackQueryHandler(trade_programmati_menu,  pattern="^trade_programmati$"))
    app.add_handler(CallbackQueryHandler(sched_cancel_handler,    pattern=r"^sched_cancel\|"))
    app.add_handler(CallbackQueryHandler(storico_menu,           pattern="^storico_trade$"))
    app.add_handler(CallbackQueryHandler(storico_show_handler,    pattern=r"^storico_show\|"))
    app.add_handler(CallbackQueryHandler(apritrade_menu,          pattern="^apritrade$"))
    app.add_handler(CallbackQueryHandler(scegli_direzione,        pattern="^" + re.escape(SIMBOLO_BROKER) + "$"))
    app.add_handler(CallbackQueryHandler(menu_info_account,       pattern="^info_account_menu$"))
    app.add_handler(CallbackQueryHandler(menu_diagnosi,           pattern="^diagnosi$"))
    app.add_handler(CallbackQueryHandler(menu_configura_op,       pattern="^configura_op$"))
    app.add_handler(CallbackQueryHandler(menu_config_credenziali, pattern="^configura_credenziali$"))
    app.add_handler(CallbackQueryHandler(visualizza_credenziali,  pattern="^visualizza_cred$"))
    app.add_handler(CallbackQueryHandler(mostra_password_temp,    pattern="^mostra_pwd$"))
    app.add_handler(CallbackQueryHandler(info_broker,             pattern="^info_broker$"))
    app.add_handler(CallbackQueryHandler(info_prop,               pattern="^info_prop$"))
    app.add_handler(CallbackQueryHandler(pnl_totale,              pattern="^pnl_tot$"))
    app.add_handler(CallbackQueryHandler(menu_config_broker,      pattern="^config_broker$"))
    app.add_handler(CallbackQueryHandler(scegli_broker_whitelist, pattern="^cfg_broker_scelta$"))
    app.add_handler(CallbackQueryHandler(salva_broker_whitelist,  pattern=r"^set_broker\|"))
    app.add_handler(CallbackQueryHandler(vis_broker_av,           pattern="^vis_broker_av$"))
    app.add_handler(CallbackQueryHandler(menu_config_prop,        pattern="^config_prop$"))
    app.add_handler(CallbackQueryHandler(vis_prop_av,             pattern="^vis_prop_av$"))
    app.add_handler(CallbackQueryHandler(diag_broker,             pattern="^diag_broker$"))
    app.add_handler(CallbackQueryHandler(diag_prop,               pattern="^diag_prop$"))
    app.add_handler(CallbackQueryHandler(stato_bot,               pattern="^stato_bot$"))
    app.add_handler(CallbackQueryHandler(notizie,                 pattern="^notizie$"))
    app.add_handler(CallbackQueryHandler(info_bot,                pattern="^info$"))
    app.add_handler(CallbackQueryHandler(riavvia_broker,          pattern="^riavvia_broker$"))
    app.add_handler(CallbackQueryHandler(riavvia_prop,            pattern="^riavvia_prop$"))
    app.add_handler(CallbackQueryHandler(riavvia_bot_start,       pattern="^riavvia_bot$"))
    app.add_handler(CallbackQueryHandler(riavvia_bot_conferma,    pattern="^riavvia_bot_(si|no)$"))
    app.add_handler(CallbackQueryHandler(mostra_menu_principale,  pattern="^indietro$"))
    app.add_handler(CallbackQueryHandler(menu_da_notifica,        pattern="^vai_menu$"))
    app.add_handler(CallbackQueryHandler(modalita_set_handler,    pattern=r"^mod_set\|"))

    # ── Apertura SEMI-AUTOMATICA ────────────────────────────────────────────
    # Volutamente FUORI da ogni ConversationHandler: tra un pulsante e l'altro
    # l'utente deve andare sul telefono ad aprire la posizione, e una
    # conversazione scadrebbe dopo 5 minuti (e morirebbe a ogni riavvio del
    # bot). Lo stato del flusso vive su disco, vedi handlers_semiauto.
    app.add_handler(CallbackQueryHandler(semi_aperta_handler,           pattern="^semi_aperta$"))
    app.add_handler(CallbackQueryHandler(semi_aperta_handler,           pattern="^semi_ricontrolla$"))
    app.add_handler(CallbackQueryHandler(semi_modificata_handler,       pattern="^semi_modificata$"))
    app.add_handler(CallbackQueryHandler(semi_copertura_retry_handler,  pattern="^semi_copertura_retry$"))
    app.add_handler(CallbackQueryHandler(semi_annulla_handler,          pattern="^semi_annulla$"))

    # Placeholders
    app.add_handler(CallbackQueryHandler(stato_trade,                pattern="^statotrade$"))
    app.add_handler(CallbackQueryHandler(automatico_sviluppo,        pattern="^automatico$"))

    # Aggiornamento OTA via documento in CHAT PRIVATA (via di riserva quando il
    # canale admin non collabora). Non tocca i flussi testuali: filtra documenti.
    app.add_handler(MessageHandler(
        filters.ChatType.PRIVATE & filters.Document.ALL, ota_documento_privato,
    ))

    # Handler password (ultimo: intercetta solo messaggi non consumati da conversation).
    # Solo chat private: i channel post del canale admin non devono mai arrivare qui.
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE, password_message_handler,
    ))

    # Comandi dal canale admin (abbonamento + flotta). Gruppo separato: i channel
    # post non interferiscono con le conversazioni private e viceversa.
    app.add_handler(
        MessageHandler(filters.UpdateType.CHANNEL_POST & filters.TEXT, admin_channel_handler),
        group=1,
    )
    # Aggiornamento OTA via DOCUMENTO: zip del pacchetto postato nel canale
    # admin con didascalia "/aggiorna <CLIENT_ID|tutti> [sha256]".
    app.add_handler(
        MessageHandler(
            filters.UpdateType.CHANNEL_POST & filters.Document.ALL,
            admin_channel_document_handler,
        ),
        group=1,
    )

    app.add_error_handler(error_handler)

    app.run_polling()


if __name__ == "__main__":
    main()
