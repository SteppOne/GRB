﻿"""AleBot - bot Telegram di hedging broker/prop (pacchetto)."""

__version__ = "55.1.0"
