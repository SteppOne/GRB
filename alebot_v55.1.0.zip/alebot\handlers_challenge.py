import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial
from typing import Optional, Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    ConversationHandler,
    ContextTypes,
)

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    CHALLENGE_CONFERMA,
    CHALLENGE_DIREZIONE,
    CHALLENGE_LOTTI,
    CHALLENGE_MINUTI,
    MT5_PROP_EXE,
)
from .messaging import ack, back_button, notifica_owner, safe_edit_message_text
from .storage import carica_dati_async, modifica_dati_async
from .state import modifier_add_challenge_trade, modifier_set_challenge_status
from .mt5_sync import MSG_AUTOTRADING_OFF
from .mt5_async import (
    chiudi_posizione_async,
    esegui_ordine_async,
    get_position_close_info_async,
    posizione_aperta_async,
    valida_simbolo_volume_async,
)
from .modalita import semiauto_attiva
from .trade_core import genera_magic
from .hedge_journal import journal_put, journal_remove, journal_update
from .news import trading_bloccato_ora_o_news
from .handlers_base import guard_auth
from .handlers_menu import _blocco_per_programmati, menu_manuale

# ========================= TRADE MINIMO PER GIORNO (TRADE-SFIDA) =========================
# Apre UN SOLO trade sulla Prop (niente hedge sul broker), senza SL/TP, e lo
# chiude automaticamente dopo i minuti indicati. Serve a marcare un "giorno di
# trading" per la regola della prop sui giorni minimi.

_CHALLENGE_DIR_TEXT = (
    "🎯 Trade minimo per giorno\n\n"
    "Apre un singolo trade sulla Prop (no hedge), che verrà chiuso "
    "automaticamente dopo i minuti che indichi.\n\nScegli la direzione:"
)
_CHALLENGE_LOTTI_TEXT = "🎯 Trade minimo giornaliero\n\nInserisci i lotti da aprire sulla prop:"
_CHALLENGE_MINUTI_TEXT = (
    "Dopo quanti minuti deve essere chiuso il trade?\n(es: 0.5 = 30 secondi)"
)

def _challenge_dir_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🟢 Compra", callback_data="chal_buy"),
         InlineKeyboardButton("🔴 Vendi",  callback_data="chal_sell")],
        [InlineKeyboardButton("⬅️ Indietro", callback_data="chal_back_menu")],
    ])

def _challenge_back_kb(callback: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Indietro", callback_data=callback)]])

def _fmt_minuti(minuti: float) -> str:
    if minuti < 1:
        return f"{int(round(minuti * 60))} secondi"
    if float(minuti).is_integer():
        n = int(minuti)
        return "1 minuto" if n == 1 else f"{n} minuti"
    return f"{minuti:g} minuti"

async def _apri_challenge_trade(
    direzione: str, lotti: float, minuti: float,
) -> Tuple[bool, str, Optional[int], Optional[str]]:
    """Apre il singolo trade sulla Prop, SENZA SL/TP.
    Ritorna (ok, msg, ticket, journal_id): il chiamante DEVE chiudere l'intento
    nel giornale (journal_remove) DOPO aver registrato il trade in
    challenge_trades — e' cio' che rende il flusso a prova di crash."""
    dati = await carica_dati_async()
    prop = dati.get("prop")
    if not prop:
        return False, "❌ Credenziali Prop mancanti.", None, None
    valid_p, err_p = await valida_simbolo_volume_async(MT5_PROP_EXE, cfg.SIMBOLO_PROP, lotti)
    if not valid_p:
        return False, f"❌ Volume non valido per la Prop ({lotti}): {err_p}", None, None
    magic  = await genera_magic()
    # Intento su disco PRIMA dell'ordine: un trade-sfida non ha SL/TP, quindi
    # un crash tra ordine e registrazione lascerebbe una posizione APERTA e
    # invisibile. Col giornale, il recovery la ritrova (per magic) e ripristina
    # il piano di chiusura originale.
    journal_id = uuid.uuid4().hex[:8]
    await journal_put(
        journal_id, kind="challenge_open", status="ordering", magic=magic,
        direzione=direzione, lotti=lotti, minuti=minuti,
    )
    ticket, motivo = await esegui_ordine_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
        direzione, cfg.SIMBOLO_PROP, lotti,
        0.0, 0.0,            # nessun SL/TP: chiusura solo a tempo
        "", magic,
    )
    if not ticket:
        await journal_remove(journal_id)   # niente e' andato a mercato
        return False, f"❌ Apertura trade-sfida fallita.\nMotivo: {motivo or 'non disponibile'}.", None, None
    await journal_update(journal_id, ticket=int(ticket), status="opened")
    return True, "ok", int(ticket), journal_id

def _modifier_challenge_ritenta(d: dict, trade_id: str) -> Optional[dict]:
    """Riporta il trade-sfida a 'open' (cosi' il backstop riprova) e marca che
    l'owner e' gia' stato avvisato: il ritentativo va ripetuto, l'avviso no."""
    for t in d.get("challenge_trades", []):
        if isinstance(t, dict) and t.get("id") == trade_id:
            t["status"] = "open"
            t["chiusura_alert"] = True
            return d
    return None

async def _chiudi_challenge(app: Application, trade_id: str) -> None:
    """Chiude un trade-sfida (claim atomico open->closing), estrae il P/L e notifica."""
    # Claim atomico: passa a "closing" SOLO se ancora "open" (no doppia chiusura
    # tra timer preciso e backstop).
    claim = {"ok": False, "rec": None}
    def _claim(d):
        for t in d.get("challenge_trades", []):
            if isinstance(t, dict) and t.get("id") == trade_id:
                if t.get("status") == "open":
                    t["status"] = "closing"
                    claim["ok"]  = True
                    claim["rec"] = dict(t)
                    return d
                return None
        return None
    await modifica_dati_async(_claim)
    if not claim["ok"]:
        return

    rec  = claim["rec"]
    dati = await carica_dati_async()
    prop = dati.get("prop")
    ticket = int(rec.get("prop_ticket", 0) or 0)
    if not prop or ticket <= 0:
        logger.error(f"Chiusura trade-sfida {trade_id}: credenziali/ticket non validi.")
        await modifica_dati_async(partial(modifier_set_challenge_status, trade_id=trade_id, status="open"))
        return

    success = await chiudi_posizione_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], ticket,
    )
    if not success:
        # ATTENZIONE: chiudi_posizione_async ritorna False in DUE casi molto
        # diversi — "la chiusura e' stata rifiutata" e "la posizione non esiste
        # piu'". Trattarli allo stesso modo era un bug grave: se il trade era
        # gia' stato chiuso altrove (chiusura serale, blocco news, chiusura
        # manuale, SL/TP del broker) lo stato tornava "open", il backstop lo
        # ritrovava scaduto un minuto dopo e il ciclo ripartiva — con un avviso
        # all'owner OGNI MINUTO, per sempre, perche' modifier_cleanup_challenge
        # purga solo gli stati terminali. Ora si chiede a MT5 come stanno
        # davvero le cose prima di concludere.
        ancora_aperta = await posizione_aperta_async(
            MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], ticket,
        )
        if ancora_aperta is False:
            logger.info(
                f"Trade-sfida {trade_id}: ticket {ticket} risulta gia' chiuso "
                f"(chiusura di massa o SL/TP). Marco come chiuso."
            )
            # Stato terminale: il backstop non lo riprendera' piu', quindi
            # questa notifica parte una volta sola per definizione.
            await modifica_dati_async(partial(
                modifier_set_challenge_status, trade_id=trade_id, status="closed"))
            await notifica_owner(
                app,
                f"🎯 Trade sfida (ticket {ticket}) risultava già chiuso "
                f"a mercato: nessuna posizione lasciata aperta.",
                reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
            )
            return
        # Aperta davvero (o stato incerto: MT5 irraggiungibile) -> si ritenta.
        # L'avviso parte UNA volta sola: il backstop riprova comunque ogni
        # minuto e non deve trasformarsi in una raffica di notifiche.
        await modifica_dati_async(partial(
            _modifier_challenge_ritenta, trade_id=trade_id))
        if not rec.get("chiusura_alert"):
            await notifica_owner(
                app,
                f"⚠️ Chiusura automatica trade-sfida (ticket {ticket}) fallita. "
                f"Riproverò ogni minuto; se persiste, chiudi manualmente."
            )
        return

    close_info = await get_position_close_info_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"],
        ticket, rec.get("opened_at_utc"),
    )
    await modifica_dati_async(partial(modifier_set_challenge_status, trade_id=trade_id, status="closed"))
    if close_info:
        pnl = float(close_info.get("profit", 0.0) or 0.0)
        await notifica_owner(
            app,
            f"🎯 Trade sfida chiuso automaticamente.\nGuadagno/perdita Prop: {pnl:+.2f}$",
            reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
        )
    else:
        await notifica_owner(
            app,
            f"🎯 Trade sfida chiuso automaticamente (ticket {ticket}).\n"
            f"P/L non disponibile dalla history.",
            reply_markup=InlineKeyboardMarkup([back_button("vai_menu")]),
        )

async def _close_challenge_after(app: Application, trade_id: str, delay_seconds: float) -> None:
    """Timer preciso: dorme i secondi esatti e poi chiude il trade-sfida."""
    try:
        await asyncio.sleep(max(0.0, delay_seconds))
    except asyncio.CancelledError:
        return
    try:
        await _chiudi_challenge(app, trade_id)
    except Exception:
        logger.exception(f"Errore nella chiusura programmata del trade-sfida {trade_id}.")

async def challenge_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    # In semi-automatica il pulsante non c'e': questa e' la difesa contro un
    # click su un menu vecchio rimasto in chat. Il trade-sfida apre sulla PROP,
    # e con la sola lettura il bot non puo'.
    if await semiauto_attiva():
        await safe_edit_message_text(
            query,
            "⛔ In modalità semi-automatica il «Trade minimo per giorno» non è "
            "disponibile: aprirebbe una posizione sulla Prop, che il bot non può "
            "comandare.\n\nAprilo e chiudilo a mano dal tuo MetaTrader.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    bloccato, motivo = await trading_bloccato_ora_o_news()
    if bloccato:
        await safe_edit_message_text(
            query, f"⛔ {motivo}", InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    # Un hedge programmato in attesa scatterebbe sulla stessa prop dove sta per
    # aprirsi questo trade: due posizioni contemporanee, contro la regola "un
    # trade alla volta". Si blocca qui, dove costa zero.
    bloccato_prog, motivo_prog = await _blocco_per_programmati()
    if bloccato_prog:
        await safe_edit_message_text(
            query, motivo_prog, InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    for k in ("challenge_direzione", "challenge_lotti", "challenge_minuti"):
        context.user_data.pop(k, None)
    await safe_edit_message_text(query, _CHALLENGE_DIR_TEXT, _challenge_dir_kb())
    return CHALLENGE_DIREZIONE

async def challenge_direzione(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    context.user_data["challenge_direzione"] = "BUY" if query.data == "chal_buy" else "SELL"
    await safe_edit_message_text(query, _CHALLENGE_LOTTI_TEXT, _challenge_back_kb("chal_back_dir"))
    return CHALLENGE_LOTTI

async def challenge_back_to_dir(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, _CHALLENGE_DIR_TEXT, _challenge_dir_kb())
    return CHALLENGE_DIREZIONE

async def challenge_exit_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await menu_manuale(update, context)
    return ConversationHandler.END

async def challenge_lotti(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
        if val <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "Valore non valido. Inserisci un numero positivo per i lotti.",
            reply_markup=_challenge_back_kb("chal_back_dir"),
        )
        return CHALLENGE_LOTTI
    context.user_data["challenge_lotti"] = val
    await update.message.reply_text(_CHALLENGE_MINUTI_TEXT, reply_markup=_challenge_back_kb("chal_back_lotti"))
    return CHALLENGE_MINUTI

async def challenge_back_to_lotti(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, _CHALLENGE_LOTTI_TEXT, _challenge_back_kb("chal_back_dir"))
    return CHALLENGE_LOTTI

async def challenge_minuti(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
        if val <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "Valore non valido. Inserisci i minuti come numero positivo (es: 0.5).",
            reply_markup=_challenge_back_kb("chal_back_lotti"),
        )
        return CHALLENGE_MINUTI
    if val > 1440:
        await update.message.reply_text(
            "Massimo 1440 minuti (24h). Inserisci un valore più basso.",
            reply_markup=_challenge_back_kb("chal_back_lotti"),
        )
        return CHALLENGE_MINUTI
    context.user_data["challenge_minuti"] = val

    direzione = context.user_data.get("challenge_direzione", "BUY")
    lotti     = float(context.user_data.get("challenge_lotti", 0) or 0)
    dir_label = "Compra" if direzione == "BUY" else "Vendi"
    recap = (
        "🎯 Trade minimo per giorno - Riepilogo\n\n"
        "I dati inseriti sono corretti?\n\n"
        f"Direzione: {dir_label}\n"
        f"Lotti prop: {lotti:g}\n"
        f"Minuti: {val:g}"
    )
    keyboard = [
        [InlineKeyboardButton("✅ Sì", callback_data="chal_si")],
        [InlineKeyboardButton("✏️ No, modifica", callback_data="chal_no")],
        [InlineKeyboardButton("❌ Annulla", callback_data="annulla")],
    ]
    await update.message.reply_text(recap, reply_markup=InlineKeyboardMarkup(keyboard))
    return CHALLENGE_CONFERMA

async def challenge_no(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, _CHALLENGE_DIR_TEXT, _challenge_dir_kb())
    return CHALLENGE_DIREZIONE

async def challenge_conferma(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    if not await guard_auth(update, context):
        return ConversationHandler.END

    bloccato, motivo = await trading_bloccato_ora_o_news()
    if bloccato:
        await safe_edit_message_text(
            query, f"⛔ {motivo}", InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END
    # Ricontrollo alla CONFERMA: tra la configurazione e il click possono
    # essere passati minuti, e nel frattempo puo' essere stato programmato un
    # hedge sulla stessa prop.
    bloccato_prog, motivo_prog = await _blocco_per_programmati()
    if bloccato_prog:
        await safe_edit_message_text(
            query, motivo_prog, InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    direzione = context.user_data.get("challenge_direzione", "BUY")
    lotti     = float(context.user_data.get("challenge_lotti", 0) or 0)
    minuti    = float(context.user_data.get("challenge_minuti", 0) or 0)
    if lotti <= 0 or minuti <= 0:
        await safe_edit_message_text(
            query, "⚠️ Dati non validi. Ricomincia.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return ConversationHandler.END

    await safe_edit_message_text(query, "⏳ Apertura trade-sfida in corso...")
    ok, msg, ticket, journal_id = await _apri_challenge_trade(direzione, lotti, minuti)
    if not ok:
        # Trade-sfida = solo Prop: se l'AutoTrading e' spento mostro il pulsante
        # per riavviare il terminale Prop (riaccende l'Algo Trading).
        righe = []
        if MSG_AUTOTRADING_OFF in msg:
            righe.append([InlineKeyboardButton("🔄 Riavvia terminale Prop", callback_data="riavvia_prop")])
        righe.append(back_button("manuale"))
        await safe_edit_message_text(query, msg, InlineKeyboardMarkup(righe))
        return ConversationHandler.END

    now_utc  = datetime.now(timezone.utc)
    close_at = now_utc + timedelta(minutes=minuti)
    record = {
        "id":            uuid.uuid4().hex,
        "prop_ticket":   int(ticket),
        "direzione":     direzione,
        "lotti":         lotti,
        "minuti":        minuti,
        "opened_at_utc": now_utc.isoformat(),
        "close_at_utc":  close_at.isoformat(),
        "status":        "open",
    }
    await modifica_dati_async(partial(modifier_add_challenge_trade, trade=record))
    # Trade registrato: da qui il backstop lo vede sempre -> intento chiuso.
    if journal_id:
        await journal_remove(journal_id)
    # Timer preciso al secondo (il backstop nel loop copre riavvii/fallimenti).
    context.application.create_task(
        _close_challenge_after(context.application, record["id"], minuti * 60.0)
    )
    for k in ("challenge_direzione", "challenge_lotti", "challenge_minuti"):
        context.user_data.pop(k, None)

    await safe_edit_message_text(
        query,
        f"✅ Trade sfida aperto con successo.\n"
        f"Verrà chiuso automaticamente tra {_fmt_minuti(minuti)}.",
        InlineKeyboardMarkup([back_button("manuale")]),
    )
    return ConversationHandler.END
