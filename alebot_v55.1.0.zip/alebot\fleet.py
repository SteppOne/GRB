"""Console di FLOTTA + aggiornamento OTA con rollback (Passo 3).

Estende il canale admin Telegram (gia' condiviso da tutti i bot della
flotta) con i comandi gestionali:

  /flotta                                   -> ogni bot risponde con la sua
                                               scheda (versione, uptime,
                                               terminali, abbonamento, trade)
  /aggiorna <CLIENT_ID|tutti> <url> <sha256>-> aggiornamento OTA del pacchetto
                                               alebot/ con verifica sha256,
                                               pre-compilazione, backup e
                                               riavvio; conferma al boot.

Sicurezza OTA: il comando arriva SOLO dal canale admin privato (stesso
trust model di /rinnova), lo zip deve combaciare con lo sha256 dichiarato,
puo' contenere SOLO alebot/*.py (niente path traversal), e ogni file viene
COMPILATO prima dello swap. Il pending non confermato al boot successivo
fa scattare il rollback (alev51.py / watchdog via ota_guard).
"""
import asyncio
import glob
import hashlib
import io
import json
import logging
import os
import py_compile
import re
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from typing import Awaitable, Callable, Optional, Tuple

import psutil
try:
    import requests
except ImportError:
    requests = None

logger = logging.getLogger(__name__)

from functools import partial

from . import __version__
from .config import (
    ADMIN_CHANNEL_ID,
    BASE_DIR,
    CLIENT_ID,
    CLIENT_NOME,
    HEARTBEAT_FILE,
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    MT5_WORKERS_ENABLED,
)
from .storage import carica_dati_async, modifica_dati_async, modifier_set_key
from .hedge_journal import JOURNAL_KEY
from .mt5_async import stato_metatrader_async

_AVVIO_UTC = datetime.now(timezone.utc)

OTA_STAGING   = os.path.join(BASE_DIR, "ota_staging")
OTA_BACKUP    = os.path.join(BASE_DIR, "ota_backup")
OTA_PENDING   = os.path.join(BASE_DIR, "ota_pending.json")
# Scritto da ota_guard quando un aggiornamento non confermato viene annullato.
OTA_ROLLBACK  = os.path.join(BASE_DIR, "ota_rollback_info.json")
PACCHETTO_DIR = os.path.join(BASE_DIR, "alebot")

# File obbligatori in ogni pacchetto OTA: un aggiornamento senza uno di
# questi non e' un pacchetto alebot valido.
_FILE_OBBLIGATORI = {"__init__.py", "config.py", "app.py"}


# ========================= CHI CI RIACCENDE? =========================
# Il bot NON si riavvia da solo: esce e il WATCHDOG lo rilancia. Se il
# watchdog non e' in esecuzione (o c'e' bot.stop, che gli dice di tenere
# il bot spento), uscire significa restare GIU' PER SEMPRE — e per un
# aggiornamento OTA vorrebbe dire: file sostituiti, bot morto, VPS da
# raggiungere a mano. Prima di qualunque uscita volontaria si verifica.
WATCHDOG_LOCK = os.path.join(BASE_DIR, "watchdog.lock")
STOP_FLAG     = os.path.join(BASE_DIR, "bot.stop")


def watchdog_attivo() -> Tuple[bool, str]:
    """(True, "") se il watchdog e' vivo e rilancera' il bot dopo l'uscita.
    Altrimenti (False, motivo leggibile)."""
    if os.path.exists(STOP_FLAG):
        return False, (
            "è presente il file bot.stop (spegnimento manuale): il watchdog "
            "NON riavvierebbe il bot. Usa avvia.bat sulla VPS."
        )
    try:
        with open(WATCHDOG_LOCK, "r", encoding="utf-8") as f:
            pid = int((f.read() or "").strip())
    except (OSError, ValueError):
        return False, (
            "il watchdog non risulta in esecuzione (watchdog.lock assente o "
            "illeggibile). Avvia il bot con avvia.bat, non a mano."
        )
    try:
        if not psutil.pid_exists(pid):
            return False, f"il watchdog non è più attivo (pid {pid} morto)."
    except Exception:
        return True, ""     # non verificabile: non blocchiamo per un dubbio
    return True, ""


# ========================= RIAVVIO (usato anche dal menu Diagnosi) =========================
async def esegui_riavvio_bot():
    """
    Chiude il processo del bot in modo che il watchdog esterno lo rilanci.
    Aspetta qualche secondo perche' Telegram consegni il messaggio di conferma,
    poi ferma i worker MT5, rilascia heartbeat e lock e termina il processo con
    os._exit (uscita immediata e affidabile anche se restano task in sospeso).
    """
    from .loops import _release_single_instance_lock  # lazy: evita ciclo import
    from .mt5_pool import pool                        # lazy: evita ciclo import
    await asyncio.sleep(2)
    # I worker MT5 sono PROCESSI FIGLI: os._exit salta la pulizia di
    # multiprocessing, quindi vanno terminati ESPLICITAMENTE. Senza questo
    # restano vivi (finche' non si accorgono della pipe rotta) tenendo aperte
    # le connessioni ai terminali, proprio mentre la nuova istanza ne spawna
    # altri: due set di worker sullo stesso MT5.
    try:
        await pool.stop()
    except Exception:
        logger.exception("Stop worker MT5 prima del riavvio fallito (proseguo).")
    try:
        if os.path.exists(HEARTBEAT_FILE):
            os.remove(HEARTBEAT_FILE)
    except OSError:
        pass
    _release_single_instance_lock()
    logging.shutdown()
    os._exit(0)

# Indirezione per i test (monkeypatch): l'OTA chiama _riavvia(), mai os._exit
# direttamente.
_riavvia = esegui_riavvio_bot


# ========================= /FLOTTA =========================
def _fmt_uptime() -> str:
    sec = int((datetime.now(timezone.utc) - _AVVIO_UTC).total_seconds())
    g, resto = divmod(sec, 86400)
    h, resto = divmod(resto, 3600)
    m = resto // 60
    if g:
        return f"{g}g {h}h"
    if h:
        return f"{h}h {m}m"
    return f"{m}m"


async def _scheda_flotta() -> str:
    # Lazy: subscription importa fleet a livello modulo, qui si evita il ciclo.
    from .subscription import _riga_scadenza, stato_abbonamento

    dati = await carica_dati_async()
    st_b, st_p = await asyncio.gather(
        stato_metatrader_async(MT5_BROKER_EXE),
        stato_metatrader_async(MT5_PROP_EXE),
    )
    memos = dati.get("trade_memos", {}) or {}
    pair_aperti = {
        (int(r.get("broker_ticket", 0) or 0), int(r.get("prop_ticket", 0) or 0))
        for r in memos.values()
        if isinstance(r, dict) and not r.get("pair_closed_notified")
    }
    n_journal = len(dati.get(JOURNAL_KEY) or {})
    riga_journal = "vuoto ✓" if n_journal == 0 else f"⚠️ {n_journal} intenti aperti"
    return (
        f"🖥 {CLIENT_NOME}" + (f" ({CLIENT_ID})" if CLIENT_ID else "") + f" — v{__version__}\n"
        f"• Uptime bot: {_fmt_uptime()} | MT5: "
        + ("worker paralleli" if MT5_WORKERS_ENABLED else "in-process") + "\n"
        f"• Broker: {st_b} | Prop: {st_p}\n"
        f"• Trade hedge aperti: {len(pair_aperti)} | Giornale ops: {riga_journal}\n"
        f"• {_riga_scadenza(stato_abbonamento(dati))}"
    )


# ========================= OTA: PREPARAZIONE (sync, in thread) =========================
def normalizza_url(url: str) -> str:
    """Corregge gli errori tipici nel link di un pacchetto su GitHub.

    Copiando il link dalla pagina web di GitHub si ottiene la pagina HTML del
    file ("blob"), non il file: scaricarla darebbe "non e' uno zip valido".
    Qui la si converte nell'equivalente 'raw', e si aggiunge ?raw=1 alle
    pagine /blob/ di altri host. Un URL gia' corretto passa invariato."""
    u = (url or "").strip()
    if "github.com/" in u and "/blob/" in u:
        u = u.replace("github.com/", "raw.githubusercontent.com/", 1)
        u = u.replace("/blob/", "/", 1)
    return u


def _scarica_zip(url: str, sha256_atteso: Optional[str]) -> Tuple[Optional[bytes], str]:
    """Scarica il pacchetto. Lo sha256 e' OPZIONALE: se fornito viene
    verificato; se assente la protezione resta comunque forte (struttura
    dello zip, file obbligatori, PRE-COMPILAZIONE di ogni file e rollback
    automatico se il bot non riparte)."""
    if requests is None:
        return None, "libreria requests non disponibile"
    url = normalizza_url(url)
    try:
        resp = requests.get(url, timeout=60)
        resp.raise_for_status()
    except Exception as e:
        return None, f"download fallito: {e}"
    contenuto = resp.content
    if sha256_atteso:
        sha = hashlib.sha256(contenuto).hexdigest().lower()
        if sha != sha256_atteso.lower():
            return None, f"sha256 NON combacia (atteso {sha256_atteso[:12]}…, reale {sha[:12]}…)"
    return contenuto, ""


# Tempo massimo concesso alla prova d'import del pacchetto nuovo.
IMPORT_PROBE_TIMEOUT_S = 120


def _moduli_persi(nomi_nuovi: list) -> list:
    """Moduli presenti nel pacchetto IN USO e assenti dallo zip nuovo."""
    try:
        attuali = {
            os.path.basename(f)
            for f in glob.glob(os.path.join(PACCHETTO_DIR, "*.py"))
        }
    except OSError:
        return []
    return sorted(attuali - set(nomi_nuovi))


def _prova_import(staging_pkg: str) -> Tuple[bool, str, bool]:
    """Importa `alebot.app` dallo STAGING in un processo separato.

    Ritorna (ok, errore, eseguita):
      ok=False + eseguita=True  -> il pacchetto e' rotto: BLOCCARE.
      ok=True  + eseguita=False -> non si e' potuto provare (interprete non
                                   avviabile, timeout): si prosegue con i
                                   controlli statici, come prima.

    Isolamento: PYTHONPATH e cwd puntano SOLO allo staging, quindi si importa
    davvero il pacchetto NUOVO e non quello in esecuzione. L'ambiente e' quello
    del bot (le variabili del .env sono gia' in os.environ), altrimenti
    config.py fallirebbe per variabili mancanti dando un falso allarme.
    """
    radice = os.path.dirname(staging_pkg)          # .../ota_staging
    env = os.environ.copy()
    env["PYTHONPATH"] = radice
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    try:
        esito = subprocess.run(
            [sys.executable, "-c", "import alebot.app"],
            cwd=radice, env=env, capture_output=True, text=True,
            timeout=IMPORT_PROBE_TIMEOUT_S,
        )
    except subprocess.TimeoutExpired:
        logger.warning("OTA: prova d'import scaduta, proseguo con i controlli statici.")
        return True, "", False
    except Exception as e:
        logger.warning(f"OTA: prova d'import non eseguibile ({e}), proseguo con i controlli statici.")
        return True, "", False

    if esito.returncode == 0:
        return True, "", True
    # Ultima riga significativa del traceback: e' quella che dice il vero.
    righe = [r.strip() for r in (esito.stderr or "").splitlines() if r.strip()]
    dettaglio = righe[-1] if righe else f"uscita con codice {esito.returncode}"
    logger.error(f"OTA: prova d'import FALLITA -> {dettaglio}")
    return False, dettaglio[:300], True


def _estrai_e_valida(zip_bytes: bytes) -> Tuple[bool, str, int, str]:
    """Estrae in staging SOLO alebot/*.py (anti path-traversal), verifica i
    file obbligatori e PRE-COMPILA tutto. Ritorna (ok, err, n_file, versione)."""
    shutil.rmtree(OTA_STAGING, ignore_errors=True)
    staging_pkg = os.path.join(OTA_STAGING, "alebot")
    os.makedirs(staging_pkg, exist_ok=True)
    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except zipfile.BadZipFile:
        return False, "il file scaricato non e' uno zip valido", 0, ""

    nomi_estratti = []
    for info in zf.infolist():
        nome = info.filename.replace("\\", "/")
        if nome.endswith("/"):
            continue
        # Whitelist rigida: solo alebot/<file>.py, nessuna sottocartella,
        # nessun '..', nessun percorso assoluto.
        if not nome.startswith("alebot/") or nome.count("/") != 1:
            continue
        base = os.path.basename(nome)
        if not base.endswith(".py") or ".." in nome or base != nome.split("/", 1)[1]:
            continue
        with zf.open(info) as src, open(os.path.join(staging_pkg, base), "wb") as dst:
            shutil.copyfileobj(src, dst)
        nomi_estratti.append(base)

    if not nomi_estratti:
        return False, "lo zip non contiene file alebot/*.py", 0, ""
    mancanti = _FILE_OBBLIGATORI - set(nomi_estratti)
    if mancanti:
        return False, f"pacchetto incompleto, mancano: {', '.join(sorted(mancanti))}", 0, ""

    # Pre-compilazione: un errore di sintassi ferma tutto QUI, prima dello swap.
    for base in nomi_estratti:
        try:
            py_compile.compile(os.path.join(staging_pkg, base), doraise=True)
        except py_compile.PyCompileError as e:
            return False, f"errore di compilazione in {base}: {e.msg}", 0, ""

    # PROVA D'IMPORT VERA: py_compile verifica solo la SINTASSI. Un pacchetto
    # sintatticamente perfetto ma con un import rotto, un modulo mancante o un
    # errore a livello di modulo passava indenne fino allo swap, e il guasto si
    # scopriva solo col bot gia' spento (rollback). Qui lo si scopre prima, in
    # un processo separato e con lo staging come UNICA sorgente del pacchetto.
    ok_import, err_import, eseguita = _prova_import(staging_pkg)
    if not ok_import:
        return False, f"il pacchetto non si importa: {err_import}", 0, ""

    if not eseguita:
        # Prova d'import non effettuabile (ambiente ostile): si ricade sul
        # controllo statico piu' prudente — nessun modulo oggi presente puo'
        # sparire. _applica_update cancella TUTTI i .py prima di copiare i
        # nuovi: uno zip incompleto smonterebbe il pacchetto.
        mancanti_rispetto_attuale = _moduli_persi(nomi_estratti)
        if mancanti_rispetto_attuale:
            return False, (
                "prova d'import non eseguibile e nel pacchetto mancano moduli "
                f"presenti nella versione in uso: {', '.join(mancanti_rispetto_attuale)}"
            ), 0, ""

    versione = ""
    try:
        with open(os.path.join(staging_pkg, "__init__.py"), encoding="utf-8") as f:
            m = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', f.read())
            versione = m.group(1) if m else ""
    except OSError:
        pass
    return True, "", len(nomi_estratti), versione


def _applica_update(versione_nuova: str) -> None:
    """Backup della versione corrente, scrittura del pending, swap dei file.
    Il pending va su disco PRIMA dello swap: un crash a meta' sostituzione
    viene comunque ripristinato da ota_guard."""
    staging_pkg = os.path.join(OTA_STAGING, "alebot")
    backup_pkg  = os.path.join(OTA_BACKUP, "alebot")

    shutil.rmtree(OTA_BACKUP, ignore_errors=True)
    os.makedirs(backup_pkg, exist_ok=True)
    for f in glob.glob(os.path.join(PACCHETTO_DIR, "*.py")):
        shutil.copy2(f, backup_pkg)

    with open(OTA_PENDING, "w", encoding="utf-8") as f:
        json.dump({
            "da":            __version__,
            "a":             versione_nuova,
            "applicato_utc": datetime.now(timezone.utc).isoformat(),
        }, f, indent=1)

    for f in glob.glob(os.path.join(PACCHETTO_DIR, "*.py")):
        os.remove(f)
    # CACHE BYTECODE: obbligatorio cancellarla. Python riusa i .pyc di
    # __pycache__ e, se un file nuovo arrivasse con mtime/size compatibili col
    # .pyc vecchio, verrebbe eseguito il CODICE VECCHIO — un aggiornamento
    # "applicato" che non cambia nulla, il guasto piu' insidioso possibile.
    # Si pulisce sia la cache del pacchetto sia quella della cartella radice
    # (alev51.py, ota_guard.py, watchdog.py): l'OTA non tocca quei file, ma un
    # aggiornamento MANUALE si', e trovare la radice gia' pulita evita al
    # proprietario di doversene ricordare.
    shutil.rmtree(os.path.join(PACCHETTO_DIR, "__pycache__"), ignore_errors=True)
    shutil.rmtree(
        os.path.join(os.path.dirname(PACCHETTO_DIR), "__pycache__"),
        ignore_errors=True,
    )
    for f in glob.glob(os.path.join(staging_pkg, "*.py")):
        shutil.copy2(f, PACCHETTO_DIR)
    shutil.rmtree(OTA_STAGING, ignore_errors=True)


async def _valida_applica_riavvia(
    bot, invia, zip_bytes: bytes,
    dopo_la_validazione: Optional[Callable[[], Awaitable[None]]] = None,
) -> None:
    """Pipeline comune a tutte le vie di consegna (URL, documento nel canale,
    documento in chat privata): valida lo zip, pre-compila, applica con
    backup+pending e riavvia.

    `dopo_la_validazione` viene eseguito SOLO se il pacchetto ha superato tutti
    i controlli e PRIMA di applicarlo: e' il gancio con cui il rilancio in
    flotta pubblica il file nel canale. Prima la pubblicazione avveniva per
    prima, e un pacchetto che QUESTO bot avrebbe scartato veniva comunque
    spedito a tutti i clienti."""
    # IDEMPOTENZA: lo stesso identico pacchetto non viene riapplicato. Protegge
    # da un comando ripostato nel canale, dal rilancio in flotta che torna
    # indietro al mittente e dagli update Telegram riconsegnati dopo il
    # riavvio: senza, la flotta rischierebbe un ciclo di riavvii.
    sha_zip = hashlib.sha256(zip_bytes).hexdigest().lower()
    dati = await carica_dati_async()
    if dati.get("ota_last_sha") == sha_zip:
        logger.info("OTA: pacchetto identico a quello gia' applicato, ignoro.")
        await invia(bot, (
            f"ℹ️ {CLIENT_NOME}: è già in esecuzione questo stesso pacchetto "
            f"(v{__version__}). Nessuna azione."
        ))
        return
    # PRIMA di toccare i file: chi ci riaccende? Senza watchdog l'uscita
    # post-aggiornamento lascerebbe il bot morto sulla VPS.
    vivo, motivo = watchdog_attivo()
    if not vivo:
        await invia(bot, (
            f"❌ {CLIENT_NOME}: aggiornamento ANNULLATO (nessun file toccato) — "
            f"{motivo}"
        ))
        return
    ok, err, n_file, versione = await asyncio.to_thread(_estrai_e_valida, zip_bytes)
    if not ok:
        await invia(bot, f"❌ {CLIENT_NOME}: aggiornamento ANNULLATO — {err}")
        return
    # Pacchetto promosso: solo ORA si puo' propagarlo alla flotta.
    if dopo_la_validazione is not None:
        try:
            await dopo_la_validazione()
        except Exception:
            logger.exception("OTA: passo post-validazione fallito (proseguo con questo bot).")
    await asyncio.to_thread(_applica_update, versione)
    await modifica_dati_async(partial(modifier_set_key, key="ota_last_sha", value=sha_zip))
    await invia(bot, (
        f"🔄 {CLIENT_NOME}: aggiornamento a v{versione or '?'} applicato "
        f"({n_file} file), riavvio in corso. Conferma al rientro; in caso di "
        f"problemi il rollback alla v{__version__} e' automatico."
    ))
    await _riavvia()


async def _esegui_ota(bot, invia, url: str, sha256_atteso: Optional[str] = None) -> None:
    await invia(bot, f"⬇️ {CLIENT_NOME}: scarico l'aggiornamento…")
    zip_bytes, err = await asyncio.to_thread(_scarica_zip, url, sha256_atteso)
    if zip_bytes is None:
        await invia(bot, f"❌ {CLIENT_NOME}: aggiornamento ANNULLATO — {err}")
        return
    await _valida_applica_riavvia(bot, invia, zip_bytes)


# Limite DURO dell'API Telegram: un bot non puo' scaricare file oltre 20 MB.
TELEGRAM_MAX_DOWNLOAD_BYTES = 20 * 1024 * 1024


def _e_sha256(token: str) -> bool:
    return len(token) == 64 and all(c in "0123456789abcdef" for c in token.lower())


async def _ota_da_documento(
    context, document, sha: Optional[str], invia,
    dopo_la_validazione: Optional[Callable[[], Awaitable[None]]] = None,
) -> None:
    """Scarica il documento da Telegram, verifica lo sha (se fornito) e applica.
    Condivisa tra la via CANALE e la via CHAT PRIVATA."""
    dimensione = int(getattr(document, "file_size", 0) or 0)
    if dimensione > TELEGRAM_MAX_DOWNLOAD_BYTES:
        await invia(context.bot, (
            f"❌ {CLIENT_NOME}: il file pesa {dimensione / 1048576:.1f} MB e un bot "
            f"Telegram può scaricarne al massimo 20. Usa la variante con URL."
        ))
        return
    await invia(context.bot, f"⬇️ {CLIENT_NOME}: scarico l'aggiornamento…")
    try:
        tg_file = await context.bot.get_file(document.file_id)
        zip_bytes = bytes(await tg_file.download_as_bytearray())
    except Exception as e:
        await invia(context.bot, f"❌ {CLIENT_NOME}: download del file fallito ({e}).")
        return
    if sha:
        reale = hashlib.sha256(zip_bytes).hexdigest().lower()
        if reale != sha:
            await invia(context.bot, (
                f"❌ {CLIENT_NOME}: aggiornamento ANNULLATO — sha256 NON combacia "
                f"(atteso {sha[:12]}…, reale {reale[:12]}…)."
            ))
            return
    await _valida_applica_riavvia(context.bot, invia, zip_bytes, dopo_la_validazione)


async def esegui_ota_da_documento(context, document, parts: list, invia) -> None:
    """OTA dal DOCUMENTO postato nel canale admin: didascalia
    '/aggiorna <CLIENT_ID|tutti> [sha256]'. Il file viaggia dentro Telegram
    (TLS, canale privato di cui i bot sono admin): nessun hosting esterno.
    Lo sha256 resta consigliato come doppio controllo, ma e' opzionale."""
    if len(parts) < 2:
        await invia(context.bot, "⚠️ Didascalia: /aggiorna <CLIENT_ID|tutti> [sha256]")
        return
    target = parts[1].lower()
    if target != "tutti" and target != (CLIENT_ID or "").lower():
        return          # destinato a un altro bot della flotta
    sha = parts[2].lower() if len(parts) > 2 else None
    await _ota_da_documento(context, document, sha, invia)


async def _rilancia_in_flotta(context, document, invia) -> bool:
    """RILANCIO IN FLOTTA: il bot ri-pubblica NEL CANALE ADMIN il documento
    ricevuto in privato, con didascalia '/aggiorna tutti'. Tutti gli altri bot
    (amministratori dello stesso canale) lo ricevono come un normale post e si
    aggiornano.

    Serve perche' e' il PROPRIETARIO a non poter caricare il file nel canale
    (client Telegram che si chiude durante l'invio): il file viene caricato
    UNA volta nella chat privata e da li' e' il bot — non il client — a
    metterlo nel canale. Nessun hosting esterno."""
    if not ADMIN_CHANNEL_ID:
        await invia(context.bot, (
            "⚠️ Canale admin non configurato (ADMIN_CHANNEL_ID): "
            "posso aggiornare solo questo bot."
        ))
        return False
    try:
        await context.bot.send_document(
            chat_id=ADMIN_CHANNEL_ID,
            document=document.file_id,
            caption="/aggiorna tutti",
        )
    except Exception as e:
        logger.exception("Rilancio del pacchetto nel canale admin fallito.")
        await invia(context.bot, (
            f"⚠️ Non sono riuscito a pubblicare il pacchetto nel canale admin "
            f"({e}). Aggiorno solo questo bot; per gli altri usa la via con URL."
        ))
        return False
    await invia(context.bot, (
        "📡 Pacchetto pubblicato nel canale admin: tutti i bot della flotta "
        "lo stanno scaricando e si aggiorneranno da soli.\n"
        "Ora aggiorno anche questo bot."
    ))
    return True


async def esegui_ota_da_documento_privato(context, document, parts: list, invia) -> None:
    """OTA dal documento inviato in CHAT PRIVATA dall'owner.

    Didascalia:
      /aggiorna          -> aggiorna SOLO questo bot
      /aggiorna tutti    -> lo pubblica nel canale admin (aggiorna la FLOTTA)
                            e poi aggiorna anche questo bot
    Eventuale sha256 in coda viene riconosciuto e verificato."""
    sha = None
    flotta = False
    for token in parts[1:]:
        if _e_sha256(token):
            sha = token.lower()
        elif token.lower() in ("tutti", "flotta"):
            flotta = True

    # Il rilancio alla flotta parte SOLO dopo che il pacchetto ha superato
    # sha256, struttura, pre-compilazione e prova d'import su QUESTO bot:
    # e' il collaudo che protegge i clienti. Prima veniva pubblicato subito,
    # quindi un pacchetto rotto raggiungeva tutti prima ancora che il bot del
    # proprietario si accorgesse che era rotto.
    async def _pubblica_alla_flotta() -> None:
        await _rilancia_in_flotta(context, document, invia)

    await _ota_da_documento(
        context, document, sha, invia,
        _pubblica_alla_flotta if flotta else None,
    )


# ========================= CONFERMA AL BOOT =========================
async def conferma_ota_al_boot(app) -> None:
    """Se questo avvio e' il primo dopo un OTA, il codice nuovo sta girando:
    consuma il pending (il rollback non deve piu' scattare) e conferma."""
    if not os.path.exists(OTA_PENDING):
        return
    from .subscription import _invia_canale_admin  # lazy: evita ciclo import
    try:
        with open(OTA_PENDING, encoding="utf-8") as f:
            info = json.load(f)
    except Exception:
        info = {}
    try:
        os.remove(OTA_PENDING)
    except OSError:
        pass
    await _invia_canale_admin(app.bot, (
        f"✅ {CLIENT_NOME}: aggiornamento OTA completato — ora in esecuzione "
        f"v{__version__} (da v{info.get('da', '?')}). Il backup della versione "
        f"precedente resta in ota_backup\\ fino al prossimo aggiornamento."
    ))


async def segnala_rollback_al_boot(app) -> None:
    """Se il bot sta ripartendo DOPO un rollback automatico, dillo — forte.

    ota_guard e' standalone (non puo' leggere lo stato cifrato ne' parlare con
    Telegram): lascia solo ota_rollback_info.json. Risultato: il proprietario
    riceveva "aggiornamento applicato", poi silenzio, e restava convinto che la
    flotta girasse la versione nuova mentre era tornata alla precedente.

    Qui si chiude anche un secondo problema: `ota_last_sha` era rimasto sul
    pacchetto FALLITO, quindi ripubblicarlo (magari dopo aver risolto la causa
    ambientale) veniva respinto con un messaggio falso — "è già in esecuzione
    questo stesso pacchetto". Azzerandolo, il ritentativo torna possibile.
    """
    if not os.path.exists(OTA_ROLLBACK):
        return
    from .subscription import _invia_canale_admin  # lazy: evita ciclo import
    from .messaging import notifica_owner          # lazy: idem
    try:
        with open(OTA_ROLLBACK, encoding="utf-8") as f:
            info = json.load(f)
    except Exception:
        info = {}
    try:
        os.remove(OTA_ROLLBACK)
    except OSError:
        logger.warning("Impossibile rimuovere ota_rollback_info.json (segnalero' di nuovo al prossimo avvio).")

    await modifica_dati_async(partial(modifier_set_key, key="ota_last_sha", value=None))

    aggiornamento = info.get("update") or {}
    testo = (
        f"↩️ {CLIENT_NOME}: AGGIORNAMENTO ANNULLATO E VERSIONE RIPRISTINATA.\n"
        f"Motivo: {info.get('motivo', 'non specificato')}.\n"
        f"Tentativo: v{aggiornamento.get('da', '?')} → v{aggiornamento.get('a', '?')}.\n"
        f"In esecuzione ORA: v{__version__}.\n\n"
        f"⚠️ Questo bot NON ha l'aggiornamento. Correggi il pacchetto e ripubblicalo."
    )
    await _invia_canale_admin(app.bot, testo)
    await notifica_owner(app, (
        "↩️ Un aggiornamento del bot non è andato a buon fine ed è stata "
        f"ripristinata automaticamente la versione precedente (v{__version__}).\n"
        "Il bot è pienamente operativo. L'assistenza è già stata avvisata."
    ))
    logger.error(f"Rollback OTA rilevato al boot: {info}")


# ========================= ROUTER COMANDI =========================
async def gestisci_comando_flotta(cmd: str, parts: list, context, invia) -> bool:
    """Comandi flotta dal canale admin. `invia` e' _invia_canale_admin
    (iniettato dal chiamante per evitare cicli di import).
    Ritorna True se il comando e' stato riconosciuto."""
    if cmd == "flotta":
        try:
            await invia(context.bot, await _scheda_flotta())
        except Exception:
            logger.exception("/flotta: errore nella composizione della scheda")
            await invia(context.bot, f"⚠️ {CLIENT_NOME}: errore nel comporre la scheda /flotta.")
        return True

    if cmd == "aggiorna":
        # /aggiorna <CLIENT_ID|tutti> <url_zip> [sha256]
        # Lo sha256 e' OPZIONALE: la validazione dello zip, la
        # pre-compilazione e il rollback automatico proteggono comunque.
        if len(parts) < 3:
            await invia(context.bot, "⚠️ Uso: /aggiorna <CLIENT_ID|tutti> <url_zip> [sha256]")
            return True
        target = parts[1].lower()
        if target != "tutti" and target != (CLIENT_ID or "").lower():
            return True     # destinato a un altro bot della flotta
        sha = parts[3].lower() if len(parts) > 3 else None
        await _esegui_ota(context.bot, invia, parts[2], sha)
        return True

    return False
