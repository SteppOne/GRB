"""Processo WORKER MT5: un terminale, una connessione, sempre calda.

Il pacchetto MetaTrader5 dialoga con UN terminale per processo. Facendo
girare un worker dedicato per il Broker e uno per la Prop, le due
connessioni restano aperte IN PARALLELO: niente piu' alternanza
broker<->prop, e le due gambe dell'hedge possono partire simultaneamente.

Il worker riceve richieste (nome_funzione, args, kwargs) su una pipe,
esegue la funzione corrispondente di mt5_sync (whitelist DISPATCH) e
risponde (True, risultato) oppure (False, "errore"). Il layer di sessione
persistente di mt5_sync vive DENTRO il worker: dato che ogni worker serve
un solo terminale, la sessione non cambia mai -> riuso massimo.

Questo modulo viene importato anche dal processo figlio (spawn): tiene
solo dipendenze leggere (config + mt5_sync), niente telegram/storage.
"""
import logging
import os
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

from . import mt5_sync as ms
from .config import BOT_LOG_FILE


def _configura_log_worker(nome: str) -> None:
    """Fa arrivare nel file del bot il log di QUESTO processo.

    PERCHE' ESISTE (guasto diagnosticato il 06/08/2026). I worker sono processi
    separati (multiprocessing spawn) e girano sotto pythonw: niente console,
    sys.stderr assente, e lo StreamHandler montato da config.py all'import
    scrive nel vuoto. Verificato sul campo: in SETTE GIORNI di bot.log, ZERO
    righe da questo modulo e da mt5_sync — cioe' proprio quelle che riportano
    il codice d'errore VERO di MT5 quando un login o un ordine viene rifiutato:

        logger.error(f"Login fallito per {path}, errore: {errore}")

    Tutte le operazioni MT5 girano qui dentro, quindi il log del bot era cieco
    esattamente sullo strato da diagnosticare: davanti a un "credenziali
    rifiutate" non restava che tirare a indovinare.

    Si scrive sullo STESSO bot.log del padre, in append: le righe restano in
    ordine cronologico insieme a quelle del bot e per capire un guasto basta
    un file solo. La rotazione resta al watchdog, che la fa a bot spento — i
    worker sono daemon e muoiono col padre, quindi non tengono handle aperti.
    """
    radice = logging.getLogger()
    # Gli handler ereditati puntano a uno stderr che in questo processo non
    # esiste: tenerli significa solo pagare un errore silenzioso per record.
    for vecchio in list(radice.handlers):
        radice.removeHandler(vecchio)
    try:
        handler = logging.FileHandler(BOT_LOG_FILE, mode="a", encoding="utf-8")
    except OSError:
        return          # senza log si lavora comunque: mai bloccare il worker
    handler.setFormatter(logging.Formatter(
        f"%(asctime)s - %(name)s [{nome}] - %(levelname)s - %(message)s"
    ))
    radice.addHandler(handler)
    radice.setLevel(logging.INFO)


def _pos_to_dict(p) -> Optional[Dict[str, Any]]:
    """Le TradePosition di MT5 non attraversano la pipe: si convertono in dict.
    I consumatori usano solo la veridicita'/campi base, quindi e' trasparente."""
    if p is None:
        return None
    return {
        "ticket":        int(getattr(p, "ticket", 0) or 0),
        "symbol":        getattr(p, "symbol", ""),
        "volume":        float(getattr(p, "volume", 0.0) or 0.0),
        "profit":        float(getattr(p, "profit", 0.0) or 0.0),
        "type":          int(getattr(p, "type", 0) or 0),
        "magic":         int(getattr(p, "magic", 0) or 0),
        "sl":            float(getattr(p, "sl", 0.0) or 0.0),
        "tp":            float(getattr(p, "tp", 0.0) or 0.0),
        "price_open":    float(getattr(p, "price_open", 0.0) or 0.0),
        "price_current": float(getattr(p, "price_current", 0.0) or 0.0),
    }


def _get_position_by_ticket_dict(*args, **kwargs):
    return _pos_to_dict(ms._get_position_by_ticket_sync(*args, **kwargs))


def _probe_terminale_sync(
    path: str, credenziali: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """UN tentativo di aggancio post-riavvio terminale.

    Ritorna un ESITO DETTAGLIATO invece di un semplice bool:
        {"acceso": bool, "autenticato": bool, "motivo": str}

    Serve a distinguere i due guasti, che chiedono all'utente cose diverse:
      - terminale spento / non raggiungibile  -> problema di avvio;
      - terminale ACCESO ma login RIFIUTATO   -> password del conto cambiata,
        ed e' il caso reale che si presenta dopo un aggiornamento di MT5,
        quando il terminale chiede la password dell'ultimo conto.
    La v53 restituiva solo True/False e l'owner leggeva un generico
    "Riavvio fallito", senza sapere quale delle due cose fosse successa.
    """
    esito = {"acceso": False, "autenticato": False, "motivo": ""}
    try:
        if not ms._mt5_initialize(path):
            esito["motivo"] = f"terminale non raggiungibile {ms.mt5.last_error()}"
            return esito
        esito["acceso"] = True
        try:
            if not credenziali:
                esito["autenticato"] = True
                return esito
            if ms._mt5_login(int(credenziali["id"]),
                             credenziali["password"],
                             credenziali["server"]):
                esito["autenticato"] = True
            else:
                esito["motivo"] = (
                    f"il terminale e' acceso ma il login sul conto "
                    f"{credenziali['id']} e' stato RIFIUTATO {ms.mt5.last_error()}"
                )
            return esito
        finally:
            try:
                ms.mt5.shutdown()
            except Exception:
                pass
    except Exception as e:
        esito["motivo"] = f"errore imprevisto: {type(e).__name__}: {e}"
        return esito
    finally:
        # Il probing usa initialize/shutdown grezzi: la sessione persistente
        # del worker va resettata per ripartire pulita alla prossima chiamata.
        ms._mt5_session["path"] = None


# --- funzioni diagnostiche/di test (non toccano MT5) ---
def _ping() -> int:
    return os.getpid()

def _sleep(sec: float) -> float:
    time.sleep(float(sec))
    return float(sec)

def _die() -> None:
    os._exit(1)


# Whitelist delle funzioni eseguibili nel worker. SOLO queste.
DISPATCH: Dict[str, Any] = {
    "info_account":                       ms.info_account,
    "_autotrading_attivo_sync":           ms._autotrading_attivo_sync,
    "esegui_ordine":                      ms.esegui_ordine,
    "_verifica_ordine_esistente_sync":    ms._verifica_ordine_esistente_sync,
    "chiudi_posizione":                   ms.chiudi_posizione,
    "posizione_aperta_sync":              ms.posizione_aperta_sync,
    "stato_metatrader":                   ms.stato_metatrader,
    "calcola_margine_wrapper":            ms.calcola_margine_wrapper,
    "get_symbol_info_wrapper":            ms.get_symbol_info_wrapper,
    "valida_simbolo_volume":              ms.valida_simbolo_volume,
    "_trova_posizione_sync":              ms._trova_posizione_sync,
    "_get_position_by_ticket_sync":       _get_position_by_ticket_dict,
    "_extract_close_deal_sync":           ms._extract_close_deal_sync,
    "_get_open_positions_snapshot_sync":  ms._get_open_positions_snapshot_sync,
    "_get_open_tickets_by_symbol_sync":   ms._get_open_tickets_by_symbol_sync,
    "_get_trade_history_sync":            ms._get_trade_history_sync,
    "_prop_daily_realized_pnl_sync":      ms._prop_daily_realized_pnl_sync,
    "get_server_date":                    ms.get_server_date,
    "info_account_prop_sync":             ms.info_account_prop_sync,
    "verifica_mt5_credenziali_sync":      ms.verifica_mt5_credenziali_sync,
    "verifica_e_identifica_broker_sync":  ms.verifica_e_identifica_broker_sync,
    "verifica_credenziali_dettagliata_sync":            ms.verifica_credenziali_dettagliata_sync,
    "verifica_e_identifica_broker_dettagliata_sync":    ms.verifica_e_identifica_broker_dettagliata_sync,
    "_mt5_disconnect":                    ms._mt5_disconnect,
    "_probe_terminale_sync":              _probe_terminale_sync,
    "stato_sessione_sync":                ms.stato_sessione_sync,
    "azzera_quarantena_sync":             ms.azzera_quarantena_sync,
    "__ping__":                           _ping,
    "__sleep__":                          _sleep,
    "__die__":                            _die,
}

STOP = "__stop__"


def worker_main(conn, nome: str) -> None:
    """Loop del processo worker: (req_id, func, args, kwargs) ->
    (req_id, ok, risultato). L'id di richiesta permette al padre di scartare
    risposte rimaste orfane dopo un timeout del chiamante."""
    _configura_log_worker(nome)     # prima di tutto: altrimenti si perde
    logger.info(f"Worker MT5 '{nome}' avviato (pid {os.getpid()}).")
    while True:
        try:
            msg = conn.recv()
        except (EOFError, OSError):
            break                      # il padre e' morto/ha chiuso: usciamo
        if msg == STOP:
            break
        req_id = None
        try:
            req_id, func_name, args, kwargs = msg
            fn = DISPATCH[func_name]
            risultato = fn(*args, **kwargs)
            conn.send((req_id, True, risultato))
        except Exception as e:
            logger.exception(f"Worker '{nome}': errore in {msg!r}")
            try:
                conn.send((req_id, False, f"{type(e).__name__}: {e}"))
            except (OSError, BrokenPipeError):
                break
    try:
        ms._mt5_disconnect()
    except Exception:
        pass
    logger.info(f"Worker MT5 '{nome}' terminato.")
