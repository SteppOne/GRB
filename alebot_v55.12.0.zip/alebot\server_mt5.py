"""Nomi dei server MT5: come li scrive l'utente, come li pretende il terminale.

MT5 accetta il nome del server SOLO se combacia con quello che ha in elenco:
"FundedNext-Server 2" entra, "FundedNext-Server2" no. Quello spazio prima della
cifra e' invisibile a occhio, viene copiato a mano da una mail o da un telefono,
e nei log della prop produce due errori che sembrano diversi ma sono la stessa
cosa:

    account 'FundedNext-Server2' - '14139031' has been deleted
    '14139031': authorization on FundedNext-Server 2 failed (Invalid account)

Finora il bot passava a MT5 la stringa cosi' com'era e, quando falliva, chiedeva
all'utente di ricontrollare — cioe' gli chiedeva di accorgersi di uno spazio.

Questo modulo e' PURO (niente MT5, niente Telegram, niente rete):
  • genera le grafie plausibili di un nome scritto a mano, in ordine di
    probabilita', cosi' il chiamante puo' provarle finche' una entra;
  • conosce i nomi UFFICIALI delle famiglie documentate, per riconoscerli a
    meno di spazi/trattini/maiuscole e per poterli elencare quando nessuna
    grafia funziona.

Le trasformazioni generiche vengono prima della tabella: un domani un'altra
prop con lo stesso vizio e' gia' coperta senza toccare niente.
"""
import re
from typing import List, Optional, Tuple

# Nomi UFFICIALI. "prefissi" serve a riconoscere la FAMIGLIA anche quando la
# grafia e' sbagliata; "nota" e' l'avvertenza da mostrare all'utente; "prop_id"
# aggancia la famiglia alla societa' prop scelta nel bot (config.PROP_FIRMS),
# cosi' a chi ha configurato FTMO si propongono i server FTMO e basta.
#
# FONTI, diverse per famiglia — vale la pena saperlo prima di fidarsi:
#   FundedNext, Fintokei  help center dei fornitori (agosto 2026).
#   FTMO                  NON pubblica l'elenco: la sua documentazione rimanda
#                         sempre alla Client Area -> Credentials. I nomi qui
#                         sotto sono quelli che si leggono nel terminale MT5,
#                         riferiti dall'utente. Per questo l'elenco NON e' mai
#                         una gabbia: in ogni schermata resta il pulsante per
#                         scrivere il nome a mano (vedi handlers_config).
# NB: lo spazio prima della cifra di FundedNext e' voluto, non e' un refuso.
SERVER_NOTI = {
    "FundedNext": {
        "prop_id":   "fundednext",
        "prefissi":  ("fundednext",),
        "ufficiali": (
            "FundedNext-Server",      # conti a pagamento
            "FundedNext-Server 2",    # conti a pagamento
            "FundedNext-Server 3",    # competizione mensile gratuita e trial
        ),
        "nota": "",
    },
    "Fintokei": {
        "prop_id":   "fintokei",
        # I conti Fintokei sono ospitati da Purple Trading finche' non si passa
        # ai server propri: entrambi i prefissi appartengono alla stessa prop.
        "prefissi":  ("fintokei", "purpletrading"),
        "ufficiali": (
            "Fintokei-MT5-Server1",   # conti creati/acquistati dal 28/01/2026
            "PurpleTradingSC-03Demo", # conti precedenti
        ),
        # Fintokei pubblica SOLO i server delle sfide. Il conto reale sta
        # altrove e il nome arriva per email: e' esattamente il punto in cui si
        # incaglia chi ha appena superato una sfida, e nessuna correzione
        # automatica puo' indovinarlo.
        "nota": (
            "Attenzione: questi sono i server delle SFIDE. Se hai superato la "
            "sfida, il conto REALE sta su un altro server: il nome esatto te "
            "lo manda Fintokei per email e lo trovi in MyFintokei → Accounts "
            "→ Detail. Non e' lo stesso della sfida."
        ),
    },
    "FTMO": {
        "prop_id":   "ftmo",
        "prefissi":  ("ftmo",),
        # A differenza delle altre due famiglie i nomi FTMO NON hanno spazio
        # prima della cifra: "FTMO-Server2", non "FTMO-Server 2". Le grafie
        # generiche coprono lo stesso l'errore, ma chi tocca il pulsante il
        # nome giusto ce l'ha gia'.
        #
        # NIENTE destinazione d'uso accanto ai nomi, al contrario di FundedNext
        # e Fintokei: quale server serva a quale tipo di conto FTMO non lo
        # documenta nessuno, e dedurlo qui vorrebbe dire far scegliere l'utente
        # su un'informazione inventata da noi. Il suo server ce l'ha scritto
        # nella Client Area (vedi "nota").
        "ufficiali": (
            "FTMO-Demo",
            "FTMO-Server",
            "FTMO-Server1",
            "FTMO-Server2",
            "FTMO-Server3",
            "FTMO-Server4",
            "FTMO-Server5",
        ),
        # FTMO assegna il server per conto, e non lo pubblica da nessuna parte:
        # se nessuno di questi entra, quello vero e' scritto nella sua area
        # riservata. Va detto, altrimenti l'utente prova i sette a caso.
        "nota": (
            "Il server esatto del TUO conto FTMO e' scritto nella Client Area "
            "→ Account MetriX → Credentials (accanto a login e password). Se "
            "non e' nell'elenco qui sopra, scrivilo a mano: FTMO ne aggiunge "
            "di nuovi e i conti FTMO US stanno su server OANDA, con un altro "
            "nome ancora."
        ),
    },
}

# Quante grafie si provano al massimo. Ogni tentativo e' un login vero verso il
# broker: poche e mirate, non un dizionario.
MAX_VARIANTI = 5

def normalizza(nome: str) -> str:
    """Chiave di confronto: solo lettere e cifre, minuscole.

    Serve a far combaciare "FundedNext-Server 2", "fundednext server2" e
    "FundedNext - SERVER 2", che per un umano sono la stessa cosa e per MT5 no.
    """
    return "".join(c for c in (nome or "").lower() if c.isalnum())

def canonico(nome: str) -> Optional[str]:
    """Il nome ufficiale, se la grafia scritta lo identifica senza ambiguita'.

    Confronto a meno di spazi, trattini e maiuscole: "fundednextserver2"
    identifica "FundedNext-Server 2" e nient'altro.
    """
    chiave = normalizza(nome)
    if not chiave:
        return None
    for voce in SERVER_NOTI.values():
        for ufficiale in voce["ufficiali"]:
            if normalizza(ufficiale) == chiave:
                return ufficiale
    return None

def famiglia_nota(nome: str) -> Optional[Tuple[str, List[str]]]:
    """(famiglia, nomi ufficiali) se il server appartiene a una famiglia che
    conosciamo, altrimenti None. Riconosce anche le grafie sbagliate: serve
    proprio a dire "e' FundedNext, ma nessuno dei suoi server si chiama cosi'".
    """
    chiave = normalizza(nome)
    if not chiave:
        return None
    for famiglia, voce in SERVER_NOTI.items():
        if any(chiave.startswith(p) for p in voce["prefissi"]):
            return famiglia, list(voce["ufficiali"])
    return None

# ===================== ELENCHI PER LA SCELTA A PULSANTE =====================
# Il modo migliore di non sbagliare a scrivere un nome e' non doverlo scrivere:
# il bot propone i server che conosce come pulsanti, e quello che arriva
# indietro e' gia' il nome esatto. Queste funzioni servono a costruire quelle
# schermate e restano PURE come il resto del modulo (nessun Telegram qui).

def famiglie() -> List[str]:
    """Le famiglie proponibili a pulsante, nell'ordine in cui si mostrano."""
    return list(SERVER_NOTI)

def server_ufficiali(famiglia: str) -> List[str]:
    """I nomi esatti di una famiglia; lista vuota se la famiglia non esiste."""
    voce = SERVER_NOTI.get(famiglia)
    return list(voce["ufficiali"]) if voce else []

def nota_famiglia(famiglia: str) -> str:
    """L'avvertenza della famiglia (dove trovare il nome vero), "" se non c'e'."""
    voce = SERVER_NOTI.get(famiglia)
    return (voce.get("nota") or "") if voce else ""

def famiglia_per_prop(prop_id: Optional[str]) -> Optional[str]:
    """La famiglia di server della prop scelta nel bot (config.PROP_FIRMS).

    Serve a saltare la domanda "di quale prop e' il conto?" a chi l'ha gia'
    detto configurando la prop. None quando la prop non ha server documentati
    (es. la demo TMGM): in quel caso si chiede, come sempre.
    """
    if not prop_id:
        return None
    for famiglia, voce in SERVER_NOTI.items():
        if voce.get("prop_id") == prop_id:
            return famiglia
    return None

# "...Server2" / "...Server 2": la cifra finale attaccata o staccata dal nome.
_CIFRA_FINALE = re.compile(r"^(.*[A-Za-z])\s*(\d+)$")

def _cifra_staccata(s: str) -> str:
    """FundedNext-Server2 -> FundedNext-Server 2 (il caso che rompe tutto)."""
    m = _CIFRA_FINALE.match(s)
    return f"{m.group(1)} {m.group(2)}" if m else ""

def _cifra_attaccata(s: str) -> str:
    """L'inverso: per i broker che invece la vogliono attaccata."""
    m = _CIFRA_FINALE.match(s)
    return f"{m.group(1)}{m.group(2)}" if m else ""

def _trattino_stretto(s: str) -> str:
    """FundedNext - Server 2 -> FundedNext-Server 2."""
    stretto = re.sub(r"\s*-\s*", "-", s)
    return stretto if stretto != s else ""

def _primo_spazio_in_trattino(s: str) -> str:
    """FundedNext Server 2 -> FundedNext-Server 2.

    Solo il PRIMO spazio, ed esclusivamente se non c'e' gia' un trattino: nei
    nomi MT5 il trattino separa il broker dal server, e il resto (l'eventuale
    numero) va lasciato dov'e'.
    """
    if "-" in s or " " not in s:
        return ""
    return s.replace(" ", "-", 1)

def varianti_server(nome: str) -> List[str]:
    """Grafie da provare, in ordine di probabilita' decrescente.

    La prima e' quella con cui conviene partire: il nome ufficiale se lo
    riconosciamo, altrimenti quello che ha scritto l'utente. Lista vuota solo
    se non ha scritto nulla.
    """
    grezzo = " ".join((nome or "").split())    # taglia e compatta gli spazi
    if not grezzo:
        return []
    # Nome gia' scritto ESATTAMENTE come lo documenta il fornitore: non c'e'
    # nessun refuso da correggere, e le varianti sarebbero solo login sprecati
    # verso il broker. Se non entra, il problema e' altrove (password, oppure
    # il conto sta su un altro server) e nessuna grafia lo risolve.
    if canonico(grezzo) == grezzo:
        return [grezzo]
    proposte = [
        canonico(grezzo) or "",                # il nome documentato vince
        grezzo,                                # poi quello che ha scritto lui
        _cifra_staccata(grezzo),
        _cifra_attaccata(grezzo),
        _trattino_stretto(grezzo),
        _primo_spazio_in_trattino(grezzo),
    ]
    viste, ordinate = set(), []
    for proposta in proposte:
        if proposta and proposta not in viste:
            viste.add(proposta)
            ordinate.append(proposta)
    return ordinate[:MAX_VARIANTI]

def suggerimento_nomi(nome: str) -> str:
    """Coda da allegare all'errore di accesso quando il server e' di una
    famiglia documentata ma la grafia non e' nessuna di quelle valide.

    E' l'unico modo per far uscire l'utente dal vicolo cieco: dirgli
    "ricontrolla il nome" non aiuta chi non vede lo spazio.
    """
    riconosciuta = famiglia_nota(nome)
    if not riconosciuta:
        return ""
    famiglia, ufficiali = riconosciuta
    elenco = "\n".join(f"   • {u}" for u in ufficiali)
    coda = f"\n\nI server di {famiglia} documentati sono:\n{elenco}"
    nota = SERVER_NOTI[famiglia].get("nota") or ""
    if nota:
        coda += f"\n\n{nota}"
    return coda
