import logging
from datetime import datetime, timezone
from functools import partial

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ConversationHandler,
    ContextTypes,
)
import MetaTrader5 as mt5

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    COSTO_PROP_AMOUNT,
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    PAYOUT_AMOUNT,
    PL_BROKER_INIT,
    RESET_PNL_CONFIRM,
)
from .messaging import _cancel_kb, ack, back_button, safe_edit_message_text
from .storage import carica_dati_async, modifica_dati_async, modifier_aggiungi_payout
from .state import (
    _inizio_ciclo_utc,
    modifier_aggiungi_costo_prop,
    modifier_reset_pnl,
    modifier_set_pl_broker_iniziale,
)
from .mt5_async import get_trade_history_async, info_account_async, info_account_prop_async
from .trade_core import _ora_italiana
from .handlers_base import guard_auth

# ========================= INFO ACCOUNT =========================
async def menu_info_account(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    keyboard = [
        [
            InlineKeyboardButton("🏦 Broker", callback_data="info_broker"),
            InlineKeyboardButton("📊 Prop",   callback_data="info_prop"),
        ],
        [InlineKeyboardButton("💰 Guadagno/perdita Totale", callback_data="pnl_tot")],
        [InlineKeyboardButton("💵 Inserisci payout",        callback_data="inserisci_payout")],
        [InlineKeyboardButton("🧾 Aggiungi costo prop",     callback_data="aggiungi_costo_prop")],
        [InlineKeyboardButton("📈 Imposta P/L broker",      callback_data="imposta_pl_broker")],
        [InlineKeyboardButton("♻️ Reset Guadagni/Perdite",  callback_data="reset_pnl")],
        [InlineKeyboardButton("⬅️ Indietro",                callback_data="gestisci")],
    ]
    await safe_edit_message_text(query, "Info Account", InlineKeyboardMarkup(keyboard))

async def info_broker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "⏳ Recupero info Broker in corso...")
    info = await info_account_async(MT5_BROKER_EXE)
    if info:
        dati    = await carica_dati_async()
        # Totale dei trade broker CHIUSI nel ciclo (dall'ultimo Reset P/L):
        # stesso valore della schermata "Guadagno/Perdita Totale". Prima qui
        # veniva mostrato pl_broker_ultimo (solo l'ULTIMO trade chiuso).
        totale_chiusi = float(dati.get("pl_broker_realizzato", 0.0) or 0.0)
        leva    = info.get("leverage", "N/D")
        balance = float(info["balance"])
        credit  = float(info.get("credit", 0.0) or 0.0)
        msg = (
            f"🏦 Info Account Broker\n\n"
            f"• Saldo reale: {balance:.2f}$\n"
            f"• Saldo (incluso bonus): {balance + credit:.2f}$\n"
            f"• Totale Guadagno/Perdita posizioni: {totale_chiusi:+.2f}$\n"
            f"• Leva: 1:{leva}"
        )
    else:
        msg = "Dati non disponibili o Broker non connesso."
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📜 Dettaglio Storico", callback_data="storico_show|broker")],
        back_button("info_account_menu"),
    ])
    await safe_edit_message_text(query, msg, keyboard)

async def info_prop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)
    await safe_edit_message_text(query, "⏳ Recupero info Prop in corso...")
    dati = await carica_dati_async()
    # NB: NON chiamare questa variabile "cfg": oscurerebbe l'alias del modulo
    # config (usato sotto come cfg.SIMBOLO_PROP) e il handler morirebbe con
    # AttributeError lasciando il messaggio fermo su "⏳". Gia' successo.
    cfg_prop = dati.get("prop_avanzata", {})
    if cfg_prop:
        info = await info_account_prop_async(MT5_PROP_EXE, cfg_prop)
    else:
        info = await info_account_async(MT5_PROP_EXE)
    if info:
        # Totale dei trade CHIUSI nel ciclo (dall'ultimo Reset P/L; senza reset,
        # ultimi 30gg), letto dallo storico MT5 del conto prop (autorevole).
        # Prima qui veniva mostrato il P/L FLOTTANTE delle posizioni aperte.
        riga_chiusi = "• Totale Guadagno/Perdita posizioni: n/d"
        cred_p = dati.get("prop") or {}
        if cred_p.get("id") and cred_p.get("password") and cred_p.get("server"):
            storico_p = await get_trade_history_async(
                MT5_PROP_EXE, int(cred_p["id"]), cred_p["password"], cred_p["server"],
                cfg.SIMBOLO_PROP, days=30, limit=None, since_utc=_inizio_ciclo_utc(dati),
            )
            if storico_p is not None:
                tot_chiusi_p = sum(float(r.get("profit", 0) or 0) for r in storico_p)
                riga_chiusi = f"• Totale Guadagno/Perdita posizioni: {tot_chiusi_p:+.2f}$"
        # Leva del conto, come nella schermata gemella del Broker. Se il dato
        # non e' un intero (terminale che non lo riporta) la riga sparisce
        # invece di stampare un "1:N/D" che non dice niente a nessuno.
        _leva_p   = info.get("leverage")
        riga_leva = f"\n• Leva: 1:{_leva_p}" if isinstance(_leva_p, int) else ""
        if cfg_prop:
            # Target a 0 (tipico dei conti reali/funded) = nessun obiettivo da
            # raggiungere: mostriamo un'etichetta invece di un numero senza senso.
            try:
                _target_cfg = float(cfg_prop.get("target", 0) or 0)
            except (TypeError, ValueError):
                _target_cfg = 0.0
            riga_target = (
                "• Mancanti a target: nessun obiettivo\n"
                if _target_cfg <= 0 else
                f"• Mancanti a target: {info['mancanti_target']:.2f}$\n"
            )
            # Profitto giornaliero massimo (regola di consistenza). Fino alla
            # v54.3 questa riga era una stringa FISSA "nessun limite": la
            # consistenza veniva chiesta all'utente, salvata... e mai usata.
            # None = nessun limite configurato -> il testo storico.
            _pgr = info.get("profitto_giornaliero_rimasto")
            if _pgr is None:
                riga_profitto = "• Profitto giornaliero rimasto: nessun limite\n"
            else:
                riga_profitto = (
                    f"• Profitto giornaliero rimasto: {_pgr:.2f}$"
                    f" (su {info.get('profitto_max_giornaliero', 0):.2f}$)\n"
                )
            msg = (
                f"📊 Info Account Prop\n\n"
                f"• Saldo: {info['balance']:.2f}$\n"
                f"• Saldo massimo raggiunto: {info['saldo_massimo']:.2f}$\n"
                f"{riga_target}"
                f"{riga_profitto}"
                f"• Perdita giornaliera rimasta: {info['perdita_giornaliera_rimasta']:.2f}$\n"
                f"• Perdita max rimasta: {info['dd_max_rimasto']:.2f}$\n"
                f"{riga_chiusi}"
                f"{riga_leva}"
            )
        else:
            # Senza configurazione prop avanzata: vista minima.
            msg = (
                f"📊 Info Account Prop\n\n"
                f"• Saldo: {info['balance']:.2f}$\n"
                f"• Equity: {info.get('equity', info['balance']):.2f}$\n"
                f"{riga_chiusi}"
                f"{riga_leva}"
            )
    else:
        msg = "Dati non disponibili o Prop non connessa."
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📜 Dettaglio Storico", callback_data="storico_show|prop")],
        back_button("info_account_menu"),
    ])
    await safe_edit_message_text(query, msg, keyboard)

async def pnl_totale(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    if not await guard_auth(update, context):
        return
    dati          = await carica_dati_async()
    p_l_broker    = float(dati.get("pl_broker_realizzato", 0.0) or 0.0)
    payouts       = dati.get("payouts", [])
    totale_payout = sum(float(p.get("importo", 0) or 0) for p in payouts)
    costi_prop    = dati.get("costi_prop", [])
    totale_costi  = sum(float(c.get("importo", 0) or 0) for c in costi_prop)
    netto         = p_l_broker + totale_payout - totale_costi
    reset_at      = dati.get("pnl_reset_at")
    reset_line    = ""
    if reset_at:
        try:
            r = datetime.fromisoformat(reset_at)
            if r.tzinfo is None:
                r = r.replace(tzinfo=timezone.utc)
            reset_line = f"\n\n♻️ Ultimo reset: {_ora_italiana(r).strftime('%Y-%m-%d %H:%M')} (ora italiana)"
        except Exception:
            pass
    msg = (
        f"💰 Guadagno/Perdita Totale\n\n"
        f"• Totale P/L posizioni broker: {p_l_broker:+.2f}$\n"
        f"• Totale payout: +{totale_payout:.2f}$\n"
        f"• Totale costi prop: {totale_costi:.2f}$\n"
        f"• Totale netto: {netto:+.2f}$"
        f"{reset_line}"
    )
    await safe_edit_message_text(query, msg, InlineKeyboardMarkup([back_button("info_account_menu")]))

# ========================= RESET GUADAGNI =========================
async def reset_pnl_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    dati          = await carica_dati_async()
    payouts       = dati.get("payouts", [])
    totale_payout = sum(float(p.get("importo", 0) or 0) for p in payouts)
    p_l_broker    = float(dati.get("pl_broker_realizzato", 0.0) or 0.0)
    costi_prop    = dati.get("costi_prop", [])
    totale_costi  = sum(float(c.get("importo", 0) or 0) for c in costi_prop)
    msg = (
        "♻️ Reset Guadagni/Perdite\n\n"
        "Verranno AZZERATI completamente:\n"
        f"• Payout: {len(payouts)} voci ({totale_payout:+.2f}$)\n"
        f"• P/L broker realizzato: {p_l_broker:+.2f}$\n"
        f"• Costi prop: {len(costi_prop)} voci ({totale_costi:.2f}$)\n"
        "• Metriche prop del ciclo: la Perdita giornaliera rimasta riparte "
        "dal limite pieno configurato, il Saldo massimo raggiunto e il Totale "
        "Guadagno/Perdita posizioni ripartono dal conto attuale\n\n"
        "Il conteggio Guadagno/Perdita Totale ripartirà da zero.\n"
        "ℹ️ Le posizioni MT5 e il saldo reale NON vengono toccati.\n\n"
        "Confermi l'operazione?"
    )
    keyboard = [
        [InlineKeyboardButton("✅ Sì, azzera tutto", callback_data="reset_pnl_si")],
        [InlineKeyboardButton("❌ No, annulla",      callback_data="reset_pnl_no")],
    ]
    await safe_edit_message_text(query, msg, InlineKeyboardMarkup(keyboard))
    return RESET_PNL_CONFIRM

async def reset_pnl_conferma(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await ack(query)
    if query.data == "reset_pnl_no":
        await safe_edit_message_text(
            query, "Operazione annullata.",
            InlineKeyboardMarkup([back_button("info_account_menu")]),
        )
        return ConversationHandler.END
    await modifica_dati_async(modifier_reset_pnl)
    await safe_edit_message_text(
        query,
        "✅ Azzerati payout, P/L broker realizzato, costi prop e metriche prop "
        "del ciclo (perdita giornaliera, saldo massimo, totale posizioni). "
        "Il contatore Guadagno/Perdita Totale riparte da zero.",
        InlineKeyboardMarkup([back_button("info_account_menu")]),
    )
    return ConversationHandler.END

# ========================= PAYOUT =========================
async def inserisci_payout_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    info = await info_account_async(MT5_PROP_EXE)
    if not info:
        await safe_edit_message_text(query, "Impossibile verificare il conto Prop.")
        return ConversationHandler.END
    if info.get("trade_mode") == mt5.ACCOUNT_TRADE_MODE_DEMO:
        await safe_edit_message_text(
            query, "⚠️ Il payout è solo per conti reali.",
            InlineKeyboardMarkup([back_button("info_account_menu")]),
        )
        return ConversationHandler.END
    await safe_edit_message_text(query, "Inserisci l'importo del payout in $:", _cancel_kb())
    return PAYOUT_AMOUNT

async def ricevi_payout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
        if val < 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("Valore non valido.", reply_markup=_cancel_kb())
        return PAYOUT_AMOUNT
    await modifica_dati_async(partial(modifier_aggiungi_payout, importo=val))
    await update.message.reply_text("✅ Payout registrato.")
    return ConversationHandler.END

# ========================= COSTI PROP (cumulativi) =========================
async def aggiungi_costo_prop_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    dati         = await carica_dati_async()
    costi        = dati.get("costi_prop", [])
    totale_costi = sum(float(c.get("importo", 0) or 0) for c in costi)
    await safe_edit_message_text(
        query,
        "Inserisci il costo di una prop da aggiungere al totale (in $).\n"
        "Ogni acquisto o reset prop si somma al cumulato.\n\n"
        f"Totale costi prop attuale: {totale_costi:.2f}$ ({len(costi)} voci)",
        _cancel_kb(),
    )
    return COSTO_PROP_AMOUNT

async def ricevi_costo_prop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
        if val < 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("Valore non valido.", reply_markup=_cancel_kb())
        return COSTO_PROP_AMOUNT
    await modifica_dati_async(partial(modifier_aggiungi_costo_prop, importo=val))
    await update.message.reply_text(f"✅ Costo prop di {val:.2f}$ aggiunto al totale.")
    return ConversationHandler.END

# ========================= P/L BROKER (seeding/correzione) =========================
async def imposta_pl_broker_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("waiting_for_password", None)
    if not await guard_auth(update, context):
        return ConversationHandler.END
    query = update.callback_query
    await ack(query)
    dati    = await carica_dati_async()
    attuale = float(dati.get("pl_broker_realizzato", 0.0) or 0.0)
    await safe_edit_message_text(
        query,
        "Imposta il P/L broker realizzato cumulato (in $).\n"
        f"Valore attuale: {attuale:+.2f}$\n\n"
        "Usa 0 per partire pulito su una nuova prop, oppure inserisci il valore "
        "storico. Sono ammessi numeri negativi.",
        _cancel_kb(),
    )
    return PL_BROKER_INIT

async def ricevi_pl_broker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        val = float(update.message.text.replace(",", "."))
    except ValueError:
        await update.message.reply_text("Valore non valido.", reply_markup=_cancel_kb())
        return PL_BROKER_INIT
    await modifica_dati_async(partial(modifier_set_pl_broker_iniziale, valore=val))
    await update.message.reply_text(f"✅ P/L broker impostato a {val:+.2f}$.")
    return ConversationHandler.END
