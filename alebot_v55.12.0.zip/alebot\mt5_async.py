"""Ponte async verso MT5.

Dal Passo 2 (worker paralleli) ogni operazione viene instradata al POOL
(mt5_pool): un processo worker per terminale, connessioni sempre calde,
Broker e Prop in parallelo. In fallback (MT5_WORKERS=0 o spawn fallito) il
pool esegue in-process con il lock globale, identico alla v51/v52.

Le firme dei wrapper sono INVARIATE rispetto alla v51: i call site non
cambiano. _mt5_timeout assorbe timeout ed errori di trasporto (Mt5PoolError)
restituendo None, esattamente come assorbiva gli errori dei thread.

REGOLA SUI TIMEOUT: il budget di _mt5_timeout deve restare SUPERIORE a quello
del worker (vedi la nota estesa in mt5_pool). Le operazioni composte — piu'
round-trip nello stesso wrapper — usano MT5_LONG_OP_TIMEOUT_SECONDS, quelle di
invio ordine WORKER_ORDER_TIMEOUT_S. Invertire quei rapporti riapre la corsa
sul pipe del worker.
"""
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple, Awaitable

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    MT5_BROKER_EXE,
    MT5_LONG_OP_TIMEOUT_SECONDS,
    MT5_OP_TIMEOUT_SECONDS,
    MT5_PROP_EXE,
)
from .storage import carica_dati_async, modifica_dati_async
from .mt5_pool import WORKER_ORDER_TIMEOUT_S, pool
# Solo le costanti degli esiti di chiusura: mt5_sync e' gia' importato dal
# processo principale (handlers_system), quindi non aggiunge dipendenze.
from .mt5_sync import ESITO_CHIUSA, ESITO_FALLITA, ESITO_GIA_CHIUSA

# ========================= LOCK & TIMEOUT WRAPPER =========================
# Serializza le chiusure di massa per evitare doppie chiusure tra news_monitor
# e nightly_close_loop / chiusura manuale.
_close_all_lock = asyncio.Lock()

async def _mt5_timeout(coro: Awaitable, name: str, timeout: float = MT5_OP_TIMEOUT_SECONDS):
    """
    Difensiva: limita il tempo di attesa per operazioni MT5.

    Il pool ha inoltre un suo timeout duro con riavvio del worker: un MT5
    davvero bloccato non richiede piu' l'intervento del watchdog esterno
    per tornare operativi.
    """
    try:
        return await asyncio.wait_for(coro, timeout=timeout)
    except asyncio.TimeoutError:
        logger.error(f"MT5 timeout ({timeout}s) in {name}.")
        return None
    except Exception:
        logger.exception(f"MT5 errore in {name}")
        return None

async def _creds_for_path(path: str) -> Tuple[Optional[int], Optional[str], Optional[str]]:
    """Risolve (login, password, server) dell'account associato al terminale.

    Usato dai wrapper di sola lettura (info/margine/simbolo) per loggarsi SEMPRE
    sull'account su cui opera il bot, non su quello mostrato dal terminale.
    """
    dati = await carica_dati_async()
    if path == MT5_PROP_EXE:
        cred = dati.get("prop")
    elif path == MT5_BROKER_EXE:
        cred = dati.get("broker")
    else:
        cred = None
    if cred and cred.get("id") and cred.get("password") and cred.get("server"):
        return int(cred["id"]), cred["password"], cred["server"]
    return None, None, None

async def info_account_async(path: str) -> Optional[Dict[str, Any]]:
    # Tutti i call site esistenti restano invariati: le credenziali sono
    # risolte qui in base al terminale.
    login, pwd, server = await _creds_for_path(path)
    return await _mt5_timeout(
        pool.exec(path, "info_account", path, login, pwd, server),
        "info_account_async",
    )

async def autotrading_attivo_async(
    path: str, login: int, password: str, server: str,
) -> Optional[bool]:
    """True/False/None se l'AutoTrading e' ON/OFF/non-determinabile (vedi
    _autotrading_attivo_sync). Su timeout _mt5_timeout torna None ->
    trattato come 'non determinabile'."""
    return await _mt5_timeout(
        pool.exec(path, "_autotrading_attivo_sync", path, login, password, server),
        "autotrading_attivo_async",
    )

async def esegui_ordine_async(
    path, login, psw, server, direzione, simbolo, lotti,
    sl_price, tp_price, commento="", magic=0,
    max_retry: int = 2, retry_delay: float = 1.5,
) -> Tuple[Optional[int], Optional[str]]:
    """
    Esegue l'ordine MT5 con retry SICURO. Ritorna (ticket, None) se eseguito,
    altrimenti (None, motivo) col motivo dell'ultimo tentativo.

    Prima di ogni retry verifica via positions_get(magic=...) se l'ordine
    e' gia' presente: in caso affermativo evita la duplicazione e restituisce
    il ticket esistente. Necessario perche' una risposta None puo' indicare
    un timeout di rete su un ordine effettivamente accettato dal broker —
    vale anche per un eventuale errore/timeout del worker.
    """
    ultimo_motivo = None
    for attempt in range(1 + max_retry):
        try:
            ticket, motivo = await pool.exec(
                path, "esegui_ordine", path, login, psw, server,
                direzione, simbolo, lotti, sl_price, tp_price, commento, magic,
                timeout=WORKER_ORDER_TIMEOUT_S,
            )
        except Exception as e:
            logger.exception("esegui_ordine_async: errore di trasporto worker")
            ticket, motivo = None, f"errore interno MT5 ({e})"
        if ticket is not None:
            return ticket, None
        ultimo_motivo = motivo
        if attempt >= max_retry:
            break
        # Prima di ritentare: l'ordine e' gia' arrivato al broker?
        try:
            esistente = await pool.exec(
                path, "_verifica_ordine_esistente_sync",
                path, login, psw, server, simbolo, magic,
            )
        except Exception:
            esistente = None
        if esistente:
            logger.warning(
                f"esegui_ordine_async: ordine gia' presente con magic={magic} "
                f"(ticket={esistente}). Evito duplicato e uso quello esistente."
            )
            return esistente, None
        logger.warning(
            f"esegui_ordine_async: tentativo {attempt + 1} fallito ({motivo}), "
            f"riprovo tra {retry_delay}s..."
        )
        await asyncio.sleep(retry_delay)
    logger.error(f"esegui_ordine_async: tutti i tentativi esauriti, ordine non inviato. Motivo: {ultimo_motivo}")
    return None, ultimo_motivo

async def chiudi_posizione_async(path, login, psw, server, ticket):
    res = await _mt5_timeout(
        pool.exec(path, "chiudi_posizione", path, login, psw, server, ticket),
        f"chiudi_posizione_async(ticket={ticket})",
    )
    return bool(res)

async def chiudi_posizione_esito_async(path, login, psw, server, ticket) -> str:
    """Come chiudi_posizione_async ma dice COM'E' andata: ESITO_CHIUSA /
    ESITO_GIA_CHIUSA / ESITO_FALLITA (vedi mt5_sync).

    Serve a chi non deve solo chiudere, ma anche RACCONTARLO all'utente: una
    posizione che non c'era gia' piu' non e' un guasto, e annunciarla come tale
    insegna a ignorare un allarme che un giorno sara' vero.
    """
    res = await _mt5_timeout(
        pool.exec(path, "chiudi_posizione_esito", path, login, psw, server, ticket),
        f"chiudi_posizione_esito_async(ticket={ticket})",
    )
    # Timeout o worker muto: nessuna notizia e' cattiva notizia.
    return res if isinstance(res, str) else ESITO_FALLITA

async def posizione_aperta_async(path, login, psw, server, ticket) -> Optional[bool]:
    """True/False/None = aperta / NON piu' aperta / non determinabile.

    Necessaria perche' chiudi_posizione_async() ritorna False sia quando la
    chiusura fallisce sia quando la posizione NON ESISTE PIU'. Confondere i due
    casi generava ritentativi eterni (e un avviso all'owner al minuto) su
    posizioni gia' chiuse dal mercato o da una chiusura di massa.
    """
    return await _mt5_timeout(
        pool.exec(path, "posizione_aperta_sync", path, login, psw, server, ticket),
        f"posizione_aperta_async(ticket={ticket})",
    )

async def stato_metatrader_async(path: str) -> str:
    res = await _mt5_timeout(
        pool.exec(path, "stato_metatrader", path),
        "stato_metatrader_async",
    )
    return res if isinstance(res, str) else "Non connesso"

async def leva_simbolo_async(path: str, simbolo: str) -> Optional[float]:
    """Leva effettiva sul simbolo (vedi mt5_sync.leva_simbolo). None = non
    calcolabile: chi mostra il dato scrive "n/d", mai la leva del conto."""
    login, pwd, server = await _creds_for_path(path)
    return await _mt5_timeout(
        pool.exec(path, "leva_simbolo", path, simbolo, login, pwd, server),
        "leva_simbolo_async",
    )

async def calcola_margine_wrapper_async(path, tipo_ord, simbolo, lotti, prezzo):
    login, pwd, server = await _creds_for_path(path)
    return await _mt5_timeout(
        pool.exec(path, "calcola_margine_wrapper",
                  path, tipo_ord, simbolo, lotti, prezzo, login, pwd, server),
        "calcola_margine_wrapper_async",
    )

async def get_symbol_info_wrapper_async(path, simbolo, direzione):
    login, pwd, server = await _creds_for_path(path)
    return await _mt5_timeout(
        pool.exec(path, "get_symbol_info_wrapper",
                  path, simbolo, direzione, login, pwd, server),
        "get_symbol_info_wrapper_async",
    )

async def valida_simbolo_volume_async(path, simbolo, volume):
    res = await _mt5_timeout(
        pool.exec(path, "valida_simbolo_volume", path, simbolo, volume),
        "valida_simbolo_volume_async",
    )
    if res is None:
        return False, "Timeout o errore comunicazione MT5"
    # Attraverso la pipe le tuple possono arrivare come liste: normalizza.
    return tuple(res)

async def get_position_by_ticket_async(path: str, login: int, password: str, server: str, ticket: int):
    return await _mt5_timeout(
        pool.exec(path, "_get_position_by_ticket_sync",
                  path, login, password, server, ticket),
        f"get_position_by_ticket_async({ticket})",
    )

async def get_position_close_info_async(
    path: str, login: int, password: str, server: str,
    ticket: int, opened_at_utc: Optional[str] = None,
):
    return await _mt5_timeout(
        pool.exec(path, "_extract_close_deal_sync",
                  path, login, password, server, ticket, opened_at_utc),
        f"get_position_close_info_async({ticket})",
    )

async def _close_info_con_retry(
    path: str, login: int, password: str, server: str,
    ticket: int, opened_at_utc: Optional[str] = None,
    tentativi: int = 3, pausa: float = 2.0,
):
    """Legge il deal di chiusura ritentando alcune volte. Subito dopo una
    chiusura (es. chiusura manuale) i fill possono non essere ANCORA tutti in
    history: la prima lettura tornerebbe None e, scrivendo con il write-once, il
    P/L del lato resterebbe "n/d" per sempre. Ritorna il close_info appena
    disponibile, altrimenti None dopo i tentativi."""
    info = await get_position_close_info_async(path, login, password, server, ticket, opened_at_utc)
    tent = 1
    while info is None and tent < tentativi:
        await asyncio.sleep(pausa)
        info = await get_position_close_info_async(path, login, password, server, ticket, opened_at_utc)
        tent += 1
    return info

async def _get_open_positions_snapshot_async(
    path: str, login: int, password: str, server: str, simbolo: str,
):
    return await _mt5_timeout(
        pool.exec(path, "_get_open_positions_snapshot_sync",
                  path, login, password, server, simbolo),
        "_get_open_positions_snapshot_async",
    )

async def get_open_tickets_by_symbol_async(
    path: str, login: int, password: str, server: str, simbolo: str,
) -> Optional[list]:
    return await _mt5_timeout(
        pool.exec(path, "_get_open_tickets_by_symbol_sync",
                  path, login, password, server, simbolo),
        "get_open_tickets_by_symbol_async",
    )

async def get_trade_history_async(
    path: str, login: int, password: str, server: str,
    simbolo: str, days: int = 30, limit: Optional[int] = 15,
    since_utc: Optional[datetime] = None,
    magic_ranges: Optional[List[Tuple[int, int]]] = None,
) -> Optional[list]:
    return await _mt5_timeout(
        pool.exec(path, "_get_trade_history_sync",
                  path, login, password, server, simbolo, days, limit, since_utc,
                  magic_ranges),
        "get_trade_history_async",
    )

async def info_account_prop_async(path: str, config: Dict[str, Any]) -> Dict[str, Any]:
    dati = await carica_dati_async()
    prop_cred = dati.get("prop") or {}

    async def _inner():
        oggi = await pool.exec(path, "get_server_date", path, cfg.SIMBOLO_PROP)
        # P/L realizzato OGGI dai soli trade prop chiusi: fonte primaria del
        # calcolo della perdita giornaliera, immune a rinnovi/reset/payout.
        # None (creds assenti o storico non leggibile) -> il calcolo ricade
        # sul metodo per differenza saldo dentro info_account_prop_sync.
        daily_pnl = None
        if prop_cred.get("id") and prop_cred.get("password") and prop_cred.get("server"):
            daily_pnl = await pool.exec(
                path, "_prop_daily_realized_pnl_sync", path,
                int(prop_cred["id"]), prop_cred["password"], prop_cred["server"],
                cfg.SIMBOLO_PROP, oggi,
            )
        result = await pool.exec(
            path, "info_account_prop_sync", path, config, oggi, dati, daily_pnl,
        )
        return oggi, result

    # Budget LUNGO: _inner fa tre round-trip verso il worker. Col budget da 30s
    # l'ultima chiamata poteva essere cancellata a meta', lasciando un thread
    # appeso sul pipe del terminale (vedi nota sui timeout in mt5_pool).
    bundle = await _mt5_timeout(
        _inner(), "info_account_prop_async", timeout=MT5_LONG_OP_TIMEOUT_SECONDS,
    )
    if not bundle:
        return {}
    oggi, result = bundle
    if not result:
        return result
    nuovo_giorno = result.get("nuovo_giorno", False)
    massimo      = result.get("saldo_massimo", 0)
    if nuovo_giorno or massimo > dati.get("prop_massimo_saldo", 0):
        def _update_stats(d):
            if nuovo_giorno:
                d["daily_start_balance"] = result["balance"]
                d["daily_start_date"]    = oggi.isoformat()
            if massimo > d.get("prop_massimo_saldo", 0):
                d["prop_massimo_saldo"]  = massimo
            return d
        await modifica_dati_async(_update_stats)
    return result
