﻿"""AleBot - bot Telegram di hedging broker/prop (pacchetto)."""

__version__ = "55.10.0"
