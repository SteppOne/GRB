import logging
import os
import warnings
from datetime import time as dt_time
from typing import Dict, Any, Optional

# --- SSL robusto: usa il cert-store di WINDOWS per la verifica dei certificati.
#     Risolve "CERTIFICATE_VERIFY_FAILED / self-signed certificate in chain" su VPS
#     con Python installato a mano (CA incomplete) o dietro proxy aziendali.
#     Vale per httpx (Telegram), requests (news) e urllib. Se 'truststore' non e'
#     installato si prosegue col comportamento di default, senza rompere nulla. ---
try:
    import truststore as _truststore
    _truststore.inject_into_ssl()
except Exception:
    pass

from telegram.warnings import PTBUserWarning
warnings.filterwarnings("ignore", category=PTBUserWarning)

# ========================= .ENV LOADING =========================
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # Se python-dotenv non e' installato, leggiamo direttamente dall'ambiente reale.
    pass

def _require_env(name: str) -> str:
    val = os.getenv(name)
    if not val or not str(val).strip():
        raise RuntimeError(
            f"Variabile d'ambiente '{name}' mancante o vuota. "
            f"Crea/aggiorna il file .env nella stessa cartella del bot."
        )
    return val.strip()

def _optional_env(name: str) -> str:
    """Come _require_env ma NON solleva: ritorna "" se assente/vuota.
    Usato per le impostazioni opzionali (es. abbonamento) che non devono
    impedire l'avvio del bot se non configurate."""
    val = os.getenv(name)
    return val.strip() if val and str(val).strip() else ""

# ========================= CONFIGURAZIONE =========================
TOKEN           = _require_env("TELEGRAM_TOKEN")

# Fonte news. Se NEWS_SOURCE_URL e' impostata, il bot legge il calendario da una
# fonte CENTRALE condivisa (un solo fetcher per tutti i bot) e le chiavi API NON
# servono su questa VPS. Se NON e' impostata, il bot chiama direttamente Finnhub/FMP
# e le chiavi sono obbligatorie (comportamento storico, pienamente retro-compatibile).
NEWS_SOURCE_URL = _optional_env("NEWS_SOURCE_URL")
if NEWS_SOURCE_URL:
    FINNHUB_API_KEY = _optional_env("FINNHUB_API_KEY")
    FMP_API_KEY     = _optional_env("FMP_API_KEY")
else:
    FINNHUB_API_KEY = _require_env("FINNHUB_API_KEY")
    FMP_API_KEY     = _require_env("FMP_API_KEY")
MT5_BROKER_DIR  = _require_env("MT5_BROKER_DIR")
MT5_PROP_DIR    = _require_env("MT5_PROP_DIR")
SIMBOLO_BROKER  = _require_env("SIMBOLO_BROKER")
SIMBOLO_PROP    = _require_env("SIMBOLO_PROP")

# Simboli XAUUSD per societa' prop: si impostano nel .env (uno per prop) e sono
# il valore abbinato quando l'utente sceglie la prop dal bot. Se la variabile
# non e' presente nel .env, default "XAUUSD" (nessun crash all'avvio).
SIMBOLO_FUNDEDNEXT = _optional_env("SIMBOLO_FUNDEDNEXT") or "XAUUSD"
SIMBOLO_FINTOKEI   = _optional_env("SIMBOLO_FINTOKEI")   or "XAUUSD"

# ---- Abbonamento (tutte OPZIONALI: se assenti, nessun vincolo) ----
# ADMIN_CHANNEL_ID: canale Telegram privato (gestito dal proprietario delle VPS)
#   dove arrivano gli avvisi di scadenza e da cui si rinnova. Lo stesso valore su
#   tutte le VPS; ogni bot dev'essere amministratore del canale.
# CLIENT_ID: slug senza spazi per indirizzare i comandi a QUESTA VPS (es. andrearossi).
# CLIENT_NOME: nome leggibile mostrato negli avvisi (es. "Andrea Rossi").
# SUB_UNTIL: scadenza iniziale opzionale (AAAA-MM-GG); poi si rinnova via comando.
ADMIN_CHANNEL_ID = _optional_env("ADMIN_CHANNEL_ID")
CLIENT_ID        = _optional_env("CLIENT_ID")
CLIENT_NOME      = _optional_env("CLIENT_NOME") or CLIENT_ID or "questo cliente"
SUB_UNTIL_ENV    = _optional_env("SUB_UNTIL")

MT5_BROKER_EXE = os.path.join(MT5_BROKER_DIR, "terminal64.exe")
MT5_PROP_EXE   = os.path.join(MT5_PROP_DIR,   "terminal64.exe")

# Cartella del bot. TUTTI i file di stato sono ancorati QUI con percorsi ASSOLUTI,
# NON relativi alla working-directory. Cosi' chiave di cifratura e dati NON vengono
# mai rigenerati/persi se il bot parte con una CWD diversa (avvio manuale, Task
# Scheduler senza "Start in", ecc.). Coerente col watchdog (stesso BASE_DIR).
# NB pacchetto: __file__ e' alebot/config.py -> la cartella del bot e' il
# PADRE del pacchetto. Stessi percorsi assoluti della v51 monolitica.
BASE_DIR       = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Nome dell'entry-point con cui watchdog/avvia.bat lanciano il bot: usato
# dal lock anti doppia-istanza per riconoscere un processo gemello.
ENTRY_SCRIPT_NAME = "alev51.py"

DATA_FILE      = os.path.join(BASE_DIR, "user_data.enc")
KEY_FILE       = os.path.join(BASE_DIR, "encryption.key")
BACKUP_FILE    = os.path.join(BASE_DIR, "user_data.enc.bak")
HEARTBEAT_FILE = os.path.join(BASE_DIR, "heartbeat.txt")
HEARTBEAT_INTERVAL_SECONDS         = 30
BOOT_RECONCILIATION_DELAY_SECONDS  = 5

# File usati per il coordinamento con il watchdog esterno (watchdog.py).
BOT_LOCK_FILE       = os.path.join(BASE_DIR, "bot.lock")        # PID dell'istanza attiva (anti doppio avvio)
OWNER_CHAT_SIDECAR  = os.path.join(BASE_DIR, "owner_chat.txt")  # chat-id owner in chiaro, per gli avvisi del watchdog

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram.ext").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

# ========================= COSTANTI DI BUSINESS / SAFETY =========================
RAPPORTO_LOTTO_INCASSO      = 6000   # divisore della formula: lotti_broker = lotti_prop * (incasso / RAPPORTO)
INCASSO_DEFAULT             = 630.0   # incasso usato se non ne e' stato configurato uno
MEMO_CLEANUP_DAYS           = 30     # i memo chiusi piu' vecchi di N giorni vengono purgati al boot
# Update Telegram lavorati IN PARALLELO. Con 1 (default di PTB) un solo
# handler lento congela l'intero bot, /start incluso: e' la causa del guasto
# "bot bloccato dopo il riavvio dei terminali". Vedi la nota in app.main().
CONCURRENT_UPDATES          = 16
# CATENA DEI TIMEOUT — regola: chi sta piu' in alto aspetta piu' a lungo.
#     mt5_sync (init 45s + login 20s)  <  worker (75s)  <  wrapper (85s)
# Se il wrapper si arrende prima del worker, il thread resta appeso sulla pipe;
# se il worker si arrende prima di MT5, si butta via una chiamata che stava per
# riuscire — ed e' esattamente cio' che e' successo il 26/07/2026, con un
# terminale che impiegava 12-40 s a sincronizzarsi dopo il riavvio.
# Sembrano valori alti: lo sono di proposito. A tenere REATTIVO il bot ci
# pensano la quarantena (i guasti ripetuti costano zero) e concurrent_updates.
MT5_OP_TIMEOUT_SECONDS      = 85
# Budget per le operazioni COMPOSTE (piu' round-trip nello stesso wrapper, es.
# info_account_prop_async che ne fa tre).
MT5_LONG_OP_TIMEOUT_SECONDS = 240
TRADE_CLOSE_MONITOR_SECONDS = 60
CLOSE_INFO_MAX_WAIT_MIN     = 10     # se dopo N min il deal di chiusura di un lato resta illeggibile, notifica comunque (con n/d) per non lasciare l'owner senza ricevuta
SCHEDULED_OPEN_CHECK_SECONDS = 60    # cadenza del loop apertura programmata + backstop chiusura sfida
SCHEDULED_LATE_GRACE_MINUTES = 15    # se il bot torna online entro N min dall'orario, apre; oltre, salta
PROP_DAILY_BASELINE_SECONDS  = 300   # cadenza con cui si aggancia il saldo di inizio giornata prop, per un reset giornaliero affidabile anche senza che l'utente apra Info Prop

# Worker MT5 paralleli (un processo per terminale, connessioni sempre calde).
# Default ATTIVI; MT5_WORKERS=0 nel .env forza il vecchio modello in-process.
# Se lo spawn dei worker fallisce, il bot degrada da solo all'in-process.
MT5_WORKERS_ENABLED = (_optional_env("MT5_WORKERS") or "1").strip() != "0"

# Guardiano di coppia: cadenza del controllo "una gamba chiusa, l'altra no".
# Coi worker sempre connessi il controllo costa millisecondi: si puo' tenere
# strettissimo. In fallback in-process si allenta per non saturare il lock.
PAIR_GUARD_SECONDS          = 2
PAIR_GUARD_SECONDS_FALLBACK = 10

SYMBOLS = {
    "broker": SIMBOLO_BROKER,
    "prop":   SIMBOLO_PROP,
}

def get_symbol(account_type: str) -> str:
    return SYMBOLS[account_type]

# ===================== SOCIETÀ PROP SUPPORTATE =====================
# Elenco delle prop selezionabili dal bot. Il SIMBOLO di ciascuna si imposta nel
# .env (SIMBOLO_FUNDEDNEXT / SIMBOLO_FINTOKEI): per cambiarlo basta modificare il
# .env, senza toccare il codice. Per AGGIUNGERE una prop nuova si aggiunge qui una
# riga (id univoco, etichetta) e la rispettiva variabile nel .env.
PROP_FIRMS = [
    {"id": "fundednext", "label": "FundedNext / demo TMGM", "simbolo": SIMBOLO_FUNDEDNEXT},
    {"id": "fintokei",   "label": "Fintokei",   "simbolo": SIMBOLO_FINTOKEI},
]

def _prop_firm_by_id(fid: str) -> Optional[Dict[str, Any]]:
    return next((f for f in PROP_FIRMS if f["id"] == fid), None)

def _attiva_simbolo_prop(sym: Optional[str]) -> None:
    """Imposta, per l'intero processo, il simbolo prop attivo (override del .env).

    SIMBOLO_PROP nasce dal .env come fallback; quando l'utente sceglie una prop
    il suo simbolo viene attivato qui e ri-applicato a ogni avvio dal valore
    salvato (vedi post_init). Tutti i punti che leggono SIMBOLO_PROP usano
    automaticamente il valore aggiornato.
    """
    global SIMBOLO_PROP
    if sym:
        SIMBOLO_PROP = sym

# ========================= STATI CONVERSATION =========================
AUTH_PASSWORD = 101
BR_ID, BR_PSW, BR_SERVER = 111, 112, 113
PR_ID, PR_PSW, PR_SERVER = 121, 122, 123
BR_CONFIRM = 114
BR_RETRY = 115
PR_CONFIRM = 126
PR_RETRY = 127
CFG_PR_MODE = 250
CFG_PR_CONFIRM = 251
CFG_PR_FIRM = 252   # scelta della società prop (abbina il simbolo)
CFG_PR_SALDO, CFG_PR_TARGET, CFG_PR_DDMAX, CFG_PR_DDDAILY, CFG_PR_COSTO = 220, 221, 222, 223, 224
CFG_PR_INCASSO, CFG_PR_TIPINC, CFG_PR_TIPDD, CFG_PR_CONS = 225, 226, 227, 228
CFG_PR_COSTO_RESET = 229
INCASSO_TARGET = 231
PWD_NEW, PWD_CONFIRM = 311, 312
SL, TP, LOTTI, CONFERMA = 411, 412, 413, 414
MEMO = 415
PROGRAMMA_ORARIO = 416   # input HH:MM per l'apertura programmata
# Trade minimo per giorno (trade-sfida: singolo, solo Prop, no hedge)
CHALLENGE_DIREZIONE, CHALLENGE_LOTTI, CHALLENGE_MINUTI, CHALLENGE_CONFERMA = 417, 418, 419, 420
# Apertura manuale: step "modifica incasso" prima del memo
INCASSO_MODIFICA_CHIEDI, INCASSO_MODIFICA_NUOVO = 421, 422
# Avviso "SL oltre la perdita giornaliera rimasta della prop" (Sì/No)
SL_RISCHIO_CONFERMA = 423
# Margine di sicurezza 10%: l'avviso scatta gia' quando lo SL inserito
# raggiunge il 90% della perdita giornaliera rimasta della prop.
SL_DAILY_SAFETY_FACTOR = 0.90
TEST_CONFIRM = 511
PAYOUT_AMOUNT = 611
CHIUDI_CONFIRM = 712
RESET_PNL_CONFIRM = 811   # nuovo: conferma reset payout
PL_BROKER_INIT    = 911   # input: imposta P/L broker realizzato iniziale (seeding)
COSTO_PROP_AMOUNT = 912   # input: aggiungi un costo prop al totale cumulato
# Rinnovo abbonamento: segnalazione "ho pagato" verso il canale admin
RENEW_CONFIRM, RENEW_METODO, RENEW_ALTRO = 1011, 1012, 1013

# ========================= PROGRAMMAZIONE OPERATIVA =========================
NIGHT_CLOSE_START = dt_time(22, 45)
NIGHT_CLOSE_END   = dt_time(22, 55)
OPEN_BLOCK_START  = dt_time(23, 0)
OPEN_BLOCK_END    = dt_time(1, 0)
NEWS_REFRESH_SECONDS = 300
NEWS_BLACKOUT_MINUTES = 45
NEWS_CLOSE_MINUTES_MIN = 12
NEWS_CLOSE_MINUTES_MAX = 18
# Avvisi "protezione news degradata" al canale admin (de-dup giornaliero):
# feed centrale piu' vecchio di 6 ore, oppure fetch fallito per ~3 ore di fila.
NEWS_FEED_STALE_ALERT_MIN    = 360
NEWS_FETCH_FAIL_ALERT_STREAK = 36   # 36 cicli da 300s = ~3 ore

# Valute monitorate per le news che muovono XAUUSD, ad alto impatto.
# NB: il feed centrale (news_fetcher.py su GitHub) deve PUBBLICARE queste valute,
# altrimenti non arrivano qui: tieni allineato il set CURRENCIES del fetcher.
NEWS_XAUUSD_CURRENCIES: frozenset = frozenset({"USD", "AUD"})
