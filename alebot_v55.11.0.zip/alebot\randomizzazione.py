"""Randomizzazione dei parametri di apertura: qui dentro c'e' solo aritmetica.

PERCHE' ESISTE. Una prop guarda i trade anche con occhio statistico: lotti
sempre tondi (1.00, 1.50) e la stessa perdita a stop loss ripetuta giorno dopo
giorno sono una FIRMA, ed e' esattamente cio' che non deve esserci. Con la
randomizzazione attiva ogni apertura porta numeri leggermente diversi dalle
altre, senza cambiare la strategia.

COSA VIENE RITOCCATO, E COSA NO. Si ritoccano i TRE numeri che l'utente digita
— perdita a stop loss in $, guadagno a take profit in $, lotti prop — e nulla
piu'. Tutto il resto (lotti broker, livelli SL/TP, copertura, margini) si
ricalcola dalle formule di sempre sui valori nuovi: l'hedge resta bilanciato al
centesimo proprio PERCHE' qui dentro non c'e' nessuna formula duplicata.

UN FATTO CHE VALE PER I LOTTI. Lo stop loss e' espresso in DOLLARI, non in
punti: con piu' lotti il bot calcola una distanza di prezzo piu' STRETTA, e la
perdita a stop loss resta quella richiesta. Ritoccare i lotti quindi non cambia
i soldi a rischio, cambia la distanza dello stop — ed e' il motivo per cui la
percentuale sui lotti puo' permettersi di essere piu' generosa di quella sui $.

DUE PROTEZIONI, e nessuna delle due e' facoltativa:

  soglia giornaliera  se il valore digitato NON aveva fatto scattare l'avviso
                      "perdita giornaliera rimasta" (o il gemello sul take
                      profit, regola di consistenza), il ritocco non puo' farlo
                      scattare: in quel caso il segno si inverte. Se invece
                      l'avviso era scattato ed e' stato confermato dall'utente,
                      il ritocco resta libero — quella decisione era sua.

  pavimento sui lotti il volume finale non scende mai sotto il lotto minimo
                      negoziabile. Un volume nullo o negativo verrebbe
                      rifiutato dal broker e lascerebbe la PROP SCOPERTA.

I lotti si contano in Decimal, non in float: `1.2 + 0.12` in virgola mobile fa
1.3199999999999998, che non e' un multiplo di 0.01 e che il broker rifiuta come
volume non valido. E' la stessa trappola del calcolo dei lotti broker (v55.2).
"""
import logging
import random
from decimal import Decimal, ROUND_DOWN
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

from .config import (
    LOTTO_MINIMO,
    RANDOM_LOTTI_PERC,
    RANDOM_LOTTI_STEP,
    RANDOM_SL_TP_PERC,
)
from .storage import leggi_chiave_async

# Chiave dello stato cifrato. Assente = spenta: chi aggiorna il bot non si
# ritrova un comportamento nuovo senza averlo chiesto.
CHIAVE_RANDOMIZZAZIONE = "randomizzazione_attiva"


async def randomizzazione_attiva() -> bool:
    """La randomizzazione e' accesa? (default: NO)"""
    return bool(await leggi_chiave_async(CHIAVE_RANDOMIZZAZIONE, False))


def _delta_a_passi(valore: float, perc: float, passo: str, rng) -> float:
    """Ritocco = un numero intero di PASSI, sorteggiato a caso.

    Il passo e' il centesimo: di dollaro per SL/TP, di lotto per il volume (che
    e' anche il passo minimo che i broker accettano).

    PERCHE' UN SORTEGGIO DISCRETO e non un numero continuo poi arrotondato. Un
    valore continuo troncato al passo ha due difetti, e sono proprio due
    irregolarita' statistiche in una funzione che esiste per non averne:

      • l'estremo diventa irraggiungibile — su 1.5 lotti (±0.15) il troncamento
        non produce MAI 0.15, perche' servirebbe un sorteggio ≥ 0.15 che non
        puo' uscire: il massimo reale sarebbe 0.14;
      • lo ZERO pesa il doppio di ogni altro valore, perche' tutto l'intervallo
        (-0.01, +0.01) ci finisce dentro.

    Sorteggiando direttamente il numero di passi, ogni valore ammesso ha la
    stessa probabilita' e il tetto e' esatto. Il conto del tetto si fa in
    Decimal: 1800 x 1.5% deve fare 27.00 e non 27.000000000000004.
    """
    try:
        base = Decimal(str(float(valore)))
    except (TypeError, ValueError):
        return 0.0
    if base <= 0 or perc <= 0:
        return 0.0
    q = Decimal(passo)
    # Passi INTERI dentro il tetto: cosi' la percentuale non viene mai superata
    # (su 1.37 lotti il 10% e' 0.137 -> 13 passi, cioe' 0.13).
    passi = int((base * Decimal(str(perc)) / Decimal(100) / q).to_integral_value(
        rounding=ROUND_DOWN))
    if passi <= 0:
        # Il tetto non arriva a coprire un passo: su 0.05 lotti il 10% e' 0.005,
        # e un ritocco piu' fine di 0.01 lotti semplicemente non esiste.
        return 0.0
    # "+ 0.0" normalizza l'eventuale zero NEGATIVO: "-0.00$" nel riepilogo
    # sembrerebbe un errore del bot.
    return float(q * rng.randint(-passi, passi)) + 0.0


def _rispetta_soglia(base: float, delta: float, soglia: Optional[float]):
    """Il ritocco non fa scattare un avviso che il valore digitato non aveva fatto
    scattare. Ritorna (delta_eventualmente_invertito, invertito).

    Un delta NEGATIVO non puo' far superare una soglia superiore: si tocca solo
    il caso in cui il ritocco spinge verso l'alto. E se il valore digitato era
    gia' oltre la soglia, l'avviso l'utente l'ha gia' visto e confermato: non
    c'e' piu' niente da preservare.
    """
    if delta <= 0 or soglia is None:
        return delta, False
    try:
        limite = float(soglia)
    except (TypeError, ValueError):
        return delta, False
    if limite <= 0 or base >= limite:
        return delta, False
    if base + delta < limite:
        return delta, False
    return -delta, True


def randomizza_parametri(
    sl_dol: float,
    tp_dol: float,
    lotti_prop: float,
    soglia_sl: Optional[float] = None,
    soglia_tp: Optional[float] = None,
    rng: Optional[random.Random] = None,
) -> Dict[str, Any]:
    """Applica il ritocco ai tre parametri richiesti dall'utente.

    `soglia_sl` / `soglia_tp` sono i livelli oltre i quali il bot avvisa
    (perdita giornaliera rimasta x fattore, profitto giornaliero x fattore),
    gia' calcolati da chi ha fatto quel controllo: None se non erano leggibili.

    `rng` esiste per i test: iniettando un random.Random(seed) il sorteggio
    diventa riproducibile.

    Ritorna sempre un dict completo — valori finali, valori richiesti e delta —
    cosi' il chiamante puo' mostrarli, registrarli e scriverli nel log senza
    rifare nessun conto.
    """
    generatore = rng if rng is not None else random
    sl_base    = float(sl_dol)
    tp_base    = float(tp_dol)
    lotti_base = float(lotti_prop)

    # SL e TP si muovono al centesimo di dollaro, i lotti al passo del volume.
    delta_sl = _delta_a_passi(sl_base,    RANDOM_SL_TP_PERC, "0.01",            generatore)
    delta_tp = _delta_a_passi(tp_base,    RANDOM_SL_TP_PERC, "0.01",            generatore)
    delta_lo = _delta_a_passi(lotti_base, RANDOM_LOTTI_PERC, RANDOM_LOTTI_STEP, generatore)

    delta_sl, invertito_sl = _rispetta_soglia(sl_base, delta_sl, soglia_sl)
    delta_tp, invertito_tp = _rispetta_soglia(tp_base, delta_tp, soglia_tp)

    # Lotti in Decimal: vedi la nota in testa al modulo.
    lotti_finali = float(Decimal(str(lotti_base)) + Decimal(str(delta_lo)))
    if lotti_finali < LOTTO_MINIMO:
        # Rete di sicurezza: con le percentuali attuali non puo' scattare (il
        # delta e' una frazione del volume), ma se un domani la percentuale
        # venisse alzata, un volume sotto il minimo verrebbe rifiutato dal
        # broker e la prop resterebbe scoperta. Meglio nessun ritocco.
        logger.warning(
            f"Randomizzazione: delta lotti {delta_lo:+.2f} porterebbe il volume "
            f"a {lotti_finali} (sotto il minimo {LOTTO_MINIMO}): lo annullo."
        )
        delta_lo     = 0.0
        lotti_finali = lotti_base

    return {
        "sl_dol":          round(sl_base + delta_sl, 2),
        "tp_dol":          round(tp_base + delta_tp, 2),
        "lotti_prop":      lotti_finali,
        "sl_richiesto":    sl_base,
        "tp_richiesto":    tp_base,
        "lotti_richiesti": lotti_base,
        "delta_sl":        delta_sl,
        "delta_tp":        delta_tp,
        "delta_lotti":     delta_lo,
        "invertito_sl":    invertito_sl,
        "invertito_tp":    invertito_tp,
    }


def _fmt_lotti(valore: float) -> str:
    return f"{float(valore):g}"


def blocco_riepilogo(rnd: Optional[Dict[str, Any]]) -> str:
    """Le righe da mostrare nel riepilogo dell'ordine (stringa vuota se spenta).

    Si mostrano SEMPRE i valori veri, quelli che andranno a mercato, e accanto
    il ritocco applicato: il riepilogo e' l'ultimo posto in cui l'utente puo'
    fermare il trade, e non deve mai dire un numero diverso da quello che verra'
    aperto.
    """
    if not rnd:
        return ""
    righe = [
        "🎲 Randomizzazione attiva",
        f"📦 Lotti: {_fmt_lotti(rnd['lotti_richiesti'])} → "
        f"{_fmt_lotti(rnd['lotti_prop'])} ({rnd['delta_lotti']:+.2f})",
        f"🛑 SL: {rnd['sl_richiesto']:.2f}$ → {rnd['sl_dol']:.2f}$ ({rnd['delta_sl']:+.2f}$)",
        f"🎯 TP: {rnd['tp_richiesto']:.2f}$ → {rnd['tp_dol']:.2f}$ ({rnd['delta_tp']:+.2f}$)",
    ]
    if rnd.get("invertito_sl") or rnd.get("invertito_tp"):
        righe.append(
            "ℹ️ Ritocco girato verso il basso per non avvicinare i limiti "
            "giornalieri della prop."
        )
    return "\n".join(righe)


def riga_log(rnd: Optional[Dict[str, Any]]) -> str:
    """Riga di log con TUTTI i numeri del sorteggio: e' l'unico posto in cui, a
    distanza di giorni, si puo' ricostruire perche' un trade aveva quei valori."""
    if not rnd:
        return "Randomizzazione: spenta."
    return (
        "Randomizzazione: "
        f"lotti {_fmt_lotti(rnd['lotti_richiesti'])} → {_fmt_lotti(rnd['lotti_prop'])} "
        f"({rnd['delta_lotti']:+.2f}, max ±{RANDOM_LOTTI_PERC:g}%) | "
        f"SL {rnd['sl_richiesto']:.2f}$ → {rnd['sl_dol']:.2f}$ "
        f"({rnd['delta_sl']:+.2f}$, max ±{RANDOM_SL_TP_PERC:g}%) | "
        f"TP {rnd['tp_richiesto']:.2f}$ → {rnd['tp_dol']:.2f}$ "
        f"({rnd['delta_tp']:+.2f}$)"
        + (" | segno invertito per la soglia giornaliera"
           if rnd.get("invertito_sl") or rnd.get("invertito_tp") else "")
    )
