import logging
from datetime import datetime, timedelta, time as dt_time, timezone
from decimal import Decimal, ROUND_DOWN, ROUND_UP
from typing import Optional

from telegram import Update, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes,
)

logger = logging.getLogger(__name__)

from . import config as cfg
from .config import (
    COMPENSAZIONE_MAX,
    COMPENSAZIONE_MIN,
    INCASSO_DEFAULT,
    LOTTO_MINIMO,
    MT5_BROKER_EXE,
    MT5_PROP_EXE,
    RAPPORTO_LOTTO_INCASSO,
    SIMBOLO_BROKER,
)
from .broker_condiviso import nota_altrui, separa_posizioni
from .messaging import ack, back_button, safe_edit_message_text
from .storage import carica_dati_async, modifica_dati_async, modifier_incrementa_magic
from .mt5_async import _get_open_positions_snapshot_async
from .handlers_base import guard_auth

# ========================= MAGIC ATOMICO + LOTTI =========================
async def genera_magic() -> int:
    dati = await modifica_dati_async(modifier_incrementa_magic)
    return dati["next_magic"] - 1

def arrotonda_lotti_verso_su(valore: float, step: str = "0.01") -> float:
    """Arrotondamento storico: mai sotto il volume calcolato.

    E' quello che si usa quando lo scarto di quotazione NON e' misurabile
    (terminale broker muto): senza compensazione, uno scalino in piu' e' il
    modo prudente di non restare sotto copertura.
    """
    d = Decimal(str(valore))
    q = Decimal(step)
    return float(d.quantize(q, rounding=ROUND_UP))


def tronca_lotti(valore: float, step: str = "0.01") -> float:
    """Taglia il volume allo step del broker, SENZA arrotondare in su.

    Si usa quando la compensazione dello scarto e' stata MISURATA: li' il
    volume calcolato e' gia' quello giusto al centesimo, e arrotondare in su
    aggiungerebbe copertura non richiesta. E' anche cio' che fa il bot di
    riferimento (0.4116 lotti -> ne apre 0.41).
    """
    d = Decimal(str(valore))
    q = Decimal(step)
    return float(d.quantize(q, rounding=ROUND_DOWN))


def distanza_prezzo(dollari: float, lotti: float, point: float, tick_value: float) -> float:
    """Quanto prezzo vale una perdita/guadagno in dollari, su questo simbolo.

    E' l'inverso di semiauto_core.dollari_da_distanza; le due vanno lette
    insieme. Ritorna 0.0 sui dati non validi, cosi' il chiamante decide.
    """
    if lotti <= 0 or tick_value <= 0 or point <= 0:
        return 0.0
    return float(dollari) / (float(lotti) * float(tick_value)) * float(point)


def fattore_compensazione(
    distanza_sl: float, scarto: float, direzione_prop: str,
) -> Optional[float]:
    """Di quanto vanno ingrassati i lotti broker per incassare davvero il dovuto.

    IL PROBLEMA. I livelli della gamba broker sono lo SPECCHIO di quelli della
    prop, ma i due conti non quotano allo stesso prezzo (e all'ingresso si paga
    mezzo spread per parte). Quando la prop tocca il suo Stop Loss, il broker si
    trova a `distanza_sl ± scarto` dal proprio prezzo di ingresso, non a
    `distanza_sl`: con i lotti puri incassa meno del richiesto.

    LA CORREZIONE. Serve che  lotti x (distanza_sl ± scarto) = lotti_puri x
    distanza_sl, quindi il fattore e' distanza_sl / (distanza_sl ± scarto).

    IL SEGNO. `scarto` = prezzo_broker - prezzo_prop, con i prezzi di INGRESSO
    effettivi (ask o bid a seconda del lato). Se la prop e' in acquisto il
    broker vende: il suo guadagno cresce con lo scarto, quindi va sommato. Se la
    prop vende, il broker compra e vale l'opposto.

    Ritorna None quando il conto non e' affidabile (dati mancanti, scarto
    grande quanto lo Stop Loss): il chiamante torna ai lotti puri.
    """
    try:
        dist = float(distanza_sl)
        off  = float(scarto)
    except (TypeError, ValueError):
        return None
    if dist <= 0:
        return None
    segno = 1.0 if str(direzione_prop).upper() == "BUY" else -1.0
    denominatore = dist + segno * off
    if denominatore <= 0:
        return None
    fattore = dist / denominatore
    if not (COMPENSAZIONE_MIN <= fattore <= COMPENSAZIONE_MAX):
        logger.warning(
            f"Compensazione scarto fuori banda ({fattore:.4f}): scarto {off:+.4f} "
            f"su distanza SL {dist:.4f}. Uso i lotti puri."
        )
        return None
    return fattore

def _incasso_corrente(dati: dict) -> float:
    """Incasso configurato (incasso_target, o legacy incasso_se_bruciata).
    Se non configurato o non valido -> INCASSO_DEFAULT (630)."""
    pa = dati.get("prop_avanzata", {}) or {}
    try:
        v = float(pa.get("incasso_target", pa.get("incasso_se_bruciata", 0)) or 0)
    except (TypeError, ValueError):
        v = 0.0
    return v if v > 0 else INCASSO_DEFAULT

def divisore_incasso(dati: dict) -> float:
    """Divisore della formula dei lotti = PERDITA MASSIMA TOTALE in dollari.

    COS'E' DAVVERO IL "6000" DELLA v51: non una costante magica, ma la perdita
    massima totale di un conto da 100.000 al 6% (100.000 x 6% = 6000). Chi
    scrisse la v51 aveva quella prop in mente e ne congelo' il risultato.

    PERCHE' IL DIVISORE E' IL DD MASSIMO — la matematica dell'hedge:
      il broker e' opposto, quindi quando la prop perde, il broker guadagna:
          guadagno_broker = perdita_prop x (lotti_broker / lotti_prop)
      Nella griglia gli SL dei singoli step SOMMANO fino al DD massimo, quindi
      a prop bruciata:
          guadagno totale = DD_max x (incasso / DD_max) = incasso   ✓ esatto
      Con un divisore fisso a 6000 su una prop al 3% si aprivano META' dei
      lotti necessari e si incassava meta' del dovuto. La prova sul campo:
      i clienti con prop 100k al 6% non hanno mai avuto problemi, quelli
      passati alle prop 100k al 3% si sono lamentati tutti.

    Ricavato dalla configurazione prop che ogni cliente ha gia' inserito, cosi'
    si adatta da solo a qualsiasi taglio di conto e a qualsiasi regola:
      100k al 6% -> 6000 (identico a prima)   200k al 3% -> 6000
      100k al 3% -> 3000                       50k al 6% -> 3000
    Se la prop non e' configurata si torna al valore storico: nessuna
    regressione per chi non ha compilato quei campi.
    """
    pa = dati.get("prop_avanzata", {}) or {}
    try:
        saldo = float(pa.get("saldo_partenza", 0) or 0)
        ddmax = float(pa.get("dd_max_perc", 0) or 0)
    except (TypeError, ValueError):
        return float(RAPPORTO_LOTTO_INCASSO)
    divisore = saldo * ddmax / 100.0
    return divisore if divisore > 0 else float(RAPPORTO_LOTTO_INCASSO)

def calcola_lotti_broker(
    lotti_prop: float, incasso_target: float, divisore: Optional[float] = None,
    compensazione: Optional[float] = None,
) -> float:
    """lotti_broker = lotti_prop x (incasso / divisore) x compensazione

    `divisore` e' la perdita massima totale in dollari (vedi divisore_incasso).
    Omesso -> RAPPORTO_LOTTO_INCASSO, il valore storico.

    `compensazione` e' il fattore che corregge lo SCARTO DI QUOTAZIONE tra i due
    conti (vedi fattore_compensazione). Ha due valori possibili e cambiano anche
    l'arrotondamento, perche' le due cose stanno insieme:

      • MISURATA (un numero) -> si TRONCA. Il volume e' gia' quello esatto che
        fa incassare il dovuto: arrotondare in su aggiungerebbe copertura non
        richiesta. E' cio' che fa il bot di riferimento.
      • NON MISURATA (None)  -> lotti puri, arrotondati PER ECCESSO. Senza la
        misura non si sa di quanto si e' sotto, e uno scalino in piu' e' il
        comportamento storico e prudente.

    IL CONTO SI FA IN DECIMAL, e l'ordine non e' un dettaglio: prima si
    MOLTIPLICA (operazioni esatte) e solo alla fine si DIVIDE. Con i float, un
    risultato come 0.49 puo' essere in realta' 0.48999999999999994, e il
    troncamento gli mangerebbe uno scalino intero: proprio l'errore nella
    direzione peggiore, quella che scopre l'hedge.
    """
    d = Decimal(str(divisore)) if divisore and float(divisore) > 0 else Decimal(str(RAPPORTO_LOTTO_INCASSO))
    esatto = (Decimal(str(lotti_prop)) * Decimal(str(incasso_target))) / d
    if compensazione is None:
        lotti = arrotonda_lotti_verso_su(esatto, "0.01")
    else:
        lotti = tronca_lotti(esatto * Decimal(str(compensazione)), "0.01")
    # Il troncamento su lotti prop piccolissimi puo' arrivare a ZERO: un ordine
    # a volume 0 verrebbe rifiutato dal broker e la prop resterebbe SCOPERTA.
    # Il volume minimo negoziabile e' il pavimento: o si apre quello, o non si
    # copre affatto.
    return max(lotti, LOTTO_MINIMO)

def _time_in_range(now_t: dt_time, start: dt_time, end: dt_time) -> bool:
    if start <= end:
        return start <= now_t <= end
    return now_t >= start or now_t <= end

def _ora_italiana(dt_in: datetime) -> datetime:
    """Converte un datetime in ora italiana (Europe/Rome) gestendo l'ora legale.

    NON usa zoneinfo/tzdata (assente su Windows) ma applica la regola UE,
    deterministica e stabile: ora legale (CEST, UTC+2) dall'ultima domenica di
    marzo all'ultima domenica di ottobre (transizioni alle 01:00 UTC), altrimenti
    ora solare (CET, UTC+1). Ritorna un datetime naive in ora locale italiana,
    pensato solo per la visualizzazione.
    """
    if dt_in.tzinfo is None:
        dt_in = dt_in.replace(tzinfo=timezone.utc)
    dt_utc = dt_in.astimezone(timezone.utc)

    def _ultima_domenica(anno: int, mese: int) -> datetime:
        d = datetime(anno, mese, 31, 1, 0, tzinfo=timezone.utc)
        while d.weekday() != 6:   # 6 = domenica
            d -= timedelta(days=1)
        return d

    inizio_dst = _ultima_domenica(dt_utc.year, 3)
    fine_dst   = _ultima_domenica(dt_utc.year, 10)
    offset     = 2 if (inizio_dst <= dt_utc < fine_dst) else 1
    return (dt_utc + timedelta(hours=offset)).replace(tzinfo=None)

# ========================= STATO TRADE =========================
def _tipo_ita(t) -> str:
    return "Compra" if str(t).upper() == "BUY" else "Vendi"

def _fmt_sl_tp(v) -> str:
    """Prezzo SL/TP formattato, o 'non impostato' se assente (0)."""
    try:
        return f"{float(v):.2f}$" if float(v) else "non impostato"
    except (TypeError, ValueError):
        return "non impostato"

def _blocco_posizione(p: dict) -> str:
    return (
        f"• Tipo: {_tipo_ita(p.get('type'))}\n"
        f"• Lotti: {float(p.get('volume', 0)):.2f}\n"
        f"• SL: {_fmt_sl_tp(p.get('sl'))}\n"
        f"• TP: {_fmt_sl_tp(p.get('tp'))}\n"
        f"• Guadagno/Perdita attuale: {float(p.get('profit', 0)):+.2f}$"
    )

def _componi_stato_trade(
    pos_b: Optional[list], pos_p: Optional[list], trade_memos: Optional[dict] = None,
) -> str:
    """Costruisce il messaggio 'Stato Trade Manuale' (Prop prima, poi Broker)."""
    pos_b = pos_b or []
    pos_p = pos_p or []
    if not pos_b and not pos_p:
        return "ℹ️ Nessun trade aperto."
    rif = (pos_p or pos_b)[0]   # riferimento per Asset/Prezzo attuale: prima la Prop
    msg = "📋 Stato Trade Manuale\n\n"
    msg += f"• Asset: {rif.get('symbol', '—')}\n"
    prezzo = rif.get("price_current")
    if prezzo:
        msg += f"• Prezzo attuale: {float(prezzo):.2f}$\n"

    def _sezione(nome: str, posizioni: list) -> str:
        if not posizioni:
            return f"\n{nome}\n• Nessuna posizione aperta"
        blocchi = [f"\n{nome}"]
        for i, p in enumerate(posizioni):
            if i > 0:
                blocchi.append("")  # riga vuota tra piu' posizioni dello stesso conto
            blocchi.append(_blocco_posizione(p))
        return "\n".join(blocchi)

    msg += _sezione("Prop", pos_p)
    msg += "\n"
    msg += _sezione("Broker", pos_b)

    # Memo: nota scritta dall'utente all'apertura. E' la stessa per la coppia
    # Prop+Broker (salvata sotto entrambi i ticket); raccogliamo i memo distinti
    # delle posizioni aperte e li mostriamo come ultima riga.
    memos: list = []
    if trade_memos:
        for p in list(pos_p) + list(pos_b):
            rec  = trade_memos.get(str(p.get("ticket")), {}) or {}
            memo = (rec.get("memo") or "").strip()
            if memo and memo not in memos:
                memos.append(memo)
    if not memos:
        msg += "\n\n📝 Memo: —"
    elif len(memos) == 1:
        msg += f"\n\n📝 Memo: {memos[0]}"
    else:
        msg += "\n\n📝 Memo:\n" + "\n".join(f"• {m}" for m in memos)
    return msg

async def stato_trade(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    query = update.callback_query
    await ack(query)

    dati = await carica_dati_async()
    broker      = dati.get("broker")
    prop        = dati.get("prop")
    trade_memos = dati.get("trade_memos", {})

    if not broker or not prop:
        await safe_edit_message_text(
            query, "❌ Credenziali mancanti.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    pos_b = await _get_open_positions_snapshot_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    )
    pos_p = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if pos_b is None or pos_p is None:
        await safe_edit_message_text(
            query, "❌ Impossibile leggere le posizioni aperte.",
            InlineKeyboardMarkup([back_button("manuale")]),
        )
        return

    # Sul BROKER le posizioni di un altro bot non vanno mostrate come se fossero
    # dell'utente: si dichiara solo quante sono. La PROP si mostra intera —
    # li' cio' che il bot non ha aperto e' comunque dell'utente.
    pos_b, altrui_b = separa_posizioni(pos_b, dati)
    msg = _componi_stato_trade(pos_b, pos_p, trade_memos) + nota_altrui(len(altrui_b))
    await safe_edit_message_text(
        query, msg, InlineKeyboardMarkup([back_button("manuale")]),
    )

async def stato_trade_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard_auth(update, context):
        return
    dati        = await carica_dati_async()
    broker      = dati.get("broker")
    prop        = dati.get("prop")
    trade_memos = dati.get("trade_memos", {})

    if not broker or not prop:
        await update.message.reply_text("❌ Credenziali mancanti.")
        return

    pos_b = await _get_open_positions_snapshot_async(
        MT5_BROKER_EXE, int(broker["id"]), broker["password"], broker["server"], SIMBOLO_BROKER,
    )
    pos_p = await _get_open_positions_snapshot_async(
        MT5_PROP_EXE, int(prop["id"]), prop["password"], prop["server"], cfg.SIMBOLO_PROP,
    )
    if pos_b is None or pos_p is None:
        await update.message.reply_text("❌ Impossibile leggere le posizioni aperte.")
        return

    # Sul BROKER le posizioni di un altro bot non vanno mostrate come se fossero
    # dell'utente: si dichiara solo quante sono. La PROP si mostra intera —
    # li' cio' che il bot non ha aperto e' comunque dell'utente.
    pos_b, altrui_b = separa_posizioni(pos_b, dati)
    msg = _componi_stato_trade(pos_b, pos_p, trade_memos) + nota_altrui(len(altrui_b))
    await update.message.reply_text(msg)
