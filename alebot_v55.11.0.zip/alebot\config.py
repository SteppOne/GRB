import logging
import os
import platform
import warnings
import zlib
from datetime import time as dt_time
from typing import Dict, Any, Optional

# --- SSL robusto: usa il cert-store di WINDOWS per la verifica dei certificati.
#     Risolve "CERTIFICATE_VERIFY_FAILED / self-signed certificate in chain" su VPS
#     con Python installato a mano (CA incomplete) o dietro proxy aziendali.
#     Vale per httpx (Telegram), requests (news) e urllib. Se 'truststore' non e'
#     installato si prosegue col comportamento di default, senza rompere nulla. ---
try:
    import truststore as _truststore
    _truststore.inject_into_ssl()
except Exception:
    pass

from telegram.warnings import PTBUserWarning
warnings.filterwarnings("ignore", category=PTBUserWarning)

# ========================= .ENV LOADING =========================
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # Se python-dotenv non e' installato, leggiamo direttamente dall'ambiente reale.
    pass

def _require_env(name: str) -> str:
    val = os.getenv(name)
    if not val or not str(val).strip():
        raise RuntimeError(
            f"Variabile d'ambiente '{name}' mancante o vuota. "
            f"Crea/aggiorna il file .env nella stessa cartella del bot."
        )
    return val.strip()

def _optional_env(name: str) -> str:
    """Come _require_env ma NON solleva: ritorna "" se assente/vuota.
    Usato per le impostazioni opzionali (es. abbonamento) che non devono
    impedire l'avvio del bot se non configurate."""
    val = os.getenv(name)
    return val.strip() if val and str(val).strip() else ""

# ========================= CONFIGURAZIONE =========================
TOKEN           = _require_env("TELEGRAM_TOKEN")

# Fonte news. Se NEWS_SOURCE_URL e' impostata, il bot legge il calendario da una
# fonte CENTRALE condivisa (un solo fetcher per tutti i bot) e le chiavi API NON
# servono su questa VPS. Se NON e' impostata, il bot chiama direttamente Finnhub/FMP
# e le chiavi sono obbligatorie (comportamento storico, pienamente retro-compatibile).
NEWS_SOURCE_URL = _optional_env("NEWS_SOURCE_URL")
if NEWS_SOURCE_URL:
    FINNHUB_API_KEY = _optional_env("FINNHUB_API_KEY")
    FMP_API_KEY     = _optional_env("FMP_API_KEY")
else:
    FINNHUB_API_KEY = _require_env("FINNHUB_API_KEY")
    FMP_API_KEY     = _require_env("FMP_API_KEY")
MT5_BROKER_DIR  = _require_env("MT5_BROKER_DIR")
MT5_PROP_DIR    = _require_env("MT5_PROP_DIR")
SIMBOLO_BROKER  = _require_env("SIMBOLO_BROKER")
SIMBOLO_PROP    = _require_env("SIMBOLO_PROP")

# Simboli XAUUSD per societa' prop: si impostano nel .env (uno per prop) e sono
# il valore abbinato quando l'utente sceglie la prop dal bot. Se la variabile
# non e' presente nel .env, default "XAUUSD" (nessun crash all'avvio).
SIMBOLO_FUNDEDNEXT = _optional_env("SIMBOLO_FUNDEDNEXT") or "XAUUSD"
SIMBOLO_FINTOKEI   = _optional_env("SIMBOLO_FINTOKEI")   or "XAUUSD"

# ---- Abbonamento (tutte OPZIONALI: se assenti, nessun vincolo) ----
# ADMIN_CHANNEL_ID: canale Telegram privato (gestito dal proprietario delle VPS)
#   dove arrivano gli avvisi di scadenza e da cui si rinnova. Lo stesso valore su
#   tutte le VPS; ogni bot dev'essere amministratore del canale.
# CLIENT_ID: slug senza spazi per indirizzare i comandi a QUESTA VPS (es. andrearossi).
# CLIENT_NOME: nome leggibile mostrato negli avvisi (es. "Andrea Rossi").
# SUB_UNTIL: scadenza iniziale opzionale (AAAA-MM-GG); poi si rinnova via comando.
ADMIN_CHANNEL_ID = _optional_env("ADMIN_CHANNEL_ID")
CLIENT_ID        = _optional_env("CLIENT_ID")
CLIENT_NOME      = _optional_env("CLIENT_NOME") or CLIENT_ID or "questo cliente"
SUB_UNTIL_ENV    = _optional_env("SUB_UNTIL")

MT5_BROKER_EXE = os.path.join(MT5_BROKER_DIR, "terminal64.exe")
MT5_PROP_EXE   = os.path.join(MT5_PROP_DIR,   "terminal64.exe")

# Cartella del bot. TUTTI i file di stato sono ancorati QUI con percorsi ASSOLUTI,
# NON relativi alla working-directory. Cosi' chiave di cifratura e dati NON vengono
# mai rigenerati/persi se il bot parte con una CWD diversa (avvio manuale, Task
# Scheduler senza "Start in", ecc.). Coerente col watchdog (stesso BASE_DIR).
# NB pacchetto: __file__ e' alebot/config.py -> la cartella del bot e' il
# PADRE del pacchetto. Stessi percorsi assoluti della v51 monolitica.
BASE_DIR       = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Nome dell'entry-point con cui watchdog/avvia.bat lanciano il bot: usato
# dal lock anti doppia-istanza per riconoscere un processo gemello.
ENTRY_SCRIPT_NAME = "alev51.py"

DATA_FILE      = os.path.join(BASE_DIR, "user_data.enc")
KEY_FILE       = os.path.join(BASE_DIR, "encryption.key")
BACKUP_FILE    = os.path.join(BASE_DIR, "user_data.enc.bak")
HEARTBEAT_FILE = os.path.join(BASE_DIR, "heartbeat.txt")
HEARTBEAT_INTERVAL_SECONDS         = 30
BOOT_RECONCILIATION_DELAY_SECONDS  = 5

# File usati per il coordinamento con il watchdog esterno (watchdog.py).
BOT_LOCK_FILE       = os.path.join(BASE_DIR, "bot.lock")        # PID dell'istanza attiva (anti doppio avvio)
OWNER_CHAT_SIDECAR  = os.path.join(BASE_DIR, "owner_chat.txt")  # chat-id owner in chiaro, per gli avvisi del watchdog
# File di log del bot: ci scrive il watchdog (redirezione dello stdout) e ci
# scrivono i processi worker MT5, che uno stdout utilizzabile non ce l'hanno
# (vedi mt5_worker._configura_log_worker). La ROTAZIONE resta del watchdog.
BOT_LOG_FILE        = os.path.join(BASE_DIR, "bot.log")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram.ext").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

# ========================= COSTANTI DI BUSINESS / SAFETY =========================
RAPPORTO_LOTTO_INCASSO      = 6000   # divisore della formula: lotti_broker = lotti_prop * (incasso / RAPPORTO)
# ---- Compensazione dello SCARTO DI QUOTAZIONE sulla gamba broker (v55.2) ----
# Broker e prop NON quotano l'oro allo stesso prezzo, e all'ingresso si paga
# anche mezzo spread per parte. I livelli della gamba broker sono lo SPECCHIO
# di quelli della prop, quindi quando la prop tocca il suo Stop Loss il broker
# si trova a una distanza LEGGERMENTE DIVERSA dal suo prezzo di ingresso: con i
# lotti "puri" della formula incassa meno del dovuto.
#
# Rimedio (lo stesso del bot di riferimento): si dimensionano i lotti in modo
# che il guadagno REALE a quel punto sia esattamente quello richiesto.
#     lotti = lotti_puri x distanza_SL / (distanza_SL +/- scarto)
# Il fattore NON e' una percentuale fissa: dipende dallo scarto misurato in
# quell'istante e da quanto e' lontano lo Stop Loss. Misurato sul bot di
# riferimento vale 1.029 con SL a 16.67$ di distanza e 1.05 con SL piu' vicini.
#
# La banda qui sotto e' una rete di sicurezza: uno scarto che vale piu' del 10%
# della distanza dello SL non e' una quotazione, e' una lettura sbagliata (o un
# SL talmente stretto da rendere l'hedge fragile a prescindere).
COMPENSAZIONE_MIN           = 0.90
COMPENSAZIONE_MAX           = 1.20
LOTTO_MINIMO                = 0.01   # sotto questo volume nessun broker accetta l'ordine
INCASSO_DEFAULT             = 630.0   # incasso usato se non ne e' stato configurato uno
# ---- Randomizzazione dei parametri di apertura (v55.11) ----
# Lotti sempre tondi e la stessa perdita a stop loss ripetuta ogni giorno sono
# una firma riconoscibile: con la randomizzazione attiva (pulsante in Manuale,
# spenta di default) il bot ritocca da solo i tre numeri digitati dall'utente.
# Le percentuali sono RELATIVE al valore inserito, non cifre fisse: cosi' il
# ritocco resta proporzionato sia su uno stop loss da 2.720$ sia su uno da 300$.
#
# Perche' i lotti possono permettersi una percentuale piu' larga dei dollari:
# lo stop loss e' espresso in DOLLARI, quindi con piu' lotti il bot calcola una
# distanza di prezzo piu' stretta e la perdita a stop loss resta quella
# richiesta. Ritoccare i lotti cambia la distanza dello stop, NON i soldi a
# rischio; ritoccare lo stop loss in $ cambia i soldi, e li' si va coi piedi di
# piombo. Vedi alebot/randomizzazione.py.
RANDOM_SL_TP_PERC           = 1.5    # ± % su Stop Loss e Take Profit in $
RANDOM_LOTTI_PERC           = 10.0   # ± % sui lotti prop
RANDOM_LOTTI_STEP           = "0.01" # passo del volume: il ritocco e' sempre un suo multiplo
MEMO_CLEANUP_DAYS           = 30     # i memo chiusi piu' vecchi di N giorni vengono purgati al boot
# Update Telegram lavorati IN PARALLELO. Con 1 (default di PTB) un solo
# handler lento congela l'intero bot, /start incluso: e' la causa del guasto
# "bot bloccato dopo il riavvio dei terminali". Vedi la nota in app.main().
CONCURRENT_UPDATES          = 16
# CATENA DEI TIMEOUT — regola: chi sta piu' in alto aspetta piu' a lungo.
#     mt5_sync (init 45s + login 20s)  <  worker (75s)  <  wrapper (85s)
# Se il wrapper si arrende prima del worker, il thread resta appeso sulla pipe;
# se il worker si arrende prima di MT5, si butta via una chiamata che stava per
# riuscire — ed e' esattamente cio' che e' successo il 26/07/2026, con un
# terminale che impiegava 12-40 s a sincronizzarsi dopo il riavvio.
# Sembrano valori alti: lo sono di proposito. A tenere REATTIVO il bot ci
# pensano la quarantena (i guasti ripetuti costano zero) e concurrent_updates.
MT5_OP_TIMEOUT_SECONDS      = 85
# Budget per le operazioni COMPOSTE (piu' round-trip nello stesso wrapper, es.
# info_account_prop_async che ne fa tre).
MT5_LONG_OP_TIMEOUT_SECONDS = 240
TRADE_CLOSE_MONITOR_SECONDS = 60
CLOSE_INFO_MAX_WAIT_MIN     = 10     # se dopo N min il deal di chiusura di un lato resta illeggibile, notifica comunque (con n/d) per non lasciare l'owner senza ricevuta
SCHEDULED_OPEN_CHECK_SECONDS = 60    # cadenza del loop apertura programmata + backstop chiusura sfida
SCHEDULED_LATE_GRACE_MINUTES = 15    # se il bot torna online entro N min dall'orario, apre; oltre, salta
PROP_DAILY_BASELINE_SECONDS  = 300   # cadenza con cui si aggancia il saldo di inizio giornata prop, per un reset giornaliero affidabile anche senza che l'utente apra Info Prop

# Worker MT5 paralleli (un processo per terminale, connessioni sempre calde).
# Default ATTIVI; MT5_WORKERS=0 nel .env forza il vecchio modello in-process.
# Se lo spawn dei worker fallisce, il bot degrada da solo all'in-process.
MT5_WORKERS_ENABLED = (_optional_env("MT5_WORKERS") or "1").strip() != "0"

# Guardiano di coppia: cadenza del controllo "una gamba chiusa, l'altra no".
# Coi worker sempre connessi il controllo costa millisecondi: si puo' tenere
# strettissimo. In fallback in-process si allenta per non saturare il lock.
PAIR_GUARD_SECONDS          = 2
PAIR_GUARD_SECONDS_FALLBACK = 10

# ==================== FIRMA DEGLI ORDINI DI QUESTO BOT ====================
# Ogni ordine aperto dal bot porta un "magic number" che ne dichiara la
# paternita'. Fino alla v54.6 il contatore partiva da 1000 su OGNI installazione,
# quindi due bot generavano presto gli stessi numeri: chi condivideva il conto
# broker tra due VPS poteva vedersi adottare (e poi chiudere) la posizione
# dell'altro. Ora ogni bot ha un blocco tutto suo, ricavato dal proprio
# CLIENT_ID: i numeri di due installazioni non si incrociano mai.
# Dimensionamento dei blocchi. Il numero di BLOCCHI e' cio' che conta davvero:
# due CLIENT_ID diversi finiscono sullo stesso blocco con probabilita' 1 su
# _MAGIC_BLOCCHI, e in quel caso i due bot tornerebbero a scambiarsi le
# posizioni. Blocchi piu' piccoli = piu' blocchi = collisione piu' improbabile:
# 10.000 magic per bot bastano per anni (uno per trade, e a fine blocco il
# contatore riparte dall'inizio del PROPRIO blocco senza sconfinare), mentre
# 200.000 blocchi portano la collisione a 1 su 200.000.
MAGIC_BLOCCO   = 10_000         # magic disponibili per bot (uno per trade)
_MAGIC_BLOCCHI = 200_000        # 10.000 x 200.000 = 2e9, sotto il limite dei 32 bit

def _calcola_magic_base() -> int:
    """Primo magic riservato a QUESTO bot: [MAGIC_BASE, MAGIC_BASE+MAGIC_BLOCCO).

    Derivato da CLIENT_ID, che e' diverso per ogni cliente e per ogni VPS: due
    installazioni cadono su blocchi diversi senza configurare nulla. Il nome
    host fa da rete di sicurezza se CLIENT_ID non e' ancora stato compilato.
    Deterministico: un riavvio non sposta il bot su un altro blocco, altrimenti
    smetterebbe di riconoscere le proprie posizioni gia' a mercato.
    """
    seme = (CLIENT_ID or platform.node() or "").strip().lower()
    if not seme:
        return MAGIC_BLOCCO     # identita' ignota: primo blocco
    return (zlib.crc32(seme.encode("utf-8")) % _MAGIC_BLOCCHI + 1) * MAGIC_BLOCCO

MAGIC_BASE = _calcola_magic_base()
# Il test trading usava il magic fisso 9999, identico su tutti i bot: anche
# quello finisce nello spazio riservato (ultimo numero del blocco).
MAGIC_TEST = MAGIC_BASE + MAGIC_BLOCCO - 1

SYMBOLS = {
    "broker": SIMBOLO_BROKER,
    "prop":   SIMBOLO_PROP,
}

def get_symbol(account_type: str) -> str:
    return SYMBOLS[account_type]

# ===================== SOCIETÀ PROP SUPPORTATE =====================
# Elenco delle prop selezionabili dal bot. Il SIMBOLO di ciascuna si imposta nel
# .env (SIMBOLO_FUNDEDNEXT / SIMBOLO_FINTOKEI): per cambiarlo basta modificare il
# .env, senza toccare il codice. Per AGGIUNGERE una prop nuova si aggiunge qui una
# riga (id univoco, etichetta) e la rispettiva variabile nel .env.
PROP_FIRMS = [
    {"id": "fundednext", "label": "FundedNext / demo TMGM", "simbolo": SIMBOLO_FUNDEDNEXT},
    {"id": "fintokei",   "label": "Fintokei",   "simbolo": SIMBOLO_FINTOKEI},
]

def _prop_firm_by_id(fid: str) -> Optional[Dict[str, Any]]:
    return next((f for f in PROP_FIRMS if f["id"] == fid), None)

def _attiva_simbolo_prop(sym: Optional[str]) -> None:
    """Imposta, per l'intero processo, il simbolo prop attivo (override del .env).

    SIMBOLO_PROP nasce dal .env come fallback; quando l'utente sceglie una prop
    il suo simbolo viene attivato qui e ri-applicato a ogni avvio dal valore
    salvato (vedi post_init). Tutti i punti che leggono SIMBOLO_PROP usano
    automaticamente il valore aggiornato.
    """
    global SIMBOLO_PROP
    if sym:
        SIMBOLO_PROP = sym

# ========================= STATI CONVERSATION =========================
AUTH_PASSWORD = 101
BR_ID, BR_PSW, BR_SERVER = 111, 112, 113
PR_ID, PR_PSW, PR_SERVER = 121, 122, 123
BR_CONFIRM = 114
BR_RETRY = 115
PR_CONFIRM = 126
PR_RETRY = 127
CFG_PR_MODE = 250
CFG_PR_CONFIRM = 251
CFG_PR_FIRM = 252   # scelta della società prop (abbina il simbolo)
CFG_PR_SALDO, CFG_PR_TARGET, CFG_PR_DDMAX, CFG_PR_DDDAILY, CFG_PR_COSTO = 220, 221, 222, 223, 224
CFG_PR_INCASSO, CFG_PR_TIPINC, CFG_PR_TIPDD, CFG_PR_CONS = 225, 226, 227, 228
CFG_PR_COSTO_RESET = 229
INCASSO_TARGET = 231
PWD_NEW, PWD_CONFIRM = 311, 312
SL, TP, LOTTI, CONFERMA = 411, 412, 413, 414
MEMO = 415
PROGRAMMA_ORARIO = 416   # input HH:MM per l'apertura programmata
# Trade minimo per giorno (trade-sfida: singolo, solo Prop, no hedge)
CHALLENGE_DIREZIONE, CHALLENGE_LOTTI, CHALLENGE_MINUTI, CHALLENGE_CONFERMA = 417, 418, 419, 420
# Apertura manuale: step "modifica incasso" prima del memo
INCASSO_MODIFICA_CHIEDI, INCASSO_MODIFICA_NUOVO = 421, 422
# Avviso "SL oltre la perdita giornaliera rimasta della prop" (Sì/No)
SL_RISCHIO_CONFERMA = 423
# Avviso "TP oltre il profitto giornaliero massimo (consistenza)" (Sì/No)
TP_RISCHIO_CONFERMA = 424
# Margine di sicurezza 10%: l'avviso scatta gia' quando lo SL inserito
# raggiunge il 90% della perdita giornaliera rimasta della prop.
# Qui il cuscinetto e' AMPIO di proposito: sfondare la perdita giornaliera
# BRUCIA la sfida, quindi conviene avvisare molto prima del limite.
SL_DAILY_SAFETY_FACTOR = 0.90
# Margine di sicurezza 3% sul TAKE PROFIT (regola di consistenza).
# Deliberatamente PIU' STRETTO di quello sullo Stop Loss, perche' i due limiti
# non hanno lo stesso peso: superare il profitto giornaliero massimo non brucia
# la sfida (di norma l'eccedenza semplicemente non conta), mentre superare la
# perdita giornaliera si'. Col 10% l'avviso scattava su ogni trade normale —
# es. limite 3.000$ e TP 2.720$, cioe' il 91% ma comunque SOTTO il limite —
# trasformando una protezione in rumore di fondo.
TP_DAILY_SAFETY_FACTOR = 0.97
TEST_CONFIRM = 511
PAYOUT_AMOUNT = 611
CHIUDI_CONFIRM = 712
RESET_PNL_CONFIRM = 811   # nuovo: conferma reset payout
PL_BROKER_INIT    = 911   # input: imposta P/L broker realizzato iniziale (seeding)
COSTO_PROP_AMOUNT = 912   # input: aggiungi un costo prop al totale cumulato
# Rinnovo abbonamento: segnalazione "ho pagato" verso il canale admin
RENEW_CONFIRM, RENEW_METODO, RENEW_ALTRO = 1011, 1012, 1013

# ========================= MODALITÀ OPERATIVA =========================
# Due modi di lavorare, scelti dall'utente con /modalita:
#
#   normale_auto     — quello storico: il bot apre e chiude DA SOLO le due gambe
#                      (broker + prop). Richiede la password MASTER della prop.
#   normale_semiauto — la prop si comanda A MANO dal MetaTrader del telefono e
#                      nel bot si mettono le credenziali di SOLA LETTURA. Il bot
#                      guida l'apertura, verifica i livelli, apre la copertura
#                      sul broker e sorveglia la coppia; sulla prop non invia
#                      MAI un ordine, perche' tecnicamente non potrebbe.
#
# La modalita' vive nello stato cifrato (chiave "modalita_operativa"): non nel
# .env, cosi' si cambia dal telefono senza toccare la VPS. Default: normale_auto,
# cioe' il comportamento di sempre per chi aggiorna.
MODALITA_AUTO     = "normale_auto"
MODALITA_SEMIAUTO = "normale_semiauto"
MODALITA_DEFAULT  = MODALITA_AUTO

# Tolleranza del PRIMO controllo sui livelli impostati a mano sulla prop.
# I valori che il bot suggerisce PRIMA dell'apertura sono calcolati sul prezzo
# di quel momento: quando l'utente apre davvero (secondi o minuti dopo) il
# prezzo si e' mosso, quindi cio' che ha digitato NON puo' coincidere al
# centesimo con la perdita/guadagno richiesti. Questa e' la soglia oltre la
# quale non e' piu' "deriva del prezzo" ma un errore vero: sotto soglia il bot
# apre SUBITO la copertura (ogni secondo la prop e' scoperta) e solo dopo fa
# impostare i valori esatti; sopra soglia ferma tutto e fa correggere prima.
SEMIAUTO_TOLLERANZA_PERC = 2.0
# Tolleranza del controllo FINALE (dopo "Ho modificato la posizione"), in
# multipli di 'point': li' i valori esatti sono gia' noti e si pretende la
# precisione, lasciando solo il margine dell'arrotondamento di visualizzazione.
SEMIAUTO_TOLLERANZA_POINT = 2.0
# Avviso "posizione prop scoperta": ogni N secondi finche' l'utente non chiude.
SEMIAUTO_ALERT_SECONDS = 300
# Un'istruzione di apertura mai raccolta scade dopo N minuti (i prezzi indicati
# non hanno piu' senso e la coda "un trade alla volta" resterebbe bloccata).
SEMIAUTO_PENDING_TTL_MINUTES = 120
# Preavvisi (minuti prima) per notizie impattanti e chiusura serale: in semiauto
# il bot non chiude nulla — chiuderebbe solo la gamba broker, sbilanciando
# l'hedge — quindi avvisa due volte e lascia agire l'utente.
SEMIAUTO_PREAVVISI_MINUTI = (30, 15)
# Ritardo massimo tollerato su un preavviso: se il bot si sveglia molto dopo
# l'istante previsto (riavvio a meta' serata) quell'avviso non ha piu' senso.
SEMIAUTO_PREAVVISO_RITARDO_MAX_S = 120

# ========================= PROGRAMMAZIONE OPERATIVA =========================
# Chiusura serale: l'orario esatto e' CASUALE nei 15 minuti che precedono le
# 23:00, diverso ogni sera e diverso da bot a bot. Serve a non lasciare alla
# prop un pattern riconoscibile.
NIGHT_CLOSE_START = dt_time(22, 45)
NIGHT_CLOSE_END   = dt_time(23, 0)
# Blocco delle aperture: parte INSIEME alla finestra di chiusura e arriva alle
# 02:30. Deve partire dalle 22:45 e non dalle 23:00, altrimenti un trade aperto
# DOPO che la chiusura serale e' gia' scattata (che puo' essere alle 22:46) non
# lo chiuderebbe piu' nessuno fino alla sera successiva.
OPEN_BLOCK_START  = dt_time(22, 45)
OPEN_BLOCK_END    = dt_time(2, 30)
NEWS_REFRESH_SECONDS = 300
NEWS_BLACKOUT_MINUTES = 45
NEWS_CLOSE_MINUTES_MIN = 12
NEWS_CLOSE_MINUTES_MAX = 18
# Avvisi "protezione news degradata" al canale admin (de-dup giornaliero):
# feed centrale piu' vecchio di 6 ore, oppure fetch fallito per ~3 ore di fila.
NEWS_FEED_STALE_ALERT_MIN    = 360
NEWS_FETCH_FAIL_ALERT_STREAK = 36   # 36 cicli da 300s = ~3 ore

# Valute monitorate per le news che muovono XAUUSD, ad alto impatto.
# NB: il feed centrale (news_fetcher.py su GitHub) deve PUBBLICARE queste valute,
# altrimenti non arrivano qui: tieni allineato il set CURRENCIES del fetcher.
NEWS_XAUUSD_CURRENCIES: frozenset = frozenset({"USD", "AUD"})
