import asyncio
import logging
from datetime import date, datetime, timedelta, timezone
from functools import partial
from typing import Dict, Any, Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    ContextTypes,
)

logger = logging.getLogger(__name__)

from .config import ADMIN_CHANNEL_ID, CLIENT_ID, CLIENT_NOME, SUB_UNTIL_ENV
from .messaging import notifica_owner
from .storage import carica_dati_async, modifica_dati_async
from .trade_core import _ora_italiana

# ========================= ABBONAMENTO =========================
SUB_DATE_FMT = "%Y-%m-%d"

def _oggi_locale() -> date:
    return datetime.now().date()

def _parse_sub_date(s) -> Optional[date]:
    try:
        return datetime.strptime(str(s).strip(), SUB_DATE_FMT).date()
    except (ValueError, TypeError, AttributeError):
        return None

def _sub_until_effettiva(dati: dict) -> Optional[date]:
    """Scadenza in vigore: prima quella salvata in user_data, poi il fallback
    da .env (SUB_UNTIL), altrimenti None (= nessun abbonamento impostato)."""
    d = _parse_sub_date(dati.get("sub_until"))
    if d is None and SUB_UNTIL_ENV:
        d = _parse_sub_date(SUB_UNTIL_ENV)
    return d

def stato_abbonamento(dati: dict) -> Dict[str, Any]:
    """Stato corrente dell'abbonamento. Se non configurato -> attivo (nessun
    vincolo): cosi' i bot senza abbonamento impostato funzionano normalmente."""
    until = _sub_until_effettiva(dati)
    if until is None:
        return {"configurato": False, "attivo": True, "scaduto": False, "until": None, "giorni": None}
    giorni = (until - _oggi_locale()).days
    return {
        "configurato": True,
        "attivo":  giorni >= 0,
        "scaduto": giorni < 0,
        "until":   until,
        "giorni":  giorni,
    }

def _riga_scadenza(st: Dict[str, Any]) -> str:
    """Riga di stato per il canale admin (include il nome del cliente)."""
    if not st["configurato"]:
        return f"ℹ️ {CLIENT_NOME}: abbonamento non impostato (nessuna scadenza)."
    d = st["until"].strftime("%d/%m/%Y")
    if st["scaduto"]:
        return f"⛔ {CLIENT_NOME}: abbonamento SCADUTO il {d} (da {abs(st['giorni'])} giorni)."
    return f"✅ {CLIENT_NOME}: abbonamento attivo — scade il {d} (tra {st['giorni']} giorni)."

def _riga_scadenza_cliente(st: Dict[str, Any]) -> Optional[str]:
    """Avviso di scadenza per il CLIENTE (owner del bot). A differenza di
    _riga_scadenza (gestionale, col nome cliente, per il canale admin) parla
    direttamente al cliente e gli dice cosa fare. Ritorna None se l'abbonamento
    non e' configurato."""
    if not st["configurato"] or st["until"] is None:
        return None
    d = st["until"].strftime("%d/%m/%Y")
    if st["scaduto"]:
        return (
            f"⛔ Il tuo abbonamento e' scaduto il {d}.\n\n"
            "Le nuove operazioni sono sospese. La gestione delle posizioni "
            "gia' aperte resta attiva.\n\n"
            "Se hai già pagato il rinnovo, segnalalo con i pulsanti qui sotto: "
            "verificheremo e riattiveremo l'abbonamento."
        )
    g = st["giorni"]
    if g == 0:
        quando = f"OGGI ({d})"
    elif g == 1:
        quando = f"DOMANI ({d})"
    else:
        quando = f"tra {g} giorni (il {d})"
    return (
        f"⏳ Il tuo abbonamento scade {quando}.\n\n"
        "Rinnova per evitare la sospensione delle nuove operazioni.\n"
        "Se hai già pagato il rinnovo, segnalalo con i pulsanti qui sotto."
    )

# ---- Preavvisi di scadenza ----
SOGLIE_PREAVVISO = (7, 3, 1)   # giorni residui a cui parte un preavviso

def _soglia_preavviso(giorni: int) -> Optional[int]:
    """Fascia di preavviso in cui cade oggi, o None se e' ancora presto.

    Il confronto e' per ATTRAVERSAMENTO (giorni <= soglia) e non per
    uguaglianza esatta: se il bot e' rimasto spento proprio nel giorno della
    soglia, l'avviso parte alla prima occasione utile invece di andare perso
    per sempre (l'indomani i giorni sono 6, e 6 non era una soglia).
    Si ritorna la fascia PIU' URGENTE gia' raggiunta, cosi' un bot rimasto giu'
    una settimana manda un solo avviso — quello vero — e non tre arretrati.
    """
    raggiunte = [s for s in SOGLIE_PREAVVISO if giorni <= s]
    return min(raggiunte) if raggiunte else None

def _preavviso_gia_consegnato(dati: dict, scadenza: str, soglia: int) -> bool:
    """Il preavviso di questa fascia e' gia' arrivato AL CLIENTE?

    La memoria e' legata alla SCADENZA a cui si riferisce: dopo un rinnovo la
    data cambia e i preavvisi si riarmano da soli, senza dover ripulire niente
    (una svista di pulizia qui significherebbe un cliente mai piu' avvisato).
    """
    if dati.get("sub_soglia_scadenza") != scadenza:
        return False
    try:
        return int(dati["sub_ultima_soglia"]) <= soglia
    except (KeyError, TypeError, ValueError):
        return False

def modifier_esito_avviso_scadenza(
    d: dict, oggi: str, scadenza: str, soglia: Optional[int],
    consegnato: bool, canale_inviato: bool,
) -> Optional[dict]:
    """Registra in un'unica scrittura cosa e' andato a segno davvero.

      sub_last_alert_day  -> riga gestionale gia' messa nel canale admin oggi;
      sub_last_client_day -> promemoria quotidiano da scaduto gia' RICEVUTO;
      sub_ultima_soglia   -> preavviso 7/3/1 RICEVUTO (non solo tentato).

    La distinzione tra "tentato" e "ricevuto" e' il punto: finche' il cliente
    non ha in mano il messaggio, la fascia resta aperta e si ritenta al giro
    dopo. Ritorna None se non c'e' nulla da salvare, cosi' i controlli a vuoto
    non toccano il disco.
    """
    cambiato = False
    if canale_inviato and d.get("sub_last_alert_day") != oggi:
        d["sub_last_alert_day"] = oggi
        cambiato = True
    if consegnato:
        if soglia is None:
            if d.get("sub_last_client_day") != oggi:
                d["sub_last_client_day"] = oggi
                cambiato = True
        elif (d.get("sub_ultima_soglia") != soglia
              or d.get("sub_soglia_scadenza") != scadenza):
            d["sub_ultima_soglia"]   = soglia
            d["sub_soglia_scadenza"] = scadenza
            cambiato = True
    return d if cambiato else None

def _postilla_consegna(consegnato: Optional[bool]) -> str:
    """Esito della consegna al cliente, allegato alla riga del canale admin.

    Senza questa postilla il canale certificava soltanto che il bot ci aveva
    PROVATO: un cliente che aveva bloccato il bot produceva una riga identica
    a quella di uno raggiunto, e il gestore non aveva modo di accorgersene.
    """
    if consegnato is None:
        return ""
    if consegnato:
        return "\n   ↳ avviso consegnato al cliente ✅"
    return ("\n   ↳ avviso NON consegnato ❌ — cliente irraggiungibile "
            "(bot bloccato o mai avviato). Riprovo da solo.")

def modifier_rinnova_abbonamento(
    d: dict, giorni: Optional[int] = None, data_esatta: Optional[date] = None,
) -> dict:
    """Rinnovo. Con data_esatta fissa la scadenza; con giorni la ESTENDE a partire
    dalla piu' avanti tra oggi e la scadenza attuale (cosi' rinnovare in anticipo
    non fa perdere giorni, e un rinnovo dopo la scadenza riparte da oggi)."""
    if data_esatta is not None:
        nuova = data_esatta
    else:
        attuale = _parse_sub_date(d.get("sub_until")) or _parse_sub_date(SUB_UNTIL_ENV)
        base = max(_oggi_locale(), attuale) if attuale else _oggi_locale()
        nuova = base + timedelta(days=int(giorni))
    d["sub_until"] = nuova.strftime(SUB_DATE_FMT)
    return d

# ---- Segnalazione pagamento ("ho rinnovato") -> canale admin ----
# L'utente NON paga tramite il bot: segnala soltanto di aver pagato e con quale
# metodo. La segnalazione arriva al canale admin; il rinnovo effettivo resta
# manuale (comando /rinnova dal canale, dopo la verifica dell'accredito).
RENEW_MAX_REPORTS_DAY = 3   # anti-spam: max segnalazioni al giorno per bot

def _segnalazioni_pagamento_oggi(dati: dict) -> int:
    rec = dati.get("renew_report_day") or {}
    if rec.get("day") != _oggi_locale().isoformat():
        return 0
    try:
        return int(rec.get("count", 0) or 0)
    except (TypeError, ValueError):
        return 0

def modifier_registra_segnalazione_pagamento(d: dict, metodo: str) -> dict:
    oggi = _oggi_locale().isoformat()
    n = _segnalazioni_pagamento_oggi(d)
    d["renew_report_day"]  = {"day": oggi, "count": n + 1}
    d["renew_last_report"] = {
        "quando": datetime.now(timezone.utc).isoformat(),
        "metodo": metodo,
    }
    return d

def _kb_alert_rinnovo() -> InlineKeyboardMarkup:
    """Tastiera allegata agli avvisi di scadenza inviati al cliente."""
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ Sì, ho rinnovato", callback_data="renew_yes"),
        InlineKeyboardButton("❌ Non ancora",       callback_data="renew_no"),
    ]])

async def _invia_segnalazione_pagamento(bot, metodo_label: str) -> bool:
    """Compone e invia al canale admin la segnalazione 'cliente ha pagato con X',
    con scadenza attuale e comando /rinnova precompilato. Ritorna l'esito reale
    dell'invio; solo se riuscito registra la segnalazione (anti-spam + storico)."""
    dati = await carica_dati_async()
    st   = stato_abbonamento(dati)
    if st["configurato"] and st["until"] is not None:
        d = st["until"].strftime("%d/%m/%Y")
        if st["scaduto"]:
            riga_scad = f"Scadenza attuale: {d} (SCADUTO da {abs(st['giorni'])} giorni)"
        else:
            riga_scad = f"Scadenza attuale: {d} (tra {st['giorni']} giorni)"
    else:
        riga_scad = "Scadenza attuale: non impostata"
    ora_it = _ora_italiana(datetime.now(timezone.utc)).strftime("%d/%m/%Y %H:%M")
    righe = [
        "💳 PAGAMENTO SEGNALATO",
        f"Cliente: {CLIENT_NOME}" + (f" ({CLIENT_ID})" if CLIENT_ID else ""),
        f"Metodo: {metodo_label}",
        riga_scad,
        f"Segnalato il: {ora_it} (ora italiana)",
    ]
    if CLIENT_ID:
        righe += ["", "Dopo la verifica rinnova con:", f"/rinnova {CLIENT_ID} 30"]
    ok = await _invia_canale_admin(bot, "\n".join(righe))
    if ok:
        await modifica_dati_async(
            partial(modifier_registra_segnalazione_pagamento, metodo=metodo_label)
        )
    return ok

async def _invia_canale_admin(bot, testo: str) -> bool:
    """Invia un messaggio al canale admin, se configurato. Best-effort: non
    solleva mai. Ritorna True se l'invio e' riuscito, False altrimenti (canale
    non configurato o errore di rete): serve alla segnalazione pagamento per
    dare un feedback ONESTO all'utente invece di un falso 'inviato'."""
    if not ADMIN_CHANNEL_ID:
        return False
    try:
        await bot.send_message(chat_id=ADMIN_CHANNEL_ID, text=testo)
        return True
    except Exception as e:
        logger.warning(f"Invio al canale admin fallito: {e}")
        return False

async def admin_channel_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comandi dal canale admin (gestito dal proprietario delle VPS):
        /rinnova <CLIENT_ID> <giorni|AAAA-MM-GG>   -> solo il bot col CLIENT_ID giusto agisce
        /scadenze                                  -> ogni bot risponde col proprio stato
    Tutti i bot sono admin dello stesso canale: chi non e' destinatario ignora."""
    msg = update.channel_post or update.effective_message
    if msg is None or not msg.text:
        return
    if not ADMIN_CHANNEL_ID or str(msg.chat_id) != str(ADMIN_CHANNEL_ID):
        return
    parts = msg.text.strip().split()
    if not parts:
        return
    cmd = parts[0].lstrip("/").split("@", 1)[0].lower()

    if cmd == "scadenze":
        st = stato_abbonamento(await carica_dati_async())
        await _invia_canale_admin(context.bot, _riga_scadenza(st))
        return

    if cmd == "rinnova":
        # serve almeno: /rinnova <slug> <arg>
        if len(parts) < 3 or not CLIENT_ID:
            return
        if parts[1].lower() != CLIENT_ID.lower():
            return  # comando destinato a un altro cliente/bot
        arg = parts[2]
        data_esatta = _parse_sub_date(arg)
        if data_esatta is not None:
            await modifica_dati_async(partial(modifier_rinnova_abbonamento, data_esatta=data_esatta))
        elif arg.isdigit() and int(arg) > 0:
            await modifica_dati_async(partial(modifier_rinnova_abbonamento, giorni=int(arg)))
        else:
            await _invia_canale_admin(
                context.bot,
                f"⚠️ {CLIENT_NOME}: argomento non valido. Usa i giorni (es. 30) "
                "oppure una data (AAAA-MM-GG).",
            )
            return
        st = stato_abbonamento(await carica_dati_async())
        await _invia_canale_admin(
            context.bot,
            f"✅ {CLIENT_NOME} rinnovato — nuova scadenza "
            f"{st['until'].strftime('%d/%m/%Y')} (tra {st['giorni']} giorni).",
        )
        return

    # Comandi console di flotta (/flotta, /aggiorna): delegati al modulo fleet.
    from .fleet import gestisci_comando_flotta   # lazy: fleet usa subscription
    await gestisci_comando_flotta(cmd, parts, context, _invia_canale_admin)

async def admin_channel_document_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Aggiornamento OTA via DOCUMENTO nel canale admin: si trascina lo zip del
    pacchetto nel canale con didascalia '/aggiorna <CLIENT_ID|tutti> [sha256]'.
    Nessun hosting esterno: i bot scaricano il file da Telegram stesso."""
    msg = update.channel_post or update.effective_message
    if msg is None or msg.document is None or not (msg.caption or "").strip():
        return
    if not ADMIN_CHANNEL_ID or str(msg.chat_id) != str(ADMIN_CHANNEL_ID):
        return
    parts = msg.caption.strip().split()
    cmd = parts[0].lstrip("/").split("@", 1)[0].lower()
    if cmd != "aggiorna":
        return
    from .fleet import esegui_ota_da_documento   # lazy: fleet usa subscription
    await esegui_ota_da_documento(context, msg.document, parts, _invia_canale_admin)

async def _controlla_e_avvisa_abbonamento(app: Application) -> None:
    """Un giro di avvisi di scadenza verso i due destinatari.

    Il cliente (owner del bot) riceve il preavviso a 7/3/1 giorni e poi un
    promemoria al giorno dalla scadenza in avanti; il canale admin riceve la
    riga gestionale con l'esito della consegna al cliente.
    """
    dati = await carica_dati_async()
    st = stato_abbonamento(dati)
    if not st["configurato"]:
        return
    giorni   = st["giorni"]
    oggi_iso = _oggi_locale().isoformat()
    scad_iso = st["until"].strftime(SUB_DATE_FMT)

    # Due regimi distinti:
    #  - PREAVVISO (7/3/1 giorni): una volta sola per fascia, e la fascia si
    #    chiude solo quando il cliente ha ricevuto davvero;
    #  - PROMEMORIA (dal giorno della scadenza in poi): tutti i giorni.
    if giorni > 0:
        soglia = _soglia_preavviso(giorni)
        if soglia is None:
            return                                    # ancora presto
        if _preavviso_gia_consegnato(dati, scad_iso, soglia):
            return
        cliente_da_fare = True
    else:
        soglia = None
        cliente_da_fare = dati.get("sub_last_client_day") != oggi_iso
    # Il canale admin resta a una riga al giorno: e' un promemoria gestionale,
    # non deve battere il ritmo dei tentativi verso il cliente.
    canale_da_fare = dati.get("sub_last_alert_day") != oggi_iso
    if not (cliente_da_fare or canale_da_fare):
        return

    # PRIMA il cliente, POI il canale: e' l'inversione che permette alla riga
    # gestionale di dichiarare l'esito vero della consegna invece del solo
    # tentativo. Entrambi gli invii sono best-effort e non sollevano mai.
    # Nota: nessun "if not ADMIN_CHANNEL_ID: return" — il cliente va avvisato
    # anche senza canale admin (l'abbonamento puo' arrivare dal solo SUB_UNTIL).
    consegnato: Optional[bool] = None
    if cliente_da_fare:
        testo_cliente = _riga_scadenza_cliente(st)
        if testo_cliente:
            # Pulsanti "Sì, ho rinnovato / Non ancora": aprono il flusso di
            # segnalazione pagamento (renew_conv) direttamente dall'avviso.
            consegnato = await notifica_owner(
                app, testo_cliente, reply_markup=_kb_alert_rinnovo(),
            )
    if canale_da_fare:
        await _invia_canale_admin(
            app.bot, _riga_scadenza(st) + _postilla_consegna(consegnato),
        )
    await modifica_dati_async(partial(
        modifier_esito_avviso_scadenza,
        oggi=oggi_iso, scadenza=scad_iso, soglia=soglia,
        consegnato=bool(consegnato), canale_inviato=canale_da_fare,
    ))

async def subscription_loop(app: Application):
    """Controllo periodico dell'abbonamento per gli avvisi al canale admin E al
    cliente (owner del bot).

    Quattro giri al giorno: il canale admin ne vede comunque uno solo, mentre
    un preavviso non consegnato viene ritentato a ogni giro finche' il cliente
    non e' raggiungibile. Un riavvio del bot fa ripartire il primo controllo
    subito, quindi un avviso in sospeso non aspetta le sei ore piene."""
    while True:
        try:
            await _controlla_e_avvisa_abbonamento(app)
        except Exception:
            logger.exception("Errore nel controllo abbonamento.")
        await asyncio.sleep(6 * 3600)
